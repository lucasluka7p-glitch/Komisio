# WhatsApp : dossiers, OCR et assistance

La version serveur Komisio ajoute un canal WhatsApp relié aux **comptes clients déjà créés par l’administrateur**. Le revendeur choisit une démarche par commande, transmet ses pièces, vérifie les suggestions de lecture automatique puis valide le dépôt. Les mêmes dossiers et les mêmes conditions tarifaires se retrouvent sur son espace Web / Telegram.

Le lien Sites public reste une démonstration statique. Il ne reçoit pas de webhooks Meta et ne crée pas d’accès WhatsApp réel. Aucun compte Meta, numéro, message ou paiement de production n’est raccordé par la livraison du code.

## Fonctionnement prévu pour le revendeur

1. L’administrateur associe son numéro WhatsApp au bon compte dans le panel. Le bot ne crée pas de compte à partir d’un nom, d’un pseudo ou d’un identifiant saisi dans la conversation.
2. Le revendeur envoie une commande telle que `/cg`, `/ww` ou `/fiche po`.
3. Il indique la catégorie de pièce attendue et transmet une photo ou un PDF. Le serveur vérifie le format, stocke le fichier dans le stockage privé puis traite la lecture OCR en arrière-plan.
4. Les informations suffisamment lisibles deviennent des **suggestions de brouillon**. Le bot demande les informations qui manquent ; le revendeur peut aussi corriger le brouillon depuis le site.
5. Le récapitulatif doit être relu avant validation. Les modifications de champs ou de pièces imposent une nouvelle vérification.
6. La validation crée la demande dans le compte associé. Une prestation sur devis reste en attente de proposition. Une prestation à prix fixe reste en attente de paiement : aucun solde n’est débité et aucune facture crypto n’est créée automatiquement par l’OCR.

Le titulaire d’une ancienne carte grise n’est pas automatiquement l’acquéreur. L’adresse de livraison et l’identité de l’acquéreur doivent être confirmées séparément. Une pièce peu lisible, une information contradictoire ou un champ absent conduit à une demande de correction, jamais à une valeur inventée.

## Commandes de démarches

| Commande | Prestation du catalogue |
| --- | --- |
| `/cg` | Changement de titulaire carte grise |
| `/cg sans ct` | Variante sans justificatif de CT joint, sous réserve de recevabilité |
| `/ww` | WW simple |
| `/ww mod`, `/ww modif`, `/ww modifier` | Modification de WW |
| `/fiche po`, `/fiche`, `/vehicule` | Situation administrative officielle du véhicule |
| `/recherche` | Demande personnelle d’accès à ses propres données |
| `/ecra` | Régularisation officielle de carte grise |
| `/leasing`, `/ecra leasing`, `/ecra leas`, `/ecraleas` | Mise à jour après fin / rachat autorisé du leasing |
| `/cession` | Déclaration de cession |
| `/da` | Déclaration d’achat |
| `/suisse` | Dédouanement suisse |
| `/creation` | Création de société |
| `/modification` | Modification de société |

Les commandes d’une démarche utilisent son service réel, ses formulaires, ses documents requis et la grille privée du client ; un intitulé abrégé n’autorise aucune prestation différente.

### Préparation et contrôle

- `/piece CLE` précise le type de la prochaine pièce. Exemple : `/piece registration_certificate`, puis la photo de la carte grise. Les clés disponibles figurent dans le récapitulatif du service.
- `/champ CLE=VALEUR` complète ou corrige un champ. Exemple : `/champ deliveryAddress=10 rue Exemple, 75001 Paris`.
- `/nom NOM` indique le nom du client final pour les services qui le demandent. Les services utilisant une identité structurée conservent leurs champs dédiés.
- `/voir` affiche le récapitulatif à contrôler et le tarif applicable.
- `/valider` dépose le dossier après le contrôle requis ; il ne constitue pas une instruction de paiement.
- `/annuler` abandonne le brouillon actif.
- `/aide` affiche l’aide et les commandes proposées par le bot.

Le parcours vise un seul dossier actif à la fois dans la conversation associée. Terminer ou annuler le brouillon avant de changer de démarche permet d’éviter le mélange des pièces de clients finaux différents.

## Choix du transport : application classique ou Cloud API

### Connecteur WhatsApp Web pour le numéro actuel

Le transport **WEB** utilise un processus séparé avec Chromium et `whatsapp-web.js`. Le propriétaire relie le compte depuis **Appareils connectés** en scannant le QR affiché dans l’interface administrateur. Il permet de recevoir les messages privés et les groupes classiques auxquels ce compte participe, sous réserve des capacités du client WhatsApp au moment de l’exécution.

Il s’agit d’un connecteur **non officiel**. WhatsApp peut modifier le fonctionnement de Web, déconnecter la session ou restreindre le compte ; la continuité ne peut pas être garantie. L’exploitant doit choisir ce mode en connaissance de ces limites. Le code ne contourne pas les restrictions du compte et ne remplace pas une autorisation de WhatsApp.

La session d’appareil connecté est privée et persistante. Elle ne doit jamais être ajoutée au dépôt, au ZIP du projet, à un stockage public ou accessible à un revendeur. Le QR est lui aussi réservé à l’administrateur : scanner un QR associe réellement le compte du téléphone. Aucun QR n’a été scanné et aucun compte réel n’a été relié pendant la livraison.

Le rattachement des revendeurs reste obligatoire, y compris en groupe : un groupe et son numéro expéditeur doivent correspondre à une association autorisée. Être membre d’un groupe ne donne pas accès à tous les comptes et dossiers du réseau.

### Cloud API comme alternative officielle

Le transport **CLOUD** utilise WhatsApp Business Platform / Cloud API, sans connexion par QR au téléphone. Il nécessite les identifiants Meta et un numéro éligible au service.

Les groupes officiels ont des conditions d’éligibilité propres à Meta, notamment le statut **Official Business Account**. La vérification de l’entreprise, un numéro WhatsApp Business ou l’accès aux messages privés ne prouvent pas à eux seuls cette éligibilité. Les groupes API et leurs invitations doivent être gérés selon les possibilités ouvertes sur le compte Meta ; il ne faut pas supposer que le bot officiel peut être ajouté à n’importe quel groupe existant créé dans l’application.

Le mode groupes Cloud reste désactivé par défaut. Après vérification de l’éligibilité et d’un véritable groupe API, l’administrateur peut autoriser le groupe et le numéro expéditeur pour le compte concerné. Les messages privés Cloud permettent d’utiliser le parcours sans dépendre de l’éligibilité aux groupes.

Références : [whatsapp-web.js](https://github.com/pedroslopez/whatsapp-web.js), [Groups API de Meta](https://developers.facebook.com/documentation/business-messaging/whatsapp/groups), [démarrage des groupes Meta](https://developers.facebook.com/documentation/business-messaging/whatsapp/groups/get-started).

## Coûts et hébergement

L’OCR fourni utilise des logiciels locaux libres et **aucune API de reconnaissance ou d’IA payante**. Le calcul d’estimation carte grise utilise également un barème local ; il ne fait pas appel à ChatGPT ni à un service payant.

Le connecteur WEB ne facture pas de messages via Cloud API, mais nécessite une machine allumée et une session valide. Pour le transport CLOUD, la messagerie est un service externe soumis à la tarification et aux quotas du compte Meta. Une fenêtre de réponse autorisée n’est pas une garantie de gratuité. Les règles et tarifs peuvent évoluer ; vérifier le tarif applicable dans le compte Meta et la [page officielle de tarification](https://developers.facebook.com/documentation/business-messaging/whatsapp/pricing) avant activation. Le code n’achète aucun abonnement et ne souscrit aucune offre payante.

L’hébergement consomme de la mémoire et du CPU pour lire les documents. Le Blueprint Render Node existant ne garantit pas la présence des outils OCR natifs. Utiliser la variante Docker ou un hôte où Tesseract et Poppler sont installés pour activer l’OCR. Un service gratuit mis en veille ne peut pas garantir le traitement immédiat des messages. Le connecteur WEB doit rester actif pour recevoir les nouveaux événements ; une reprise après déconnexion n’est pas une garantie de récupération complète de l’historique. Les files déjà enregistrées dans PostgreSQL reprennent lorsque le serveur se réveille. Il peut être hébergé sur une machine personnelle sans abonnement supplémentaire, à condition qu’elle reste allumée, connectée et suffisamment dimensionnée. Les limites d’hébergement restent décrites dans [FREE-HOSTING.md](./FREE-HOSTING.md).

## OCR local et limites

Le moteur repose sur **Tesseract** et les outils **Poppler**. Il doit être activé explicitement ; l’absence des exécutables ou d’une langue requise est signalée comme indisponibilité, sans résultat simulé.

Les pièces OCR sont limitées à 10 Mo, en PDF, JPEG ou PNG. Les photos doivent rester sous 20 mégapixels et 7 000 pixels par côté. Pour un PDF, seules les trois premières pages sont traitées automatiquement ; une alerte signale les pages supplémentaires. Le budget de lecture est de 35 secondes, avec des limites natives par processus sur la mémoire, le CPU et la taille des fichiers temporaires.

Les documents restent dans le stockage privé du serveur. Les fichiers de travail OCR utilisent un répertoire temporaire privé, supprimé après traitement. Les appels aux outils natifs passent par des arguments séparés, sans shell ; les tailles, les délais, la sortie texte et le nombre de pages sont bornés. Aucun texte lu dans un document ne peut déclencher une commande, modifier un tarif, fournir des instructions au serveur ou provoquer un paiement.

La lecture est volontairement conservatrice : immatriculation, VIN, numéro de formule, identité / adresse du titulaire, puissance fiscale et première mise en circulation sont proposés lorsque des libellés reconnus sont lisibles. Les champs d’identité personnelle dépendent du rôle de la pièce explicitement indiqué. Les informations ambiguës sont laissées à compléter. Le kilométrage, le motif d’une demande et d’autres renseignements non présents sur les pièces doivent être ajoutés par le revendeur.

La qualité dépend de la netteté, du cadrage, de l’orientation et du type de document. Ce moteur n’est ni une vérification d’authenticité des pièces ni une garantie de dossier complet. La validation et les contrôles du service choisi restent ceux de Komisio.

Références : [Tesseract](https://github.com/tesseract-ocr/tesseract), [documentation Tesseract](https://tesseract-ocr.github.io/tessdoc/), [Poppler](https://poppler.freedesktop.org/).

## Assistance depuis le site

Le bouton d’assistance ouvre une conversation WhatsApp avec le numéro professionnel configuré, avec un message prérempli. Il n’envoie aucun message à la place du visiteur. Aucun numéro fictif n’est utilisé si la configuration est absente.

Ne transmettre ni clé API, ni mot de passe, ni code de connexion dans la conversation d’assistance. Les pièces de dossier doivent suivre le parcours prévu afin de rester associées au bon client et au bon dossier.

## Mise en service

Préparer dans tous les cas un serveur Next / PostgreSQL accessible en HTTPS, le stockage privé, les associations numéro / client, puis un worker ou une tâche de reprise des files. Les outils natifs OCR sont nécessaires si la lecture automatique est activée.

### Transport WEB

Les variables serveur sont :

| Variable | Rôle |
| --- | --- |
| `WHATSAPP_TRANSPORT=WEB` | Sélection du connecteur pour le compte classique |
| `WHATSAPP_BRIDGE_URL` | Adresse interne du service de connexion WhatsApp |
| `WHATSAPP_BRIDGE_SECRET` | Secret distinct d’au moins 32 caractères, partagé seulement avec le connecteur |

Le connecteur s’exécute comme service séparé avec Chromium et un volume privé persistant pour `LocalAuth`. Son port ne doit pas être exposé publiquement sans protection. Le serveur reçoit les événements signés sur `/api/whatsapp/bridge` ; l’interface admin interroge l’état et le QR par `/api/admin/whatsapp/bridge`. Ces routes ne doivent pas être configurées comme webhook Cloud Meta.

Le serveur et le connecteur doivent pouvoir communiquer dans les deux sens. `http://whatsapp-bridge:…` fonctionne sur le même réseau Docker ; `localhost` désigne toujours la machine du processus qui l’utilise. Si l’application est sur Render et le connecteur sur un ordinateur personnel, une adresse accessible et protégée pour ce connecteur doit être fournie : le numéro de téléphone et le QR ne créent pas cette connectivité. Conserver le port sur un réseau privé lorsqu’application et connecteur partagent la même machine.

Le QR s’obtient uniquement après lancement du service et configuration des adresses et secrets. Le numéro d’assistance public peut être le même compte, mais le simple fait de renseigner ce numéro ne connecte pas le robot.

### Transport CLOUD

Préparer un compte WhatsApp Business Platform, une application Meta et le Business Phone Number ID ; stocker le jeton d’accès serveur, le secret de l’application et un jeton distinct de vérification du webhook dans les variables privées de l’hébergement. Autoriser les associations groupes uniquement si le compte est effectivement éligible.

Les secrets ne sont jamais à coller dans le code source, le dépôt Git, le panel client ou cette documentation. Le raccordement doit être vérifié avec un dossier fictif et le compte de l’exploitant avant de transmettre des documents réels. Les appels WhatsApp et la connexion du téléphone doivent être réalisés par l’exploitant sur son propre compte.

## Mise en route du mode numéro ordinaire

La procédure complète se trouve dans [whatsapp-bridge/README.md](./whatsapp-bridge/README.md). Sur une même machine Docker, ajouter `compose.whatsapp.yaml` au déploiement existant. Le service privé s’appelle `whatsapp`, avec `WHATSAPP_BRIDGE_URL=http://whatsapp:3104`. Le QR et la sélection des groupes sont accessibles dans **Admin → WhatsApp** après raccordement du serveur réel.

Les routes réelles sont `/api/whatsapp/bridge`, `/api/whatsapp/bridge/bindings`, `/api/whatsapp/webhook` (alternative Cloud), `/api/admin/whatsapp`, `/api/admin/whatsapp/bridge`, `/api/admin/whatsapp/groups` et `/api/whatsapp/drafts`. Les pièces de brouillon sont accessibles uniquement au propriétaire ou à l’admin sur `/api/whatsapp/drafts/ID/files/ID_PIECE`.

Le worker existant appelle les traitements WhatsApp avec la file de notifications. Il réclame un travail à la fois, conserve le résultat et traite les réponses séparément. Les réceptions sont dédupliquées par identifiant externe ; une nouvelle commande n’est pas autorisée à remplacer silencieusement un brouillon ouvert. L’ancienne photo d’un autre dossier n’est pas réutilisée : commencer par la commande, puis envoyer les documents.

Pour les pièces déjà reçues : `/classer 2 buyer_identity` classe la pièce numéro 2 comme identité de l’acquéreur. `/piece buyer_identity` annonce le type du prochain envoi et permet l’extraction avec le bon rôle. Après une question du bot, une réponse simple complète le champ explicitement demandé. `/voir` présente le récapitulatif ; `/valider` exige cette relecture et des données complètes. Un récapitulatif trop long n’est pas tronqué pour permettre la validation : il faut le vérifier dans l’espace sécurisé.

`/accepter NUMERO VERSION` et `/refuser NUMERO VERSION` répondent au devis proposé. `/payer NUMERO` demande explicitement une facture Plisio USDT TRC20 au prix enregistré dans le dossier ; aucune facture ne découle de l’OCR seul et aucun débit portefeuille n’est automatique. `/livrable NUMERO` envoie le livrable d’un dossier terminé dans la conversation WEB rattachée. Les changements de statut, devis et livrables sont également mis en file par les actions admin. En WEB, ils peuvent être envoyés au-delà de 24 h ; la fenêtre de 24 h ne concerne que le mode Cloud, sans modèle payant automatique.

Le rattachement WhatsApp est un accès indépendant accordé par l’admin à un compte actif et tarifé. Il permet de déposer par WhatsApp même si le mot de passe Web temporaire n’a pas encore été changé. La première connexion au site reste soumise au changement de ce mot de passe. La suspension du compte ou la désactivation du rattachement bloque ce canal.

Photos/PDF : maximum 10 Mo ; vidéos MP4/MOV : maximum 10 Mo via ce pont, sans OCR. `/ct` ouvre le contrôle technique ; les exigences de pièces du catalogue restent applicables. Le pont peut refuser une pièce dont la taille n’est pas vérifiable avant téléchargement. Une lecture peu fiable reste à compléter manuellement.

Les messages d’envoi au résultat inconnu sont signalés à l’admin et ne sont pas renvoyés automatiquement. Les reprises de ces cas nécessitent une vérification opérateur du journal et de la conversation ; le panneau ne propose pas de forçage aveugle.

## Box Simular et gratuité

La documentation officielle de [Box](https://box.simular.ai/docs/mcp) décrit un ordinateur cloud gratuit qui se met en veille lorsqu’il est inactif. Ce n’est pas une garantie d’hébergement WhatsApp 24 h/24. Les caractéristiques « 4 cœurs / 8 Go » du message partagé ne sont pas garanties dans les pages officielles consultées. Aucun compte Box n’a été créé ou raccordé ici.
