> Comptes clients et prix personnalisés ajoutés : voir [CLIENT-ACCESS.md](./CLIENT-ACCESS.md). `/api/auth/telegram` ne crée plus de revendeur ; `/api/auth/password` accepte uniquement les accès provisionnés. Les administrateurs restent reconnus par leur ID Telegram autorisé.

> **Fournisseur actuel : Plisio**, avec factures hébergées et API de retraits. Les détails qui suivent sur NOWPayments décrivent la compatibilité des anciennes factures. Configuration et recette actuelles : PLISIO.md et FREE-HOSTING.md.

# Backend V1 — Forma Partners

Le backend est une application Next.js Node.js avec Prisma/PostgreSQL. La prévisualisation statique utilise des données de démonstration dans le navigateur ; les routes ci-dessous nécessitent le déploiement Next.js et ses variables serveur. Aucun paiement ni message réel n’est déclenché par les tests.

## Démarrage

```sh
cp .env.example .env
npm install
npx prisma generate
npx prisma migrate deploy
npm run db:seed
npm run dev
```

Renseigner une vraie base PostgreSQL, `APP_URL` (origine publique HTTPS exacte), `MINI_APP_URL`, le token BotFather, la liste des IDs numériques administrateurs, deux secrets distincts de 32 caractères minimum pour `SESSION_SECRET` et `CRON_SECRET`, le secret du webhook Telegram et les clés NOWPayments. Le catalogue initial contient 29 services et leurs formulaires ; le seed préserve les modifications ultérieures des administrateurs. Aucun compte ou solde fictif n’est créé en production. Les variables privées ne portent jamais le préfixe `NEXT_PUBLIC_`.

Déployer avec `npm run build && npm start` sur un hébergement Node.js. Fournir un volume persistant privé pour `PRIVATE_UPLOAD_DIR`, sauvegarder ce volume avec la base et chiffrer les disques et sauvegardes. Le répertoire `.private/` doit être ignoré par Git et exclu des artefacts. Aucun document ne doit être déposé dans `public/`. La migration initiale ajoute des contraintes PostgreSQL sur les prix et soldes, en complément des validations applicatives.

## Telegram

Configurer l’URL HTTPS de la Mini App et le bouton de menu dans BotFather. Enregistrer le webhook Telegram sur `APP_URL/api/bot` avec son `secret_token` égal à `TELEGRAM_WEBHOOK_SECRET` via `setWebhook`. Les revendeurs et administrateurs doivent démarrer le bot en conversation privée pour recevoir ses notifications. La commande `/start` répond avec un bouton WebApp.

Le navigateur envoie les données **brutes** `Telegram.WebApp.initData` à `POST /api/auth/telegram` avec `{ "initData": "..." }`. Le serveur vérifie HMAC SHA-256, fraîcheur de 10 minutes, futur maximal de 30 secondes, paramètres uniques et identité. Il ne fait jamais confiance à `initDataUnsafe`. Réponse : `{user:{id,firstName,username,role,balanceCents}}`, accompagnée d’un cookie HttpOnly HMAC signé valable 24 heures. En production, `SameSite=None; Secure; Partitioned` permet l’intégration dans Telegram Web. La disponibilité des cookies dépend aussi du navigateur. Toutes les écritures authentifiées vérifient strictement l’en-tête `Origin` contre `APP_URL`. Le rôle administrateur est recalculé depuis `ADMIN_TELEGRAM_IDS` à chaque requête ; aucune promotion n’est possible via le navigateur ou un nom d’utilisateur Telegram.

`POST /api/auth/logout` efface le cookie. Pour les essais locaux, ouvrir `http://localhost:3000` avec `APP_URL` correspondant ; l’authentification réelle nécessite des initData Telegram valides.

## Contrats des API

Les réponses Prisma JSON utilisent des dates ISO, les prix et soldes sont des **centimes d’euro entiers**. Les montants crypto sont conservés en chaînes décimales. Les routes nécessitent une session sauf `/api/auth/telegram`, `/api/bot`, `/api/webhooks/nowpayments` et `/api/cron/notifications`, qui vérifient leurs propres signatures ou secrets. Les erreurs renvoient `{error:string,issues?:array}` et un code HTTP 4xx/5xx.

| Route                               | Contrat                                                                                                                               |
| ----------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| `GET /api/me`                       | `{user,ledger:LedgerEntry[],orders:[{status,_count}]}` ; 100 dernières lignes du journal                                              |
| `GET /api/catalog`                  | `Service[]` actifs                                                                                                                    |
| `GET /api/orders`                   | `Order[]` du revendeur, 200 derniers, incluant service, documents et événements                                                       |
| `POST /api/orders`                  | `{serviceId,customerName,customerEmail?,fields,documentIds,paymentMethod:"WALLET"\|"CRYPTO",idempotencyKey:UUID}` ; réponse `{order}` |
| `GET /api/orders/:id`               | Dossier complet accessible au propriétaire et à l’admin                                                                               |
| `PATCH /api/orders/:id`             | `{note}` : réponse du revendeur, historisée et notifiée à l’admin                                                                     |
| `POST /api/orders/:id/pay`          | Payer un dossier existant avec le portefeuille ; réponse `Order`                                                                      |
| `POST /api/documents`               | Multipart `{file,serviceId,fieldKey,orderId?,kind?:"ATTACHMENT"\|"DELIVERABLE"}`                                                      |
| `GET /api/documents/:id`            | Téléchargement privé propriétaire/admin, forcé comme pièce jointe                                                                     |
| `POST /api/payments`                | `{amountCents,payCurrency,idempotencyKey:UUID,orderId?}` ; réponse `Payment`                                                          |
| `GET /api/payments/:id`             | `Payment` après réconciliation avec la passerelle ; accessible propriétaire/admin                                                     |
| `POST /api/webhooks/nowpayments`    | Corps JSON signé et en-tête `x-nowpayments-sig`                                                                                       |
| `GET/POST /api/admin/services`      | Lire/créer des services                                                                                                               |
| `PATCH /api/admin/services/:id`     | Modifier tout ou partie d’un service ; validation après fusion                                                                        |
| `GET /api/admin/orders`             | 500 derniers dossiers incluant revendeur, documents et événements                                                                     |
| `PATCH /api/admin/orders/:id`       | `{status,note?,deliverableId?}` ; réponse dossier                                                                                     |
| `GET /api/admin/users`              | 500 derniers utilisateurs, `_count.orders`, 50 lignes de journal, montants/statuts des commandes                                      |
| `POST /api/admin/users/:id/balance` | `{amountCents:signedInteger,reason,idempotencyKey:UUID}` ; réponse `{user,entry}`                                                     |
| `GET /api/admin/payments`           | 500 derniers paiements crypto incluant les identifiants du revendeur                                                                  |
| `POST /api/cron/notifications`      | `Authorization: Bearer CRON_SECRET` ; résultat `{configured,sent,failed}`                                                             |

`Service` : `{id,slug,name,description,category,priceCents,turnaround,active,fields,requiredDocuments}`. Catégories : `FORMALITES`, `AUTOMOBILE`, `ASSISTANCE`. `fields` contient `{key,label,type,required,options?}` ; types acceptés `text`, `email`, `date`, `textarea`, `select`. `requiredDocuments` contient `{key,label,required}`. Le seed utilise `doc_0`, `doc_1`, etc. Le frontend doit conserver les clés exactes du service pour les uploads. Les définitions de formulaire et le prix sont figés dans chaque commande.

`Order` : `{id,number,userId,serviceId,serviceName,priceCents,customerName,customerEmail,fields,formSnapshot,status,paidAt,createdAt,documents,events}`. Un document exposé par l’API contient `{id,fileName,mimeType,bytes,fieldKey,kind,createdAt}`, jamais sa clé de stockage. Les pièces envoyées avant création du dossier appartiennent au revendeur et ne peuvent être liées qu’à son propre dossier et au service correspondant. Les pièces complémentaires utilisent `orderId`. PDF, PNG et JPEG identifiés par signature binaire et limités à 10 Mo. Les définitions de pièces acceptent un type `video` : MP4/MOV, conteneur vérifié, 25 Mo maximum. Un fichier vidéo est refusé dans les champs document et inversement. Les formulaires multipart sont bornés avant parsing, même sans Content-Length.

`Payment` : `{id,userId,orderId?,providerPaymentId?,amountCents,payCurrency,payAmount?,payAddress?,status,providerStatus?,expiresAt?,confirmedAt?,createdAt}`. `payCurrency` : `usdttrc20`, `usdterc20`, `btc`, `eth`, `sol`. Statuts : `CREATING`, `WAITING`, `CONFIRMED`, `EXPIRED`, `FAILED`. Le frontend affiche le QR code de `payAddress` et interroge la route de paiement pour le suivi. L’activation réelle des monnaies et les minimums dépendent du compte NOWPayments ; vérifier ces paramètres avant ouverture.

## Parcours commande et paiements

1. Charger le catalogue authentifié, remplir les champs et envoyer les pièces requises.
2. Créer la commande avec une clé UUID d’idempotence stable pour cette soumission. Le prix vient exclusivement de la base.
3. `WALLET` débite le portefeuille et passe le dossier en traitement dans une transaction PostgreSQL sérialisable ; solde insuffisant : 409, aucune commande ni débit partiel. `CRYPTO` crée un dossier en attente.
4. Pour le règlement crypto direct, créer un paiement avec `orderId` ; le serveur reprend le montant de la commande. Pour une recharge, omettre `orderId`, minimum 10 €.
5. NOWPayments reçoit `price_currency=eur`, `order_id=Payment.id` et l’URL du webhook. Le taux fixe et les frais à charge du payeur sont demandés.
6. Le webhook vérifie la signature SHA-512 de la représentation JSON triée récursivement, puis interroge NOWPayments avec la clé serveur. Le crédit n’est accordé qu’au statut final `finished`, après vérification des identifiants, devises, prix EUR et montant crypto reçu. Le statut `confirmed` du fournisseur n’est pas encore final.
7. La mise à jour de paiement, le journal et le crédit/statut sont atomiques et protégés contre les doubles notifications et courses concurrentes. Une réponse fournisseur ancienne ne peut pas faire régresser un paiement déjà confirmé. Un paiement tardif sur un dossier annulé ou déjà payé est crédité au portefeuille.

Un POST fournisseur ayant expiré peut avoir créé une facture à distance. Le paiement local reste `CREATING` et le serveur ne répète pas automatiquement ce POST. La vue d’ensemble admin permet désormais de retrouver les factures bloquées et de rattacher un `payment_id` via `POST /api/admin/payments/:id/link`. La référence marchande, le prix EUR, la devise et le montant crypto sont vérifiés auprès de NOWPayments avant rattachement audité, puis le règlement suit la réconciliation habituelle. Un rattachement ne peut pas créditer deux fois le portefeuille.

Une annulation d’une commande payée recrédite le montant en euros sur le portefeuille interne et crée une ligne de remboursement ; elle ne déclenche pas d’envoi crypto externe. Les clôtures sont définitives. Un dossier en attente de paiement ne peut pas être passé manuellement en traitement. `ACTION_REQUIRED` exige une note et `COMPLETED` un livrable privé déjà envoyé. Le journal des écritures financières et les modifications administratives sont conservés séparément dans `LedgerEntry` et `AuditLog`.

## Notifications et exploitation

Chaque événement crée une notification dans la même transaction que le changement métier. `after()` de Next.js l’envoie après la réponse HTTP. Programmer aussi un POST protégé à `/api/cron/notifications` chaque minute pour reprendre les échecs. La file utilise un verrou atomique, une reprise après verrou bloqué, un délai exponentiel et dix essais maximum. Surveiller les lignes non envoyées après dix essais. La livraison Telegram est au moins une fois : une panne après envoi mais avant acquittement peut produire un doublon. Les messages sont en texte brut et n’incluent aucune pièce KYC ni donnée détaillée du client final.

Avant utilisation avec des données réelles : configurer sauvegardes/restauration, conservation et purge des KYC, supervision de la file et des paiements `CREATING`, limitation de débit au reverse proxy et analyse antivirus des fichiers selon les besoins de l’exploitant. Les fichiers temporaires non liés ont une limite de 100 par utilisateur ; prévoir une purge d’exploitation avec délai de conservation documenté. Les listes V1 ont des limites fixes (200/500) ; ajouter une pagination pour un volume supérieur.

## Vérifications réalisées

La recette complète est consignée dans [VERIFICATION.md](./VERIFICATION.md). Les 99 tests de `npm run test:integration` passent sans suite ignorée, sur des bases PostgreSQL jetables. Le serveur Next est testé par HTTP avec des simulateurs locaux des fournisseurs. L’application Node de production démarre avec la base et le stockage privé. Les comptes Telegram/Plisio et les transferts réels ne sont pas raccordés pendant cette recette.

## Retraits

La migration `20261021010000_withdrawals` ajoute les demandes de retrait et les mouvements de réservation/libération du solde. Procédure, contrats API et activation : [WITHDRAWALS.md](./WITHDRAWALS.md). Envoi manuel en V1 ; aucune API de payout automatique n’est actuellement connectée.

Le champ nullable `Service.subcategory` classe les prestations sous leur catégorie principale. L’API catalogue admin valide la cohérence de cette sélection. Les pièces peuvent être de type `image` (JPEG/PNG uniquement), `document` (PDF/JPEG/PNG) ou `video` (MP4/MOV). Les demandes WW utilisent deux champs image obligatoires et l’adresse postale du titulaire, avec tarifs initiaux 50 € / 80 €. CEDEO est sur devis ; les anciennes commandes conservent leur tarif.


## Finalisation et déploiement

Consultez DEPLOYMENT.md pour les fichiers Docker/Compose, le volume privé, PostgreSQL, HTTPS, la vérification de configuration et le raccordement BotFather. `/api/health` donne un état public minimal (200/503) ; `/api/config` fournit uniquement le lien public du bot. `/api/admin/operations` affiche les problèmes de configuration, les notifications en attente/épuisées et les factures non synchronisées ; son POST relance les notifications épuisées avec journal d’audit. L’envoi en arrière-plan est doublé d’un worker de reprise toutes les 30 secondes.

La suite `npm run test:integration` utilise un PostgreSQL jetable et de vrais échanges HTTP avec Next, en remplaçant les services externes par des simulateurs locaux. Elle vérifie notamment les accès aux documents, les livrables, le règlement portefeuille, les devis, le webhook crypto, la récupération d’une facture ambiguë, les retraits manuels et la file Telegram. Elle n’active aucun compte externe et ne déplace aucun fonds réel.
