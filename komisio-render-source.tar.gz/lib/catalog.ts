export type Category = "formalites" | "automobile" | "assistance";
export type Service = {
  id: string;
  slug?: string;
  documentKeys?: string[];
  documentRequired?: boolean[];
  documentTypes?: ("document" | "image" | "video")[];
  subcategory?: string | null;
  catalogVersion?: number;
  offerVersion?: number;
  pricing?: import("./pricing").PricingSnapshot;
  pricingRevision?: number;
  catalogUpdatedAt?: string;
  formVersion?: number;
  title: string;
  description: string;
  category: Category;
  price: number;
  requiresQuote?: boolean;
  delay: string;
  icon: string;
  popular?: boolean;
  active: boolean;
  documents: string[];
  fields: {
    key: string;
    label: string;
    type?: string;
    options?: string[];
    required: boolean;
  }[];
};
export type OrderStatus =
  | "AWAITING_QUOTE"
  | "QUOTE_PROPOSED"
  | "QUOTE_REJECTED"
  | "AWAITING_PAYMENT"
  | "PROCESSING"
  | "ACTION_REQUIRED"
  | "COMPLETED"
  | "CANCELLED";
export type Attachment = {
  id: string;
  name: string;
  fieldKey: string;
  data?: string;
  type?: string;
};
export type Order = {
  id: string;
  reference: string;
  serviceId: string;
  serviceTitle: string;
  customerName: string;
  customerEmail?: string;
  amount: number;
  requiresQuote?: boolean;
  quoteVersion?: number;
  pricingSnapshot?: import("./pricing").PricingSnapshot | null;
  quoteReferenceCents?: number | null;
  quoteAcceptedAt?: string | null;
  originalDocument?: import("./original-document").OriginalDocument | null;
  status: OrderStatus;
  createdAt: string;
  documents: Attachment[];
  fields: Record<string, string>;
  note?: string;
  deliverable?: Attachment;
  userName?: string;
  userId?: string;
  documentDefinitions?: { key: string; label: string; required: boolean; type?: "document" | "image" | "video" }[];
};
export type Transaction = {
  id: string;
  label: string;
  amount: number;
  date: string;
  status: "CONFIRMED" | "PENDING" | "EXPIRED";
  currency: string;
};
export const categories = [
  { id: "all", label: "Tous les services" },
  { id: "formalites", label: "Comptabilité & formalités" },
  { id: "automobile", label: "Démarches automobiles" },
  { id: "assistance", label: "Assistance administrative" },
];
const companyFields = [
  { key: "company", label: "Dénomination de la société", required: true },
  { key: "legalForm", label: "Forme juridique", required: true },
  { key: "address", label: "Adresse du siège social", required: true },
];
const vehicleFields = [
  { key: "registration", label: "Immatriculation du véhicule", required: true },
  { key: "vin", label: "Numéro de série (VIN)", required: true },
];
const transferFields: Service["fields"] = [
      { key: "registration", label: "Plaque d’immatriculation", required: true },
      { key: "vin", label: "Numéro VIN", required: true },
      { key: "formulaNumber", label: "Numéro de formule", required: true },
      { key: "holderIdentity", label: "Identité du titulaire", required: true },
      { key: "buyerLastName", label: "Nom de l’acquéreur", required: true },
      { key: "buyerFirstName", label: "Prénom de l’acquéreur", required: true },
      { key: "buyerBirthPlace", label: "Lieu de naissance de l’acquéreur", required: true },
      { key: "buyerBirthDate", label: "Date de naissance de l’acquéreur", type: "date", required: true },
      { key: "deliveryAddress", label: "Adresse de livraison complète", type: "textarea", required: true },
    ];
const baseServices: Service[] = [
  {
    id: "creation",
    title: "Création de société",
    description:
      "SAS, SASU, SARL, EURL… De votre projet à votre immatriculation, nous nous occupons de tout.",
    category: "formalites",
    price: 140000,
    delay: "48 à 72 h",
    icon: "building",
    popular: true,
    active: true,
    documents: [
      "Pièce d’identité du dirigeant",
      "Justificatif de domiciliation",
      "Projet de statuts",
    ],
    fields: companyFields,
  },
  {
    id: "modification",
    title: "Modification statutaire",
    description:
      "Changement de dirigeant, transfert de siège ou modification de l’objet social en toute simplicité.",
    category: "formalites",
    price: 65000,
    delay: "48 à 72 h",
    icon: "file-pen",
    active: true,
    documents: ["Kbis de moins de 3 mois", "Procès-verbal de décision"],
    fields: companyFields,
  },
  {
    id: "comptes",
    title: "Dépôt des comptes annuels",
    description:
      "Confiez-nous le dépôt de vos comptes au greffe et respectez vos obligations annuelles.",
    category: "formalites",
    price: 7900,
    delay: "24 à 48 h",
    icon: "chart",
    active: true,
    documents: ["Comptes annuels signés", "Procès-verbal d’approbation"],
    fields: companyFields,
  },
  {
    id: "carte-grise",
    title: "Changement de titulaire carte grise",
    description:
      "Un nouveau véhicule ? Nous réalisons le changement de titulaire de votre carte grise.",
    category: "automobile",
    price: 0,
    requiresQuote: true,
    delay: "24 à 48 h",
    icon: "car",
    popular: true,
    active: true,
    formVersion: 5,
    documents: ["Carte grise", "Pièce d’identité de l’acquéreur", "Cession de vente"],
    documentRequired: [false, false, false],
    documentKeys: ["registration_certificate", "buyer_identity", "sale_certificate"],
    fields: transferFields,
  },
  {
    id: "carte-grise-sans-ct",
    title: "Changement de titulaire — sans justificatif de contrôle technique joint",
    description: "Dépôt d’un dossier sans document de contrôle technique joint, uniquement lorsque les conditions réglementaires du véhicule le permettent. Une dispense de pièce ne dispense pas d’un contrôle légalement obligatoire. Prix proposé après étude du dossier.",
    category: "automobile", price: 0, requiresQuote: true, delay: "24 à 48 h", icon: "car", active: true, formVersion: 2,
    documents: ["Carte grise", "Pièce d’identité de l’acquéreur", "Cession de vente"],
    documentKeys: ["registration_certificate", "buyer_identity", "sale_certificate"],
    documentRequired: [false, false, false], fields: transferFields,
  },
  {
    id: "ww",
    title: "WW simple — certificat provisoire",
    description:
      "Obtenez votre immatriculation provisoire pour circuler avec un véhicule importé.",
    category: "automobile",
    price: 8000,
    delay: "24 à 48 h",
    icon: "card",
    active: true,
    formVersion: 2,
    documents: ["Photo de la carte grise", "Photo de la pièce d’identité du titulaire"],
    documentTypes: ["image", "image"],
    documentKeys: ["registration_certificate", "holder_identity"],
    fields: [
      { key: "holderAddress", label: "Adresse postale complète du titulaire", type: "textarea", required: true },
    ],
  },
  {
    id: "assistance",
    title: "Constitution de dossier",
    description:
      "Un accompagnement sur mesure pour préparer et vérifier vos dossiers administratifs.",
    category: "assistance",
    price: 4900,
    delay: "24 à 48 h",
    icon: "folder",
    active: true,
    documents: ["Pièce d’identité", "Justificatifs du dossier"],
    fields: [
      { key: "request", label: "Décrivez votre démarche", required: true },
    ],
  },
  {
    id: "sommeil",
    title: "Mise en sommeil / Reprise",
    description:
      "Suspendez ou relancez l’activité de votre société avec un dossier complet.",
    category: "formalites",
    price: 8900,
    delay: "48 à 72 h",
    icon: "building",
    active: true,
    documents: ["Kbis de moins de 3 mois", "Décision de l’associé"],
    fields: companyFields,
  },
  {
    id: "rne",
    title: "Correction RNE",
    description:
      "Faites rectifier les informations de votre entreprise au Registre national des entreprises.",
    category: "formalites",
    price: 6900,
    delay: "3 à 5 jours",
    icon: "file-pen",
    active: true,
    documents: ["Extrait RNE", "Justificatif de correction"],
    fields: companyFields,
  },
  {
    id: "cessation",
    title: "Cessation d’activité",
    description:
      "Toutes les formalités nécessaires pour clôturer votre activité sereinement.",
    category: "formalites",
    price: 12900,
    delay: "3 à 5 jours",
    icon: "folder",
    active: true,
    documents: ["Kbis", "Décision de cessation"],
    fields: companyFields,
  },
  {
    id: "regularisation",
    title: "Régularisation de société",
    description:
      "Mettez votre dossier à jour et retrouvez une situation administrative conforme.",
    category: "formalites",
    price: 11900,
    delay: "3 à 5 jours",
    icon: "file-pen",
    active: true,
    documents: ["Extrait RNE", "Documents à régulariser"],
    fields: companyFields,
  },
  {
    id: "achat",
    title: "Déclaration d’achat",
    description:
      "Enregistrez l’achat de vos véhicules professionnels auprès du SIV.",
    category: "automobile",
    price: 4000,
    delay: "Sous 24 h",
    icon: "car",
    active: true,
    documents: ["Certificat de cession", "Kbis du professionnel"],
    fields: vehicleFields,
  },
  {
    id: "douane",
    title: "Dédouanement légal",
    description:
      "Un accompagnement dans les formalités douanières de vos véhicules importés.",
    category: "automobile",
    price: 9900,
    delay: "3 à 5 jours",
    icon: "card",
    active: true,
    documents: ["Facture du véhicule", "Titre de circulation étranger"],
    fields: vehicleFields,
  },
  {
    id: "rdv",
    title: "Accompagnement & rendez-vous",
    description:
      "Préparez vos démarches et vos rendez-vous en préfecture ou en auto-école.",
    category: "assistance",
    price: 3500,
    delay: "24 à 48 h",
    icon: "folder",
    active: true,
    documents: ["Pièce d’identité"],
    fields: [
      {
        key: "request",
        label: "Votre demande et vos disponibilités",
        required: true,
      },
    ],
  },
  {
    id: "douane-suisse",
    title: "Dédouanement suisse",
    description: "Envoyez une photo de la carte grise et le kilométrage pour recevoir un devis. Après votre accord, nous fixons un rendez-vous pour récupérer la carte grise originale. Elle vous est restituée une fois la démarche effectuée. Droits, taxes et frais externes précisés dans le devis.",
    category: "automobile",
    price: 0,
    requiresQuote: true,
    delay: "Sur devis et rendez-vous",
    icon: "card",
    active: true,
    formVersion: 1,
    documents: ["Photo de la carte grise"],
    documentKeys: ["registration_certificate"],
    documentTypes: ["image"],
    documentRequired: [true],
    fields: [{ key: "mileage", label: "Kilométrage du véhicule", type: "number", required: true }],
  },
  {
    id: "code-route",
    title: "Inscription au code de la route",
    description:
      "Assistance à l’inscription à l’examen du code auprès d’un organisme agréé. La prestation ne garantit ni résultat ni réussite à l’examen. Frais de service hors frais d’examen.",
    category: "assistance",
    price: 3900,
    delay: "Selon la démarche",
    icon: "folder",
    active: true,
    documents: ["Pièce d’identité du candidat", "Attestation du numéro NEPH"],
    fields: [
      { key: "neph", label: "Numéro NEPH", required: true },
      {
        key: "trainingMode",
        label: "Modalité d’inscription",
        type: "select",
        options: ["Candidat libre", "Via une auto-école"],
        required: true,
      },
      {
        key: "examCity",
        label: "Ville souhaitée pour l’examen",
        required: true,
      },
    ],
  },
  {
    id: "examen-permis",
    title: "Réservation d’examen du permis",
    description:
      "Aide à la réservation sur les plateformes officielles, selon les créneaux disponibles et l’éligibilité du candidat, sans garantie de date ni de réussite. Frais de service hors formation et frais externes.",
    category: "assistance",
    price: 4900,
    delay: "Selon la démarche",
    icon: "folder",
    active: true,
    documents: ["Pièce d’identité du candidat", "Attestation du numéro NEPH"],
    fields: [
      { key: "neph", label: "Numéro NEPH", required: true },
      {
        key: "licenceCategory",
        label: "Catégorie de permis",
        type: "select",
        options: ["B", "A1", "A2", "Autre catégorie"],
        required: true,
      },
      {
        key: "availability",
        label: "Centre souhaité et disponibilités",
        type: "textarea",
        required: true,
      },
    ],
  },
  {
    id: "titre-sejour",
    title: "Dossier de titre de séjour",
    description:
      "Assistance à la préparation et au dépôt du dossier auprès de l’autorité compétente. La décision et les délais relèvent exclusivement de l’administration. Frais de service hors taxes et timbres fiscaux.",
    category: "assistance",
    price: 12900,
    delay: "Selon la démarche",
    icon: "folder",
    active: true,
    documents: [
      "Document d’identité du demandeur",
      "Justificatif de domicile",
      "Justificatifs correspondant au type de demande",
    ],
    fields: [
      {
        key: "applicationType",
        label: "Type de demande",
        type: "select",
        options: [
          "Première demande",
          "Renouvellement",
          "Changement de situation",
        ],
        required: true,
      },
      {
        key: "prefecture",
        label: "Préfecture ou autorité compétente",
        required: true,
      },
    ],
  },
  {
    id: "cedeo-pro",
    title: "CEDEO — remise professionnelle de 40 %",
    description:
      "Accompagnement à l’application de la remise professionnelle de 40 % selon votre accord commercial CEDEO et ses conditions. Frais de service hors achats.",
    category: "assistance",
    price: 0,
    requiresQuote: true,
    delay: "24 à 48 h",
    icon: "folder",
    active: true,
    documents: ["Devis CEDEO", "Mandat du client professionnel"],
    fields: [
      { key: "quoteRef", label: "Référence du devis CEDEO", required: true },
      {
        key: "cartAmount",
        label: "Montant du devis avant remise (€)",
        required: true,
      },
    ],
  },
  {
    id: "controle-convoyage",
    title: "Contrôle technique avec convoyage",
    description:
      "Organisation du contrôle avec véhicule obligatoirement présenté dans un centre agréé, même si le client est absent. Frais de coordination hors contrôle et transport, chiffrés séparément.",
    category: "automobile",
    price: 18000,
    delay: "24 à 48 h",
    icon: "car",
    active: true,
    formVersion: 1,
    documents: ["Carte grise", "Vidéo du véhicule"],
    documentKeys: ["registration_certificate", "vehicle_video"],
    documentRequired: [true, true], documentTypes: ["document", "video"],
    fields: [{ key: "mileage", label: "Kilométrage du véhicule", type: "number", required: true }],
  },
  {
    id: "remboursement-pare-brise",
    title: "Dossier de remboursement pare-brise",
    description:
      "Assistance à une demande fondée sur un sinistre réel et des dépenses justifiées, selon le contrat. La décision appartient à l’assureur, sans remboursement garanti. Tarif de l’accompagnement.",
    category: "assistance",
    price: 4900,
    delay: "Selon la démarche",
    icon: "folder",
    active: true,
    documents: [
      "Facture de réparation ou de remplacement",
      "Justificatif de déclaration du sinistre",
      "Garantie applicable du contrat d’assurance",
    ],
    fields: [
      { key: "insurer", label: "Assureur concerné", required: true },
      { key: "claimReference", label: "Référence du sinistre", required: true },
      {
        key: "registration",
        label: "Immatriculation du véhicule",
        required: true,
      },
    ],
  },
  {
    id: "remboursement-ameli",
    title: "Dossier de remboursement Ameli",
    description:
      "Aide à constituer une demande pour des soins réels et des dépenses justifiées auprès de la CPAM. La caisse décide de la prise en charge. Accompagnement sur devis, délai indicatif de 15 jours ; le délai de remboursement dépend de la CPAM. Sans collecte des identifiants ni du mot de passe Ameli.",
    category: "assistance",
    price: 0,
    requiresQuote: true,
    delay: "15 jours",
    icon: "folder",
    active: true,
    formVersion: 1,
    documents: ["Attestation de droits Ameli"], documentKeys: ["rights_certificate"], documentRequired: [true],
    fields: [],
  },
  {
    id: "acces-donnees-personnelles",
    title: "Données de police — demande d’accès personnelle",
    description:
      "Accompagnement aux demandes officielles d’accès ou de rectification portant uniquement sur les propres données du demandeur. Aucun accès direct aux fichiers ni recherche sur un tiers. Préparation de la demande sous 24 à 48 h à titre indicatif ; le délai de réponse de l’autorité reste distinct. Tarif de l’assistance.",
    category: "assistance",
    price: 20000,
    delay: "24 à 48 h · préparation",
    icon: "folder",
    active: true,
    formVersion: 1,
    documents: [],
    fields: [
      { key: "lastName", label: "Nom du demandeur concerné", required: true },
      { key: "firstName", label: "Prénom du demandeur concerné", required: true },
      { key: "birthDate", label: "Date de naissance du demandeur concerné", type: "date", required: true },
    ],
  },
  {
    id: "situation-vehicule",
    title: "Véhicule — certificat de situation administrative",
    description:
      "Aide à obtenir le certificat officiel de situation administrative du véhicule pour son propriétaire ou son mandataire autorisé. Aucun accès aux fichiers de police. Préparation de la demande sous 24 à 48 h à titre indicatif ; le délai de réponse de l’autorité reste distinct. Tarif de l’accompagnement.",
    category: "automobile",
    price: 5000,
    delay: "24 à 48 h · préparation",
    icon: "car",
    active: true,
    formVersion: 1,
    documents: [],
    fields: [{ key: "registration", label: "Plaque d’immatriculation", required: true }],
  },
  {
    id: "fin-leasing",
    title: "Fin de leasing / mise à jour carte grise",
    description:
      "Démarches officielles après rachat effectif du véhicule ou accord du bailleur, avec justificatifs de cession et d’autorisation. Frais de service hors rachat, taxes et frais d’immatriculation.",
    category: "automobile",
    price: 17000,
    delay: "Selon la démarche",
    icon: "car",
    active: true,
    documents: [
      "Accord de cession ou autorisation du bailleur",
      "Preuve du rachat ou certificat de cession",
      "Carte grise du véhicule",
    ],
    fields: [
      ...vehicleFields,
      {
        key: "lessorName",
        label: "Nom du bailleur ou organisme de leasing",
        required: true,
      },
      {
        key: "transferDate",
        label: "Date de rachat ou de cession autorisée",
        type: "date",
        required: true,
      },
    ],
  },
  {
    id: "ww-modification",
    title: "Modification d’un dossier WW",
    description:
      "Assistance à la rectification officielle d’un dossier d’immatriculation provisoire WW sur présentation de justificatifs valides. Frais de service hors taxes et frais administratifs éventuels.",
    category: "automobile",
    price: 10000,
    delay: "24 à 48 h",
    icon: "card",
    active: true,
    formVersion: 2,
    documents: ["Photo de la carte grise", "Photo de la pièce d’identité du titulaire"],
    documentTypes: ["image", "image"],
    documentKeys: ["registration_certificate", "holder_identity"],
    fields: [
      { key: "holderAddress", label: "Adresse postale complète du titulaire", type: "textarea", required: true },
    ],
  },
  {
    id: "levee-procedure",
    title: "Levée de procédure VE / VEI / RSV",
    description:
      "Accompagnement à la levée officielle après réparations, rapport favorable de l’expert et validation administrative requise. Frais de service hors réparations, expertise et frais externes.",
    category: "automobile",
    price: 19900,
    delay: "Selon la démarche",
    icon: "car",
    active: true,
    documents: [
      "Rapport d’expertise favorable après réparations",
      "Justificatifs de remise en conformité",
      "Notification de procédure ou décision administrative",
    ],
    fields: [
      ...vehicleFields,
      {
        key: "procedureType",
        label: "Procédure concernée",
        type: "select",
        options: ["VE", "VEI", "RSV"],
        required: true,
      },
      {
        key: "expertReference",
        label: "Référence du rapport de l’expert",
        required: true,
      },
    ],
  },
  {
    id: "levee-saisie",
    title: "Mainlevée d’opposition ou de saisie",
    description:
      "Constitution du dossier après régularisation et décision de mainlevée émise par l’autorité ou le créancier compétent. Frais de service hors dettes, frais judiciaires et frais externes.",
    category: "automobile",
    price: 12900,
    delay: "Selon la démarche",
    icon: "card",
    active: true,
    documents: [
      "Décision de mainlevée de l’autorité ou du créancier",
      "Justificatif de régularisation",
      "Carte grise du véhicule",
    ],
    fields: [
      ...vehicleFields,
      {
        key: "authority",
        label: "Autorité ou créancier ayant autorisé la mainlevée",
        required: true,
      },
      {
        key: "decisionReference",
        label: "Référence de la décision de mainlevée",
        required: true,
      },
    ],
  },
  {
    id: "levee-immobilisation",
    title: "Levée d’immobilisation",
    description:
      "Aide aux démarches de levée après remise en conformité justifiée et autorisation de l’autorité compétente. Frais de service hors réparations, contrôles et autres frais externes.",
    category: "automobile",
    price: 9900,
    delay: "Selon la démarche",
    icon: "car",
    active: true,
    documents: [
      "Avis ou fiche d’immobilisation",
      "Justificatifs de remise en conformité",
      "Autorisation de levée de l’autorité compétente",
    ],
    fields: [
      ...vehicleFields,
      {
        key: "authority",
        label: "Autorité ayant autorisé la levée",
        required: true,
      },
      {
        key: "noticeReference",
        label: "Référence de l’avis d’immobilisation",
        required: true,
      },
    ],
  },
  {
    id: "regularisation-carte-grise",
    title: "Régularisation de carte grise",
    description: "Correction ou régularisation officielle d’un dossier d’immatriculation sur justificatifs de propriété et mandat. Accompagnement à la régularisation du dossier. Hors taxes et frais administratifs.",
    category: "automobile", price: 10000, requiresQuote: false, delay: "Après étude du dossier", icon: "car", active: true,
    documents: ["Carte grise ou justificatif du dossier d’immatriculation", "Justificatif de propriété ou certificat de cession", "Mandat du titulaire"],
    fields: [...vehicleFields, { key: "requestReason", label: "Situation à régulariser", type: "textarea", required: true }],
  },
  {
    id: "homologation",
    title: "Homologation de véhicule",
    description: "Accompagnement à la constitution d’un dossier de conformité ou de réception auprès des organismes compétents. Les vérifications et décisions relèvent de ces organismes. Devis selon le véhicule, hors essais, taxes et frais externes.",
    category: "automobile", price: 0, requiresQuote: true, delay: "Selon le véhicule et l’organisme", icon: "car", active: true,
    documents: ["Carte grise étrangère ou document d’origine", "Certificat de conformité (si disponible)", "Documents techniques du véhicule (si disponibles)"],
    documentRequired: [true, false, false],
    fields: [
      { key: "vin", label: "Numéro VIN", required: true },
      { key: "vehicleModel", label: "Marque et modèle du véhicule", required: true },
      { key: "originCountry", label: "Pays d’origine du véhicule", required: true },
      { key: "requestDetails", label: "Précisions sur la demande", type: "textarea", required: false },
    ],
  },
  {
    id: "remboursement-mutuelle",
    title: "Dossier de remboursement mutuelle",
    description: "Aide à préparer une demande pour des soins réels et des frais justifiés auprès de votre complémentaire santé. La prise en charge dépend des garanties et de la décision de la mutuelle. Accompagnement sur devis, sans collecte de mot de passe.",
    category: "assistance", price: 0, requiresQuote: true, delay: "Selon la mutuelle", icon: "folder", active: true,
    documents: ["Facture des soins concernés", "Décompte de l’Assurance maladie (si applicable)", "Attestation ou carte de mutuelle"],
    documentRequired: [true, false, true],
    fields: [
      { key: "mutualName", label: "Nom de la mutuelle", required: true },
      { key: "memberReference", label: "Numéro d’adhérent", required: true },
      { key: "requestDetails", label: "Soins et demande à préparer", type: "textarea", required: true },
    ],
  },
  {
    id: "dossier-recepisse",
    title: "Dossier récépissé de séjour",
    description: "Accompagnement à la préparation d’une demande ou d’un renouvellement de récépissé auprès de la préfecture compétente. Le document est délivré uniquement par l’administration, selon l’éligibilité et l’état du dossier. Prestation sur devis, hors taxes et timbres éventuels.",
    category: "assistance", price: 0, requiresQuote: true, delay: "Selon la préfecture", icon: "folder", active: true,
    documents: ["Justificatif de dépôt de la demande de séjour", "Titre de séjour ou récépissé actuel (si disponible)"],
    documentRequired: [true, false],
    fields: [
      { key: "requestType", label: "Type de demande", type: "select", options: ["Première demande", "Renouvellement", "Suivi d’une demande"], required: true },
      { key: "prefecture", label: "Préfecture compétente", required: true },
      { key: "applicationReference", label: "Référence du dossier (si connue)", required: false },
    ],
  },
  {
    id: "dossier-logement",
    title: "Constitution de dossier logement",
    description: "Aide à assembler et vérifier vos justificatifs pour une demande de location ou de logement social. Le dossier utilise des documents authentiques ; l’attribution reste décidée par le bailleur ou l’organisme. Accompagnement sur devis.",
    category: "assistance", price: 0, requiresQuote: true, delay: "Après étude du dossier", icon: "folder", active: true,
    documents: ["Pièce d’identité du demandeur", "Justificatifs de ressources", "Justificatif de situation actuelle (si disponible)"],
    documentRequired: [true, true, false],
    fields: [
      { key: "housingType", label: "Type de dossier", type: "select", options: ["Location privée", "Logement social", "Autre demande de logement"], required: true },
      { key: "requestedCity", label: "Commune ou secteur recherché", required: true },
      { key: "householdDetails", label: "Situation et composition du foyer", type: "textarea", required: true },
    ],
  },
  {
    id: "creation-neph",
    title: "Création du numéro NEPH",
    description: "Assistance à la demande officielle de numéro NEPH auprès de l’ANTS / France Titres pour l’inscription au permis. La validation et le délai dépendent de l’administration. Accompagnement sur devis, hors frais de photo et frais externes, sans collecte des identifiants du compte.",
    category: "assistance", price: 0, requiresQuote: true, delay: "Selon l’administration", icon: "folder", active: true,
    documents: ["Pièce d’identité du candidat", "Justificatif de domicile", "Justificatifs complémentaires de situation (si applicables)"],
    documentRequired: [true, true, false],
    fields: [
      { key: "birthDate", label: "Date de naissance du candidat", type: "date", required: true },
      { key: "licenceCategory", label: "Catégorie de permis", type: "select", options: ["B", "A1", "A2", "Autre catégorie"], required: true },
      { key: "photoCode", label: "Code e-photo (si disponible)", required: false },
    ],
  },
  {
    id: "cession", title: "Déclaration de cession", description: "Enregistrement officiel de la vente du véhicule sur la base du certificat de cession et du mandat du titulaire. Hors taxes éventuelles.",
    category: "automobile", subcategory: "immatriculation", price: 4000, delay: "24 à 48 h", icon: "car", active: true,
    documents: ["Carte grise", "Certificat de cession signé", "Mandat du vendeur"],
    fields: [...vehicleFields, { key: "saleDate", label: "Date de cession", type: "date", required: true }],
  },
];

export const subcategories: { id: string; category: Category; label: string }[] = [
  { id: "creation-modification", category: "formalites", label: "Création & modification de société" },
  { id: "comptabilite-depots", category: "formalites", label: "Comptabilité & dépôt des comptes" },
  { id: "vie-entreprise", category: "formalites", label: "Mise en sommeil, reprise & cessation" },
  { id: "corrections-regularisations", category: "formalites", label: "Corrections RNE & régularisations" },
  { id: "immatriculation", category: "automobile", label: "Cartes grises, WW & homologation" },
  { id: "douanes", category: "automobile", label: "Importation & dédouanement" },
  { id: "controle-restrictions", category: "automobile", label: "Contrôle technique & levées de restrictions" },
  { id: "documents-vehicule", category: "automobile", label: "Informations du véhicule" },
  { id: "dossiers-rendez-vous", category: "assistance", label: "Dossiers administratifs & rendez-vous" },
  { id: "permis-examens", category: "assistance", label: "Permis & examens" },
  { id: "remboursements", category: "assistance", label: "Demandes de remboursement" },
  { id: "demandes-personnelles", category: "assistance", label: "Demandes personnelles d’accès aux données" },
  { id: "offres-professionnelles", category: "assistance", label: "Offres professionnelles — CEDEO" },
];
const initialSubcategories: Record<string, string> = {
  creation: "creation-modification", modification: "creation-modification", comptes: "comptabilite-depots",
  sommeil: "vie-entreprise", cessation: "vie-entreprise", rne: "corrections-regularisations", regularisation: "corrections-regularisations",
  "carte-grise": "immatriculation", "carte-grise-sans-ct": "immatriculation", ww: "immatriculation", "ww-modification": "immatriculation", achat: "immatriculation", cession: "immatriculation",
  douane: "douanes", "douane-suisse": "douanes", "controle-convoyage": "controle-restrictions", "levee-procedure": "controle-restrictions", "levee-saisie": "controle-restrictions", "levee-immobilisation": "controle-restrictions",
  "situation-vehicule": "documents-vehicule", "fin-leasing": "immatriculation",
  "regularisation-carte-grise": "immatriculation", homologation: "immatriculation",
  "remboursement-mutuelle": "remboursements", "dossier-recepisse": "dossiers-rendez-vous", "dossier-logement": "dossiers-rendez-vous", "creation-neph": "permis-examens",
  assistance: "dossiers-rendez-vous", rdv: "dossiers-rendez-vous", "titre-sejour": "dossiers-rendez-vous", "code-route": "permis-examens", "examen-permis": "permis-examens",
  "remboursement-ameli": "remboursements", "remboursement-pare-brise": "remboursements", "acces-donnees-personnelles": "demandes-personnelles", "cedeo-pro": "offres-professionnelles",
};
// This revision changes offers only: custom forms, grouping and existing orders stay intact.
const revisedOfferIds = new Set(["situation-vehicule", "acces-donnees-personnelles", "carte-grise-sans-ct", "remboursement-ameli", "controle-convoyage", "ww", "ww-modification", "cedeo-pro"]);
const clientPriceRevision: Record<string, number> = {"creation": 140000, "modification": 65000, "ww": 8000, "ww-modification": 10000, "situation-vehicule": 5000, "fin-leasing": 17000, "achat": 4000, "regularisation-carte-grise": 10000};
const oldClientPrices: Record<string, number> = { creation: 14900, modification: 9900, ww: 5000, "ww-modification": 8000, "situation-vehicule": 7000, "fin-leasing": 14900, achat: 2900, "regularisation-carte-grise": 0 };
export const initialServices: Service[] = baseServices.map(service => ({ ...service, subcategory: initialSubcategories[service.id] || null, catalogVersion: service.id === "fin-leasing" ? 2 : 1,
  ...(Object.prototype.hasOwnProperty.call(clientPriceRevision, service.id) ? { pricingRevision: 1 } : {}),
  ...(revisedOfferIds.has(service.id) ? { offerVersion: service.id === "cedeo-pro" ? 2 : 1 } : {}),
}));
export const subcategoryLabel = (service: Service) => subcategories.find(group => group.id === service.subcategory && group.category === service.category)?.label || "Autres prestations";
export function groupCatalogue(services: Service[]) {
  return categories.filter(category => category.id !== "all").map(category => {
    const matches = services.filter(service => service.category === category.id);
    const known = subcategories.filter(group => group.category === category.id);
    const groups = [...known, { id: "other", label: "Autres prestations", category: category.id }].map(group => ({
      id: group.id, label: group.label,
      services: matches.filter(service => group.id === "other" ? !known.some(item => item.id === service.subcategory) : service.subcategory === group.id),
    })).filter(group => group.services.length);
    return { id: category.id, label: category.label, groups, count: matches.length };
  }).filter(category => category.count);
}

/** Preserve browser edits and append services introduced by later catalogue versions. */
export function mergeDemoServices(
  saved: Service[],
  defaults: Service[] = initialServices,
): Service[] {
  const renamedServices: Record<string, { previous: string; current: string }> =
    {
      "carte-grise": {
        previous: "Changement de titulaire",
        current: "Changement de titulaire carte grise",
      },
      ww: {
        previous: "Certificat provisoire WW",
        current: "WW simple — certificat provisoire",
      },
    };
  const defaultTitles = new Map(
    defaults.map((service) => [service.id, service.title]),
  );
  const defaultsById = new Map(defaults.map((service) => [service.id, service]));
  const savedById = new Map<string, Service>();
  for (let service of saved) {
    const updated = defaultsById.get(service.id);
    // Apply explicitly revised forms once; preserve prices and subsequent admin edits.
    if (updated?.formVersion && (service.formVersion ?? 0) < updated.formVersion) {
      const quoteRevision = (service.id === "carte-grise" && (service.formVersion ?? 0) < 3 && updated.formVersion >= 3) || service.id === "douane-suisse";
      const updateDocuments = !(service.id === "carte-grise" && (service.formVersion ?? 0) >= 1 && (updated.formVersion < 4 || (service.formVersion ?? 0) >= 4));
      const holderLabelOnly = (service.id === "carte-grise" && (service.formVersion ?? 0) >= 4) || (service.id === "carte-grise-sans-ct" && (service.formVersion ?? 0) >= 1);
      const revisedFields = holderLabelOnly ? service.fields.map(field => field.key === "holderIdentity" ? { ...field, label: "Identité du titulaire" } : field) : updated.fields;
      service = { ...service, formVersion: updated.formVersion, fields: revisedFields,
        ...(service.id === "douane-suisse" ? { description: updated.description, delay: updated.delay } : {}),
        ...(updateDocuments ? { documents: updated.documents, documentKeys: updated.documentKeys, documentTypes: updated.documentTypes,
          documentRequired: updated.documents.map((_, index) => updated.documentRequired?.[index] !== false) } : {}),
        ...(quoteRevision ? { requiresQuote: true, price: 0, documentRequired: service.id === "douane-suisse" ? [true] : (updateDocuments ? updated.documents : service.documents).map(() => false) } : {}) };
    }
    if (updated?.catalogVersion && (service.catalogVersion ?? 0) < updated.catalogVersion) {
      const pricing = ["ww", "ww-modification", "cedeo-pro"].includes(service.id);
      service = { ...service, catalogVersion: updated.catalogVersion, subcategory: service.id === "fin-leasing" && service.subcategory && service.subcategory !== "documents-vehicule" ? service.subcategory : updated.subcategory,
        ...(pricing ? { price: updated.price, requiresQuote: !!updated.requiresQuote } : {}) };
    }
    if (updated?.offerVersion && (service.offerVersion ?? 0) < updated.offerVersion) {
      service = { ...service, offerVersion: updated.offerVersion, price: updated.price,
        requiresQuote: !!updated.requiresQuote, delay: updated.delay,
        ...(service.id === "cedeo-pro" && updated.offerVersion >= 2 ? {
          title: service.title === "CEDEO — remise professionnelle de 30 %" ? updated.title : service.title,
          description: service.description === "Accompagnement à l’application de la remise professionnelle de 30 % selon votre accord commercial CEDEO et ses conditions. Frais de service hors achats." ? updated.description : service.description,
        } : {}),
        ...(["situation-vehicule", "acces-donnees-personnelles", "remboursement-ameli"].includes(service.id) ? { description: updated.description } : {}),
      };
    }
    if (updated?.pricingRevision && (service.pricingRevision ?? 0) < updated.pricingRevision) {
      service = { ...service, pricingRevision: updated.pricingRevision,
        ...(service.price === oldClientPrices[service.id] ? { price: updated.price, requiresQuote: !!updated.requiresQuote } : {}) };
    }
    const renamed = renamedServices[service.id];
    savedById.set(
      service.id,
      renamed && service.title === renamed.previous
        ? {
            ...service,
            title: defaultTitles.get(service.id) || renamed.current,
          }
        : service,
    );
  }
  return [
    ...savedById.values(),
    ...defaults.filter((service) => !savedById.has(service.id)),
  ];
}

export const statusLabels: Record<OrderStatus, string> = {
  AWAITING_QUOTE: "En attente de devis",
  QUOTE_PROPOSED: "Devis à valider",
  QUOTE_REJECTED: "Devis refusé",
  AWAITING_PAYMENT: "En attente de paiement",
  PROCESSING: "En cours",
  ACTION_REQUIRED: "Action requise",
  COMPLETED: "Terminé",
  CANCELLED: "Annulé",
};
export const euro = (cents: number) =>
  new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency: "EUR",
    maximumFractionDigits: 2,
  }).format(cents / 100);
export const dateFR = (date: string) =>
  new Intl.DateTimeFormat("fr-FR", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  }).format(new Date(date));
export const initialOrders: Order[] = [
  {
    id: "order-1042",
    reference: "1042",
    serviceId: "creation",
    serviceTitle: "Création de société",
    customerName: "Alexandre Martin",
    amount: 14900,
    status: "ACTION_REQUIRED",
    createdAt: "2026-10-20T10:42:00Z",
    documents: [],
    fields: { company: "AM Consulting", legalForm: "SASU" },
    note: "Merci d’ajouter un justificatif de domiciliation de moins de 3 mois.",
    userName: "Thomas Dubois",
    userId: "demo",
  },
  {
    id: "order-1041",
    reference: "1041",
    serviceId: "carte-grise",
    serviceTitle: "Changement de titulaire",
    customerName: "Sophie Bernard",
    amount: 3900,
    status: "PROCESSING",
    createdAt: "2026-10-20T09:15:00Z",
    documents: [],
    fields: { registration: "AB-123-CD" },
    userName: "Thomas Dubois",
    userId: "demo",
  },
  {
    id: "order-1038",
    reference: "1038",
    serviceId: "comptes",
    serviceTitle: "Dépôt des comptes annuels",
    customerName: "Lucas Petit",
    amount: 7900,
    status: "COMPLETED",
    createdAt: "2026-10-19T14:30:00Z",
    documents: [],
    fields: { company: "LP Studio" },
    userName: "Thomas Dubois",
    userId: "demo",
    note: "Votre récépissé de dépôt est disponible.",
  },
  {
    id: "order-1035",
    reference: "1035",
    serviceId: "ww",
    serviceTitle: "Certificat provisoire WW",
    customerName: "Emma Laurent",
    amount: 5900,
    status: "COMPLETED",
    createdAt: "2026-10-18T11:00:00Z",
    documents: [],
    fields: { registration: "WW-482-YZ" },
    userName: "Thomas Dubois",
    userId: "demo",
  },
  {
    id: "order-1032",
    reference: "1032",
    serviceId: "modification",
    serviceTitle: "Modification statutaire",
    customerName: "Nicolas Moreau",
    amount: 9900,
    status: "PROCESSING",
    createdAt: "2026-10-17T16:00:00Z",
    documents: [],
    fields: { company: "NM Agency" },
    userName: "Thomas Dubois",
    userId: "demo",
  },
];
export const initialTransactions: Transaction[] = [
  {
    id: "tx-1",
    label: "Rechargement du portefeuille",
    amount: 50000,
    date: "2026-10-20T08:00:00Z",
    status: "CONFIRMED",
    currency: "USDT · TRC20",
  },
  {
    id: "tx-2",
    label: "Création de société · #1042",
    amount: -14900,
    date: "2026-10-20T10:42:00Z",
    status: "CONFIRMED",
    currency: "Portefeuille EUR",
  },
  {
    id: "tx-3",
    label: "Changement de titulaire · #1041",
    amount: -3900,
    date: "2026-10-20T09:15:00Z",
    status: "CONFIRMED",
    currency: "Portefeuille EUR",
  },
];

export const servicePrice = (service: Service) => service.requiresQuote ? "Sur devis" : euro(service.price);
export const orderPrice = (order: Order) => order.status === "AWAITING_QUOTE" ? "Sur devis" : euro(order.amount);
export const isPaidStatus = (status: OrderStatus) => ["PROCESSING", "ACTION_REQUIRED", "COMPLETED"].includes(status);

export const isVehicleTransferService = (id: string) => ["carte-grise", "carte-grise-sans-ct"].includes(id);
export const usesStructuredCustomer = (id: string) => isVehicleTransferService(id) || ["douane-suisse", "ww", "ww-modification", "controle-convoyage", "remboursement-ameli", "acces-donnees-personnelles", "situation-vehicule"].includes(id);
export function serviceCustomerName(id: string, fields: Record<string, string>, fallback = "") {
  if (isVehicleTransferService(id)) return [fields.buyerLastName?.trim(), fields.buyerFirstName?.trim()].filter(Boolean).join(" ");
  if (id === "acces-donnees-personnelles") return [fields.lastName?.trim(), fields.firstName?.trim()].filter(Boolean).join(" ");
  if (id === "situation-vehicule") return fields.registration?.trim() || "";
  if (id === "douane-suisse") return `Dédouanement suisse — ${fields.mileage || ""} km`;
  if (id === "controle-convoyage") return `Contrôle technique — ${fields.mileage || ""} km`;
  if (id === "remboursement-ameli") return "Dossier Ameli";
  if (id === "ww" || id === "ww-modification") return id === "ww" ? "Dossier WW simple" : "Dossier WW modifié";
  return fallback;
}
