/** Offline estimate for an ordinary used passenger car already registered in France.
 * Sources checked 2026-11-08. No plate lookup, OCR, paid API or AI is involved.
 * Imports, malus, exemptions, conversions and other vehicle classes require the official simulator.
 */
export const officialVehicleSimulator = "https://www.service-public.gouv.fr/simulateur/calcul/cout-certificat-immatriculation";
export const vehicleRateSource = "https://www.service-public.gouv.fr/particuliers/actualites/A18021";
export const vehicleRates = [
  { id: "ara", name: "Auvergne-Rhône-Alpes", cents: 4300 },
  { id: "bfc", name: "Bourgogne-Franche-Comté", cents: 6000 },
  { id: "bre", name: "Bretagne", cents: 6000 },
  { id: "cvl", name: "Centre-Val de Loire", cents: 6000 },
  { id: "cor", name: "Corse", cents: 5300 },
  { id: "ges", name: "Grand Est", cents: 6000 },
  { id: "hdf", name: "Hauts-de-France", cents: 4300 },
  { id: "idf", name: "Île-de-France", cents: 6895 },
  { id: "nor", name: "Normandie", cents: 6000 },
  { id: "naq", name: "Nouvelle-Aquitaine", cents: 5800 },
  { id: "occ", name: "Occitanie", cents: 5950 },
  { id: "pdl", name: "Pays de la Loire", cents: 5100 },
  { id: "pac", name: "Provence-Alpes-Côte d’Azur", cents: 6000 },
  { id: "gua", name: "Guadeloupe", cents: 4100 },
  { id: "guy", name: "Guyane", cents: 4250 },
  { id: "mar", name: "Martinique", cents: 5300 },
  { id: "reu", name: "La Réunion", cents: 6000 },
  { id: "may", name: "Mayotte", cents: 3000 },
] as const;
export type VehicleEstimateInput = { region: string; fiscalPower: number; firstRegistration: string; ordinaryFrenchUsedCar: boolean };
export function estimateVehicleTax(input: VehicleEstimateInput, now = new Date()) {
  const date = now.toISOString().slice(0, 10);
  if (date < "2026-04-01" || date > "2026-12-31") throw new Error("Barème à actualiser. Utilisez le simulateur officiel pour cette date.");
  if (!input.ordinaryFrenchUsedCar) throw new Error("Ce calcul couvre uniquement une voiture particulière essence ou diesel d’occasion, déjà immatriculée en France, sans exonération, malus résiduel ni transformation. Utilisez le simulateur officiel pour les autres cas.");
  const region = vehicleRates.find(rate => rate.id === input.region);
  if (!region || !Number.isInteger(input.fiscalPower) || input.fiscalPower < 1 || input.fiscalPower > 1000) throw new Error("Région ou puissance fiscale invalide.");
  const first = new Date(input.firstRegistration + "T00:00:00.000Z");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.firstRegistration) || !Number.isFinite(first.getTime()) || first.toISOString().slice(0, 10) !== input.firstRegistration || input.firstRegistration > date || input.firstRegistration < "1900-01-01") throw new Error("Date de première immatriculation invalide.");
  const anniversary = new Date(first); anniversary.setUTCFullYear(first.getUTCFullYear() + 10);
  const oldVehicle = now.getTime() >= anniversary.getTime();
  const regionalCents = Math.round(region.cents * input.fiscalPower * (oldVehicle ? 0.5 : 1) / 100) * 100;
  return { referenceCents: regionalCents + 1100 + 276, regionalCents, fixedCents: 1100, deliveryCents: 276, oldVehicle, rateCents: region.cents, region: region.name, calculatedAt: date, validUntil: "2026-12-31", source: vehicleRateSource, simulator: officialVehicleSimulator, estimateOnly: true as const };
}
