import { initialServices, subcategories, subcategoryLabel, type Service } from "./catalog";
export const catalogueSections = [
  { id: "immatriculation", label: "Carte grise & immatriculation", description: "Carte grise, WW, leasing et homologation", categories: ["automobile"], groups: ["immatriculation"], tone: "blue" },
  { id: "automobile", label: "Régularisation & procédures automobiles", description: "Levées, dédouanement suisse et contrôle technique", categories: ["automobile"], groups: ["controle-restrictions", "douanes"], tone: "cyan" },
  { id: "informations", label: "Informations véhicule & particulier", description: "Situation du véhicule et accès à ses données", categories: ["automobile", "assistance"], groups: ["documents-vehicule", "demandes-personnelles"], tone: "blue" },
  { id: "remboursements", label: "Remboursements & assurances", description: "Ameli, bris de glace et mutuelle", categories: ["assistance"], groups: ["remboursements"], tone: "cyan" },
  { id: "administratif", label: "Démarches administratives", description: "Récépissé, logement et formalités de société", categories: ["assistance", "formalites"], groups: ["dossiers-rendez-vous", "creation-modification", "comptabilite-depots", "vie-entreprise", "corrections-regularisations"], tone: "green" },
  { id: "permis", label: "Permis de conduire", description: "Code, création NEPH et date d’examen", categories: ["assistance"], groups: ["permis-examens"], tone: "green" },
  { id: "offres-pro", label: "Avantages & réductions", description: "CEDEO : votre remise pro de 40 % sur devis", categories: ["assistance"], groups: ["offres-professionnelles"], tone: "green" },
] as const;
export type CatalogueSectionId = typeof catalogueSections[number]["id"];
/** Presentation only: preserve database categories and include custom/uncategorised services. */
export function serviceSection(service: Service) {
  return catalogueSections.find(section => (section.categories as readonly string[]).includes(service.category) && (section.groups as readonly string[]).includes(service.subcategory || "")
    && subcategories.some(group => group.id === service.subcategory && group.category === service.category))
    || catalogueSections.find(section => section.id === (service.category === "automobile" ? "automobile" : "administratif"))!;
}
export const catalogueGroupLabels: Record<string, string> = {
  "creation-modification": "Création & modification", "comptabilite-depots": "Comptabilité",
  "vie-entreprise": "Vie de l’entreprise", "corrections-regularisations": "Régularisation",
  immatriculation: "Cartes grises & WW", douanes: "Importation", "controle-restrictions": "Contrôle & restrictions", "documents-vehicule": "Informations véhicule",
  "dossiers-rendez-vous": "Dossiers & rendez-vous", "permis-examens": "Permis & examens", remboursements: "Remboursements", "demandes-personnelles": "Données personnelles", "offres-professionnelles": "CEDEO pro",
};
const defaults = new Map(initialServices.map(service => [service.id, service]));
const summaries: Record<string, string> = {
  "carte-grise": "Changez le titulaire de la carte grise de votre véhicule.",
  "carte-grise-sans-ct": "Dossier sans justificatif CT joint, selon l’éligibilité du véhicule.",
  ww: "Une immatriculation provisoire pour votre véhicule importé.",
  "ww-modification": "Faites rectifier officiellement votre dossier WW.",
  creation: "Lancez votre société : SAS, SASU, SARL ou EURL.",
  modification: "Dirigeant, siège ou activité : mettez vos statuts à jour.",
  comptes: "Préparez le dépôt des comptes annuels de votre société.",
  sommeil: "Suspendez ou reprenez l’activité de votre société.",
  rne: "Corrigez les informations de votre entreprise au RNE.",
  cessation: "Effectuez les formalités de fin d’activité.",
  regularisation: "Mettez votre situation administrative à jour.",
  achat: "Enregistrez l’achat d’un véhicule professionnel au SIV.",
  douane: "Faites-vous accompagner dans les formalités d’importation.",
  "douane-suisse": "Photo et kilométrage, puis devis et rendez-vous pour l’original.",
  "cedeo-pro": "Votre remise professionnelle de 40 %, selon l’accord CEDEO.",
  "controle-convoyage": "Organisation du passage en centre agréé, avec convoyage.",
  "remboursement-ameli": "Constituez une demande justifiée auprès de la CPAM, sans mot de passe.",
  "remboursement-pare-brise": "Préparez une demande justifiée à votre assureur après un sinistre réel.",
  "acces-donnees-personnelles": "Demandez officiellement l’accès à vos propres données uniquement.",
  "situation-vehicule": "Obtenez le certificat officiel pour votre véhicule ou avec mandat.",
  "fin-leasing": "Mettez la carte grise à jour après rachat ou accord du bailleur.",
  "levee-procedure": "Accompagnement après réparations et validation de l’expert.",
  "levee-saisie": "Constituez le dossier après une décision officielle de mainlevée.",
  "levee-immobilisation": "Préparez la levée après conformité et autorisation officielle.",
  "code-route": "Inscrivez-vous à l’examen auprès d’un organisme agréé.",
  "examen-permis": "Accompagnement à la réservation selon les créneaux officiels.",
  "titre-sejour": "Préparez votre demande auprès de l’administration compétente.",
  assistance: "Constituez et vérifiez votre dossier administratif.",
  rdv: "Préparez votre démarche et votre rendez-vous officiel.",
};
const titles: Record<string, string> = {
  "carte-grise": "Changement de titulaire",
  "carte-grise-sans-ct": "Carte grise · sans CT joint",
  ww: "WW simple", "ww-modification": "WW modifié", "cedeo-pro": "CEDEO · remise de 40 %",
  "controle-convoyage": "Contrôle technique & convoyage",
  "acces-donnees-personnelles": "Accès à ses données personnelles",
  "situation-vehicule": "Fiche infos véhicule · certificat officiel",
  "fin-leasing": "Leasing · mise à jour carte grise",
  "remboursement-pare-brise": "Remboursement bris de glace",
  "examen-permis": "Date d’examen du permis",
};
const aliases: Record<string, string> = {
  "regularisation-carte-grise": "ecrasement carte grise regularisation correction", "fin-leasing": "ecrasement leasing rachat fin leasing",
  "homologation": "conformite reception dreal rti", "remboursement-mutuelle": "complementaire sante mutuelle",
  "dossier-recepisse": "recepisse sejour prefecture", "dossier-logement": "logement location hlm social", "creation-neph": "neph numero permis inscription ants",
  "levee-saisie": "levee valant saisie saisie mainlevee", "examen-permis": "date examen permis",
  "carte-grise": "cg changement titulaire", "carte-grise-sans-ct": "cg sans controle technique",
  ww: "ww simple provisoire", "ww-modification": "ww modifier modification modifie",
  "situation-vehicule": "fiche infos vehicule fiche police vehicule non gage", "acces-donnees-personnelles": "fiche police recherche acces personnel",
  "remboursement-ameli": "ameli securite sociale cpam", "cedeo-pro": "cedeo 40 remise pro",
};
export const shortServiceTitle = (service: Service) => service.title === defaults.get(service.id)?.title ? titles[service.id] || service.title : service.title;
export const serviceSummary = (service: Service) => service.description === defaults.get(service.id)?.description ? summaries[service.id] || service.description : service.description;
export const normalizeCatalogueQuery = (value: string) => value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[’']/g, " ").trim();
export function findCatalogueServices(services: Service[], options: { category: string; group: string; query: string; pricing: string; sort: string; section?: string }) {
  const words = normalizeCatalogueQuery(options.query).split(/\s+/).filter(Boolean);
  return services.filter(service => {
    const search = normalizeCatalogueQuery([service.title, shortServiceTitle(service), service.description, subcategoryLabel(service), serviceSection(service).label, aliases[service.id]].join(" "));
    return service.active && (!options.section || options.section === "all" || serviceSection(service).id === options.section) && (options.category === "all" || service.category === options.category) &&
      (options.group === "all" || service.subcategory === options.group || (options.group === "other" && !subcategories.some(item => item.id === service.subcategory && item.category === service.category))) &&
      (options.pricing === "all" || (options.pricing === "quote" ? !!service.requiresQuote : !service.requiresQuote)) && words.every(word => search.includes(word));
  }).sort((a,b) => options.sort === "price" ? (a.requiresQuote ? Number.MAX_SAFE_INTEGER : a.price) - (b.requiresQuote ? Number.MAX_SAFE_INTEGER : b.price) || a.title.localeCompare(b.title, "fr") : options.sort === "name" ? a.title.localeCompare(b.title, "fr") : Number(!!b.popular) - Number(!!a.popular));
}
export function quickCatalogueServices(services: Service[]) {
  const preferred = ["carte-grise", "ww", "ww-modification", "creation", "cedeo-pro", "douane-suisse"];
  const active = services.filter(service => service.active);
  const picked = preferred.flatMap(id => active.find(service => service.id === id) || []);
  return [...picked, ...active.filter(service => !preferred.includes(service.id))].slice(0, 6);
}
export function attachmentSummary(service: Service) {
  const count = service.documents.length;
  const required = service.documents.filter((_, index) => service.documentRequired?.[index] !== false).length;
  if (!count) return "Sans pièce jointe";
  if (!required) return `${count} pièce${count > 1 ? "s" : ""} facultative${count > 1 ? "s" : ""}`;
  const photos = service.documentTypes?.every(type => type === "image") && service.documentTypes.length === count;
  return `${required} ${photos ? "photo" : "pièce"}${required > 1 ? "s" : ""} requise${required > 1 ? "s" : ""}`;
}
