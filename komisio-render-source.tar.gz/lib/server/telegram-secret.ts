import { createHash } from 'node:crypto';
/** Render generates base64 secrets; Telegram accepts only A-Z a-z 0-9 _ -. */
export function telegramWebhookSecret(value=process.env.TELEGRAM_WEBHOOK_SECRET||''){
 if(!value)return '';
 return /^[a-zA-Z0-9_-]{1,256}$/.test(value)?value:createHash('sha256').update(value).digest('hex');
}
