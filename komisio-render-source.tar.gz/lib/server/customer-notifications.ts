import type { Prisma } from "@prisma/client";
import { queueNotification } from "./telegram";
/** One business event, delivered only through the channels explicitly linked to its owner. */
export async function queueCustomerNotification(tx: Prisma.TransactionClient, user: { id: string; telegramId: string | null }, text: string, documentId?: string, whatsappText?: string) {
  await queueNotification(tx, user.telegramId, text);
  if (process.env.WHATSAPP_ENABLED === "true") {
    const { queueWhatsAppUserNotification } = await import("./whatsapp");
    await queueWhatsAppUserNotification(tx, user.id, whatsappText || text, documentId);
  }
}
