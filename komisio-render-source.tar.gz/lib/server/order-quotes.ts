import { queueCustomerNotification } from "./customer-notifications";
import { quotePrice, type PricingSnapshot } from "../pricing";
import { estimateVehicleTax } from "../vehicle-estimate";
import { z } from "zod";
import { serializable } from "./db";
import { HttpError } from "./http";
import { orderInclude } from "./orders";
import { queueAdmins } from "./telegram";
export const proposalInput = z.object({
  amountCents: z.number().int().min(100).max(10_000_000),
  vehicleEstimate: z.object({ region: z.string().max(10), fiscalPower: z.number().int(), firstRegistration: z.string().max(10), ordinaryFrenchUsedCar: z.boolean() }).strict().optional(),
  expectedVersion: z.number().int().min(0),
  note: z.string().trim().max(4000).default(""),
}).strict();
export const decisionInput = z.object({ action: z.enum(["accept", "reject"]), quoteVersion: z.number().int().positive() }).strict();
export async function proposeOrderQuote(id: string, actorId: string, input: z.infer<typeof proposalInput>) {
  return serializable(async tx => {
    const order = await tx.order.findUnique({ where: { id }, include: { user: true } });
    if (!order) throw new HttpError(404, "Dossier introuvable.");
    if (!order.requiresQuote || !["AWAITING_QUOTE", "QUOTE_PROPOSED"].includes(order.status) || order.paidAt || order.quoteAcceptedAt)
      throw new HttpError(409, "Ce dossier ne peut plus recevoir de devis.");
    if (order.quoteVersion !== input.expectedVersion) throw new HttpError(409, "Le devis a changé. Actualisez le dossier.");
    if (input.vehicleEstimate) {
      if (!["carte-grise", "carte-grise-sans-ct"].includes(order.serviceId)) throw new HttpError(400, "Ce calcul concerne uniquement les cartes grises.");
      try { if (estimateVehicleTax(input.vehicleEstimate).referenceCents !== input.amountCents) throw new Error("L’estimation ne correspond plus au montant de référence."); } catch (error) { throw new HttpError(400, (error as Error).message); }
    }
    const amountCents = quotePrice(input.amountCents, order.pricingSnapshot as PricingSnapshot | null);
    const updated = await tx.order.update({ where: { id }, data: {
      status: "QUOTE_PROPOSED", priceCents: amountCents, quoteReferenceCents: input.amountCents, quoteVersion: { increment: 1 },
      events: { create: { status: "QUOTE_PROPOSED", actorId, note: `Prix proposé : ${(amountCents / 100).toFixed(2)} €. ${input.note}`.trim() } },
    }, include: orderInclude });
    await tx.auditLog.create({ data: { actorId, action: "ORDER_QUOTE_PROPOSED", targetId: id, details: { amountCents, referenceCents: input.amountCents, ...(input.vehicleEstimate ? { vehicleEstimate: input.vehicleEstimate, calculation: estimateVehicleTax(input.vehicleEstimate) } : {}), quoteVersion: updated.quoteVersion, note: input.note } } });
    await queueCustomerNotification(tx, order.user, `💬 Dossier #${order.number} : prix proposé ${(amountCents / 100).toFixed(2)} €. Consultez votre dossier pour accepter et payer, ou refuser.${input.note ? `\n${input.note}` : ""}`);
    return updated;
  });
}
export async function decideOrderQuote(id: string, userId: string, input: z.infer<typeof decisionInput>) {
  return serializable(async tx => {
    const order = await tx.order.findFirst({ where: { id, userId } });
    if (!order) throw new HttpError(404, "Dossier introuvable.");
    if (!order.requiresQuote || order.quoteVersion !== input.quoteVersion) throw new HttpError(409, "Le devis a changé. Vérifiez le nouveau montant.");
    if (input.action === "accept" && order.quoteAcceptedAt && !["CANCELLED", "QUOTE_REJECTED"].includes(order.status)) return tx.order.findUniqueOrThrow({ where: { id }, include: orderInclude });
    if (input.action === "reject" && order.status === "QUOTE_REJECTED") return tx.order.findUniqueOrThrow({ where: { id }, include: orderInclude });
    if (order.status !== "QUOTE_PROPOSED" || order.paidAt || order.quoteAcceptedAt) throw new HttpError(409, "Ce devis n’est plus disponible.");
    const accepted = input.action === "accept";
    const status = accepted ? "AWAITING_PAYMENT" : "QUOTE_REJECTED";
    const updated = await tx.order.update({ where: { id }, data: { status, ...(accepted ? { quoteAcceptedAt: new Date() } : {}), events: { create: { status, actorId: userId, note: accepted ? `Devis accepté : ${(order.priceCents / 100).toFixed(2)} €. Paiement attendu avant traitement.` : "Devis refusé par le revendeur. Aucun paiement." } } }, include: orderInclude });
    await tx.auditLog.create({ data: { actorId: userId, action: accepted ? "ORDER_QUOTE_ACCEPTED" : "ORDER_QUOTE_REJECTED", targetId: id, details: { quoteVersion: order.quoteVersion, amountCents: order.priceCents } } });
    await queueAdmins(tx, `📋 Devis du dossier #${order.number} ${accepted ? "accepté — paiement en attente" : "refusé"}.${accepted && order.serviceId === "douane-suisse" ? " Rendez-vous de récupération de la carte grise originale à fixer." : ""}`);
    return updated;
  });
}
