import { createHmac, timingSafeEqual } from "node:crypto";

/** NOWPayments IPN canonical JSON: recursively sort object keys; retain array order. */
export function canonicalize(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(canonicalize);
  if (value && typeof value === "object") {
    const object = value as Record<string, unknown>;
    return Object.fromEntries(
      Object.keys(object)
        .sort()
        .map((key) => [key, canonicalize(object[key])]),
    );
  }
  return value;
}

export function verifyIpn(
  payload: unknown,
  signature: string,
  secret: string,
): boolean {
  if (!secret || !/^[a-f0-9]{128}$/i.test(signature)) return false;
  const serialized = JSON.stringify(canonicalize(payload));
  if (serialized === undefined) return false;
  const expected = createHmac("sha512", secret).update(serialized).digest();
  const actual = Buffer.from(signature, "hex");
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}
