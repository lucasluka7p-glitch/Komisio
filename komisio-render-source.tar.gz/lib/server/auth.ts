import { createHmac, timingSafeEqual } from "node:crypto";
import { HttpError, sameOrigin } from "./http";

export const SESSION_COOKIE = "forma_session";
const SESSION_SECONDS = 24 * 60 * 60;

export function safeEqual(a: string, b: string): boolean {
  const left = Buffer.from(a);
  const right = Buffer.from(b);
  return left.length === right.length && timingSafeEqual(left, right);
}

export type TelegramIdentity = {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
};

/** Telegram WebApp HMAC verification. Never trust initDataUnsafe. */
export function validateTelegramInitData(
  raw: string,
  botToken: string,
  now = Math.floor(Date.now() / 1000),
): TelegramIdentity {
  if (!botToken)
    throw new HttpError(503, "Authentification Telegram non configurée.");
  if (!raw || raw.length > 16_384)
    throw new HttpError(401, "Données Telegram invalides.");
  const params = new URLSearchParams(raw);
  const keys = [...params.keys()];
  if (new Set(keys).size !== keys.length)
    throw new HttpError(401, "Paramètres Telegram dupliqués.");
  const suppliedHash = params.get("hash") ?? "";
  if (!/^[a-fA-F0-9]{64}$/.test(suppliedHash))
    throw new HttpError(401, "Signature Telegram invalide.");
  params.delete("hash");
  const checkString = [...params.entries()]
    .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
    .map(([key, value]) => `${key}=${value}`)
    .join("\n");
  const secret = createHmac("sha256", "WebAppData").update(botToken).digest();
  const expected = createHmac("sha256", secret)
    .update(checkString)
    .digest("hex");
  if (!safeEqual(expected, suppliedHash.toLowerCase()))
    throw new HttpError(401, "Signature Telegram invalide.");
  const authDateRaw = params.get("auth_date") ?? "";
  if (!/^\d+$/.test(authDateRaw))
    throw new HttpError(401, "Date Telegram invalide.");
  const authDate = Number(authDateRaw);
  if (
    !Number.isSafeInteger(authDate) ||
    authDate > now + 30 ||
    now - authDate > 600
  )
    throw new HttpError(401, "Session Telegram expirée. Rouvrez la Mini App.");
  let user: unknown;
  try {
    user = JSON.parse(params.get("user") ?? "null");
  } catch {
    throw new HttpError(401, "Utilisateur Telegram invalide.");
  }
  if (!user || typeof user !== "object")
    throw new HttpError(401, "Utilisateur Telegram absent.");
  const value = user as Record<string, unknown>;
  if (
    !Number.isSafeInteger(value.id) ||
    Number(value.id) <= 0 ||
    typeof value.first_name !== "string" ||
    value.first_name.length > 128 ||
    !value.first_name.trim()
  )
    throw new HttpError(401, "Utilisateur Telegram invalide.");
  if (
    value.username !== undefined &&
    (typeof value.username !== "string" ||
      !/^[a-zA-Z0-9_]{1,64}$/.test(value.username))
  )
    throw new HttpError(401, "Identifiant Telegram invalide.");
  return {
    id: Number(value.id),
    first_name: value.first_name,
    ...(typeof value.last_name === "string"
      ? { last_name: value.last_name.slice(0, 128) }
      : {}),
    ...(typeof value.username === "string" ? { username: value.username } : {}),
  };
}

function checkedSecret(secret: string): string {
  if (secret.length < 32)
    throw new HttpError(
      503,
      "Secret de session non configuré (32 caractères minimum).",
    );
  return secret;
}

export function createSessionToken(
  userId: string,
  secret: string,
  now = Math.floor(Date.now() / 1000),
  version = 0,
): string {
  checkedSecret(secret);
  const payload = Buffer.from(
    JSON.stringify({ sub: userId, exp: now + SESSION_SECONDS, ver: version }),
  ).toString("base64url");
  const signature = createHmac("sha256", secret)
    .update(payload)
    .digest("base64url");
  return `${payload}.${signature}`;
}

export function verifySessionToken(
  token: string,
  secret: string,
  now = Math.floor(Date.now() / 1000),
): string {
  checkedSecret(secret);
  if (token.length > 2048) throw new HttpError(401, "Session invalide.");
  const parts = token.split(".");
  if (parts.length !== 2) throw new HttpError(401, "Session invalide.");
  const expected = createHmac("sha256", secret)
    .update(parts[0])
    .digest("base64url");
  if (!safeEqual(parts[1], expected))
    throw new HttpError(401, "Session invalide.");
  try {
    const body = JSON.parse(
      Buffer.from(parts[0], "base64url").toString("utf8"),
    );
    if (
      typeof body.sub !== "string" ||
      !body.sub ||
      body.sub.length > 128 ||
      !Number.isSafeInteger(body.exp) ||
      body.exp <= now ||
      body.exp > now + SESSION_SECONDS + 30
    )
      throw new Error("invalid");
    return body.sub;
  } catch {
    throw new HttpError(401, "Session expirée ou invalide.");
  }
}

export function adminTelegramIds(): string[] {
  return (process.env.ADMIN_TELEGRAM_IDS ?? "")
    .split(",")
    .map((value) => value.trim())
    .filter((value) => /^\d+$/.test(value));
}

export function sessionCookie(userId: string, version = 0): string {
  const token = createSessionToken(userId, process.env.SESSION_SECRET ?? "", undefined, version);
  return `${SESSION_COOKIE}=${token}; HttpOnly; Path=/; Max-Age=${SESSION_SECONDS}; ${sessionCookiePolicy()}`;
}

/** Partitioned cookies support Telegram Web's cross-site iframe with origin-checked writes. */
export function sessionCookiePolicy(): string {
  return process.env.NODE_ENV === "production"
    ? "SameSite=None; Secure; Partitioned"
    : "SameSite=Lax";
}

export function assertSameOrigin(request: Request): void {
  if (["GET", "HEAD", "OPTIONS"].includes(request.method)) return;
  if (request.headers.get("sec-fetch-site") === "cross-site")
    throw new HttpError(403, "Requête intersite refusée.");
  sameOrigin(request);
}

export async function requireUser(request: Request, admin = false, allowPasswordChange = false) {
  assertSameOrigin(request);
  const cookie = request.headers
    .get("cookie")
    ?.split(";")
    .map((value) => value.trim())
    .find((value) => value.startsWith(`${SESSION_COOKIE}=`));
  if (!cookie)
    throw new HttpError(401, "Ouvrez cette application depuis Telegram.");
  const id = verifySessionToken(
    cookie.slice(SESSION_COOKIE.length + 1),
    process.env.SESSION_SECRET ?? "",
  );
  const { db } = await import("./db");
  const user = await db.user.findUnique({ where: { id } });
  if (!user || user.disabled || !user.accessReady) throw new HttpError(403, "Compte indisponible.");
  const claims = JSON.parse(Buffer.from(cookie.slice(SESSION_COOKIE.length + 1).split(".")[0], "base64url").toString("utf8"));
  if ((claims.ver ?? 0) !== user.credentialVersion) throw new HttpError(401, "Votre accès a été renouvelé. Reconnectez-vous.");
  const isAdmin = !!user.telegramId && adminTelegramIds().includes(user.telegramId);
  if (user.mustChangePassword && !isAdmin && !allowPasswordChange) throw new HttpError(403, "Choisissez votre mot de passe personnel avant de continuer.");
  if (admin && !isAdmin)
    throw new HttpError(403, "Accès administrateur requis.");
  return {
    ...user,
    role: isAdmin ? ("ADMIN" as const) : ("RESELLER" as const),
  };
}
