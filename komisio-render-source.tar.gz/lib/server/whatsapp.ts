import { Prisma, type WhatsAppBinding, type WhatsAppInbound } from '@prisma/client';
import { createHash } from 'node:crypto';
import { z } from 'zod';
import { db, serializable } from './db';
import { HttpError } from './http';
import { storeFile, loadFile, removeFile, fileMime, videoMime, MAX_FILE_BYTES } from './storage';
import { whatsappCommand, whatsappHelp, whatsappPhone } from '../whatsapp';
import { whatsappConfigured, whatsappTransport, downloadWhatsAppMedia, sendWhatsAppText } from './whatsapp-transport';
import { whatsappDraftSummary, getWhatsAppDraft, editWhatsAppDraft } from './whatsapp-drafts';
import { extractDocument } from './document-ocr';
import { fieldDefinition, documentDefinition } from './validation';
import { queueAdmins } from './telegram';
import { euro, statusLabels } from '../catalog';
import { createPayment } from './payments';
import { decideOrderQuote } from './order-quotes';
export { whatsappConfigured, whatsappTransport } from './whatsapp-transport';

export type WhatsAppMessage = { id: string; sender: string; groupId: string | null; timestamp: number; type: 'text' | 'image' | 'document' | 'video'; text?: string; mediaId?: string; fileName?: string; storageKey?: string; mimeType?: string; bytes?: number };
const DAY = 86400_000;
export async function queueWhatsAppUserNotification(tx: Prisma.TransactionClient, userId: string, text: string, documentId?: string) {
  if (!whatsappConfigured()) return 0;
  const bindings = await tx.whatsAppBinding.findMany({ where: { userId, active: true, ...(whatsappTransport() === 'CLOUD' ? { lastInboundAt: { gt: new Date(Date.now() - DAY + 60000) } } : {}) } });
  for (const binding of bindings) await tx.whatsAppOutbox.create({ data: { bindingId: binding.id, reference: `notification:${crypto.randomUUID()}`, text: text.slice(0, 3800), documentId, sendBefore: new Date(whatsappTransport() === 'WEB' ? Date.now() + 7 * DAY : binding.lastInboundAt!.getTime() + DAY - 60000) } });
  return bindings.length;
}
export async function queueWhatsAppReply(binding: WhatsAppBinding, reference: string, text: string, documentId?: string) {
  if (whatsappTransport() === 'CLOUD' && (!binding.lastInboundAt || binding.lastInboundAt.getTime() + DAY <= Date.now() + 60000)) return;
  return db.whatsAppOutbox.upsert({ where: { reference }, create: { bindingId: binding.id, reference, text: text.slice(0, 3800), documentId, sendBefore: new Date(whatsappTransport() === 'WEB' ? Date.now() + DAY : binding.lastInboundAt!.getTime() + DAY - 60000) }, update: {} });
}
export async function enqueueWhatsAppMessage(message: WhatsAppMessage, media?: { bytes: Uint8Array; mimeType: string; fileName: string }) {
  if (!whatsappConfigured()) return { accepted: false };
  const sender = whatsappPhone(message.sender);
  if (!Number.isSafeInteger(message.timestamp) || message.timestamp * 1000 > Date.now() + 60000 || message.timestamp * 1000 < Date.now() - DAY) return { accepted: false };
  const groupId = message.groupId || null;
  if (groupId && whatsappTransport() === 'CLOUD' && process.env.WHATSAPP_GROUPS_ENABLED !== 'true') return { accepted: false };
  const conversation = groupId || sender;
  const binding = await db.whatsAppBinding.findUnique({ where: { phone_conversation: { phone: sender, conversation } }, include: { user: true } });
  if (!binding?.active || binding.user.disabled || !binding.user.accessReady) return { accepted: false };
  if (await db.whatsAppInbound.findUnique({ where: { id: message.id } })) return { accepted: true, duplicate: true };
  if (await db.whatsAppInbound.count({ where: { bindingId: binding.id, status: { in: ['PENDING', 'PROCESSING'] } } }) >= 100 || await db.whatsAppInbound.count({ where: { status: { in: ['PENDING', 'PROCESSING'] } } }) >= 1000) throw new HttpError(429, 'File WhatsApp occupée. Réessayez plus tard.');
  let key: string | undefined;
  if (media) {
    if (!media.bytes.length || media.bytes.length > MAX_FILE_BYTES) throw new HttpError(413, 'Pièce limitée à 10 Mo.');
    const mime = fileMime(media.bytes) || videoMime(media.bytes); if (!mime) throw new HttpError(400, 'Format de pièce non reconnu.');
    key = await storeFile(media.bytes); message = { ...message, storageKey: key, mimeType: mime, fileName: media.fileName.replace(/[\x00-\x1f/\\]/g, '_').slice(0, 100), bytes: media.bytes.length };
  }
  try {
    const result = await serializable(async tx => {
      if (await tx.whatsAppInbound.findUnique({ where: { id: message.id } })) return { accepted: true, duplicate: true, discardedKey: key };
      const ready = await tx.whatsAppBinding.findFirst({ where: { id: binding.id, active: true, user: { disabled: false, accessReady: true } } });
      if (!ready) throw new HttpError(403, 'Accès WhatsApp indisponible.');
      const queued = await tx.whatsAppInbound.count({ where: { bindingId: binding.id, status: { in: ['PENDING', 'PROCESSING'] } } }); if (queued >= 100) throw new HttpError(429, 'File WhatsApp occupée.');
      await tx.whatsAppInbound.create({ data: { id: message.id, bindingId: binding.id, payload: message, messageAt: new Date(message.timestamp * 1000) } });
      await tx.whatsAppBinding.updateMany({ where: { id: binding.id, OR: [{ lastInboundAt: null }, { lastInboundAt: { lt: new Date(message.timestamp * 1000) } }] }, data: { lastInboundAt: new Date(message.timestamp * 1000) } });
      return { accepted: true, duplicate: false };
    });
    if ('discardedKey' in result && result.discardedKey) await removeFile(result.discardedKey);
    return { accepted: result.accepted, duplicate: result.duplicate };
  } catch (error) { if (key) await removeFile(key); throw error; }
}
function uuidFor(value: string) { const hash = createHash('sha256').update(value).digest('hex'); return `${hash.slice(0, 8)}-${hash.slice(8, 12)}-4${hash.slice(13, 16)}-a${hash.slice(17, 20)}-${hash.slice(20, 32)}`; }
async function activeDraft(binding: WhatsAppBinding) { return db.whatsAppDraft.findFirst({ where: { bindingId: binding.id, status: { in: ['OPEN', 'SUBMITTING'] } }, orderBy: { createdAt: 'desc' } }); }
async function nextPrompt(id: string, userId: string) {
  const view = await getWhatsAppDraft(id, userId);
  const definitions = z.array(fieldDefinition).parse(view.draft.service.fields);
  const next = definitions.find(field => field.required && !(view.draft.fields as Record<string,string>)[field.key]?.trim());
  await db.whatsAppDraft.updateMany({ where: { id, status: 'OPEN' }, data: { pendingFieldKey: next?.key || null } });
  return next ? `\nRépondez simplement avec : ${next.label}${next.type === 'date' ? ' (AAAA-MM-JJ)' : ''}.` : '';
}
async function attachMessageFile(binding: WhatsAppBinding, job: WhatsAppInbound, message: WhatsAppMessage) {
  if (await db.whatsAppFile.findUnique({ where: { sourceMessageId: job.id } })) return 'Pièce déjà enregistrée.';
  const draft = await activeDraft(binding);
  if (!draft || draft.status !== 'OPEN') { if (message.storageKey) await removeFile(message.storageKey); return 'Choisissez d’abord la démarche (/cg, /ww, /fiche po, /ecra…), puis renvoyez les pièces de ce dossier.'; }
  const [draftFiles, userFiles] = await Promise.all([db.whatsAppFile.count({ where: { draftId: draft.id } }), db.whatsAppFile.count({ where: { draft: { userId: draft.userId }, createdAt: { gt: new Date(Date.now() - 30 * DAY) } } })]);
  if (draftFiles >= 20 || userFiles >= 100) throw new HttpError(429, 'Limite de pièces atteinte. Contactez le support.');
  let key = message.storageKey;
  const media = key ? { bytes: await loadFile(key), mimeType: message.mimeType! } : await downloadWhatsAppMedia(message.mediaId || '');
  if (!key) key = await storeFile(media.bytes);
  const service = await db.service.findUniqueOrThrow({ where: { id: draft.serviceId } }); const definitions = z.array(documentDefinition).parse(service.requiredDocuments);
  const pending = definitions.find(def => def.key === draft.pendingDocumentKey);
  const role = pending?.key === 'buyer_identity' ? 'buyer_identity' : pending?.key === 'holder_identity' ? 'holder_identity' : pending?.key === 'registration_certificate' ? 'registration' : 'unknown';
  let fields: Record<string, string> = {}, warnings: string[] = [], ocrStatus = 'DONE', fieldKey = pending?.key || null;
  try {
    if (media.mimeType.startsWith('video/')) { ocrStatus = 'NOT_APPLICABLE'; warnings = ['Vidéo conservée, sans OCR.']; }
    else { const result = await extractDocument(media.bytes, media.mimeType, message.fileName, { role }); fields = result.fields; warnings = result.warnings; if (!fieldKey && result.documentType === 'registration') fieldKey = definitions.find(def => def.key === 'registration_certificate')?.key || null; }
  } catch { ocrStatus = 'MANUAL_REQUIRED'; warnings = ['Lecture automatique indisponible. La pièce est conservée : vérifiez et complétez les champs manuellement.']; }
  const definition = definitions.find(def => def.key === fieldKey);
  if (definition && ((definition.type === 'image' && !media.mimeType.startsWith('image/')) || (definition.type === 'video' && !media.mimeType.startsWith('video/')) || (definition.type !== 'video' && media.mimeType.startsWith('video/')))) { fieldKey = null; warnings.push('Cette pièce ne correspond pas au format demandé.'); }
  const allowed = z.array(fieldDefinition).parse(service.fields);
  const safeFields = Object.fromEntries(Object.entries(fields).filter(([name, value]) => allowed.some(field => field.key === name) && typeof value === 'string' && value.length <= 5000));
  try {
    await serializable(async tx => {
      const current = await tx.whatsAppDraft.findUniqueOrThrow({ where: { id: draft.id } });
      if (current.status !== 'OPEN') throw new HttpError(409, 'Le brouillon est déjà en cours de dépôt.');
      if (await tx.whatsAppFile.findUnique({ where: { sourceMessageId: job.id } })) return;
      // OCR never overwrites a value already entered/reviewed by the person.
      const existing = current.fields as Record<string, string>;
      const additions = Object.fromEntries(Object.entries(safeFields).filter(([name]) => !existing[name]?.trim()));
      await tx.whatsAppFile.create({ data: { draftId: draft.id, sourceMessageId: job.id, storageKey: key!, fileName: message.fileName || `piece-${job.id.slice(-8)}`, mimeType: media.mimeType, bytes: media.bytes.length, fieldKey, ocrStatus, warnings } });
      await tx.whatsAppDraft.update({ where: { id: draft.id }, data: { fields: { ...existing, ...additions }, version: { increment: 1 }, reviewedVersion: null, reviewSnapshot: Prisma.DbNull, pendingDocumentKey: null } });
    });
  } catch (error) { if (!await db.whatsAppFile.findUnique({ where: { sourceMessageId: job.id } })) await removeFile(key); throw error; }
  return `Pièce enregistrée${fieldKey ? ` (${fieldKey})` : ' — type à préciser dans le récapitulatif'}. ${warnings.join(' ')}\n${await whatsappDraftSummary(draft.id, draft.userId)}${await nextPrompt(draft.id, draft.userId)}`;
}
async function handleWhatsAppJob(binding: WhatsAppBinding, job: WhatsAppInbound) {
  const message = job.payload as unknown as WhatsAppMessage; const command = whatsappCommand(message.text || ''); const media = message.type !== 'text';
  const reply = (text: string, suffix = 'reply', documentId?: string) => queueWhatsAppReply(binding, `${job.id}:${suffix}`, text, documentId);
  if (command?.command === 'start') {
    const previous = await db.whatsAppDraft.findUnique({ where: { sourceMessageId: job.id } });
    let draft = previous || await activeDraft(binding);
    if (draft && draft.serviceId !== command.serviceId) { await reply('Un brouillon est déjà ouvert. Envoyez /voir pour le reprendre, ou /annuler avant de changer de démarche.'); return; }
    if (!draft) {
      if (await db.whatsAppDraft.count({ where: { userId: binding.userId, status: { in: ['OPEN', 'SUBMITTING'] } } }) >= 10) throw new HttpError(429, 'Trop de brouillons ouverts.');
      const service = await db.service.findFirst({ where: { id: command.serviceId, active: true } }); if (!service) throw new HttpError(404, 'Prestation indisponible.');
      draft = await db.whatsAppDraft.create({ data: { bindingId: binding.id, userId: binding.userId, serviceId: service.id, sourceMessageId: job.id } });
    }
    if (!media) { const service = await db.service.findUniqueOrThrow({ where: { id: draft.serviceId } }); const docs = z.array(documentDefinition).parse(service.requiredDocuments); await reply(`Dossier ${service.name} ouvert. Envoyez les photos/PDF du même dossier.\n${docs.map(def => `${def.label}${def.required ? ' (requise)' : ' (facultative)'} : /piece ${def.key}`).join('\n')}\n/voir pour contrôler les données et les champs à compléter. Aucun débit.${await nextPrompt(draft.id, draft.userId)}`); return; }
  } else if (command?.command === 'classer') {
    const draft = await activeDraft(binding); if (!draft || draft.status !== 'OPEN') throw new HttpError(409, 'Ouvrez d’abord un brouillon.');
    const match = command.argument.match(/^(\d{1,2})\s+([a-zA-Z][a-zA-Z0-9_]{0,99})$/);
    if (!match) throw new HttpError(400, 'Format : /classer NUMERO_PIECE CLE. Consultez /voir pour les pièces numérotées et les types disponibles.');
    const view = await getWhatsAppDraft(draft.id, binding.userId), file = view.draft.files[Number(match[1]) - 1];
    if (!file) throw new HttpError(400, 'Numéro de pièce inconnu.');
    await editWhatsAppDraft(draft.id, binding.userId, false, { action: 'update', expectedVersion: draft.version, fields: {}, files: [{ id: file.id, fieldKey: match[2] }] });
    await reply(`Pièce classée. Vérifiez les champs extraits avec /voir et complétez ceux qui manquent. Aucun paiement.`); return;
  } else if (command?.command === 'piece') {
    const draft = await activeDraft(binding); if (!draft || draft.status !== 'OPEN') throw new HttpError(409, 'Ouvrez d’abord un dossier avec une commande.');
    const service = await db.service.findUniqueOrThrow({ where: { id: draft.serviceId } }); const docs = z.array(documentDefinition).parse(service.requiredDocuments);
    if (!docs.some(def => def.key === command.argument)) throw new HttpError(400, `Type de pièce attendu : ${docs.map(def => `${def.label} (/piece ${def.key})`).join(' ; ')}`);
    await db.whatsAppDraft.update({ where: { id: draft.id }, data: { pendingDocumentKey: command.argument } });
    if (!media) { await reply(`Envoyez maintenant : ${docs.find(def => def.key === command.argument)!.label}.`); return; }
  } else if (media && command) { await reply('Envoyez la pièce avant de confirmer le dossier. Utilisez /voir pour vérifier son contenu.'); return; }
  if (media) { await reply(await attachMessageFile(binding, job, message)); return; }
  if (!command || ['champ', 'nom', 'voir', 'reprendre', 'valider', 'annuler'].includes(command.command)) {
    const draft = await activeDraft(binding);
    if (!draft) { await reply('Aucun brouillon ouvert. Choisissez la démarche avant d’envoyer des documents.\n' + whatsappHelp); return; }
    if (draft.status === 'SUBMITTING') { await reply('Dépôt en cours. Patientez avant de renvoyer une commande.'); return; }
    if (command?.command === 'annuler') { await editWhatsAppDraft(draft.id, binding.userId, false, { action: 'cancel', expectedVersion: draft.version }); await reply('Brouillon annulé. Aucun montant débité.'); return; }
    if (command?.command === 'valider') { const result = await editWhatsAppDraft(draft.id, binding.userId, false, { action: 'submit', expectedVersion: draft.version }); const order = await db.order.findUniqueOrThrow({ where: { id: result.draft.orderId! } }); await reply(`Dossier #${order.number} déposé sur votre compte. ${order.requiresQuote ? 'Vous recevrez un devis à accepter avant paiement.' : `Montant : ${euro(order.priceCents)}. /payer ${order.number} pour obtenir une facture crypto.`} Aucun débit automatique.`); return; }
    if (command?.command === 'champ') {
      const match = command.argument.match(/^([a-zA-Z][a-zA-Z0-9_]{0,49})\s*=\s*([\s\S]{0,5000})$/); if (!match) throw new HttpError(400, 'Format : /champ CLE=VALEUR. Consultez /voir pour les noms de champs.');
      await editWhatsAppDraft(draft.id, binding.userId, false, { action: 'update', expectedVersion: draft.version, fields: { [match[1]]: match[2].trim() } });
    } else if (command?.command === 'nom') await editWhatsAppDraft(draft.id, binding.userId, false, { action: 'update', expectedVersion: draft.version, fields: {}, customerName: command.argument });
    else if (!command && message.text?.trim()) {
      const view = await getWhatsAppDraft(draft.id, binding.userId); const fields = z.array(fieldDefinition).parse(view.draft.service.fields); const empty = fields.filter(field => field.required && !(draft.fields as Record<string, string>)[field.key]?.trim());
      if (draft.pendingFieldKey && empty.some(field => field.key === draft.pendingFieldKey)) { const field = empty.find(field => field.key === draft.pendingFieldKey)!; await editWhatsAppDraft(draft.id, binding.userId, false, { action: 'update', expectedVersion: draft.version, fields: { [field.key]: message.text.trim().slice(0, 5000) } }); }
      else { await reply('Consultez /voir pour savoir quelle information compléter, ou utilisez /champ CLE=VALEUR pour corriger une donnée.'); return; }
    }
    const updated = await db.whatsAppDraft.findUniqueOrThrow({ where: { id: draft.id } });
    if (command?.command === 'voir' || command?.command === 'reprendre') { const summary = await whatsappDraftSummary(draft.id, binding.userId); if (summary.length <= 3800) await editWhatsAppDraft(draft.id, binding.userId, false, { action: 'review', expectedVersion: updated.version }); }
    const view = await getWhatsAppDraft(draft.id, binding.userId); const definitions = z.array(fieldDefinition).parse(view.draft.service.fields); const next = definitions.find(field => field.required && !(view.draft.fields as Record<string, string>)[field.key]?.trim());
    await reply(`${await whatsappDraftSummary(draft.id, binding.userId)}${await nextPrompt(draft.id, binding.userId)}`); return;
  }
  if (command.command === 'aide' || command.command === 'help' || command.command === 'start') { await reply(whatsappHelp); return; }
  if (command.command === 'solde') { const user = await db.user.findUniqueOrThrow({ where: { id: binding.userId } }); await reply(`Solde disponible : ${euro(user.balanceCents)}. Aucun retrait ni débit de portefeuille n’est déclenché par ce bot.`); return; }
  if (command.command === 'statut' || command.command === 'devis') { const orders = await db.order.findMany({ where: { userId: binding.userId, ...(command.command === 'devis' ? { status: 'QUOTE_PROPOSED' } : {}) }, orderBy: { createdAt: 'desc' }, take: 5 }); await reply(orders.length ? orders.map(order => `#${order.number} ${order.serviceName} : ${statusLabels[order.status]}${order.status === 'QUOTE_PROPOSED' ? ` · ${euro(order.priceCents)}\n/accepter ${order.number} ${order.quoteVersion} ou /refuser ${order.number} ${order.quoteVersion}` : ''}`).join('\n') : 'Aucun dossier correspondant.'); return; }
  if (command.command === 'support') { if (command.argument.length < 3) throw new HttpError(400, 'Format : /support votre message et la référence du dossier.'); await serializable(async tx => { const targetId = `whatsapp-support:${job.id}`; if (await tx.auditLog.findFirst({ where: { targetId, action: 'WHATSAPP_SUPPORT' } })) return; await queueAdmins(tx, `💬 Support WhatsApp — compte ${binding.userId}\n${command.argument.slice(0, 2500)}`); await tx.auditLog.create({ data: { actorId: binding.userId, action: 'WHATSAPP_SUPPORT', targetId, details: { text: command.argument.slice(0, 2500) } } }); }); await reply('Votre demande est transmise à l’équipe.'); return; }
  if (['payer', 'livrable', 'accepter', 'refuser'].includes(command.command)) {
    const match = command.argument.match(/^#?(\d+)(?:\s+(\d+))?$/); if (!match) throw new HttpError(400, `Format : /${command.command} NUMERO${['accepter', 'refuser'].includes(command.command) ? ' VERSION' : ''}.`);
    const order = await db.order.findFirst({ where: { number: Number(match[1]), userId: binding.userId } }); if (!order) throw new HttpError(404, 'Dossier introuvable sur votre compte.');
    if (command.command === 'accepter' || command.command === 'refuser') { const version = Number(match[2]); if (!Number.isSafeInteger(version) || version < 1) throw new HttpError(400, 'Consultez /devis pour le numéro de version à confirmer.'); await decideOrderQuote(order.id, binding.userId, { action: command.command === 'accepter' ? 'accept' : 'reject', quoteVersion: version }); await reply(command.command === 'accepter' ? `Devis accepté. /payer ${order.number} pour obtenir la facture crypto.` : 'Devis refusé. Aucun débit.'); return; }
    if (command.command === 'payer') { const payment = await createPayment({ userId: binding.userId, orderId: order.id, amountCents: order.priceCents, payCurrency: 'usdttrc20', idempotencyKey: uuidFor(job.id) }); if (!payment.invoiceUrl) throw new HttpError(409, 'La facture est en cours de création. Vérifiez son état avant toute nouvelle demande.'); await reply(`Dossier #${order.number} · ${euro(payment.amountCents)}\nFacture crypto USDT TRC20 : ${payment.invoiceUrl}\nVérifiez le montant et le réseau avant de payer. Aucun débit de portefeuille.`); return; }
    const document = await db.document.findFirst({ where: { orderId: order.id, ownerId: binding.userId, kind: 'DELIVERABLE' }, orderBy: { createdAt: 'desc' } });
    if (order.status !== 'COMPLETED' || !document) throw new HttpError(409, 'Aucun livrable final disponible pour ce dossier.');
    await reply(`Livrable du dossier #${order.number} : ${document.fileName}`, 'deliverable', document.id); return;
  }
  await reply(whatsappHelp);
}
export async function processWhatsAppJobs() {
  if (!whatsappConfigured()) return { configured: false, processed: 0 };
  const stale = new Date(Date.now() - 5 * 60000);
  await db.whatsAppInbound.updateMany({ where: { status: 'PROCESSING', lockedAt: { lt: stale } }, data: { status: 'PENDING', lockedAt: null } });
  await db.whatsAppBinding.updateMany({ where: { processingAt: { lt: stale } }, data: { processingAt: null } });
  const candidates = await db.whatsAppInbound.findMany({ where: { status: 'PENDING' }, orderBy: [{ messageAt: 'asc' }, { createdAt: 'asc' }], take: 20 });
  for (const job of candidates) {
    const binding = await db.whatsAppBinding.findUnique({ where: { id: job.bindingId }, include: { user: true } });
    if (!binding?.active || binding.user.disabled || !binding.user.accessReady || (binding.groupId && whatsappTransport() === 'CLOUD' && process.env.WHATSAPP_GROUPS_ENABLED !== 'true') || job.messageAt.getTime() + DAY < Date.now()) { await db.whatsAppInbound.update({ where: { id: job.id }, data: { status: 'IGNORED', payload: {} } }); continue; }
    const claimed = await db.whatsAppBinding.updateMany({ where: { id: binding.id, processingAt: null, active: true }, data: { processingAt: new Date() } }); if (!claimed.count) continue;
    try {
      const claim = await db.whatsAppInbound.updateMany({ where: { id: job.id, status: 'PENDING' }, data: { status: 'PROCESSING', lockedAt: new Date(), attempts: { increment: 1 } } }); if (!claim.count) continue;
      await handleWhatsAppJob(binding, job);
      await db.whatsAppInbound.update({ where: { id: job.id }, data: { status: 'DONE', lockedAt: null, error: null, payload: {} } });
    } catch (error) {
      const message = error instanceof HttpError && error.status < 500 ? error.message : 'Traitement interrompu. La pièce ou le dossier doit être vérifié ; aucune opération financière automatique.';
      await db.whatsAppInbound.update({ where: { id: job.id }, data: { status: 'FAILED', lockedAt: null, error: message.slice(0, 500) } });
      await queueWhatsAppReply(binding, `${job.id}:error`, message);
    } finally { await db.whatsAppBinding.update({ where: { id: binding.id }, data: { processingAt: null } }); }
    return { configured: true, processed: 1 };
  }
  return { configured: true, processed: 0 };
}
export async function processWhatsAppOutbox() {
  if (!whatsappConfigured()) return { configured: false, sent: 0 };
  await db.whatsAppOutbox.updateMany({ where: { status: 'PENDING', sendBefore: { lte: new Date() } }, data: { status: 'EXPIRED', error: 'Fenêtre de réponse expirée. Le client doit réécrire.' } });
  const items = await db.whatsAppOutbox.findMany({ where: { status: 'PENDING' }, include: { binding: { include: { user: { select: { disabled: true, accessReady: true } } } } }, orderBy: { createdAt: 'asc' }, take: 3 });
  let sent = 0;
  await Promise.all(items.map(async item => {
    if (!item.binding.active || item.binding.user.disabled || !item.binding.user.accessReady || (item.binding.groupId && whatsappTransport() === 'CLOUD' && process.env.WHATSAPP_GROUPS_ENABLED !== 'true')) { await db.whatsAppOutbox.update({ where: { id: item.id }, data: { status: 'CANCELLED' } }); return; }
    const claimed = await db.whatsAppOutbox.updateMany({ where: { id: item.id, status: 'PENDING' }, data: { status: 'SENDING', attempts: { increment: 1 } } }); if (!claimed.count) return;
    try {
      const providerMessageId = await sendWhatsAppText({ id: item.id, phone: item.binding.phone, conversation: item.binding.conversation, groupId: item.binding.groupId, text: item.text, ...(item.documentId ? { documentId: item.documentId, userId: item.binding.userId } : {}) });
      await db.whatsAppOutbox.update({ where: { id: item.id }, data: { status: 'SENT', sentAt: new Date(), providerMessageId, error: null } }); sent++;
    } catch { await db.whatsAppOutbox.update({ where: { id: item.id }, data: { status: 'UNKNOWN', error: 'Résultat d’envoi inconnu. Vérifiez le connecteur avant de renvoyer ; aucun renvoi automatique.' } }); }
  }));
  return { configured: true, sent };
}
