import type { Prisma } from "@prisma/client";
import { telegramBot } from "./integrations";
import { adminTelegramIds } from "./auth";
import { db } from "./db";

export async function queueNotification(
  tx: Prisma.TransactionClient,
  chatId: string | null,
  text: string,
) {
  if (!chatId) return null; // Web clients may connect Telegram later.
  if (!/^-?\d+$/.test(chatId)) throw new Error("Invalid Telegram chat ID");
  const url = process.env.MINI_APP_URL ?? process.env.APP_URL;
  return tx.notificationOutbox.create({
    data: { chatId, text: `${text.slice(0, 3500)}${url ? `\n${url}` : ""}` },
  });
}

export async function queueAdmins(tx: Prisma.TransactionClient, text: string) {
  for (const id of adminTelegramIds()) await queueNotification(tx, id, text);
}

/** Durable at-least-once delivery. A stale lock is reclaimed after five minutes. */
export async function processNotifications() {
  if (!process.env.TELEGRAM_BOT_TOKEN)
    return { configured: false, sent: 0, failed: 0 };
  const bot = telegramBot();
  const deadline = Date.now() + 20_000;
  const stale = new Date(Date.now() - 5 * 60_000);
  const ready = await db.notificationOutbox.findMany({
    where: {
      sentAt: null,
      attempts: { lt: 10 },
      nextAttemptAt: { lte: new Date() },
      OR: [{ lockedAt: null }, { lockedAt: { lt: stale } }],
    },
    orderBy: { createdAt: "asc" },
    take: 25,
  });
  let sent = 0;
  let failed = 0;
  for (const message of ready) {
    if (Date.now() >= deadline) break;
    const claimed = await db.notificationOutbox.updateMany({
      where: {
        id: message.id,
        sentAt: null,
        attempts: message.attempts,
        nextAttemptAt: { lte: new Date() },
        OR: [{ lockedAt: null }, { lockedAt: { lt: stale } }],
      },
      data: { lockedAt: new Date(), attempts: { increment: 1 } },
    });
    if (!claimed.count) continue;
    try {
      // Plain text avoids interpreting client-supplied Markdown or HTML.
      await bot.api.sendMessage(message.chatId, message.text, {
        link_preview_options: { is_disabled: true },
      });
      await db.notificationOutbox.update({
        where: { id: message.id },
        data: { sentAt: new Date(), lockedAt: null },
      });
      sent++;
    } catch {
      await db.notificationOutbox.update({
        where: { id: message.id },
        data: {
          lockedAt: null,
          nextAttemptAt: new Date(
            Date.now() + Math.min(3600, 30 * 2 ** message.attempts) * 1000,
          ),
        },
      });
      failed++;
    }
  }
  return { configured: true, sent, failed };
}
