import { mkdir, readFile, writeFile, unlink } from "node:fs/promises";
import { resolve, relative, isAbsolute } from "node:path";
import { randomUUID } from "node:crypto";
import { integrationEndpoint } from "./integrations";
import { HttpError } from "./http";

export const MAX_FILE_BYTES = 10 * 1024 * 1024;
export const MAX_VIDEO_BYTES = 25 * 1024 * 1024;
function directory() {
  const root = resolve(process.env.PRIVATE_UPLOAD_DIR ?? ".private/uploads");
  const publicRoot = resolve("public");
  const rel = relative(publicRoot, root);
  if (rel === "" || (!rel.startsWith("..") && !isAbsolute(rel)))
    throw new HttpError(503, "Le stockage doit être privé.");
  return root;
}

export function fileMime(bytes: Uint8Array): string | null {
  if (
    bytes.length >= 5 &&
    Buffer.from(bytes.subarray(0, 5)).toString("ascii") === "%PDF-"
  )
    return "application/pdf";
  if (
    bytes.length >= 8 &&
    Buffer.from(bytes.subarray(0, 8)).equals(
      Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    )
  )
    return "image/png";
  if (
    bytes.length >= 3 &&
    bytes[0] === 255 &&
    bytes[1] === 216 &&
    bytes[2] === 255
  )
    return "image/jpeg";
  return null;
}

/** Recognise ISO-BMFF MP4 / QuickTime containers, never infer type from extension. */
export function videoMime(bytes: Uint8Array): string | null {
  if (bytes.length < 16) return null;
  const header = Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const size = header.readUInt32BE(0);
  if (size < 16 || size > bytes.length || header.toString("ascii", 4, 8) !== "ftyp") return null;
  const brand = header.toString("ascii", 8, 12);
  if (brand === "qt  ") return "video/quicktime";
  return ["isom", "iso2", "mp41", "mp42", "avc1", "M4V ", "M4VH", "M4VP", "MSNV"].includes(brand) ? "video/mp4" : null;
}
export function attachmentMime(bytes: Uint8Array, kind: "document" | "image" | "video" = "document") {
  if (kind === "video") return videoMime(bytes);
  const mime = fileMime(bytes);
  return kind === "image" && !mime?.startsWith("image/") ? null : mime;
}

function path(key: string) {
  if (!/^[0-9a-f-]{36}$/.test(key))
    throw new HttpError(400, "Identifiant de fichier invalide");
  return resolve(directory(), key);
}
async function storageRequest(key: string, method: string, bytes?: Uint8Array) {
  if (!/^[0-9a-f-]{36}$/.test(key)) throw new HttpError(400,"Identifiant de fichier invalide");
  const endpoint=integrationEndpoint("TEST_SUPABASE_STORAGE_ROOT",process.env.SUPABASE_URL || "");
  const token=process.env.SUPABASE_SERVICE_ROLE_KEY, bucket=process.env.SUPABASE_STORAGE_BUCKET;
  if(!endpoint || !token || !bucket || !/^[a-zA-Z0-9_-]+$/.test(bucket))throw new HttpError(503,"Stockage privé Supabase non configuré.");
  let url:URL;try{url=new URL(endpoint);if(url.protocol!=="https:" && !(process.env.KOMISIO_INTEGRATION_TEST_MODE === "true" && process.env.NODE_ENV !== "production" && url.hostname === "127.0.0.1"))throw Error();}catch{throw new HttpError(503,"URL de stockage privé invalide.");}
  const bucketResponse=await fetch(`${url.origin}/storage/v1/bucket/${encodeURIComponent(bucket)}`,{headers:{authorization:`Bearer ${token}`,apikey:token},cache:"no-store",redirect:"error",signal:AbortSignal.timeout(10000)});
  if(!bucketResponse.ok || (await bucketResponse.json()).public !== false) throw new HttpError(503,"Le bucket Supabase doit être privé.");
  const response=await fetch(`${url.origin}/storage/v1/object/${encodeURIComponent(bucket)}${method === "DELETE" ? "" : `/${key}`}`,{method,headers:{authorization:`Bearer ${token}`,apikey:token,"content-type":method === "DELETE" ? "application/json" : "application/octet-stream",...(method === "POST" ? {"x-upsert":"false"} : {})},body:method === "DELETE" ? JSON.stringify({prefixes:[key]}) : bytes ? new Uint8Array(bytes) : undefined,cache:"no-store",redirect:"error",signal:AbortSignal.timeout(20000)});
  if(!response.ok && !(method === "DELETE" && response.status === 404))throw new HttpError(503,"Stockage privé momentanément indisponible.");
  return response;
}
export async function storeFile(bytes: Uint8Array) {
  const key = randomUUID();
  if(process.env.STORAGE_DRIVER === "supabase") { await storageRequest(key,"POST",bytes); return key; }
  await mkdir(directory(), { recursive: true, mode: 0o700 });
  await writeFile(path(key), bytes, { flag: "wx", mode: 0o600 }); return key;
}
export async function loadFile(key:string) { return process.env.STORAGE_DRIVER === "supabase" ? Buffer.from(await (await storageRequest(key,"GET")).arrayBuffer()) : readFile(path(key)); }
export async function removeFile(key:string) {
  if(process.env.STORAGE_DRIVER === "supabase") { await storageRequest(key,"DELETE"); return; }
  await unlink(path(key)).catch(()=>undefined);
}

/** Bound multipart parsing even for chunked requests without Content-Length. */
export async function boundedFormData(request: Request, maxFileBytes = MAX_FILE_BYTES) {
  const max = maxFileBytes + 64_000;
  const limitMessage = `Taille maximale : ${Math.floor(maxFileBytes / 1024 / 1024)} Mo.`;
  if (Number(request.headers.get("content-length") ?? 0) > max)
    throw new HttpError(413, limitMessage);
  const reader = request.body?.getReader();
  if (!reader) throw new HttpError(400, "Fichier absent");
  const chunks: Uint8Array[] = [];
  let size = 0;
  while (true) {
    const part = await reader.read();
    if (part.done) break;
    size += part.value.length;
    if (size > max) {
      await reader.cancel();
      throw new HttpError(413, limitMessage);
    }
    chunks.push(part.value);
  }
  const bytes = Buffer.concat(chunks);
  return new Response(bytes, {
    headers: { "content-type": request.headers.get("content-type") ?? "" },
  }).formData();
}
