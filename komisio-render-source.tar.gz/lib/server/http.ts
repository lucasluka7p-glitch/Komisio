import { Prisma } from "@prisma/client";
import { ZodError } from "zod";

export class HttpError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
  }
}

export function json(data: unknown, status = 200) {
  return Response.json(data, {
    status,
    headers: { "Cache-Control": "no-store" },
  });
}

export function handle<T extends unknown[]>(
  handler: (...args: T) => Promise<Response>,
) {
  return async (...args: T): Promise<Response> => {
    try {
      const response = await handler(...args);
      const request = args[0];
      const pathname =
        request instanceof Request ? new URL(request.url).pathname : "";
      if (
        request instanceof Request &&
        (!["GET", "HEAD", "OPTIONS"].includes(request.method) ||
          /^\/api\/payments\/[^/]+$/.test(pathname)) &&
        !pathname.startsWith("/api/cron/")
      ) {
        // Send immediately after the response, with the persistent outbox as retry fallback.
        const { after } = await import("next/server");
        after(async () => {
          try {
            const { processNotifications } = await import("./telegram");
            await processNotifications();
          } catch {
            console.error(
              "Notification outbox dispatch failed; cron will retry.",
            );
          }
        });
      }
      return response;
    } catch (error) {
      if (error instanceof HttpError)
        return json({ error: error.message }, error.status);
      if (error instanceof ZodError)
        return json({ error: "Données invalides", issues: error.issues }, 400);
      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        error.code === "P2002"
      )
        return json(
          { error: "Cette opération existe déjà. Actualisez puis réessayez." },
          409,
        );
      if (error instanceof SyntaxError)
        return json({ error: "JSON invalide" }, 400);
      console.error(
        "API error",
        error instanceof Error ? error.name : "unknown",
      );
      return json({ error: "Une erreur interne est survenue." }, 500);
    }
  };
}

export const MAX_JSON_BYTES = 128_000;

export async function body(request: Request) {
  if (Number(request.headers.get("content-length") ?? 0) > MAX_JSON_BYTES)
    throw new HttpError(413, "Requête trop volumineuse");
  const reader = request.body?.getReader();
  if (!reader) throw new HttpError(400, "Corps JSON requis");
  const chunks: Uint8Array[] = [];
  let size = 0;
  while (true) {
    const chunk = await reader.read();
    if (chunk.done) break;
    size += chunk.value.byteLength;
    if (size > MAX_JSON_BYTES) {
      await reader.cancel();
      throw new HttpError(413, "Requête trop volumineuse");
    }
    chunks.push(chunk.value);
  }
  let raw: string;
  try {
    raw = new TextDecoder("utf-8", { fatal: true }).decode(
      Buffer.concat(chunks, size),
    );
  } catch {
    throw new HttpError(400, "Encodage JSON invalide");
  }
  return JSON.parse(raw);
}

/** Cookie-authenticated writes must come from our configured public origin. */
export function sameOrigin(request: Request) {
  const allowed = process.env.APP_URL;
  if (!allowed) throw new HttpError(503, "APP_URL non configurée");
  const origin = request.headers.get("origin");
  if (!origin || origin !== new URL(allowed).origin)
    throw new HttpError(403, "Origine refusée");
}
