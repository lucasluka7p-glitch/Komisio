import { queueCustomerNotification } from "./customer-notifications";
import type { z } from "zod";
import type { Prisma, WithdrawalStatus } from "@prisma/client";
import { db, serializable } from "./db";
import { HttpError } from "./http";
import { queueAdmins } from "./telegram";
import { calculateNet, type withdrawalInput, type withdrawalAction, type adminWithdrawalAction } from "./withdrawal-validation";

export async function requestWithdrawal(userId: string, input: z.infer<typeof withdrawalInput>) {
  if (process.env.WITHDRAWALS_ENABLED !== "true") throw new HttpError(503, "Les retraits ne sont pas encore activés. Aucun montant n’a été débité.");
  return serializable(async tx => {
    const duplicate = await tx.withdrawal.findUnique({ where: { userId_idempotencyKey: { userId, idempotencyKey: input.idempotencyKey } } });
    if (duplicate) {
      if (duplicate.amountCents !== input.amountCents || duplicate.address !== input.address || duplicate.currency !== input.currency) throw new HttpError(409, "Cette référence correspond à une autre demande.");
      return duplicate;
    }
    const user = await tx.user.findUniqueOrThrow({ where: { id: userId } });
    if (user.disabled || user.balanceCents < input.amountCents) throw new HttpError(409, "Solde disponible insuffisant ou compte indisponible.");
    if (await tx.withdrawal.count({ where: { userId, status: { in: ["REQUESTED", "QUOTED"] } } }) >= 5) throw new HttpError(409, "Vous avez déjà cinq demandes en attente de confirmation.");
    const withdrawal = await tx.withdrawal.create({ data: { ...input, userId } });
    await queueAdmins(tx, `💸 Demande de retrait ${withdrawal.id} : ${(input.amountCents / 100).toFixed(2)} € en USDT TRC20. Frais à proposer.`);
    return withdrawal;
  });
}
export async function actOnWithdrawal(id: string, actorId: string, admin: boolean, action: z.infer<typeof withdrawalAction> | z.infer<typeof adminWithdrawalAction>) {
  return serializable(async tx => {
    const w = await tx.withdrawal.findFirst({ where: { id, ...(!admin ? { userId: actorId } : {}) }, include: { user: true } });
    if (!w) throw new HttpError(404, "Retrait introuvable.");
    const invalid = () => { throw new HttpError(409, "Action indisponible dans ce statut. Actualisez le retrait."); };
    // Never trust the caller to pair an admin action with reseller permissions.
    if (!admin && !["accept", "cancel"].includes(action.action)) throw new HttpError(403, "Accès administrateur requis.");
    let data: Parameters<typeof tx.withdrawal.update>[0]["data"] = {};
    let message = "";
    if (action.action === "quote") {
      if (!["REQUESTED", "QUOTED"].includes(w.status)) return invalid();
      const netAmount = calculateNet(w.amountCents, action.feeCents, action.exchangeRate);
      data = { status: "QUOTED", feeCents: action.feeCents, exchangeRate: action.exchangeRate, netAmount, quoteSource: action.source, quoteVersion: { increment: 1 }, quoteExpiresAt: new Date(Date.now() + 15 * 60_000) };
      message = `Frais du retrait disponibles : ${(action.feeCents / 100).toFixed(2)} €. Net reçu : ${netAmount} USDT. Confirmez sous 15 minutes dans votre portefeuille.`;
    } else if (action.action === "accept") {
      if (admin) throw new HttpError(403, "Seul le titulaire peut accepter les frais.");
      if (action.quoteVersion !== w.quoteVersion) throw new HttpError(409, "Le devis a changé. Vérifiez les nouveaux frais.");
      if (["APPROVED", "PROCESSING", "SENT", "COMPLETED"].includes(w.status)) return w;
      if (w.status !== "QUOTED") return invalid();
      if (!w.quoteExpiresAt || w.quoteExpiresAt.getTime() <= Date.now()) throw new HttpError(409, "Ce devis a expiré. Annulez la demande pour en créer une nouvelle, ou attendez un nouveau devis.");
      const claim = await tx.user.updateMany({ where: { id: w.userId, disabled: false, balanceCents: { gte: w.amountCents } }, data: { balanceCents: { decrement: w.amountCents } } });
      if (!claim.count) throw new HttpError(409, "Solde disponible insuffisant.");
      const owner = await tx.user.findUniqueOrThrow({ where: { id: w.userId } });
      await tx.ledgerEntry.create({ data: { userId: w.userId, amountCents: -w.amountCents, balanceAfter: owner.balanceCents, kind: "WITHDRAWAL_HOLD", reference: `withdrawal:hold:${id}`, reason: `Réservation du retrait ${id}`, actorId } });
      data = { status: "APPROVED", acceptedAt: new Date() };
      message = "Retrait confirmé : le montant est réservé. L’administrateur prépare l’envoi.";
      await queueAdmins(tx, `💸 Retrait ${id} accepté par le revendeur. ${(w.amountCents / 100).toFixed(2)} € réservés. Vérifiez la trésorerie avant l’envoi.`);
    } else if (action.action === "cancel" || action.action === "reject") {
      const target = action.action === "cancel" ? "CANCELLED" : "REJECTED";
      if (w.status === target) return w;
      // Once sending starts there is no automatic release, even after timeout.
      if (!["REQUESTED", "QUOTED", "APPROVED"].includes(w.status)) return invalid();
      if (w.status === "APPROVED") {
        const owner = await tx.user.update({ where: { id: w.userId }, data: { balanceCents: { increment: w.amountCents } } });
        await tx.ledgerEntry.create({ data: { userId: w.userId, amountCents: w.amountCents, balanceAfter: owner.balanceCents, kind: "WITHDRAWAL_RELEASE", reference: `withdrawal:release:${id}`, reason: `Libération du retrait ${id}`, actorId } });
      }
      data = { status: target, note: action.action === "reject" ? action.note : "Annulé par le titulaire." };
      message = `Retrait ${target === "CANCELLED" ? "annulé" : "refusé"}. Tout montant réservé a été remis à disposition.${action.action === "reject" ? ` Motif : ${action.note}` : ""}`;
    } else if (action.action === "fail") {
      if (w.status === "FAILED") return w;
      if (!["PROCESSING", "SENT"].includes(w.status)) return invalid();
      // Explicit operator reconciliation only. A timeout or provider error is never sufficient.
      const owner = await tx.user.update({ where: { id: w.userId }, data: { balanceCents: { increment: w.amountCents } } });
      await tx.ledgerEntry.create({ data: { userId: w.userId, amountCents: w.amountCents, balanceAfter: owner.balanceCents, kind: "WITHDRAWAL_RELEASE", reference: `withdrawal:release:${id}`, reason: `Retrait ${id} : échec définitif vérifié par admin`, actorId } });
      data = { status: "FAILED", note: action.note };
      message = "Échec du retrait vérifié par l’administrateur. Le montant réservé a été remis à disposition.";
    } else if (action.action === "process") {
      if (w.status === "PROCESSING") return w;
      if (w.status !== "APPROVED") return invalid();
      data = { status: "PROCESSING" };
      message = "Votre retrait est en cours de préparation. Le montant reste réservé.";
    } else if (action.action === "sent") {
      const txHash = action.txHash.toLowerCase();
      if (["SENT", "COMPLETED"].includes(w.status) && w.txHash === txHash) return w;
      if (w.status !== "PROCESSING") return invalid();
      data = { status: "SENT", txHash };
      message = `Retrait déclaré envoyé sur TRON. Transaction : ${txHash}. Confirmation réseau en attente.`;
    } else if (action.action === "complete") {
      if (w.status === "COMPLETED") return w;
      if (w.status !== "SENT" || !w.txHash) return invalid();
      data = { status: "COMPLETED", note: action.note };
      message = `Retrait confirmé par l’administrateur après vérification du réseau. Transaction : ${w.txHash}.`;
    }
    const result = await tx.withdrawal.update({ where: { id }, data });
    await tx.auditLog.create({ data: { actorId, action: `withdrawal.${action.action}`, targetId: id, details: { from: w.status, to: result.status, quoteVersion: result.quoteVersion, feeCents: result.feeCents, netAmount: result.netAmount, txHash: result.txHash, note: result.note } } });
    await queueCustomerNotification(tx, w.user, `💸 Retrait ${id}\n${message}`);
    return result;
  });
}
export async function listWithdrawals(userId?: string) {
  // Never hide an old active request or omit its reserve behind the history limit.
  const active: WithdrawalStatus[] = ["REQUESTED", "QUOTED", "APPROVED", "PROCESSING", "SENT"];
  const owner: Prisma.WithdrawalWhereInput = userId ? { userId } : {};
  const include = userId ? undefined : { user: { select: { firstName: true, telegramId: true } } };
  const [pending, history] = await Promise.all([
    db.withdrawal.findMany({ where: { ...owner, status: { in: active } }, orderBy: { createdAt: "desc" }, include }),
    db.withdrawal.findMany({ where: { ...owner, status: { notIn: active } }, orderBy: { createdAt: "desc" }, take: 200, include }),
  ]);
  return [...pending, ...history].sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
}
