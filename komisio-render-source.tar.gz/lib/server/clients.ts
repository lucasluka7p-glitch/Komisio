import type { Prisma } from "@prisma/client";
import { db, serializable } from "./db";
import { HttpError } from "./http";
import { adminTelegramIds } from "./auth";
import { generatePassword, hashPassword } from "./passwords";
import { createClientInput, updateClientInput, clientPricingInput } from "./client-validation";
import type { z } from "zod";

// Explicit public projections: never return password hashes, lockouts or session versions.
export const publicUserSelect = { id: true, telegramId: true, username: true, firstName: true, role: true, disabled: true, balanceCents: true, login: true, accessReady: true, mustChangePassword: true, defaultDiscountBps: true, pricingVersion: true, createdAt: true, updatedAt: true } satisfies Prisma.UserSelect;
export const clientSelect = { ...publicUserSelect, credentialVersion: true, servicePrices: true, _count: { select: { orders: true } }, ledger: { orderBy: { createdAt: "desc" as const }, take: 50 }, orders: { select: { priceCents: true, paidAt: true, status: true } } } satisfies Prisma.UserSelect;
async function validateServices(tx: Prisma.TransactionClient, pricing: z.infer<typeof clientPricingInput>) {
  const count = await tx.service.count({ where: { id: { in: pricing.prices.map(price => price.serviceId) } } });
  if (count !== pricing.prices.length) throw new HttpError(400, "Une prestation de cette grille n’existe plus.");
}
async function assertClient(tx: Prisma.TransactionClient, id: string) {
  const client = await tx.user.findUnique({ where: { id } });
  if (!client) throw new HttpError(404, "Client introuvable.");
  if (client.role === "ADMIN" || (client.telegramId && adminTelegramIds().includes(client.telegramId))) throw new HttpError(403, "Cette action concerne uniquement les comptes clients.");
  return client;
}
export async function createClient(actorId: string, input: z.infer<typeof createClientInput>) {
  if (input.telegramId && adminTelegramIds().includes(input.telegramId)) throw new HttpError(400, "Cet identifiant Telegram est réservé à un administrateur.");
  const password = input.activate ? generatePassword() : null;
  const passwordHash = password ? await hashPassword(password) : null;
  const client = await serializable(async tx => {
    await validateServices(tx, input.pricing);
    const user = await tx.user.create({ data: {
      firstName: input.name, login: input.login, telegramId: input.telegramId, role: "RESELLER",
      accessReady: input.activate, passwordHash, mustChangePassword: input.activate,
      defaultDiscountBps: input.pricing.defaultDiscountBps, pricingVersion: 1,
      servicePrices: { create: input.pricing.prices.map(({ serviceId, ...rule }) => ({ serviceId, ...rule })) },
    }, select: clientSelect });
    await tx.auditLog.create({ data: { actorId, action: "CLIENT_CREATED", targetId: user.id, details: { login: user.login, activated: input.activate, pricing: input.pricing } } });
    return user;
  });
  return { client, ...(password ? { credentials: { login: client.login, password } } : {}) };
}
export async function updateClient(id: string, actorId: string, input: z.infer<typeof updateClientInput>) {
  return serializable(async tx => {
    const current = await assertClient(tx, id);
    if (current.pricingVersion !== input.expectedVersion) throw new HttpError(409, "La grille a changé. Actualisez ce client avant de modifier ses tarifs.");
    await validateServices(tx, input.pricing);
    await tx.clientServicePrice.deleteMany({ where: { userId: id } });
    const client = await tx.user.update({ where: { id }, data: {
      firstName: input.name, login: input.login, defaultDiscountBps: input.pricing.defaultDiscountBps,
      pricingVersion: { increment: 1 }, servicePrices: { create: input.pricing.prices.map(({ serviceId, ...rule }) => ({ serviceId, ...rule })) },
    }, select: clientSelect });
    await tx.auditLog.create({ data: { actorId, action: "CLIENT_PRICING_UPDATED", targetId: id, details: { previousVersion: current.pricingVersion, pricing: input.pricing } } });
    return { client };
  });
}
export async function clientAccessAction(id: string, actorId: string, action: "activate" | "reset" | "suspend" | "resume", expectedVersion: number) {
  const password = ["activate", "reset"].includes(action) ? generatePassword() : null;
  const passwordHash = password ? await hashPassword(password) : null;
  return serializable(async tx => {
    const current = await assertClient(tx, id);
    if (current.credentialVersion !== expectedVersion) throw new HttpError(409, "L’accès a changé. Actualisez ce client.");
    if (action === "activate" && current.accessReady) throw new HttpError(409, "Ce compte est déjà activé. Utilisez la réinitialisation.");
    if (action === "reset" && !current.accessReady) throw new HttpError(409, "Activez d’abord cet accès.");
    if (password && (!current.login || current.pricingVersion < 1)) throw new HttpError(409, "Enregistrez l’identifiant et la grille avant de générer un accès.");
    if (action === "resume" && (!current.accessReady || (!current.passwordHash && !current.telegramId))) throw new HttpError(409, "Générez d’abord un accès client.");
    const client = await tx.user.update({ where: { id }, data: { credentialVersion: { increment: 1 }, ...(password ? { passwordHash, mustChangePassword: true, accessReady: true, disabled: false } : { disabled: action === "suspend" }) }, select: clientSelect });
    await tx.auditLog.create({ data: { actorId, action: `CLIENT_ACCESS_${action.toUpperCase()}`, targetId: id, details: { login: current.login } } });
    return { client, ...(password ? { credentials: { login: current.login, password } } : {}) };
  });
}
export async function listClients() {
  const users = await db.user.findMany({ take: 500, orderBy: { createdAt: "desc" }, select: { ...clientSelect, credentialVersion: true } });
  return users;
}
