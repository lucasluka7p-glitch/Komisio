import { z } from "zod";
import { subcategories } from "../catalog";

export const currencies = [
  "usdttrc20",
  "usdterc20",
  "btc",
  "eth",
  "sol",
] as const;
export const idempotency = z.string().uuid();

/** Accept a real Gregorian date without allowing JavaScript's rollover behavior. */
export function validIsoDate(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parsed = new Date(`${value}T00:00:00.000Z`);
  return (
    Number.isFinite(parsed.getTime()) &&
    parsed.toISOString().slice(0, 10) === value
  );
}
export const fieldDefinition = z.object({
  key: z.string().regex(/^[a-zA-Z][a-zA-Z0-9_]{0,49}$/),
  label: z.string().min(1).max(150),
  type: z.enum(["text", "email", "date", "textarea", "select", "number"]),
  required: z.boolean(),
  options: z.array(z.string().min(1).max(150)).max(50).optional(),
});
export const documentDefinition = z.object({
  type: z.enum(["document", "image", "video"]).default("document"),
  key: z.string().regex(/^[a-zA-Z][a-zA-Z0-9_]{0,49}$/),
  label: z.string().min(1).max(150),
  required: z.boolean(),
});
export const serviceInput = z
  .object({
    slug: z
      .string()
      .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/)
      .max(100),
    name: z.string().min(3).max(150),
    description: z.string().min(10).max(2000),
    category: z.enum(["FORMALITES", "AUTOMOBILE", "ASSISTANCE"]),
    subcategory: z.string().max(80).nullish(),
    priceCents: z.number().int().min(0).max(10_000_000),
    requiresQuote: z.boolean().default(false),
    turnaround: z.string().min(1).max(100),
    active: z.boolean().default(true),
    fields: z.array(fieldDefinition).max(30),
    requiredDocuments: z.array(documentDefinition).max(20),
  })
  .superRefine((v, ctx) => {
    if (v.subcategory && !subcategories.some(group => group.id === v.subcategory && group.category === v.category.toLowerCase()))
      ctx.addIssue({ code: "custom", message: "Sous-catégorie incompatible avec la catégorie.", path: ["subcategory"] });
    if (v.requiresQuote ? v.priceCents !== 0 : v.priceCents < 100)
      ctx.addIssue({ code: "custom", message: "Sur devis : tarif initial à zéro. Sinon, minimum 1 €.", path: ["priceCents"] });
    for (const key of ["fields", "requiredDocuments"] as const) {
      if (new Set(v[key].map((f) => f.key)).size !== v[key].length)
        ctx.addIssue({
          code: "custom",
          message: "Clés de formulaire dupliquées",
          path: [key],
        });
    }
    if (v.fields.some((f) => f.type === "select" && !f.options?.length))
      ctx.addIssue({
        code: "custom",
        message: "Options requises pour les listes",
      });
  });
