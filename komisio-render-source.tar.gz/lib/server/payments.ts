import { queueCustomerNotification } from "./customer-notifications";
import { createPlisioInvoice, readPlisioPayment, plisioRequest, plisioDecimal, plisioAssetMatches, type PlisioOperation } from "./plisio";
import { integrationEndpoint } from "./integrations";
import { Prisma } from "@prisma/client";
import { db, serializable } from "./db";
import { HttpError } from "./http";
import { queueAdmins } from "./telegram";

export { canonicalize, verifyIpn } from "./payment-signature";

type ProviderPayment = {
  payment_id: number | string;
  order_id: string;
  payment_status: string;
  price_amount: number | string;
  price_currency: string;
  pay_currency: string;
  pay_amount: number | string;
  actually_paid?: number | string;
  pay_address: string;
  expiration_estimate_date?: string;
};

async function provider(
  path: string,
  init?: RequestInit,
): Promise<ProviderPayment> {
  const key = process.env.NOWPAYMENTS_API_KEY;
  if (!key)
    throw new HttpError(503, "La passerelle crypto n’est pas configurée.");
  const response = await fetch(`${integrationEndpoint("TEST_NOWPAYMENTS_API_ROOT", "https://api.nowpayments.io/v1")}${path}`, {
    ...init,
    cache: "no-store",
    signal: AbortSignal.timeout(20_000),
    headers: {
      "x-api-key": key,
      "Content-Type": "application/json",
      ...init?.headers,
    },
  });
  if (!response.ok)
    throw new HttpError(
      502,
      "La passerelle crypto est momentanément indisponible.",
    );
  return response.json();
}

export async function createPayment(input: {
  userId: string;
  amountCents: number;
  payCurrency: string;
  idempotencyKey: string;
  orderId?: string;
}) {
  const selectedProvider = process.env.PAYMENT_PROVIDER || "PLISIO";
  if (!["PLISIO", "NOWPAYMENTS"].includes(selectedProvider)) throw new HttpError(503,"Passerelle non reconnue.");
  if (!(selectedProvider === "PLISIO" ? process.env.PLISIO_API_KEY : process.env.NOWPAYMENTS_API_KEY) || !process.env.APP_URL)
    throw new HttpError(503, "Paiements crypto non configurés.");
  if (!input.orderId && input.amountCents < 1_000)
    throw new HttpError(400, "Recharge minimale : 10 €.");
  const reserved = await serializable(async (tx) => {
    const duplicate = await tx.payment.findUnique({
      where: {
        userId_idempotencyKey: {
          userId: input.userId,
          idempotencyKey: input.idempotencyKey,
        },
      },
    });
    if (duplicate) return { payment: duplicate, fresh: false };
    let amountCents = input.amountCents;
    if (input.orderId) {
      const order = await tx.order.findFirst({
        where: { id: input.orderId, userId: input.userId },
      });
      if (!order) throw new HttpError(404, "Dossier introuvable");
      if (order.status !== "AWAITING_PAYMENT" || order.paidAt || order.priceCents < 100 || (order.requiresQuote && !order.quoteAcceptedAt))
        throw new HttpError(409, "Ce dossier n’est plus payable.");
      amountCents = order.priceCents;
      const active = await tx.payment.findFirst({
        where: { orderId: order.id, status: { in: ["CREATING", "WAITING"] } },
      });
      if (active) return { payment: active, fresh: false };
    }
    return {
      payment: await tx.payment.create({ data: { ...input, amountCents, provider: selectedProvider } }),
      fresh: true,
    };
  });
  if (!reserved.fresh) return reserved.payment;
  const payment = reserved.payment;
  try {
    if (payment.provider === "PLISIO") return await db.payment.update({ where: { id: payment.id }, data: await createPlisioInvoice(payment) });
    const remote = await provider("/payment", {
      method: "POST",
      body: JSON.stringify({
        price_amount: (payment.amountCents / 100).toFixed(2),
        price_currency: "eur",
        pay_currency: payment.payCurrency,
        order_id: payment.id,
        order_description: payment.orderId
          ? `Dossier ${payment.orderId}`
          : "Recharge portefeuille B2B",
        ipn_callback_url: `${process.env.APP_URL!.replace(/\/$/, "")}/api/webhooks/nowpayments`,
        is_fixed_rate: true,
        is_fee_paid_by_user: true,
      }),
    });
    if (
      !remote.payment_id || remote.order_id !== payment.id || remote.price_currency?.toLowerCase() !== "eur" ||
      !new Prisma.Decimal(remote.pay_amount).gt(0) ||
      !remote.pay_address ||
      remote.pay_currency !== payment.payCurrency ||
      !new Prisma.Decimal(remote.price_amount)
        .times(100)
        .eq(payment.amountCents)
    )
      throw new Error("Provider contract mismatch");
    return await db.payment.update({
      where: { id: payment.id },
      data: {
        providerPaymentId: String(remote.payment_id),
        status: "WAITING",
        providerStatus: remote.payment_status,
        payAmount: String(remote.pay_amount),
        payAddress: remote.pay_address,
        expiresAt: remote.expiration_estimate_date
          ? new Date(remote.expiration_estimate_date)
          : null,
      },
    });
  } catch (error) {
    // Keep CREATING after an ambiguous network failure: never retry a provider POST blindly.
    // Reconcile the merchant order_id in NOWPayments, then bind its payment_id operationally.
    if (error instanceof HttpError && error.status === 503)
      await db.payment.update({
        where: { id: payment.id },
        data: { status: "FAILED" },
      });
    throw error;
  }
}

export async function reconcilePayment(id: string) {
  const local = await db.payment.findUnique({
    where: { id },
    include: { user: true },
  });
  if (!local) throw new HttpError(404, "Paiement introuvable");
  if (local.status === "CONFIRMED" || !local.providerPaymentId) return local;
  const remote = local.provider === "PLISIO" ? await readPlisioPayment(local) : await provider(
    `/payment/${encodeURIComponent(local.providerPaymentId)}`,
  );
  if (
    String(remote.payment_id) !== local.providerPaymentId ||
    remote.order_id !== local.id ||
    remote.price_currency?.toLowerCase() !== "eur" ||
    remote.pay_currency?.toLowerCase() !== local.payCurrency ||
    !new Prisma.Decimal(remote.price_amount).times(100).eq(local.amountCents) ||
    !new Prisma.Decimal(remote.pay_amount).eq(local.payAmount ?? "0")
  )
    throw new HttpError(
      409,
      "Le paiement reçu ne correspond pas à la facture.",
    );
  if (remote.payment_status !== "finished") {
    const status =
      remote.payment_status === "expired"
        ? "EXPIRED"
        : remote.payment_status === "failed" ||
            remote.payment_status === "refunded"
          ? "FAILED"
          : "WAITING";
    // A slow WAITING response must never overwrite a concurrent finished settlement.
    await db.payment.updateMany({
      where: { id: local.id, status: { not: "CONFIRMED" } },
      data: { status, providerStatus: remote.payment_status },
    });
    return db.payment.findUniqueOrThrow({ where: { id: local.id } });
  }
  if (
    !remote.actually_paid ||
    new Prisma.Decimal(remote.actually_paid).lt(remote.pay_amount)
  )
    throw new HttpError(409, "Montant crypto reçu insuffisant.");
  return serializable(async (tx) => {
    const payment = await tx.payment.findUniqueOrThrow({ where: { id } });
    if (payment.status === "CONFIRMED") return payment;
    const claim = await tx.payment.updateMany({
      where: { id, status: { not: "CONFIRMED" } },
      data: {
        status: "CONFIRMED",
        providerStatus: "finished",
        confirmedAt: new Date(),
      },
    });
    if (!claim.count) return tx.payment.findUniqueOrThrow({ where: { id } });
    const order = payment.orderId
      ? await tx.order.findUnique({ where: { id: payment.orderId } })
      : null;
    if (order && order.status === "AWAITING_PAYMENT" && !order.paidAt && (!order.requiresQuote || order.quoteAcceptedAt)) {
      const owner = await tx.user.findUniqueOrThrow({
        where: { id: payment.userId },
      });
      await tx.order.update({
        where: { id: order.id },
        data: {
          status: "PROCESSING",
          paidAt: new Date(),
          events: {
            create: {
              status: "PROCESSING",
              actorId: payment.provider,
              note: "Paiement crypto confirmé.",
            },
          },
        },
      });
      await tx.ledgerEntry.create({
        data: {
          userId: local.userId,
          amountCents: 0,
          balanceAfter: owner.balanceCents,
          kind: "ORDER_PAYMENT",
          paymentId: id,
          orderId: order.id,
          reference: `crypto:${id}`,
          reason: `Paiement crypto direct : dossier #${order.number}`,
        },
      });
      await queueAdmins(
        tx,
        `💼 Nouvelle commande payée #${order.number} : ${order.serviceName}.`,
      );
    } else {
      // A late payment on a cancelled/already-paid order becomes usable wallet credit.
      const user = await tx.user.update({
        where: { id: payment.userId },
        data: { balanceCents: { increment: payment.amountCents } },
      });
      await tx.ledgerEntry.create({
        data: {
          userId: user.id,
          amountCents: payment.amountCents,
          balanceAfter: user.balanceCents,
          kind: "TOPUP",
          paymentId: id,
          reference: `crypto:${id}`,
          reason: order
            ? `Paiement tardif du dossier #${order.number} crédité au portefeuille`
            : "Recharge crypto confirmée",
        },
      });
      await queueCustomerNotification(
        tx,
        user,
        `✅ Recharge de ${(payment.amountCents / 100).toFixed(2)} € confirmée sur votre portefeuille.`,
      );
    }
    return tx.payment.findUniqueOrThrow({ where: { id } });
  });
}

/** Recover a provider POST whose response was lost, without creating a second invoice. */
export async function linkProviderPayment(id: string, providerId: string, actorId: string) {
  const local=await db.payment.findUnique({where:{id}});
  if(!local)throw new HttpError(404,'Paiement introuvable.');
  if(local.providerPaymentId && local.providerPaymentId!==providerId)throw new HttpError(409,'Une autre facture est déjà liée.');
  if(local.providerPaymentId===providerId)return reconcilePayment(id);
  if(local.status!=='CREATING')throw new HttpError(409,'Seules les factures en cours de création peuvent être rattachées.');
  if(local.provider==='PLISIO') {
    const remote=await plisioRequest<PlisioOperation>(`/operations/${encodeURIComponent(providerId)}`);
    if(remote.id!==providerId||remote.type!=='invoice'||remote.params?.order_number!==id||String(remote.params.source_currency).toUpperCase()!=='EUR'||!plisioDecimal(remote.params.source_amount).times(100).eq(local.amountCents)||!plisioAssetMatches(local.payCurrency,remote.psys_cid||remote.currency))throw new HttpError(409,'Métadonnées Plisio insuffisantes ou incohérentes. Attendez le callback signé pour rattacher cette facture.');
    await serializable(async tx=>{const current=await tx.payment.findUniqueOrThrow({where:{id}});if(current.providerPaymentId===providerId)return;if(current.status!=='CREATING'||current.providerPaymentId)throw new HttpError(409,'Le paiement a changé.');await tx.payment.update({where:{id},data:{providerPaymentId:providerId,invoiceUrl:`https://plisio.net/invoice/${encodeURIComponent(providerId)}`,status:'WAITING'}});await tx.auditLog.create({data:{actorId,action:'PAYMENT_PROVIDER_LINKED',targetId:id,details:{providerPaymentId:providerId,provider:'PLISIO'}}});});
    return reconcilePayment(id);
  }
  const remote=await provider(`/payment/${encodeURIComponent(providerId)}`);
  if(String(remote.payment_id)!==providerId || remote.order_id!==id || remote.price_currency?.toLowerCase()!=='eur' || remote.pay_currency?.toLowerCase()!==local.payCurrency || !new Prisma.Decimal(remote.price_amount).times(100).eq(local.amountCents) || !new Prisma.Decimal(remote.pay_amount).gt(0) || !remote.pay_address)
    throw new HttpError(409,'Cette facture ne correspond pas au paiement local.');
  await serializable(async tx=>{
    const latest=await tx.payment.findUniqueOrThrow({where:{id}});
    if(latest.providerPaymentId===providerId)return;
    if(latest.status!=='CREATING' || latest.providerPaymentId)throw new HttpError(409,'Ce paiement a déjà changé. Actualisez.');
    await tx.payment.update({where:{id},data:{providerPaymentId:providerId,payAddress:remote.pay_address,payAmount:String(remote.pay_amount),providerStatus:remote.payment_status,status:'WAITING'}});
    await tx.auditLog.create({data:{actorId,action:'PAYMENT_PROVIDER_LINKED',targetId:id,details:{providerPaymentId:providerId}}});
  });
  return reconcilePayment(id);
}
