import { execFile } from "node:child_process";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileMime, MAX_FILE_BYTES } from "./storage";
import { HttpError } from "./http";
import { extractDocumentFields, type DocumentExtraction, type DocumentRole } from "../document-extraction";

const MAX_PIXELS = 20_000_000;
const MAX_SIDE = 7000;
const MAX_PAGES = 3;
const TOTAL_MS = 35_000;
const PROCESS_MS = 12_000;
const MAX_OUTPUT = 2 * 1024 * 1024;
const commandEnvironment = (): NodeJS.ProcessEnv => ({ NODE_ENV: process.env.NODE_ENV ?? "production", PATH: "/usr/local/bin:/usr/bin:/bin", LANG: "C.UTF-8", OMP_THREAD_LIMIT: "1" });

/** Direct executable invocation only. Error messages deliberately exclude stderr and document text. */
function execute(command: string, args: string[], timeout: number, cwd?: string): Promise<string> {
  return new Promise((resolve, reject) => {
    // Linux child limits bound native parser memory, CPU and temporary files.
    execFile("prlimit", ["--as=536870912", "--cpu=12", "--fsize=33554432", "--nofile=64", "--", command, ...args], { cwd, timeout, maxBuffer: MAX_OUTPUT, encoding: "utf8", windowsHide: true, env: commandEnvironment() }, (error, stdout) => {
      if (error) reject(new HttpError(503, "La lecture automatique locale a échoué ou dépassé sa limite. Complétez le dossier manuellement."));
      else resolve(stdout);
    });
  });
}

type Availability = { enabled: boolean; available: boolean; pdf: boolean; languages: string[]; reason: "ready" | "disabled" | "unavailable" };
let cachedAvailability: { expiresAt: number; value: Availability } | null = null;
export async function documentOcrAvailability(): Promise<Availability> {
  if (process.env.WHATSAPP_OCR_ENABLED !== "true") return { enabled: false, available: false, pdf: false, languages: [], reason: "disabled" };
  if (cachedAvailability && cachedAvailability.expiresAt > Date.now()) return cachedAvailability.value;
  let value: Availability;
  try {
    const languagesOutput = await execute("tesseract", ["--list-langs"], 3000);
    const languages = languagesOutput.split(/\r?\n/).map(value => value.trim()).filter(value => /^(?:fra|eng)$/.test(value));
    if (!languages.length) throw new Error("No OCR language");
    let pdf = true;
    try { await execute("pdfinfo", ["-v"], 3000); await execute("pdftotext", ["-v"], 3000); await execute("pdftoppm", ["-v"], 3000); } catch { pdf = false; }
    value = { enabled: true, available: true, pdf, languages, reason: "ready" };
  } catch { value = { enabled: true, available: false, pdf: false, languages: [], reason: "unavailable" }; }
  cachedAvailability = { expiresAt: Date.now() + 60_000, value };
  return value;
}

export function documentImageDimensions(bytes: Uint8Array, mime: string): { width: number; height: number } | null {
  const data = Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (mime === "image/png") {
    if (data.length < 24 || data.toString("ascii", 12, 16) !== "IHDR") return null;
    return { width: data.readUInt32BE(16), height: data.readUInt32BE(20) };
  }
  if (mime === "image/jpeg") {
    let offset = 2;
    while (offset + 4 <= data.length) {
      if (data[offset++] !== 0xff) return null;
      while (offset < data.length && data[offset] === 0xff) offset++;
      if (offset >= data.length) return null;
      const marker = data[offset++];
      if (marker === 0xda || marker === 0xd9) return null;
      if (marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) continue;
      if (offset + 2 > data.length) return null;
      const length = data.readUInt16BE(offset);
      if (length < 2 || offset + length > data.length) return null;
      if ([0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf].includes(marker)) {
        if (length < 8) return null;
        return { width: data.readUInt16BE(offset + 5), height: data.readUInt16BE(offset + 3) };
      }
      offset += length;
    }
  }
  return null;
}

function checkedImage(bytes: Uint8Array, mime: string) {
  const size = documentImageDimensions(bytes, mime);
  if (!size || size.width <= 0 || size.height <= 0) throw new HttpError(400, "L’image reçue est illisible. Envoyez une nouvelle photo JPEG ou PNG.");
  if (size.width > MAX_SIDE || size.height > MAX_SIDE || size.width * size.height > MAX_PIXELS) throw new HttpError(413, "Photo trop grande pour la lecture automatique : maximum 20 mégapixels et 7 000 pixels par côté.");
}

/** Tesseract TSV offers per-word confidence without persisting its output. */
export function parseOcrTsv(tsv: string): { text: string; confidence: number } {
  const lines = new Map<string, string[]>();
  let confidenceTotal = 0, words = 0;
  for (const row of tsv.slice(0, MAX_OUTPUT).split(/\r?\n/).slice(1)) {
    const columns = row.split("\t");
    if (columns.length < 12 || columns[0] !== "5") continue;
    const confidence = Number(columns[10]);
    const text = columns.slice(11).join(" ").trim();
    if (!text || !Number.isFinite(confidence) || confidence < 0) continue;
    const key = columns.slice(1, 5).join(":");
    lines.set(key, [...(lines.get(key) ?? []), text]);
    confidenceTotal += confidence; words++;
  }
  return { text: [...lines.values()].map(words => words.join(" ")).join("\n"), confidence: words ? Math.round(confidenceTotal / words) : 0 };
}

export type OcrResult = DocumentExtraction & { engine: "tesseract-local"; pagesProcessed: number };
export async function extractDocument(bytes: Uint8Array, mimeType: string, _filename?: string, options: { role?: DocumentRole } = {}): Promise<OcrResult> {
  if (!bytes.byteLength || bytes.byteLength > MAX_FILE_BYTES) throw new HttpError(413, "Pièce vide ou trop volumineuse : maximum 10 Mo.");
  const actualMime = fileMime(bytes);
  if (!actualMime || actualMime !== mimeType || !["image/jpeg", "image/png", "application/pdf"].includes(actualMime)) throw new HttpError(400, "Lecture automatique : formats acceptés PDF, JPEG et PNG valides.");
  if (actualMime !== "application/pdf") checkedImage(bytes, actualMime);
  const availability = await documentOcrAvailability();
  if (!availability.available || (actualMime === "application/pdf" && !availability.pdf)) throw new HttpError(503, availability.reason === "disabled" ? "La lecture automatique est désactivée. Les documents peuvent être classés et complétés manuellement." : "La lecture automatique locale est indisponible sur cet hébergement. Les documents restent disponibles pour une saisie manuelle.");
  const directory = await mkdtemp(join(tmpdir(), "komisio-ocr-"));
  const deadline = Date.now() + TOTAL_MS;
  const warnings: string[] = [];
  const run = async (command: string, args: string[]) => {
    const remaining = deadline - Date.now();
    if (remaining <= 0) throw new HttpError(503, "Temps de lecture automatique dépassé. Complétez les champs manuellement.");
    return execute(command, args, Math.min(PROCESS_MS, remaining), directory);
  };
  const texts: string[] = [], scores: number[] = [];
  let pagesProcessed = 0;
  try {
    const input = join(directory, actualMime === "application/pdf" ? "document.pdf" : actualMime === "image/png" ? "document.png" : "document.jpg");
    await writeFile(input, bytes, { mode: 0o600 });
    const language = availability.languages.includes("fra") ? availability.languages.includes("eng") ? "fra+eng" : "fra" : "eng";
    if (!availability.languages.includes("fra")) warnings.push("Modèle français absent : lecture avec le modèle anglais, vérification renforcée nécessaire.");
    async function readImage(path: string) {
      const result = parseOcrTsv(await run("tesseract", [path, "stdout", "-l", language, "--psm", "6", "tsv"]));
      if (result.confidence >= 35) texts.push(result.text);
      else warnings.push(`Page ${pagesProcessed + 1} trop peu lisible pour proposer des champs : saisie manuelle nécessaire.`);
      scores.push(result.confidence); pagesProcessed++;
    }
    if (actualMime === "application/pdf") {
      const info = await run("pdfinfo", [input]);
      const totalPages = Number(info.match(/^Pages:\s+(\d+)\s*$/m)?.[1]);
      if (!Number.isSafeInteger(totalPages) || totalPages < 1) throw new HttpError(400, "Impossible de lire les pages du PDF. Envoyez des photos lisibles des pièces.");
      if (totalPages > MAX_PAGES) warnings.push(`Le PDF contient ${totalPages} pages. Seules les ${MAX_PAGES} premières ont été lues automatiquement.`);
      for (let page = 1; page <= Math.min(totalPages, MAX_PAGES); page++) {
        const text = await run("pdftotext", ["-f", String(page), "-l", String(page), "-layout", "-nopgbrk", input, "-"]);
        if (text.trim().length >= 60) { texts.push(text); scores.push(85); pagesProcessed++; continue; }
        const prefix = join(directory, `page-${page}`);
        await run("pdftoppm", ["-f", String(page), "-l", String(page), "-scale-to", "2500", "-r", "150", "-singlefile", "-png", input, prefix]);
        const png = await readFile(prefix + ".png"); checkedImage(png, "image/png");
        await readImage(prefix + ".png");
      }
    } else await readImage(input);
    const confidence = scores.length ? Math.round(scores.reduce((sum, score) => sum + score, 0) / scores.length) : 0;
    const parsed = extractDocumentFields(texts.join("\n"), options.role ?? "unknown", confidence);
    return { ...parsed, warnings: [...parsed.warnings, ...warnings], engine: "tesseract-local", pagesProcessed };
  } finally { await rm(directory, { recursive: true, force: true }); }
}
