import { createHmac,timingSafeEqual } from 'node:crypto';
import { Prisma,type Payment } from '@prisma/client';
import { HttpError } from './http';
import { integrationEndpoint } from './integrations';
export const plisioCurrencies:Record<string,string>={usdttrc20:'USDT_TRX',usdterc20:'USDT',btc:'BTC',eth:'ETH',sol:'SOL'};
export type PlisioOperation={id:string;type:string;status:string;psys_cid?:string;currency?:string;amount?:string;sum?:string;fee?:string;confirmations?:number;wallet_hash?:string;tx?:{txid:string}[];tx_id?:string[];tx_url?:string;params?:{order_number?:string;source_amount?:string;source_currency?:string;amount?:string}};
export async function plisioRequest<T>(path:string,params:Record<string,string>={}):Promise<T>{
 const key=process.env.PLISIO_API_KEY;if(!key)throw new HttpError(503,'Plisio n’est pas configuré.');
 const url=new URL(integrationEndpoint('TEST_PLISIO_API_ROOT','https://api.plisio.net/api/v1')+path);
 for(const [name,value]of Object.entries({...params,api_key:key}))url.searchParams.set(name,value);
 try{
  // Plisio documents GET for invoice and withdrawal creation. Never retry a transfer request.
  const response=await fetch(url,{method:'GET',cache:'no-store',redirect:'error',signal:AbortSignal.timeout(15000)});
  const payload=await response.json();
  if(!response.ok||payload.status!=='success'||!payload.data||typeof payload.data!=='object')throw new Error('provider response');
  return payload.data as T;
 }catch{throw new HttpError(502,'Plisio est momentanément indisponible. Vérifiez l’état de l’opération avant toute nouvelle tentative.');}
}
export function verifyPlisioCallback(payload:unknown,key:string){
 if(!key||!payload||typeof payload!=='object'||Array.isArray(payload))return false;
 const record=payload as Record<string,unknown>;if(typeof record.verify_hash!=='string'||!/^[a-f0-9]{40}$/i.test(record.verify_hash))return false;
 const ordered={...record};delete ordered.verify_hash;
 // Official Node protocol with ?json=true: preserve JSON insertion order, unlike NOWPayments.
 const expected=createHmac('sha1',key).update(JSON.stringify(ordered)).digest();const signature=Buffer.from(record.verify_hash,'hex');
 return expected.length===signature.length&&timingSafeEqual(expected,signature);
}
export function plisioAssetMatches(currency:string,actual:unknown){return typeof actual==='string'&&(actual.toUpperCase()===plisioCurrencies[currency]||(currency==='sol'&&actual.toUpperCase()==='SOLANA'));}
export function plisioDecimal(value:unknown){try{if(typeof value!=='string'&&typeof value!=='number')throw Error();const result=new Prisma.Decimal(value);if(!result.isFinite()||result.lt(0))throw Error();return result;}catch{throw new HttpError(409,'Montant Plisio invalide.');}}
export function checkedInvoiceUrl(value:unknown){
 if(typeof value!=='string')throw new HttpError(502,'Lien de facture Plisio absent.');
 const url=new URL(value);if(url.origin!=='https://plisio.net'||!url.pathname.startsWith('/invoice/')||url.username||url.password)throw new HttpError(502,'Lien de facture Plisio invalide.');return url.toString();
}
export async function createPlisioInvoice(payment:Payment){
 const currency=plisioCurrencies[payment.payCurrency];if(!currency)throw new HttpError(400,'Devise non prise en charge par Plisio.');
 const result=await plisioRequest<{txn_id:string;invoice_url:string;invoice_total_sum?:string}>('/invoices/new',{
  source_currency:'EUR',source_amount:(payment.amountCents/100).toFixed(2),order_number:payment.id,
  order_name:payment.orderId?`Dossier ${payment.orderId}`:'Recharge Komisio',currency,allowed_psys_cids:currency,
  callback_url:`${process.env.APP_URL!.replace(/\/$/,'')}/api/webhooks/plisio?json=true`,
  success_invoice_url:process.env.MINI_APP_URL||process.env.APP_URL!,fail_invoice_url:process.env.MINI_APP_URL||process.env.APP_URL!,return_existing:'1',expire_min:'60',
 });
 if(typeof result.txn_id!=='string'||!result.txn_id||result.txn_id.length>100)throw new HttpError(502,'Identifiant de facture Plisio invalide.');
 return {providerPaymentId:result.txn_id,invoiceUrl:checkedInvoiceUrl(result.invoice_url),payAmount:result.invoice_total_sum?plisioDecimal(result.invoice_total_sum).toFixed():null,status:'WAITING' as const,providerStatus:'new'};
}
export function validatePlisioReceipt(payment:Payment,payload:Record<string,unknown>){
 if(payload.ipn_type!=='invoice'||payload.order_number!==payment.id||typeof payload.txn_id!=='string'||!payload.txn_id||String(payload.source_currency).toUpperCase()!=='EUR'||!plisioDecimal(payload.source_amount).times(100).eq(payment.amountCents)||!plisioAssetMatches(payment.payCurrency,payload.psys_cid||payload.currency))throw new HttpError(409,'Le règlement Plisio ne correspond pas à la facture.');
 if(payment.providerPaymentId&&payment.providerPaymentId!==payload.txn_id)throw new HttpError(409,'Identifiant de facture Plisio incohérent.');
 if(payload.status==='completed'){
  const total=plisioDecimal(payload.invoice_total_sum);if(!total.gt(0)||plisioDecimal(payload.amount).lt(total)||(payment.payAmount&&!total.eq(payment.payAmount)))throw new HttpError(409,'Montant Plisio reçu insuffisant ou incohérent.');
 }
}
export async function readPlisioPayment(payment:Payment){
 const remote=await plisioRequest<PlisioOperation>(`/operations/${encodeURIComponent(payment.providerPaymentId!)}`);
 if(remote.id!==payment.providerPaymentId||remote.type!=='invoice')throw new HttpError(409,'Opération Plisio incohérente.');
 const receipt=payment.callbackData as Record<string,unknown>|null;
 if(remote.params?.order_number&&remote.params.order_number!==payment.id)throw new HttpError(409,'Référence Plisio incohérente.');
 if(remote.psys_cid&&!plisioAssetMatches(payment.payCurrency,remote.psys_cid))throw new HttpError(409,'Réseau Plisio incohérent.');
 if(receipt)validatePlisioReceipt(payment,receipt);
 // Standard hosted invoices need the signed fiat receipt as well as API confirmation.
 const settled=remote.status==='completed'&&receipt?.status==='completed';
 return {payment_id:payment.providerPaymentId!,order_id:payment.id,price_amount:(payment.amountCents/100).toFixed(2),price_currency:'eur',pay_currency:payment.payCurrency,pay_amount:payment.payAmount||'0',actually_paid:settled?String(receipt!.amount):undefined,pay_address:payment.payAddress||'',payment_status:settled?'finished':remote.status==='expired'?'expired':['error','cancelled','cancelled duplicate'].includes(remote.status)?'failed':'waiting'};
}
