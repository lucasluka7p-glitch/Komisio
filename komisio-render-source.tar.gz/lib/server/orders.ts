import { resolvePrice } from "../pricing";
import { z } from "zod";
import { isVehicleTransferService, usesStructuredCustomer, serviceCustomerName } from "../catalog";
import { Prisma } from "@prisma/client";
import { serializable } from "./db";
import { HttpError } from "./http";
import {
  fieldDefinition,
  documentDefinition,
  idempotency,
  validIsoDate,
} from "./validation";
import { queueAdmins } from "./telegram";

export const orderInput = z.object({
  serviceId: z.string().min(1).max(100),
  expectedPriceCents: z.number().int().min(0).max(10_000_000).optional(),
  expectedRequiresQuote: z.boolean().optional(),
  expectedPricingVersion: z.number().int().min(0).optional(),
  expectedServiceUpdatedAt: z.string().datetime().optional(),
  customerName: z.string().trim().min(2).max(150).optional(),
  customerEmail: z
    .union([z.string().email().max(254), z.literal("")])
    .optional(),
  fields: z.record(z.string().max(5000)),
  documentIds: z.array(z.string().min(1).max(100)).max(30),
  paymentMethod: z.enum(["WALLET", "CRYPTO"]).default("CRYPTO"),
  idempotencyKey: idempotency,
}).transform((input, ctx) => {
  if (usesStructuredCustomer(input.serviceId) && !isVehicleTransferService(input.serviceId)) {
    const schema = input.serviceId === "acces-donnees-personnelles"
      ? z.object({ lastName: z.string().trim().min(1).max(70), firstName: z.string().trim().min(1).max(70), birthDate: z.string().refine(value => validIsoDate(value) && value <= new Date().toISOString().slice(0, 10), "Date de naissance invalide") })
      : input.serviceId === "situation-vehicule" ? z.object({ registration: z.string().trim().min(1).max(30) })
      : ["controle-convoyage", "douane-suisse"].includes(input.serviceId) ? z.object({ mileage: z.string().regex(/^\d{1,8}$/, "Kilométrage entier requis") })
      : ["ww", "ww-modification"].includes(input.serviceId) ? z.object({ holderAddress: z.string().trim().min(3).max(1000) })
      : z.object({});
    const result = schema.safeParse(input.fields);
    if (!result.success) {
      for (const issue of result.error.issues) ctx.addIssue({ ...issue, path: ["fields", ...issue.path] });
      return z.NEVER;
    }
    return { ...input, customerName: serviceCustomerName(input.serviceId, input.fields), customerEmail: undefined };
  }
  if (!isVehicleTransferService(input.serviceId)) {
    const name = z.string().trim().min(2).max(150).safeParse(input.customerName);
    if (!name.success) {
      for (const issue of name.error.issues) ctx.addIssue({ ...issue, path: ["customerName", ...issue.path] });
      return z.NEVER;
    }
    return { ...input, customerName: name.data };
  }
  const parsed = z.object({
    buyerLastName: z.string().trim().min(1).max(70),
    buyerFirstName: z.string().trim().min(1).max(70),
    buyerBirthPlace: z.string().trim().min(1).max(200),
    buyerBirthDate: z.string().refine(value => validIsoDate(value) && value <= new Date().toISOString().slice(0, 10), "Date de naissance invalide"),
  }).safeParse(input.fields);
  if (!parsed.success) {
    for (const issue of parsed.error.issues) ctx.addIssue({ ...issue, path: ["fields", ...issue.path] });
    return z.NEVER;
  }
  const buyer = parsed.data;
  // Keep the searchable order label without asking for the same identity twice.
  return { ...input, customerName: `${buyer.buyerLastName} ${buyer.buyerFirstName}`, customerEmail: undefined };
});

export const documentSelection = {
  id: true,
  fileName: true,
  mimeType: true,
  bytes: true,
  fieldKey: true,
  kind: true,
  createdAt: true,
} satisfies Prisma.DocumentSelect;
export const orderInclude = {
  service: true,
  originalDocument: true,
  documents: { select: documentSelection },
  events: { orderBy: { createdAt: "asc" as const } },
} satisfies Prisma.OrderInclude;

export async function payOrderWithWallet(
  tx: Prisma.TransactionClient,
  order: {
    id: string;
    userId: string;
    priceCents: number;
    number: number;
    serviceName: string;
    status: string;
    paidAt: Date | null;
    requiresQuote?: boolean;
    quoteAcceptedAt?: Date | null;
  },
) {
  if (order.paidAt || order.status !== "AWAITING_PAYMENT" || order.priceCents < 100 || (order.requiresQuote && !order.quoteAcceptedAt))
    throw new HttpError(409, "Ce dossier n’est plus payable.");
  const charged = await tx.user.updateMany({
    where: {
      id: order.userId,
      disabled: false,
      balanceCents: { gte: order.priceCents },
    },
    data: { balanceCents: { decrement: order.priceCents } },
  });
  if (!charged.count)
    throw new HttpError(
      409,
      "Solde insuffisant. Rechargez votre portefeuille.",
    );
  const user = await tx.user.findUniqueOrThrow({ where: { id: order.userId } });
  await tx.ledgerEntry.create({
    data: {
      userId: user.id,
      orderId: order.id,
      amountCents: -order.priceCents,
      balanceAfter: user.balanceCents,
      kind: "ORDER_PAYMENT",
      reference: `wallet-order:${order.id}`,
      reason: `${order.serviceName} · #${order.number}`,
    },
  });
  await tx.order.update({
    where: { id: order.id },
    data: {
      paidAt: new Date(),
      status: "PROCESSING",
      events: {
        create: {
          actorId: user.id,
          status: "PROCESSING",
          note: "Paiement par portefeuille validé.",
        },
      },
    },
  });
  await queueAdmins(
    tx,
    `💼 Nouvelle commande payée #${order.number} : ${order.serviceName}.`,
  );
}

export async function createOrder(
  userId: string,
  input: z.infer<typeof orderInput>,
  channel?: { whatsappBindingId: string },
) {
  return serializable(async (tx) => {
    const previous = await tx.order.findUnique({
      where: {
        userId_idempotencyKey: { userId, idempotencyKey: input.idempotencyKey },
      },
      include: orderInclude,
    });
    if (previous) return previous;
    const service = await tx.service.findFirst({
      where: { id: input.serviceId, active: true },
    });
    if (!service) throw new HttpError(404, "Service indisponible");
    const user = await tx.user.findUniqueOrThrow({ where: { id: userId } });
    const whatsappBinding = channel ? await tx.whatsAppBinding.findFirst({ where: { id: channel.whatsappBindingId, userId, active: true } }) : null;
    if (channel && (!whatsappBinding || user.pricingVersion < 1 || input.paymentMethod !== "CRYPTO")) throw new HttpError(403, "Accès WhatsApp indisponible.");
    if (user.disabled || !user.accessReady || (user.mustChangePassword && !whatsappBinding)) throw new HttpError(403, "Accès client indisponible.");
    const rule = await tx.clientServicePrice.findUnique({ where: { userId_serviceId: { userId, serviceId: service.id } } });
    const tariff = resolvePrice(service, user, rule as import("../pricing").PriceRule | null);
    if ((input.expectedPriceCents !== undefined && input.expectedPriceCents !== tariff.priceCents)
      || (input.expectedRequiresQuote !== undefined && input.expectedRequiresQuote !== tariff.requiresQuote)
      || (input.expectedPricingVersion !== undefined && input.expectedPricingVersion !== user.pricingVersion)
      || (input.expectedServiceUpdatedAt !== undefined && input.expectedServiceUpdatedAt !== service.updatedAt.toISOString()))
      throw new HttpError(409, "Le tarif ou les conditions de cette prestation ont changé. Fermez ce formulaire et actualisez le catalogue avant de valider. Aucun débit effectué.");
    const fields = z.array(fieldDefinition).parse(service.fields);
    const definitions = z
      .array(documentDefinition)
      .parse(service.requiredDocuments);
    for (const field of fields) {
      const value = input.fields[field.key]?.trim() ?? "";
      if (field.required && !value)
        throw new HttpError(400, `Champ requis : ${field.label}`);
      if (!value) continue;
      if (
        field.type === "email" &&
        !z.string().email().safeParse(value).success
      )
        throw new HttpError(400, `Adresse e-mail invalide : ${field.label}`);
      if (field.type === "number" && !Number.isFinite(Number(value)))
        throw new HttpError(400, `Nombre invalide : ${field.label}`);
      if (field.type === "date" && !validIsoDate(value))
        throw new HttpError(400, `Date invalide : ${field.label}`);
      if (field.type === "select" && !field.options?.includes(value))
        throw new HttpError(400, `Option invalide : ${field.label}`);
    }
    if (
      Object.keys(input.fields).some(
        (key) => !fields.some((field) => field.key === key),
      )
    )
      throw new HttpError(400, "Champ de formulaire inconnu");
    if (new Set(input.documentIds).size !== input.documentIds.length)
      throw new HttpError(400, "Document dupliqué");
    const documents = await tx.document.findMany({
      where: {
        id: { in: input.documentIds },
        ownerId: userId,
        serviceId: service.id,
        orderId: null,
        kind: "ATTACHMENT",
      },
    });
    if (documents.length !== input.documentIds.length)
      throw new HttpError(403, "Une pièce jointe est indisponible.");
    for (const definition of definitions) {
      if (
        definition.required &&
        !documents.some((doc) => doc.fieldKey === definition.key && (definition.type === "video" ? doc.mimeType.startsWith("video/") : definition.type === "image" ? doc.mimeType.startsWith("image/") : !doc.mimeType.startsWith("video/")))
      )
        throw new HttpError(400, `Pièce requise : ${definition.label}`);
    }
    const order = await tx.order.create({
      data: {
        userId,
        serviceId: service.id,
        serviceName: service.name,
        priceCents: tariff.priceCents,
        pricingSnapshot: tariff.pricing,
        requiresQuote: tariff.requiresQuote,
        status: tariff.requiresQuote ? "AWAITING_QUOTE" : "AWAITING_PAYMENT",
        customerName: input.customerName,
        customerEmail: input.customerEmail || null,
        fields: input.fields,
        formSnapshot: {
          fields: service.fields,
          requiredDocuments: service.requiredDocuments,
        },
        idempotencyKey: input.idempotencyKey,
        ...(service.id === "douane-suisse" ? { originalDocument: { create: {} } } : {}),
        documents: { connect: documents.map((doc) => ({ id: doc.id })) },
        events: {
          create: {
            status: tariff.requiresQuote ? "AWAITING_QUOTE" : "AWAITING_PAYMENT",
            actorId: userId,
            note: tariff.requiresQuote ? "Dossier déposé pour devis. Aucun paiement demandé." : "Dossier créé.",
          },
        },
      },
    });
    if (tariff.requiresQuote) await queueAdmins(tx, `📋 Nouveau dossier #${order.number} (${service.name}) à étudier pour devis.`);
    else if (input.paymentMethod === "WALLET") await payOrderWithWallet(tx, order);
    return tx.order.findUniqueOrThrow({
      where: { id: order.id },
      include: orderInclude,
    });
  });
}
