import { queueCustomerNotification } from "./customer-notifications";
import { z } from "zod";
import { advanceOriginalDocument, originalDocumentLabels, type OriginalDocument } from "../original-document";
import { serializable } from "./db";
import { HttpError } from "./http";
import { orderInclude } from "./orders";

const expectedVersion = z.number().int().min(0);
export const originalDocumentInput = z.discriminatedUnion("action", [
  z.object({ action: z.literal("schedule"), expectedVersion, appointmentAt: z.string().datetime({ offset: true }).transform(value => new Date(value).toISOString()), location: z.string().trim().min(3).max(1000), note: z.string().trim().max(2000).default("") }).strict(),
  z.object({ action: z.literal("collect"), expectedVersion, confirmed: z.literal(true) }).strict(),
  z.object({ action: z.literal("ready"), expectedVersion, confirmed: z.literal(true) }).strict(),
  z.object({ action: z.literal("return"), expectedVersion, confirmed: z.literal(true) }).strict(),
]);

export async function updateOriginalDocument(id: string, actorId: string, input: z.infer<typeof originalDocumentInput>) {
  return serializable(async tx => {
    const order = await tx.order.findUnique({ where: { id }, include: { originalDocument: true, user: true } });
    if (!order?.originalDocument) throw new HttpError(404, "Ce dossier ne dispose pas d’un suivi d’original.");
    const record = order.originalDocument;
    const originalDocument: OriginalDocument = { ...record, appointmentAt: record.appointmentAt?.toISOString(), collectedAt: record.collectedAt?.toISOString(), readyAt: record.readyAt?.toISOString(), returnedAt: record.returnedAt?.toISOString() };
    let result;
    try {
      result = advanceOriginalDocument({ status: order.status, requiresQuote: order.requiresQuote, quoteAcceptedAt: order.quoteAcceptedAt?.toISOString(), paid: !!order.paidAt, originalDocument }, input);
    } catch (error) { throw new HttpError(409, (error as Error).message); }
    if (!result.changed) return tx.order.findUniqueOrThrow({ where: { id }, include: orderInclude });
    const next = result.originalDocument;
    const message = `${originalDocumentLabels[next.status]}.${input.action === "schedule" ? `\n${new Intl.DateTimeFormat("fr-FR", { dateStyle: "full", timeStyle: "short", timeZone: "Europe/Paris" }).format(new Date(input.appointmentAt))} (heure de Paris)\n${input.location}${input.note ? `\n${input.note}` : ""}` : ""}`;
    await tx.originalDocument.update({ where: { orderId: id }, data: {
      status: next.status, version: next.version, appointmentAt: next.appointmentAt ? new Date(next.appointmentAt) : null, location: next.location, note: next.note,
      collectedAt: next.collectedAt ? new Date(next.collectedAt) : null, readyAt: next.readyAt ? new Date(next.readyAt) : null, returnedAt: next.returnedAt ? new Date(next.returnedAt) : null,
    } });
    const updated = await tx.order.update({ where: { id }, data: { status: result.status, events: { create: { status: result.status, actorId, note: message } } }, include: orderInclude });
    await tx.auditLog.create({ data: { actorId, action: `ORIGINAL_DOCUMENT_${input.action.toUpperCase()}`, targetId: id, details: { ...input, previousStatus: record.status, status: next.status } } });
    await queueCustomerNotification(tx, order.user, `📄 Dossier #${order.number} — ${order.serviceName}\n${message}\nConsultez le suivi dans la Mini App.`);
    return updated;
  });
}
