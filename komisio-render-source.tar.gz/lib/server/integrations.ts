import { Bot } from 'grammy';
/** Local protocol tests must not send messages or create invoices on real services. */
export function integrationEndpoint(testVariable: string, production: string, env: Record<string, string | undefined> = process.env) {
  const override=env[testVariable];
  if(!override)return production;
  const url=new URL(override);
  if(env.NODE_ENV==='production' || env.KOMISIO_INTEGRATION_TEST_MODE!=='true' || url.protocol!=='http:' || url.hostname!=='127.0.0.1' || url.username || url.password)
    throw new Error('Integration test endpoints are restricted to an explicit local test process.');
  return url.toString().replace(/\/$/,'');
}
export function telegramBot() {
  if(!process.env.TELEGRAM_BOT_TOKEN)throw new Error('Telegram is not configured');
  return new Bot(process.env.TELEGRAM_BOT_TOKEN,{client:{timeoutSeconds:10,apiRoot:integrationEndpoint('TEST_TELEGRAM_API_ROOT','https://api.telegram.org')}});
}
