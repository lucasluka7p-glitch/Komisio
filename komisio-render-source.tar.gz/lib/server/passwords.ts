import { randomBytes, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
const scrypt = promisify(scryptCallback);
export const generatePassword = () => randomBytes(18).toString("base64url");
export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  const hash = await scrypt(password, salt, 64) as Buffer;
  return `scrypt$${salt}$${hash.toString("hex")}`;
}
export async function verifyPassword(password: string, stored: string | null): Promise<boolean> {
  // Equal-cost work even for an unknown login. No plaintext password is persisted.
  const [kind, salt, expected] = (stored || `scrypt$${"0".repeat(32)}$${"0".repeat(128)}`).split("$");
  const hash = await scrypt(password, salt || "0".repeat(32), 64) as Buffer;
  return kind === "scrypt" && /^[a-f0-9]{128}$/.test(expected || "") && timingSafeEqual(hash, Buffer.from(expected, "hex"));
}
