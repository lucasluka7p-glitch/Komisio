import { Prisma, type WhatsAppDraft } from '@prisma/client';
import { z } from 'zod';
import { db, serializable } from './db';
import { HttpError } from './http';
import { createOrder, orderInput } from './orders';
import { fieldDefinition, documentDefinition } from './validation';
import { resolvePrice, type PriceRule } from '../pricing';
import { usesStructuredCustomer, euro } from '../catalog';

export const whatsappDraftInclude = { service: true, files: { orderBy: { createdAt: 'asc' as const } }, user: { select: { firstName: true, login: true } } } satisfies Prisma.WhatsAppDraftInclude;
export const draftAction = z.discriminatedUnion('action', [
  z.object({ action: z.literal('update'), expectedVersion: z.number().int().min(0), fields: z.record(z.string().max(5000)), customerName: z.string().trim().max(150).optional(), files: z.array(z.object({ id: z.string().min(1).max(100), fieldKey: z.string().max(100).nullable() }).strict()).max(30).optional() }).strict(),
  z.object({ action: z.literal('review'), expectedVersion: z.number().int().min(0) }).strict(),
  z.object({ action: z.literal('submit'), expectedVersion: z.number().int().min(0) }).strict(),
  z.object({ action: z.literal('cancel'), expectedVersion: z.number().int().min(0) }).strict(),
]);
export type WhatsAppReview = { expectedPriceCents: number; expectedRequiresQuote: boolean; expectedPricingVersion: number; expectedServiceUpdatedAt: string };
export async function getWhatsAppDraft(id: string, userId?: string) {
  const draft = await db.whatsAppDraft.findFirst({ where: { id, ...(userId ? { userId } : {}) }, include: whatsappDraftInclude });
  if (!draft) throw new HttpError(404, 'Brouillon introuvable.');
  const [user, rule] = await Promise.all([db.user.findUniqueOrThrow({ where: { id: draft.userId } }), db.clientServicePrice.findUnique({ where: { userId_serviceId: { userId: draft.userId, serviceId: draft.serviceId } } })]);
  const pricing = resolvePrice(draft.service, user, rule as PriceRule | null);
  const fields = z.array(fieldDefinition).parse(draft.service.fields);
  const definitions = z.array(documentDefinition).parse(draft.service.requiredDocuments);
  const values = draft.fields as Record<string, string>;
  const missing = fields.filter(field => field.required && !values[field.key]?.trim()).map(field => `${field.label} (${field.key})`);
  if (!usesStructuredCustomer(draft.serviceId) && draft.customerName.trim().length < 2) missing.push('Nom du client final (/nom NOM)');
  for (const definition of definitions) if (definition.required && !draft.files.some(file => file.fieldKey === definition.key && (definition.type === 'image' ? file.mimeType.startsWith('image/') : definition.type === 'video' ? file.mimeType.startsWith('video/') : !file.mimeType.startsWith('video/')))) missing.push(`Pièce : ${definition.label} (${definition.key})`);
  for (const file of draft.files) if (!file.fieldKey) missing.push(`Classer la pièce « ${file.fileName} »`);
  if (!draft.service.active) missing.push('Prestation désactivée par l’administrateur');
  return { draft: { ...draft, files: draft.files.map(({ storageKey: _storage, ...file }) => file) }, pricing, missing };
}
function assertEditable(draft: WhatsAppDraft, expectedVersion: number) {
  if (draft.status !== 'OPEN') throw new HttpError(409, 'Ce brouillon ne peut plus être modifié.');
  if (draft.version !== expectedVersion) throw new HttpError(409, 'Le brouillon a changé. Actualisez le récapitulatif.');
}
export async function editWhatsAppDraft(id: string, actorId: string, admin: boolean, action: z.infer<typeof draftAction>) {
  const view = await getWhatsAppDraft(id, admin ? undefined : actorId);
  if (action.action === 'submit') return submitWhatsAppDraft(view.draft.id, action.expectedVersion, actorId, admin);
  await serializable(async tx => {
    const draft = await tx.whatsAppDraft.findUniqueOrThrow({ where: { id } }); assertEditable(draft, action.expectedVersion);
    if (action.action === 'review') {
      const user = await tx.user.findUniqueOrThrow({ where: { id: draft.userId } }); const service = await tx.service.findUniqueOrThrow({ where: { id: draft.serviceId } }); const rule = await tx.clientServicePrice.findUnique({ where: { userId_serviceId: { userId: draft.userId, serviceId: draft.serviceId } } });
      const pricing = resolvePrice(service, user, rule as PriceRule | null);
      const snapshot: WhatsAppReview = { expectedPriceCents: pricing.priceCents, expectedRequiresQuote: pricing.requiresQuote, expectedPricingVersion: user.pricingVersion, expectedServiceUpdatedAt: service.updatedAt.toISOString() };
      await tx.whatsAppDraft.update({ where: { id }, data: { reviewedVersion: draft.version, reviewSnapshot: snapshot } });
    } else if (action.action === 'cancel') {
      await tx.whatsAppDraft.update({ where: { id }, data: { status: 'CANCELLED', version: { increment: 1 }, reviewedVersion: null, reviewSnapshot: Prisma.DbNull } });
    } else {
      const allowed = z.array(fieldDefinition).parse(view.draft.service.fields);
      if (Object.keys(action.fields).some(key => !allowed.some(field => field.key === key))) throw new HttpError(400, 'Champ de formulaire inconnu.');
      const definitions = z.array(documentDefinition).parse(view.draft.service.requiredDocuments);
      if (action.files) {
        if (new Set(action.files.map(file => file.id)).size !== action.files.length) throw new HttpError(400, 'Pièce dupliquée.');
        for (const file of action.files) {
          const stored = await tx.whatsAppFile.findFirst({ where: { id: file.id, draftId: id } });
          if (!stored) throw new HttpError(404, 'Pièce introuvable.');
          const definition = definitions.find(def => def.key === file.fieldKey);
          if (file.fieldKey && (!definition || (definition.type === 'image' && !stored.mimeType.startsWith('image/')) || (definition.type === 'video' && !stored.mimeType.startsWith('video/')) || (definition.type !== 'video' && stored.mimeType.startsWith('video/')))) throw new HttpError(400, 'Classement ou format de pièce invalide.');
          if (stored.documentId && file.fieldKey) await tx.document.updateMany({ where: { id: stored.documentId, ownerId: draft.userId, orderId: null }, data: { fieldKey: file.fieldKey } });
          await tx.whatsAppFile.update({ where: { id: file.id }, data: { fieldKey: file.fieldKey } });
        }
      }
      await tx.whatsAppDraft.update({ where: { id }, data: { fields: { ...(draft.fields as Record<string, string>), ...action.fields }, ...(action.customerName !== undefined ? { customerName: action.customerName } : {}), version: { increment: 1 }, reviewedVersion: null, reviewSnapshot: Prisma.DbNull } });
    }
    await tx.auditLog.create({ data: { actorId, action: `WHATSAPP_DRAFT_${action.action.toUpperCase()}`, targetId: id, details: { version: draft.version } } });
  });
  return getWhatsAppDraft(id, admin ? undefined : actorId);
}
export async function submitWhatsAppDraft(id: string, version: number, actorId: string, admin = false) {
  const view = await getWhatsAppDraft(id, admin ? undefined : actorId);
  const prior = await db.order.findUnique({ where: { userId_idempotencyKey: { userId: view.draft.userId, idempotencyKey: view.draft.submitKey } } });
  if (prior) { await db.whatsAppDraft.update({ where: { id }, data: { status: 'SUBMITTED', orderId: prior.id } }); return { ...(await getWhatsAppDraft(id, admin ? undefined : actorId)), orderId: prior.id }; }
  if (view.draft.status === 'SUBMITTING' && view.draft.updatedAt.getTime() < Date.now() - 5 * 60000) await db.whatsAppDraft.updateMany({ where: { id, status: 'SUBMITTING', version }, data: { status: 'OPEN' } });
  const current = await db.whatsAppDraft.findUniqueOrThrow({ where: { id } });
  assertEditable(current, version);
  if (view.draft.reviewedVersion !== version || !view.draft.reviewSnapshot) throw new HttpError(409, 'Consultez /voir puis confirmez /valider après avoir vérifié chaque donnée.');
  if (view.missing.length) throw new HttpError(400, `À compléter : ${view.missing.join(' ; ')}`);
  const claimed = await db.whatsAppDraft.updateMany({ where: { id, status: 'OPEN', version, reviewedVersion: version }, data: { status: 'SUBMITTING' } });
  if (!claimed.count) throw new HttpError(409, 'Dépôt déjà en cours. Consultez son état avant de réessayer.');
  try {
    const documents = await serializable(async tx => {
      const files = await tx.whatsAppFile.findMany({ where: { draftId: id } });
      const ids: string[] = [];
      for (const file of files) {
        if (!file.fieldKey) continue;
        if (file.documentId) { ids.push(file.documentId); continue; }
        const document = await tx.document.create({ data: { ownerId: view.draft.userId, serviceId: view.draft.serviceId, fieldKey: file.fieldKey, kind: 'ATTACHMENT', fileName: file.fileName, mimeType: file.mimeType, bytes: file.bytes, storageKey: file.storageKey } });
        await tx.whatsAppFile.update({ where: { id: file.id }, data: { documentId: document.id } }); ids.push(document.id);
      }
      return ids;
    });
    const order = await createOrder(view.draft.userId, orderInput.parse({ serviceId: view.draft.serviceId, customerName: view.draft.customerName || undefined, fields: view.draft.fields, documentIds: documents, paymentMethod: 'CRYPTO', idempotencyKey: view.draft.submitKey, ...(view.draft.reviewSnapshot as WhatsAppReview) }), { whatsappBindingId: view.draft.bindingId });
    await db.whatsAppDraft.update({ where: { id }, data: { status: 'SUBMITTED', orderId: order.id } });
    return { ...(await getWhatsAppDraft(id, admin ? undefined : actorId)), orderId: order.id };
  } catch (error) {
    await db.whatsAppDraft.updateMany({ where: { id, status: 'SUBMITTING' }, data: { status: 'OPEN', reviewedVersion: null, reviewSnapshot: Prisma.DbNull } }); throw error;
  }
}
export async function whatsappDraftSummary(id: string, userId: string) {
  const view = await getWhatsAppDraft(id, userId); const draft = view.draft;
  const definitions = z.array(fieldDefinition).parse(draft.service.fields);
  const values = draft.fields as Record<string, string>;
  const lines = [`Brouillon ${draft.id} · ${draft.service.name}`, ...definitions.map(field => `${field.label} [${field.key}] : ${values[field.key] || 'à compléter'}`)];
  if (draft.customerName) lines.push(`Client : ${draft.customerName}`);
  lines.push(`Pièces : ${draft.files.map((file, index) => `${index + 1}. ${file.fileName} → ${file.fieldKey || 'à classer'}`).join(', ') || 'aucune'}`);
  lines.push(view.pricing.requiresQuote ? 'Tarif : sur devis. Aucun paiement avant votre accord.' : `Votre tarif : ${euro(view.pricing.priceCents)}. Paiement séparé après dépôt.`);
  lines.push(view.missing.length ? `À compléter : ${view.missing.join(' ; ')}` : 'Données complètes : vérifiez les informations puis /valider.');
  lines.push('OCR indicatif. /champ CLE=VALEUR pour corriger. /piece CLE puis renvoyez une pièce pour préciser son type.');
  const summary = lines.join('\n');
  if (summary.length > 3800) throw new HttpError(400, 'Récapitulatif trop long pour WhatsApp. Réduisez les champs ou vérifiez ce brouillon dans votre espace sécurisé. Aucun dépôt automatique.');
  return summary;
}
