import { createHmac, timingSafeEqual } from 'node:crypto';
import { HttpError } from './http';
import { integrationEndpoint } from './integrations';
import { MAX_FILE_BYTES, fileMime, videoMime } from './storage';
export const whatsappTransport = () => process.env.WHATSAPP_TRANSPORT === 'CLOUD' ? 'CLOUD' as const : 'WEB' as const;
export function whatsappConfigured() {
  return process.env.WHATSAPP_ENABLED === 'true' && (whatsappTransport() === 'WEB' ? !!(process.env.WHATSAPP_BRIDGE_SECRET && process.env.WHATSAPP_BRIDGE_SECRET.length >= 32 && process.env.WHATSAPP_BRIDGE_URL) : !!(process.env.WHATSAPP_ACCESS_TOKEN && process.env.WHATSAPP_PHONE_NUMBER_ID && process.env.WHATSAPP_APP_SECRET && process.env.WHATSAPP_VERIFY_TOKEN));
}
export function validWhatsAppSignature(raw: Uint8Array, signature: string, secret: string) {
  if (!secret || !/^sha256=[a-f0-9]{64}$/i.test(signature)) return false;
  const expected = createHmac('sha256', secret).update(raw).digest();
  return timingSafeEqual(expected, Buffer.from(signature.slice(7), 'hex'));
}
export async function whatsappRawBody(request: Request, max = 128000) {
  if (Number(request.headers.get('content-length') || 0) > max) throw new HttpError(413, 'Message trop volumineux.');
  const reader = request.body?.getReader(); if (!reader) throw new HttpError(400, 'Message absent.');
  const chunks: Uint8Array[] = []; let bytes = 0;
  for (;;) { const part = await reader.read(); if (part.done) break; bytes += part.value.length; if (bytes > max) { await reader.cancel(); throw new HttpError(413, 'Message trop volumineux.'); } chunks.push(part.value); }
  return Buffer.concat(chunks, bytes);
}
export function whatsappGraphRoot() {
  const version = process.env.WHATSAPP_GRAPH_VERSION || 'v24.0';
  if (!/^v\d{2}\.\d+$/.test(version)) throw new HttpError(503, 'Version Graph invalide.');
  return integrationEndpoint('TEST_WHATSAPP_GRAPH_ROOT', `https://graph.facebook.com/${version}`);
}
async function boundedResponse(response: Response, max: number) {
  if (Number(response.headers.get('content-length') || 0) > max) throw new HttpError(413, 'Pièce trop volumineuse.');
  const reader = response.body?.getReader(); if (!reader) throw new HttpError(502, 'Pièce indisponible.'); const chunks: Uint8Array[] = []; let total = 0;
  for (;;) { const chunk = await reader.read(); if (chunk.done) break; total += chunk.value.length; if (total > max) { await reader.cancel(); throw new HttpError(413, 'Pièce trop volumineuse.'); } chunks.push(chunk.value); }
  return Buffer.concat(chunks, total);
}
export async function downloadWhatsAppMedia(mediaId: string) {
  if (!/^[a-zA-Z0-9_-]{1,200}$/.test(mediaId)) throw new HttpError(400, 'Référence de pièce invalide.');
  const token = process.env.WHATSAPP_ACCESS_TOKEN; if (!token) throw new HttpError(503, 'WhatsApp non configuré.');
  const metadataResponse = await fetch(`${whatsappGraphRoot()}/${encodeURIComponent(mediaId)}`, { headers: { authorization: `Bearer ${token}` }, redirect: 'error', cache: 'no-store', signal: AbortSignal.timeout(15000) });
  if (!metadataResponse.ok) throw new HttpError(502, 'Pièce WhatsApp indisponible.');
  const metadata = JSON.parse((await boundedResponse(metadataResponse, 16000)).toString('utf8'));
  if (metadata.id && String(metadata.id) !== mediaId) throw new HttpError(502, 'Référence de pièce incohérente.');
  const url = new URL(String(metadata.url || ''));
  const test = process.env.NODE_ENV !== 'production' && process.env.KOMISIO_INTEGRATION_TEST_MODE === 'true' && url.protocol === 'http:' && url.hostname === '127.0.0.1';
  if (!test && (url.protocol !== 'https:' || url.username || url.password || !(url.hostname === 'lookaside.fbsbx.com' || url.hostname.endsWith('.fbcdn.net')))) throw new HttpError(502, 'Domaine de pièce WhatsApp refusé.');
  if (Number(metadata.file_size) > MAX_FILE_BYTES) throw new HttpError(413, 'Pièce limitée à 10 Mo.');
  const response = await fetch(url, { headers: { authorization: `Bearer ${token}` }, redirect: 'error', cache: 'no-store', signal: AbortSignal.timeout(20000) });
  if (!response.ok) throw new HttpError(502, 'Téléchargement WhatsApp indisponible.');
  const bytes = await boundedResponse(response, MAX_FILE_BYTES);
  const mimeType = fileMime(bytes) || videoMime(bytes); if (!mimeType) throw new HttpError(400, 'Formats acceptés : PDF, JPG, PNG, MP4 ou MOV.');
  if (metadata.sha256) { const { createHash } = await import('node:crypto'); const hash = createHash('sha256').update(bytes); const hex = hash.digest('hex'); const expected = String(metadata.sha256); if (expected !== hex && expected !== Buffer.from(hex, 'hex').toString('base64')) throw new HttpError(502, 'Intégrité de la pièce invalide.'); }
  return { bytes, mimeType };
}
export async function sendWhatsAppText(input: { id: string; phone: string; conversation: string; groupId: string | null; text: string; documentId?: string; userId?: string }) {
  let media: { base64: string; mimeType: string; filename: string } | undefined;
  if (input.documentId) {
    const { db } = await import('./db'); const { loadFile } = await import('./storage');
    const document = await db.document.findFirst({ where: { id: input.documentId, ownerId: input.userId || '__none__', kind: 'DELIVERABLE', order: { status: 'COMPLETED' } } });
    if (!document || document.bytes > MAX_FILE_BYTES) throw new HttpError(409, 'Livrable indisponible.');
    media = { base64: Buffer.from(await loadFile(document.storageKey)).toString('base64'), mimeType: document.mimeType, filename: document.fileName.replace(/[\x00-\x1f/\\]/g, '_').slice(0, 100) };
  }
  if (whatsappTransport() === 'WEB') {
    const url = new URL(process.env.WHATSAPP_BRIDGE_URL || '');
    const local = ['127.0.0.1', 'localhost', 'whatsapp-bridge', 'whatsapp'].includes(url.hostname);
    if (url.username || url.password || !(url.protocol === 'https:' || (url.protocol === 'http:' && local))) throw new HttpError(503, 'Adresse du connecteur WhatsApp invalide.');
    const response = await fetch(new URL('/send', url), { method: 'POST', headers: { authorization: `Bearer ${process.env.WHATSAPP_BRIDGE_SECRET || ''}`, 'content-type': 'application/json' }, body: JSON.stringify({ idempotencyKey: input.id, to: input.conversation, sender: input.phone, groupId: input.groupId, text: input.text, ...(media ? { media } : {}) }), redirect: 'error', signal: AbortSignal.timeout(15000) });
    if (!response.ok) throw new HttpError(502, 'Envoi WhatsApp à vérifier sur le connecteur.');
    const data = await response.json(); if (typeof data.id !== 'string' || !data.id || data.id.length > 300) throw new HttpError(502, 'Réponse du connecteur inconnue.'); return data.id;
  }
  if (media) throw new HttpError(409, 'Livrable à télécharger depuis votre espace sécurisé en mode Cloud.');
  const response = await fetch(`${whatsappGraphRoot()}/${encodeURIComponent(process.env.WHATSAPP_PHONE_NUMBER_ID || '')}/messages`, { method: 'POST', headers: { authorization: `Bearer ${process.env.WHATSAPP_ACCESS_TOKEN || ''}`, 'content-type': 'application/json' }, body: JSON.stringify({ messaging_product: 'whatsapp', recipient_type: input.groupId ? 'group' : 'individual', to: input.groupId || input.phone, type: 'text', text: { body: input.text, preview_url: false } }), redirect: 'error', signal: AbortSignal.timeout(15000) });
  if (!response.ok) throw new HttpError(502, 'Envoi WhatsApp à vérifier dans Meta.');
  const result = await response.json(); if (typeof result.messages?.[0]?.id !== 'string') throw new HttpError(502, 'Réponse d’envoi WhatsApp inconnue.'); return result.messages[0].id;
}
