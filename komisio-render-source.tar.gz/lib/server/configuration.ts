export function configurationIssues(env: Record<string, string | undefined> = process.env, production = env.NODE_ENV === 'production'): string[] {
  const issues: string[] = [];
  const required = ['DATABASE_URL','APP_URL','MINI_APP_URL','TELEGRAM_BOT_TOKEN','TELEGRAM_BOT_USERNAME','ADMIN_TELEGRAM_IDS','SESSION_SECRET','CRON_SECRET','TELEGRAM_WEBHOOK_SECRET','PRIVATE_UPLOAD_DIR'];
  const provider=env.PAYMENT_PROVIDER || 'PLISIO';
  if(provider==='PLISIO')required.push('PLISIO_API_KEY');else if(provider==='NOWPAYMENTS')required.push('NOWPAYMENTS_API_KEY','NOWPAYMENTS_IPN_SECRET');else issues.push('PAYMENT_PROVIDER invalide');
  if(env.STORAGE_DRIVER==='supabase'){required.push('SUPABASE_URL','SUPABASE_SERVICE_ROLE_KEY','SUPABASE_STORAGE_BUCKET');}else if(env.STORAGE_DRIVER && env.STORAGE_DRIVER!=='local')issues.push('STORAGE_DRIVER invalide');
  for (const key of required) if (!env[key]?.trim()) issues.push(`${key} manquant`);
  for (const key of ['SESSION_SECRET','CRON_SECRET','TELEGRAM_WEBHOOK_SECRET','NOWPAYMENTS_IPN_SECRET']) if (env[key] && env[key]!.length < 32) issues.push(`${key} : 32 caractères minimum`);
  if (env.SESSION_SECRET && env.SESSION_SECRET === env.CRON_SECRET) issues.push('SESSION_SECRET et CRON_SECRET doivent être distincts');
  if (env.ADMIN_TELEGRAM_IDS && !/^\d+(,\s*\d+)*$/.test(env.ADMIN_TELEGRAM_IDS.trim())) issues.push('ADMIN_TELEGRAM_IDS invalide');
  if (env.TELEGRAM_BOT_USERNAME && !/^[a-zA-Z0-9_]{5,32}$/.test(env.TELEGRAM_BOT_USERNAME)) issues.push('TELEGRAM_BOT_USERNAME invalide (sans @)');
  for (const key of ['APP_URL','MINI_APP_URL']) {
    if (!env[key]) continue;
    try { const url = new URL(env[key]!); if (url.username || url.password || !['http:','https:'].includes(url.protocol) || (production && url.protocol !== 'https:')) throw Error(); }
    catch { issues.push(`${key} : URL ${production ? 'HTTPS ' : ''}valide requise`); }
  }
  try { if (env.APP_URL && env.MINI_APP_URL && new URL(env.APP_URL).origin !== new URL(env.MINI_APP_URL).origin) issues.push('APP_URL et MINI_APP_URL doivent partager la même origine'); } catch {}
  if (env.DATABASE_URL) { try { if (!['postgres:','postgresql:'].includes(new URL(env.DATABASE_URL).protocol)) throw Error(); } catch { issues.push('DATABASE_URL : connexion PostgreSQL requise'); } }
  if (env.WHATSAPP_ENABLED === 'true') {
    const transport = env.WHATSAPP_TRANSPORT || 'WEB';
    if (!['WEB','CLOUD'].includes(transport)) issues.push('WHATSAPP_TRANSPORT invalide');
    if (transport === 'WEB') {
      if (!env.WHATSAPP_BRIDGE_SECRET || env.WHATSAPP_BRIDGE_SECRET.length < 32) issues.push('WHATSAPP_BRIDGE_SECRET : 32 caractères minimum');
      try { const url = new URL(env.WHATSAPP_BRIDGE_URL || ''); if (!['http:','https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) throw Error(); } catch { issues.push('WHATSAPP_BRIDGE_URL invalide'); }
    } else if (transport === 'CLOUD') {
      for (const key of ['WHATSAPP_ACCESS_TOKEN','WHATSAPP_PHONE_NUMBER_ID','WHATSAPP_APP_SECRET','WHATSAPP_VERIFY_TOKEN']) if (!env[key]?.trim()) issues.push(`${key} manquant`);
    }
  }
  if (production && env.NEXT_PUBLIC_DEMO_MODE !== 'false') issues.push('NEXT_PUBLIC_DEMO_MODE doit être false en production');
  if (production && (env.KOMISIO_INTEGRATION_TEST_MODE || env.TEST_TELEGRAM_API_ROOT || env.TEST_NOWPAYMENTS_API_ROOT || env.TEST_PLISIO_API_ROOT || env.TEST_SUPABASE_STORAGE_ROOT || env.TEST_WHATSAPP_GRAPH_ROOT)) issues.push('Les réglages de test sont interdits en production');
  return issues;
}
