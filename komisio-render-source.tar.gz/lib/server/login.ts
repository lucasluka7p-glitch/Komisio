import { createHmac } from "node:crypto";
import { serializable } from "./db";
import { HttpError } from "./http";
/** Shared PostgreSQL limits survive restarts and multiple web instances. */
export async function limitLogin(login: string) {
  const secret = process.env.SESSION_SECRET ?? "";
  if (secret.length < 32) throw new HttpError(503, "Connexion non configurée.");
  const keys = [{ key: "password:global", limit: 300 }, { key: "password:" + createHmac("sha256", secret).update(login).digest("hex"), limit: 8 }];
  const allowed = await serializable(async tx => {
    const cutoff = new Date(Date.now() - 15 * 60_000);
    await tx.loginAttempt.deleteMany({ where: { windowAt: { lt: new Date(Date.now() - 86400_000) } } });
    let ok = true;
    for (const item of keys) {
      await tx.loginAttempt.updateMany({ where: { key: item.key, windowAt: { lt: cutoff } }, data: { attempts: 0, windowAt: new Date() } });
      const attempt = await tx.loginAttempt.upsert({ where: { key: item.key }, create: { key: item.key }, update: { attempts: { increment: 1 } } });
      if (attempt.attempts > item.limit) ok = false;
    }
    return ok;
  });
  if (!allowed) throw new HttpError(429, "Trop de tentatives. Réessayez dans 15 minutes ou contactez votre administrateur.");
}

export async function clearLoginLimit(login: string) {
  const { db } = await import("./db");
  const key = "password:" + createHmac("sha256", process.env.SESSION_SECRET ?? "").update(login).digest("hex");
  await db.loginAttempt.deleteMany({ where: { key } });
}
