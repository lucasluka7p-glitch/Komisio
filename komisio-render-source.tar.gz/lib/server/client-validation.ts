import { z } from "zod";
import { carteGriseIds } from "../pricing";
export const clientLogin = z.string().trim().toLowerCase().regex(/^[a-z0-9][a-z0-9._-]{2,63}$/, "Identifiant : 3 à 64 caractères, lettres, chiffres, point, tiret ou underscore.");
export const clientPricingInput = z.object({
  defaultDiscountBps: z.number().int().min(0).max(10000),
  prices: z.array(z.object({
    serviceId: z.string().min(1).max(100), mode: z.enum(["FIXED", "DISCOUNT", "QUOTE"]),
    priceCents: z.number().int().min(100).max(10_000_000).nullable(),
    discountBps: z.number().int().min(0).max(10000),
    minimumCents: z.number().int().min(0).max(10_000_000),
  }).strict().superRefine((value, ctx) => {
    if ((value.mode === "FIXED") !== (value.priceCents !== null)) ctx.addIssue({ code: "custom", path: ["priceCents"], message: "Un montant est requis uniquement pour un prix fixe." });
    if (value.mode !== "DISCOUNT" && value.discountBps !== 0) ctx.addIssue({ code: "custom", path: ["discountBps"], message: "La remise nécessite le mode pourcentage." });
    if (carteGriseIds.includes(value.serviceId) && (value.minimumCents < 6000 || (value.priceCents !== null && value.priceCents < 6000))) ctx.addIssue({ code: "custom", path: ["minimumCents"], message: "Minimum de 60 € par carte grise." });
  })).max(500),
}).strict().superRefine((value, ctx) => {
  if (new Set(value.prices.map(price => price.serviceId)).size !== value.prices.length) ctx.addIssue({ code: "custom", path: ["prices"], message: "Une règle maximum par service." });
});
export const createClientInput = z.object({
  name: z.string().trim().min(2).max(128), login: clientLogin,
  telegramId: z.string().regex(/^[1-9]\d{4,15}$/).nullable().default(null),
  pricing: clientPricingInput,
  activate: z.boolean().default(false),
}).strict();
export const updateClientInput = z.object({
  name: z.string().trim().min(2).max(128), login: clientLogin,
  expectedVersion: z.number().int().min(0), pricing: clientPricingInput,
}).strict();
