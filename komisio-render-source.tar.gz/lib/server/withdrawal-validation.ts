import { createHash } from "node:crypto";
import { Prisma } from "@prisma/client";
import { z } from "zod";
import { HttpError } from "./http";

/** TRON mainnet base58check, including version and checksum. */
export function validTronAddress(value: string) {
  if (!/^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(value)) return false;
  const alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
  let n = 0n;
  for (const c of value) n = n * 58n + BigInt(alphabet.indexOf(c));
  const bytes = Buffer.from(n.toString(16).padStart(50, "0"), "hex");
  if (bytes.length !== 25 || bytes[0] !== 0x41) return false;
  const hash = createHash("sha256").update(createHash("sha256").update(bytes.subarray(0, 21)).digest()).digest();
  return bytes.subarray(21).equals(hash.subarray(0, 4));
}
export const withdrawalInput = z.object({
  amountCents: z.number().int().min(1).max(10_000_000),
  currency: z.literal("usdttrc20"),
  address: z.string().trim().refine(validTronAddress, "Adresse TRON invalide (réseau TRC20)."),
  idempotencyKey: z.string().uuid(),
}).strict();
export const withdrawalAction = z.discriminatedUnion("action", [
  z.object({ action: z.literal("accept"), quoteVersion: z.number().int().positive() }).strict(),
  z.object({ action: z.literal("cancel") }).strict(),
]);
export const adminWithdrawalAction = z.discriminatedUnion("action", [
  z.object({ action: z.literal("quote"), feeCents: z.number().int().min(0).max(10_000_000), exchangeRate: z.string().regex(/^[1-9]\d{0,5}(\.\d{1,10})?$|^0\.\d{1,10}$/), source: z.string().trim().min(3).max(250) }).strict(),
  z.object({ action: z.literal("reject"), note: z.string().trim().min(3).max(1000) }).strict(),
  z.object({ action: z.literal("fail"), confirmedNoFundsMoved: z.literal(true), note: z.string().trim().min(20).max(1000) }).strict(),
  z.object({ action: z.literal("process") }).strict(),
  z.object({ action: z.literal("sent"), txHash: z.string().regex(/^[a-fA-F0-9]{64}$/) }).strict(),
  z.object({ action: z.literal("complete"), note: z.string().trim().min(3).max(1000) }).strict(),
]);
export function calculateNet(amountCents: number, feeCents: number, exchangeRate: string) {
  const rate = new Prisma.Decimal(exchangeRate);
  if (feeCents >= amountCents || !rate.gt(0)) throw new HttpError(400, "Les frais doivent être inférieurs au montant et le taux positif.");
  const net = new Prisma.Decimal(amountCents - feeCents).div(100).times(rate).toDecimalPlaces(6, Prisma.Decimal.ROUND_DOWN);
  if (!net.gt(0)) throw new HttpError(400, "Montant net trop faible pour ce réseau.");
  return net.toFixed(6);
}
