import { telegramWebhookSecret } from './telegram-secret';
import { telegramBot } from './integrations';
import { HttpError } from './http';
export async function configureTelegramBot(){
 const username=process.env.TELEGRAM_BOT_USERNAME,secret=process.env.TELEGRAM_WEBHOOK_SECRET,app=process.env.APP_URL,mini=process.env.MINI_APP_URL;
 if(!username||!secret||secret.length<32||!app||!mini||new URL(app).protocol!=='https:'||new URL(mini).protocol!=='https:')throw new HttpError(503,'Configuration Telegram incomplète.');
 const bot=telegramBot(),identity=await bot.api.getMe();
 if(identity.username?.toLowerCase()!==username.toLowerCase())throw new HttpError(409,'Le token ne correspond pas au nom du bot configuré.');
 await bot.api.setMyCommands([{command:'start',description:'Ouvrir votre espace partenaire Komisio'}]);
 await bot.api.setChatMenuButton({menu_button:{type:'web_app',text:'Komisio',web_app:{url:mini}}});
 const webhookUrl=`${new URL(app).origin}/api/bot`;
 await bot.api.setWebhook(webhookUrl,{secret_token:telegramWebhookSecret(secret),allowed_updates:['message'],drop_pending_updates:false});
 const webhook=await bot.api.getWebhookInfo();if(webhook.url!==webhookUrl)throw new HttpError(502,'Webhook Telegram non confirmé.');
 return {botUsername:identity.username,webhookUrl};
}
