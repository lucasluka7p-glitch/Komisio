import { queueCustomerNotification } from "./customer-notifications";
import type { Withdrawal } from '@prisma/client';
import { db,serializable } from './db';
import { HttpError } from './http';
import { plisioRequest,plisioDecimal,type PlisioOperation } from './plisio';
import { actOnWithdrawal } from './withdrawals';
function enabled(){if(process.env.PLISIO_PAYOUTS_ENABLED!=='true'||!process.env.PLISIO_API_KEY)throw new HttpError(503,'Les retraits Plisio ne sont pas encore raccordés.');}
async function fee(address:string,amount:string){const result=await plisioRequest<{psys_cid:string;currency:string;fee:string}>('/operations/fee/USDT_TRX',{addresses:address,amounts:amount,feePlan:'normal'});if(result.psys_cid!=='USDT_TRX'||!['USDT_TRX','USDT'].includes(result.currency))throw new HttpError(409,'Unité des frais Plisio non vérifiable. Utilisez un devis vérifié.');return plisioDecimal(result.fee);}
export async function quotePlisioPayout(id:string,actorId:string){
 enabled();const w=await db.withdrawal.findUnique({where:{id}});if(!w||!['REQUESTED','QUOTED'].includes(w.status))throw new HttpError(409,'Ce retrait ne peut plus recevoir de devis.');
 const coins=await plisioRequest<{cid:string;fiat:string;fiat_rate:string;maintenance?:boolean;hidden?:number}[]>('/currencies/EUR');
 const coin=coins.find(c=>c.cid==='USDT_TRX'&&c.fiat==='EUR'&&!c.maintenance&&c.hidden!==1);if(!coin)throw new HttpError(503,'USDT TRC20 n’est pas disponible sur le compte Plisio.');
 const rate=plisioDecimal(coin.fiat_rate);if(!rate.gt(0))throw new HttpError(409,'Taux Plisio invalide.');
 const estimate=await fee(w.address,rate.times(w.amountCents).div(100).toFixed(6));
 const feeCents=estimate.div(rate).times(100).ceil().toNumber();
 return actOnWithdrawal(id,actorId,true,{action:'quote',feeCents,exchangeRate:rate.toFixed(10),source:'Plisio : taux EUR/USDT et estimation réseau normal'});
}
function validateTransfer(w:Withdrawal,operation:PlisioOperation){
 if(operation.type!=='cash_out'||operation.psys_cid!=='USDT_TRX'||operation.wallet_hash!==w.address||!w.netAmount||!plisioDecimal(operation.amount).eq(w.netAmount))throw new HttpError(409,'Le transfert Plisio ne correspond pas au retrait.');
}
function transferHash(operation:PlisioOperation){
 const candidates=[...(operation.tx||[]).map(tx=>tx.txid),...(operation.tx_id||[])];
 if(operation.tx_url){try{const url=new URL(operation.tx_url);candidates.push(url.searchParams.get('query')||url.pathname.split('/').at(-1)||'');}catch{}}
 return candidates.find(value=>typeof value==='string'&&/^[a-f0-9]{64}$/i.test(value));
}
export async function reconcilePlisioPayout(id:string,actorId?:string){
 const w=await db.withdrawal.findUnique({where:{id}});if(!w||w.provider!=='PLISIO'||!w.providerTransferId||!['PROCESSING','SENT'].includes(w.status))return w;
 const operation=await plisioRequest<PlisioOperation>(`/operations/${encodeURIComponent(w.providerTransferId)}`);if(operation.id!==w.providerTransferId||operation.type!=='cash_out')throw new HttpError(409,'Identifiant de transfert incohérent.');
 const proof=w.providerReceipt as (PlisioOperation&{tx_hash?:string})|null;
 if(operation.psys_cid&&operation.wallet_hash&&operation.amount)validateTransfer(w,operation);
 else {
  if(!proof||proof.id!==operation.id)throw new HttpError(409,'Métadonnées de transfert insuffisantes pour une confirmation automatique.');validateTransfer(w,proof);
  if(operation.psys_cid&&operation.psys_cid!=='USDT_TRX'||operation.wallet_hash&&operation.wallet_hash!==w.address||operation.amount&&!plisioDecimal(operation.amount).eq(w.netAmount!))throw new HttpError(409,'Métadonnées de transfert incohérentes.');
 }
 const hash=transferHash(operation)||proof?.tx_hash||w.txHash;
 if(!hash||!/^[a-f0-9]{64}$/i.test(hash))return w;const target=operation.status==='completed'&&Number(operation.confirmations)>=1?'COMPLETED':'SENT';
 return serializable(async tx=>{
  const current=await tx.withdrawal.findUniqueOrThrow({where:{id},include:{user:true}});
  if(!['PROCESSING','SENT'].includes(current.status)||current.status===target&&current.txHash===hash.toLowerCase())return current;
  if(current.providerTransferId!==operation.id)throw new HttpError(409,'Le retrait a changé.');
  const updated=await tx.withdrawal.update({where:{id},data:{status:target,txHash:hash.toLowerCase(),note:target==='COMPLETED'?'Transfert confirmé par Plisio sur TRON.':'Transfert Plisio diffusé, confirmation réseau en attente.'}});
  const initiator=actorId ? {actorId} : await tx.auditLog.findFirst({where:{targetId:id,action:'withdrawal.plisio_attempt'},orderBy:{createdAt:'desc'},select:{actorId:true}});
  if(!initiator)throw new HttpError(409,'Audit de l’envoi Plisio introuvable.');
  await tx.auditLog.create({data:{actorId:initiator.actorId,action:'withdrawal.plisio_reconciled',targetId:id,details:{operationId:operation.id,status:target,txHash:hash,automated:!actorId}}});
  await queueCustomerNotification(tx,current.user,`💸 Retrait ${id} : ${target==='COMPLETED'?'confirmé':'envoyé sur TRON'}. Transaction : ${hash}.`);return updated;
 });
}
export async function sendPlisioPayout(id:string,actorId:string){
 enabled();const w=await db.withdrawal.findUnique({where:{id}});if(!w)throw new HttpError(404,'Retrait introuvable.');
 if(w.providerTransferId)return reconcilePlisioPayout(id,actorId);
 if(w.status!=='APPROVED'||w.providerAttemptedAt||!w.netAmount||!w.exchangeRate||w.feeCents===null)throw new HttpError(409,'Un envoi a déjà été lancé ou les frais ne sont pas acceptés. Réconciliez avant toute nouvelle tentative.');
 const estimate=await fee(w.address,w.netAmount);const approved=plisioDecimal(w.exchangeRate).times(w.feeCents).div(100);
 if(estimate.gt(approved))throw new HttpError(409,'Les frais réseau ont augmenté. Annulez le retrait pour présenter un nouveau devis avant tout envoi.');
 const balance=await plisioRequest<{psys_cid:string;balance:string}>('/balances/USDT_TRX');if(balance.psys_cid!=='USDT_TRX'||plisioDecimal(balance.balance).lt(plisioDecimal(w.netAmount).plus(estimate)))throw new HttpError(409,'Solde USDT TRC20 Plisio insuffisant. Aucun envoi lancé.');
 await serializable(async tx=>{
  const claim=await tx.withdrawal.updateMany({where:{id,status:'APPROVED',providerAttemptedAt:null,quoteVersion:w.quoteVersion},data:{status:'PROCESSING',provider:'PLISIO',providerAttemptedAt:new Date(),note:'Envoi Plisio lancé. Toute réponse inconnue exige une réconciliation.'}});
  if(!claim.count)throw new HttpError(409,'Un envoi est déjà lancé pour ce retrait.');
  await tx.auditLog.create({data:{actorId,action:'withdrawal.plisio_attempt',targetId:id,details:{netAmount:w.netAmount}}});
 });
 // One side-effecting provider call, outside the transaction. Never repeat after an ambiguous response.
 const operation=await plisioRequest<PlisioOperation>('/operations/withdraw',{currency:'USDT_TRX',type:'cash_out',to:w.address,amount:w.netAmount,feePlan:'normal'});validateTransfer(w,operation);
 if(!operation.id)throw new HttpError(502,'Réponse Plisio ambiguë. Réconciliez le retrait.');
 await db.withdrawal.update({where:{id},data:{providerTransferId:operation.id,providerReceipt:{id:operation.id,type:operation.type,psys_cid:operation.psys_cid!,wallet_hash:operation.wallet_hash!,amount:operation.amount!,tx_hash:transferHash(operation)||null}}});
 return reconcilePlisioPayout(id,actorId);
}
export async function linkPlisioPayout(id:string,operationId:string,actorId:string){
 enabled();const w=await db.withdrawal.findUnique({where:{id}});if(!w||w.provider!=='PLISIO'||!w.providerAttemptedAt||w.status!=='PROCESSING')throw new HttpError(409,'Ce retrait n’attend pas de rattachement.');
 if(w.providerTransferId){if(w.providerTransferId!==operationId)throw new HttpError(409,'Une autre opération est déjà rattachée.');return reconcilePlisioPayout(id,actorId);}
 const operation=await plisioRequest<PlisioOperation&{created_at_utc?:number}>(`/operations/${encodeURIComponent(operationId)}`);if(operation.id!==operationId)throw new HttpError(409,'Identifiant incohérent.');validateTransfer(w,operation);
 let created=Number(operation.created_at_utc);if(created<1e12)created*=1000;if(!Number.isFinite(created)||created<w.providerAttemptedAt.getTime()-60000||created>Date.now()+60000)throw new HttpError(409,'La date du transfert ne correspond pas à cet envoi.');
 await serializable(async tx=>{const current=await tx.withdrawal.findUniqueOrThrow({where:{id}});if(current.providerTransferId||current.status!=='PROCESSING')throw new HttpError(409,'Le retrait a changé.');await tx.withdrawal.update({where:{id},data:{providerTransferId:operationId,providerReceipt:{id:operation.id,type:operation.type,psys_cid:operation.psys_cid!,wallet_hash:operation.wallet_hash!,amount:operation.amount!,tx_hash:transferHash(operation)||null}}});await tx.auditLog.create({data:{actorId,action:'withdrawal.plisio_linked',targetId:id,details:{operationId}}});});return reconcilePlisioPayout(id,actorId);
}
