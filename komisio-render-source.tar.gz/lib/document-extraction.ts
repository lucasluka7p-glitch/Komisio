/** OCR is untrusted text. Only anchored, known document labels become suggestions.
 * No instructions, links, amounts, commands or payment data are interpreted.
 */
export type DocumentRole = "registration" | "buyer_identity" | "holder_identity" | "requester_identity" | "unknown";
export type DocumentExtraction = {
  fields: Record<string, string>;
  confidence: number;
  fieldConfidence: Record<string, number>;
  warnings: string[];
  reviewRequired: true;
  documentType: "registration" | "identity" | "unknown";
};

const normalize = (value: string) => value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[’‘]/g, "'").toUpperCase();
const tidy = (value: string) => value.replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").trim();
const labelLike = /^(?:[A-Z](?:\.\d)?[\s.:|)]|NOM\b|PRENOM\b|DATE\b|LIEU\b|ADRESSE\b|SIGNATURE\b|NUMERO\b|N[°O]\b)/;

function labelled(lines: string[], labels: RegExp[], maxLines = 1): string[] {
  const values: string[] = [];
  for (let i = 0; i < lines.length; i++) {
    const line = normalize(lines[i]);
    for (const label of labels) {
      const found = label.exec(line);
      if (!found || found.index !== 0) continue;
      let value = tidy(lines[i].slice(found[0].length));
      let cursor = i + 1;
      if (!value && cursor < lines.length && !labelLike.test(normalize(lines[cursor]))) value = tidy(lines[cursor++]);
      for (let extra = 1; extra < maxLines && cursor < lines.length; extra++, cursor++) {
        const next = tidy(lines[cursor]);
        if (!next || labelLike.test(normalize(next))) break;
        value += ` ${next}`;
      }
      if (value) values.push(value);
      break;
    }
  }
  return [...new Set(values)];
}

function isoDate(value: string): string | null {
  const match = value.match(/^(\d{2})[/.\-](\d{2})[/.\-](\d{4})$/) || value.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match) return null;
  const candidate = match[1].length === 4 ? `${match[1]}-${match[2]}-${match[3]}` : `${match[3]}-${match[2]}-${match[1]}`;
  const parsed = new Date(candidate + "T00:00:00Z");
  return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === candidate && candidate >= "1900-01-01" && candidate <= new Date().toISOString().slice(0, 10) ? candidate : null;
}

export function extractDocumentFields(text: string, role: DocumentRole = "unknown", engineConfidence = 75): DocumentExtraction {
  const lines = text.slice(0, 500_000).split(/\r?\n/).map(tidy).filter(Boolean);
  const normalized = normalize(lines.join("\n"));
  const isRegistration = role === "registration" || /CERTIFICAT D[' ]IMMATRICULATION|CARTE GRISE/.test(normalized) || (/^P[. ]?6\b/m.test(normalized) && /^E[\s.:|)]/m.test(normalized));
  const isIdentity = !isRegistration && (/CARTE NATIONALE D[' ]IDENTITE|PASSEPORT|IDENTITY CARD|PASSPORT/.test(normalized) || ["buyer_identity", "holder_identity", "requester_identity"].includes(role));
  const fields: Record<string, string> = {};
  const fieldConfidence: Record<string, number> = {};
  const warnings = ["Lecture automatique à vérifier avant toute validation du dossier."];
  const confidence = Math.max(0, Math.min(99, Number.isFinite(engineConfidence) ? engineConfidence : 0));
  if (confidence < 35) return { fields, confidence, fieldConfidence, warnings: [...warnings, "Qualité de lecture insuffisante : aucune information préremplie. Envoyez une photo plus nette ou saisissez les champs manuellement."], reviewRequired: true, documentType: isRegistration ? "registration" : isIdentity ? "identity" : "unknown" };
  function put(key: string, candidates: string[], transform: (value: string) => string | null = tidy) {
    const values = [...new Set(candidates.map(transform).filter((value): value is string => !!value))];
    if (values.length > 1) { warnings.push(`Plusieurs valeurs possibles pour ${key} : saisie manuelle requise.`); return; }
    if (values.length === 1 && values[0].length <= 500) { fields[key] = values[0]; fieldConfidence[key] = confidence; }
  }
  if (isRegistration) {
    put("registration", labelled(lines, [/^(?:A\s*[.:|)]\s*)/, /^(?:IMMATRICULATION|PLAQUE(?: D[' ]IMMATRICULATION)?)\s*[:|=-]\s*/]), value => {
      const compact = normalize(value).replace(/[\s-]/g, "");
      if (/^[A-Z]{2}\d{3}[A-Z]{2}$/.test(compact)) return `${compact.slice(0, 2)}-${compact.slice(2, 5)}-${compact.slice(5)}`;
      return /^\d{1,4}[A-Z]{1,3}\d{2,3}$/.test(compact) ? compact : null;
    });
    put("vin", labelled(lines, [/^E\s*[.:|)]\s*/, /^(?:VIN|NUMERO (?:DE SERIE|VIN)|N[°O]\s*(?:DE SERIE|VIN))\s*[:|=-]\s*/]), value => {
      const compact = normalize(value).replace(/\s/g, "");
      return /^[A-HJ-NPR-Z0-9]{17}$/.test(compact) ? compact : null;
    });
    put("formulaNumber", labelled(lines, [/^(?:NUMERO|N[°O])\s*(?:DE )?FORMULE\s*[:|=-]\s*/, /^FORMULE\s*[:|=-]\s*/]), value => {
      const compact = normalize(value).replace(/\s/g, ""); return /^\d{4}[A-Z]{2}\d{5}$/.test(compact) ? compact : null;
    });
    put("holderIdentity", labelled(lines, [/^C\s*\.\s*1\s*[:|=-]?\s*/, /^(?:TITULAIRE|IDENTITE DU TITULAIRE)\s*[:|=-]\s*/]), value => {
      const clean = tidy(value); return clean.length >= 2 && !/^https?:|^\/|[<>{}]/i.test(clean) ? clean : null;
    });
    put("holderAddress", labelled(lines, [/^C\s*\.\s*3\s*[:|=-]?\s*/, /^ADRESSE(?: DU TITULAIRE)?\s*[:|=-]\s*/], 3), value => /\b\d{5}\b/.test(value) ? tidy(value) : null);
    put("fiscalPower", labelled(lines, [/^P\s*\.\s*6\s*[:|=-]?\s*/, /^PUISSANCE FISCALE\s*[:|=-]\s*/]), value => /^\d{1,3}$/.test(value) && Number(value) > 0 ? String(Number(value)) : null);
    put("firstRegistration", labelled(lines, [/^B\s*[.:|)]\s*/, /^DATE (?:DE )?(?:1(?:ERE|RE)?|PREMIERE) (?:IMMATRICULATION|MISE EN CIRCULATION)\s*[:|=-]\s*/]), isoDate);
    warnings.push("Le titulaire de la carte grise n’est pas automatiquement l’acquéreur. Adresse de livraison et identité de l’acquéreur à confirmer séparément.");
  } else if (isIdentity) {
    if (role === "unknown") warnings.push("Précisez à qui appartient cette pièce d’identité avant de préremplir des champs personnels.");
    else {
      const names = labelled(lines, [/^NOM\b(?: DE (?:FAMILLE|NAISSANCE))?(?:\s*\/\s*(?:SURNAME|LAST NAME))?\s*[:|=-]?\s*/]);
      const firstNames = labelled(lines, [/^PRENOMS?\b(?:\s*\/\s*(?:GIVEN NAMES?|FIRST NAMES?))?\s*[:|=-]?\s*/]);
      const birthDates = labelled(lines, [/^(?:DATE DE NAISSANCE|NE\(?E?\)? LE)(?:\s*\/\s*DATE OF BIRTH)?\s*[:|=-]?\s*/]);
      const birthPlaces = labelled(lines, [/^(?:LIEU DE NAISSANCE|NE\(?E?\)? A)(?:\s*\/\s*PLACE OF BIRTH)?\s*[:|=-]?\s*/]);
      const personalName = (value: string) => /^[\p{L}][\p{L}\s'’-]{0,100}$/u.test(value) ? tidy(value) : null;
      if (role === "buyer_identity") {
        put("buyerLastName", names, personalName); put("buyerFirstName", firstNames, personalName);
        put("buyerBirthDate", birthDates, isoDate); put("buyerBirthPlace", birthPlaces, personalName);
      } else if (role === "requester_identity") {
        put("lastName", names, personalName); put("firstName", firstNames, personalName); put("birthDate", birthDates, isoDate);
      } else {
        const last = [...new Set(names.map(personalName).filter(Boolean))], first = [...new Set(firstNames.map(personalName).filter(Boolean))];
        if (last.length === 1 && first.length === 1) put("holderIdentity", [`${last[0]} ${first[0]}`]);
      }
    }
  }
  if (!Object.keys(fields).length) warnings.push("Aucun champ suffisamment lisible et non ambigu n’a été extrait. Complétez le dossier manuellement.");
  return { fields, confidence, fieldConfidence, warnings, reviewRequired: true, documentType: isRegistration ? "registration" : isIdentity ? "identity" : "unknown" };
}
