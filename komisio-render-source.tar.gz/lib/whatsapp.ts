export const whatsappServices: Record<string, string> = {
  ct: 'controle-convoyage', cg: 'carte-grise', 'cg sans ct': 'carte-grise-sans-ct', ww: 'ww', 'ww mod': 'ww-modification', 'ww modif': 'ww-modification', 'ww modifier': 'ww-modification',
  'fiche po': 'situation-vehicule', fiche: 'situation-vehicule', vehicule: 'situation-vehicule', recherche: 'acces-donnees-personnelles', ecra: 'regularisation-carte-grise', leasing: 'fin-leasing', ecraleas: 'fin-leasing', 'ecra leas': 'fin-leasing', 'ecra leasing': 'fin-leasing', cession: 'cession', da: 'achat', suisse: 'douane-suisse', creation: 'creation', modification: 'modification',
};
export function whatsappCommand(text: string) {
  if (!text.trim().startsWith('/')) return null;
  const value = text.trim().slice(1).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ');
  if (whatsappServices[value]) return { command: 'start', serviceId: whatsappServices[value], argument: '' };
  const split = text.trim().slice(1).match(/^(\S+)(?:\s+([\s\S]*))?$/)!;
  return { command: split[1].toLowerCase(), argument: (split[2] || '').trim() };
}
export const whatsappHelp = 'Komisio — commandes\n/cg · /cg sans ct · /ww · /ww mod · /fiche po · /recherche · /ecra · /leasing · /cession · /da · /suisse · /creation · /modification\nEnvoyez ensuite les pièces du même dossier.\n/piece CLE : préciser la prochaine pièce\n/classer NUMERO CLE : classer une pièce reçue\n/champ CLE=VALEUR : corriger un champ\n/nom NOM : nom du client final si demandé\n/voir : contrôler le récapitulatif et le tarif\n/valider : déposer le dossier après contrôle, sans paiement\n/annuler : abandonner le brouillon\n/statut · /devis · /solde · /support MESSAGE\n/accepter NUMERO VERSION · /refuser NUMERO VERSION\n/payer NUMERO · /livrable NUMERO\nL’OCR propose des données à vérifier. Il ne valide jamais un dossier et ne déclenche aucun débit.';
export function whatsappPhone(value: string) { const phone = value.trim().replace(/^\+/, ''); if (!/^[1-9]\d{6,14}$/.test(phone)) throw new Error('Numéro WhatsApp international invalide.'); return phone; }
