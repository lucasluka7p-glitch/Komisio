/** All money is integer euro cents; discounts are basis points (100 = 1%). */
export type PriceRule = { serviceId: string; mode: "FIXED" | "DISCOUNT" | "QUOTE"; priceCents: number | null; discountBps: number; minimumCents: number };
export type PricingSnapshot = { mode: PriceRule["mode"]; basePriceCents: number; discountBps: number; minimumCents: number; source: "CLIENT" | "CATALOGUE"; version: number };
export const carteGriseIds = ["carte-grise", "carte-grise-sans-ct"];
export function discountedPrice(referenceCents: number, discountBps: number, minimumCents = 0): number {
  if (![referenceCents, discountBps, minimumCents].every(Number.isSafeInteger) || referenceCents < 0 || referenceCents > 10_000_000 || discountBps < 0 || discountBps > 10000 || minimumCents < 0 || minimumCents > 10_000_000) throw new Error("Tarif invalide.");
  return Math.max(minimumCents, Math.round(referenceCents * (10000 - discountBps) / 10000));
}
export function resolvePrice(service: { id: string; priceCents: number; requiresQuote: boolean }, user: { defaultDiscountBps: number; pricingVersion: number }, rule?: PriceRule | null) {
  const minimumCents = Math.max(carteGriseIds.includes(service.id) ? 6000 : 100, rule?.minimumCents ?? 0);
  const discountBps = rule ? (rule.mode === "DISCOUNT" ? rule.discountBps : 0) : user.defaultDiscountBps;
  const mode = rule?.mode ?? (discountBps ? "DISCOUNT" : service.requiresQuote ? "QUOTE" : "FIXED");
  const requiresQuote = mode === "QUOTE" || (mode === "DISCOUNT" && service.requiresQuote);
  const basePriceCents = rule?.mode === "FIXED" ? rule.priceCents! : service.priceCents;
  const pricing: PricingSnapshot = { mode, basePriceCents, discountBps, minimumCents, source: rule || discountBps ? "CLIENT" : "CATALOGUE", version: user.pricingVersion };
  return { priceCents: requiresQuote ? 0 : discountedPrice(basePriceCents, discountBps, minimumCents), requiresQuote, pricing };
}
export function quotePrice(referenceCents: number, snapshot: PricingSnapshot | null | undefined): number {
  if (!snapshot) return referenceCents; // Existing dossiers retain their agreed rules.
  return discountedPrice(referenceCents, snapshot.mode === "DISCOUNT" ? snapshot.discountBps : 0, snapshot.minimumCents);
}
export function pricingHint(pricing?: PricingSnapshot | null, requiresQuote = true) {
  if (!pricing) return "";
  const parts: string[] = [];
  if (pricing.discountBps) parts.push(`−${pricing.discountBps / 100} %${requiresQuote ? " sur le montant de référence" : " sur le tarif catalogue"}`);
  if (pricing.minimumCents > 100) parts.push(`minimum ${(pricing.minimumCents / 100).toLocaleString("fr-FR")} €`);
  return parts.join(" · ");
}
export function newClientRules(services: { id: string }[]): PriceRule[] {
  return services.filter(service => carteGriseIds.includes(service.id)).map(service => ({ serviceId: service.id, mode: "DISCOUNT", priceCents: null, discountBps: 5000, minimumCents: 6000 }));
}
