/** Shared display contracts. Currency amounts remain decimal strings. */
export const withdrawalLabels = {
  REQUESTED: "Frais à calculer", QUOTED: "À confirmer", APPROVED: "Solde réservé",
  PROCESSING: "Envoi en préparation", SENT: "Envoyé sur le réseau", COMPLETED: "Confirmé",
  CANCELLED: "Annulé", REJECTED: "Refusé", FAILED: "Échec vérifié · solde libéré",
} as const;
export type WithdrawalStatus = keyof typeof withdrawalLabels;
export type WithdrawalView = {
  id: string; amountCents: number; currency: string; address: string;
  status: WithdrawalStatus; quoteVersion: number; feeCents: number | null;
  exchangeRate: string | null; netAmount: string | null; quoteSource: string | null;
  quoteExpiresAt: string | null; txHash: string | null; note: string | null;
  provider?: string | null; providerTransferId?: string | null; providerAttemptedAt?: string | null;
  createdAt: string; user?: { firstName: string; telegramId: string };
};
export const reservedStatuses: WithdrawalStatus[] = ["APPROVED", "PROCESSING", "SENT"];
