export type Appearance = "light" | "dark";
export const APPEARANCE_KEY = "komisio-appearance";
export const appearanceColor = (theme: Appearance) => theme === "dark" ? "#081426" : "#f4f7fc";

// Runs in the head before the first paint, including on the static demonstration.
// Storage may be unavailable in a private WebView; the OS preference still works.
export const appearanceInitScript = `(function(){var t;try{t=localStorage.getItem('${APPEARANCE_KEY}')}catch(e){}if(t!=='light'&&t!=='dark')t=window.matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light';var r=document.documentElement;r.dataset.theme=t;r.style.colorScheme=t;document.querySelectorAll('meta[name="theme-color"]').forEach(function(m){m.content=t==='dark'?'#081426':'#f4f7fc'})})();`;

export function applyAppearance(theme: Appearance) {
  document.documentElement.dataset.theme = theme;
  document.documentElement.style.colorScheme = theme;
  document.querySelectorAll<HTMLMetaElement>('meta[name="theme-color"]').forEach(meta => { meta.content = appearanceColor(theme); });
}
