/** Only public support numbers belong in this helper. Never pass API credentials. */
export function whatsappSupportUrl(number: string | undefined, text = "Bonjour Komisio, j’ai besoin d’aide avec mon espace partenaire."): string | null {
  const digits = (number || "").trim().replace(/[\s()+.-]/g, "");
  if (!/^[1-9]\d{7,14}$/.test(digits)) return null;
  const url = new URL(`https://wa.me/${digits}`);
  url.searchParams.set("text", text.slice(0, 600));
  return url.toString();
}

/** The UI never follows arbitrary links returned as a support destination. */
export function validateWhatsAppSupportUrl(value: unknown): string | null {
  if (typeof value !== "string") return null;
  try {
    const url = new URL(value);
    if (url.origin !== "https://wa.me" || url.username || url.password || !/^\/[1-9]\d{7,14}$/.test(url.pathname)) return null;
    return url.toString();
  } catch { return null; }
}
