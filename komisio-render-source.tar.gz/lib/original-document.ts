import type { OrderStatus } from "./catalog";

export const originalDocumentLabels = {
  TO_SCHEDULE: "Rendez-vous à fixer",
  APPOINTMENT_SET: "Rendez-vous fixé",
  COLLECTED: "Carte grise originale récupérée",
  READY_FOR_RETURN: "Carte grise prête à être restituée",
  RETURNED: "Carte grise originale restituée",
};
export type OriginalDocument = {
  status: keyof typeof originalDocumentLabels;
  appointmentAt?: string | null;
  location?: string | null;
  note?: string | null;
  collectedAt?: string | null;
  readyAt?: string | null;
  returnedAt?: string | null;
  version: number;
};
export type OriginalDocumentAction = {
  expectedVersion: number;
} & ({ action: "schedule"; appointmentAt: string; location: string; note: string } |
  { action: "collect" | "ready" | "return"; confirmed: true });

/** Shared state rules for the demo and server. Financial changes stay on the server. */
export function advanceOriginalDocument(
  order: { status: OrderStatus; quoteAcceptedAt?: string | null; requiresQuote?: boolean; paid: boolean; originalDocument: OriginalDocument },
  input: OriginalDocumentAction,
  now = new Date(),
): { originalDocument: OriginalDocument; status: OrderStatus; changed: boolean } {
  const current = order.originalDocument;
  const target = { schedule: "APPOINTMENT_SET", collect: "COLLECTED", ready: "READY_FOR_RETURN", return: "RETURNED" }[input.action] as OriginalDocument["status"];
  // Only an exact replay of the immediately preceding action is idempotent.
  const replay = input.expectedVersion === current.version - 1 && current.status === target &&
    (input.action !== "schedule" || (current.appointmentAt === input.appointmentAt && current.location === input.location && current.note === input.note));
  if (replay) return { originalDocument: current, status: order.status, changed: false };
  if (input.expectedVersion !== current.version) throw new Error("Le suivi a changé. Actualisez le dossier.");
  if (input.action !== "schedule" && input.confirmed !== true) throw new Error("Confirmez la remise physique de la carte grise.");
  if (order.status === "COMPLETED" || order.status === "QUOTE_REJECTED") throw new Error("Ce dossier est clôturé.");
  const next = { ...current, version: current.version + 1 };
  let status: OrderStatus = order.status;
  if (input.action === "schedule") {
    if (!["TO_SCHEDULE", "APPOINTMENT_SET"].includes(current.status) || order.status === "CANCELLED" || (order.requiresQuote && !order.quoteAcceptedAt))
      throw new Error("Le rendez-vous peut être fixé après acceptation du devis et avant récupération de l’original.");
    if (!Number.isFinite(Date.parse(input.appointmentAt)) || Date.parse(input.appointmentAt) <= now.getTime()) throw new Error("Choisissez une date de rendez-vous future.");
    if (input.location.trim().length < 3) throw new Error("Précisez le lieu du rendez-vous.");
    next.appointmentAt = input.appointmentAt; next.location = input.location; next.note = input.note;
  } else if (input.action === "collect") {
    if (current.status !== "APPOINTMENT_SET" || order.status === "CANCELLED") throw new Error("Fixez le rendez-vous avant de confirmer la récupération.");
    next.collectedAt = now.toISOString();
  } else if (input.action === "ready") {
    if (current.status !== "COLLECTED") throw new Error("La carte grise doit d’abord être récupérée.");
    if (order.status !== "CANCELLED" && (!order.paid || !["PROCESSING", "ACTION_REQUIRED"].includes(order.status))) throw new Error("Le paiement doit être confirmé avant de finaliser la démarche.");
    next.readyAt = now.toISOString();
  } else {
    if (current.status !== "READY_FOR_RETURN") throw new Error("Confirmez d’abord que la carte grise est prête à être restituée.");
    if (order.status !== "CANCELLED" && (!order.paid || !["PROCESSING", "ACTION_REQUIRED"].includes(order.status))) throw new Error("Le dossier doit être payé avant sa clôture.");
    next.returnedAt = now.toISOString();
    if (order.status !== "CANCELLED") status = "COMPLETED";
  }
  next.status = target;
  return { originalDocument: next, status, changed: true };
}

export function assertOriginalDocumentReturned(original?: { status: string } | null) {
  if (original && original.status !== "RETURNED") throw new Error("Confirmez la restitution de la carte grise originale avant de terminer le dossier.");
}
