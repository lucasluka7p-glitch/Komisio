# Komisio sur Render Free + Supabase Free

Configuration préparée le 24 octobre 2026 à partir des offres officielles :

| Élément | Offre | Limites importantes |
| --- | --- | --- |
| Application Next et API | [Render Free](https://render.com/docs/free) | 750 heures gratuites par espace/mois ; mise en veille après 15 minutes sans trafic entrant ; réveil pouvant prendre environ une minute ; disque local éphémère. Render réserve ce plan aux essais/prototypes et ne le recommande pas pour la production. |
| PostgreSQL et documents privés | [Supabase Free](https://supabase.com/pricing) | 500 Mo de base, 1 Go de stockage de fichiers, quotas de trafic ; projet suspendu après une semaine d’inactivité. |
| URL et HTTPS | Sous-domaine `onrender.com` fourni | Aucun achat de domaine nécessaire. |
| Encaissements et retraits | [Plisio](https://plisio.net/documentation) | Compte marchand, clé API, frais Plisio/réseau et liquidité crypto nécessaires. Les quotas d’hébergement n’exonèrent pas des frais des opérations. |

Ce montage permet une version pilote à 0 € d’hébergement dans les quotas. Il ne garantit pas un service financier disponible sans interruption. Si l’un des hébergeurs demande une vérification de compte ou bancaire, ses conditions d’inscription s’appliquent. Aucune souscription payante n’a été créée.

## 1. Supabase

1. Créez un projet gratuit sur [Supabase](https://supabase.com/dashboard/sign-up).
2. Créez le bucket **privé** `komisio-private` dans Storage. Ne le rendez pas public et n’ajoutez aucune politique d’accès public. Le backend refuse de démarrer sainement si le bucket est public. Conservez les réglages de types de fichiers par défaut ; le backend valide les formats et les tailles.
3. Dans **Connect**, copiez la connexion PostgreSQL **Session pooler**, port 5432, compatible IPv4. Utilisez l’utilisateur `postgres.<référence-projet>` côté serveur. Remplacez le mot de passe dans l’URI en l’encodant si nécessaire ; ajoutez `?sslmode=require&connection_limit=3` si l’URI n’a pas encore de paramètres. Évitez le pooler transaction pour les migrations et transactions interactives de cette V1.
4. Retrouvez l’URL du projet et la clé serveur `service_role` (JWT) dans les paramètres API. Cette clé reste exclusivement dans Render ; aucune clé Supabase n’est envoyée au navigateur.

Les migrations activent RLS sur les tables métier sans politique publique : les rôles de l’API Supabase ne peuvent pas lire directement les comptes ou portefeuilles. Prisma accède aux données via le compte PostgreSQL propriétaire du serveur, puis applique les sessions client/Telegram et les règles B2B.

## 2. Render

1. Créez un compte sur [Render](https://dashboard.render.com/register).
2. Placez le projet dans un dépôt GitHub privé que vous contrôlez. Dans Render, créez un **Blueprint** depuis ce dépôt ; `render.yaml` crée un unique service Web **Free**, sans base Render payante et sans worker payant.
3. Renseignez les variables demandées :
   - `DATABASE_URL` : connexion Supabase Session pooler.
   - `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY` et le nom du bucket.
   - `PLISIO_API_KEY` : clé du site marchand.
   - `TELEGRAM_BOT_TOKEN` : token actuel conservé en secret, et `ADMIN_TELEGRAM_IDS` : votre ID utilisateur numérique (jamais l’ID du bot).
4. Le Blueprint génère trois secrets distincts pour sessions, cron et webhook. Les valeurs base64 générées pour le webhook sont normalisées côté serveur au format accepté par Telegram.
5. Lancez le déploiement. Le build prépare l’application Node standalone ; le démarrage vérifie la configuration, applique les migrations et ajoute les services manquants. Les documents sont envoyés à Supabase, jamais gardés sur le disque éphémère.

`APP_URL` et `MINI_APP_URL` prennent automatiquement l’URL HTTPS `RENDER_EXTERNAL_URL`. Pour un domaine personnalisé, renseignez explicitement les deux valeurs. L’état prêt est vérifiable sur `/api/health`, sans divulgation de secrets. Le worker de reprise tourne avec le serveur Web et reprend les notifications et règlements lors des périodes où Render est actif ; il s’arrête pendant les mises en veille. Les accès et les quotas gratuits doivent être surveillés dans les tableaux de bord des hébergeurs.

## 3. Mini App Telegram

1. Dans BotFather, utilisez `/setmenubutton`, sélectionnez `@Komisiobot`, collez l’URL HTTPS Render et donnez au bouton le libellé **Komisio**. Vous pouvez également configurer la Mini App principale dans les réglages du bot.
2. Ouvrez le bot dans Telegram puis son bouton **Komisio**. L’application valide `initData` et reconnaît l’admin grâce à votre ID utilisateur renseigné dans Render.
3. Dans **Admin → Vue d’ensemble → État de la plateforme**, cliquez **Raccorder le bot Telegram**. Le serveur vérifie son identité, enregistre le webhook et configure les commandes et le menu. Il n’y a pas besoin du Shell Render payant.
4. Envoyez `/start` au bot depuis chaque compte admin et revendeur qui doit recevoir des notifications.

Un token précédemment partagé doit être révoqué/régénéré dans BotFather et remplacé dans les secrets Render avant la mise en service.

## Comptes clients

Une fois connecté comme admin, créez chaque accès dans **Clients & tarifs**, configurez sa grille, puis générez les identifiants à remettre. Aucun nouvel utilisateur Telegram ne s’inscrit automatiquement. Guide : [CLIENT-ACCESS.md](./CLIENT-ACCESS.md).

## 4. Plisio

Dans Plisio, créez/configurez le site marchand avec l’URL Render, activez les monnaies nécessaires et renseignez la clé API dans Render. Le choix du payeur de la commission se règle dans Plisio (**Who pays the commission**) : sélectionnez le client si vous souhaitez lui répercuter les frais Plisio. Le callback est automatiquement demandé sur :

`https://VOTRE-SERVICE.onrender.com/api/webhooks/plisio?json=true`

Plisio accepte des adresses ou sous-réseaux CIDR dans **Limit Access by IP address** ([documentation](https://plisio.net/documentation/getting-started/setting-shop)). Dans le service Render, ouvrez **Connect → Outbound** et copiez les plages affichées ([documentation Render](https://render.com/docs/outbound-ip-addresses)). Autorisez ces plages dans votre compte Plisio pour les vérifications de paiement et les retraits. Ces sorties sont partagées par les services de la région, et la clé API reste nécessaire ; n’autorisez pas toutes les IP. Vérifiez ce réglage avec une transaction de recette.

Testez une petite recharge réelle sur le compte marchand. Quand les autorisations API et la réserve USDT TRC20 sont vérifiées, activez `WITHDRAWALS_ENABLED=true` et `PLISIO_PAYOUTS_ENABLED=true` dans Render. Les frais sont proposés, le revendeur les accepte, puis l’admin déclenche l’envoi Plisio. Les confirmations sont reprises par le serveur et le journal reste atomique. Les crédits EUR peuvent provenir d’autres cryptos : le compte Plisio doit disposer de suffisamment d’USDT TRC20 pour les retraits ; l’application n’effectue pas de conversion automatique entre portefeuilles Plisio.

## État de cette livraison

Le code, le Blueprint et les tests sont fournis. Aucun compte Render/Supabase ni site marchand Plisio n’a été créé ou raccordé à la place du titulaire. L’URL Sites conserve la démonstration jusqu’au raccordement réel de ces comptes. Une transaction réelle de recette reste à effectuer avec vos comptes et vos fonds.

## Connecteur WhatsApp Web et OCR

La variante Docker `compose.whatsapp.yaml` est fournie pour une machine qui reste allumée. Le service Render Free natif ne fournit pas les binaires Tesseract/Poppler ni un Chromium persistant pour WhatsApp. Box Simular annonce un ordinateur gratuit mais sa documentation prévoit une mise en veille à l’inactivité : ne pas le considérer comme une garantie de bot permanent. Voir WHATSAPP.md pour les limites et la solution sur machine personnelle.
