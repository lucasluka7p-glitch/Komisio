# Catalogue et tarifs initiaux

Tarifs catalogue du 8 novembre 2026. Chaque client peut disposer de sa propre grille, voir [CLIENT-ACCESS.md](./CLIENT-ACCESS.md). Cartes grises : devis, remise configurée par client et minimum de 60 €. Tarifs de prestation modifiables dans le dashboard administrateur. Les achats, taxes et frais de tiers sont exclus lorsqu’indiqué dans la prestation. La remise CEDEO s’applique selon l’accord professionnel de l’exploitant.

| Prestation | Tarif initial |
| --- | ---: |
| Création de société | 1 400,00 € |
| Modification statutaire | 650,00 € |
| Dépôt des comptes annuels | 79,00 € |
| Changement de titulaire carte grise | Sur devis |
| Changement de titulaire — sans justificatif de contrôle technique joint | Sur devis |
| WW simple — certificat provisoire | 80,00 € |
| Constitution de dossier | 49,00 € |
| Mise en sommeil / Reprise | 89,00 € |
| Correction RNE | 69,00 € |
| Cessation d’activité | 129,00 € |
| Régularisation de société | 119,00 € |
| Déclaration d’achat | 40,00 € |
| Dédouanement légal | 99,00 € |
| Accompagnement & rendez-vous | 35,00 € |
| Dédouanement suisse | Sur devis |
| Inscription au code de la route | 39,00 € |
| Réservation d’examen du permis | 49,00 € |
| Dossier de titre de séjour | 129,00 € |
| CEDEO — remise professionnelle de 40 % | Sur devis |
| Contrôle technique avec convoyage | 180,00 € |
| Dossier de remboursement pare-brise | 49,00 € |
| Dossier de remboursement Ameli | Sur devis |
| Données de police — demande d’accès personnelle | 200,00 € |
| Véhicule — certificat de situation administrative | 50,00 € |
| Fin de leasing / mise à jour carte grise | 170,00 € |
| Modification d’un dossier WW | 100,00 € |
| Levée de procédure VE / VEI / RSV | 199,00 € |
| Mainlevée d’opposition ou de saisie | 129,00 € |
| Levée d’immobilisation | 99,00 € |
| Régularisation de carte grise | 100,00 € |
| Homologation de véhicule | Sur devis |
| Remboursement mutuelle | Sur devis |
| Dossier récépissé de séjour | Sur devis |
| Constitution de dossier logement | Sur devis |
| Création du numéro NEPH | Sur devis |
| Déclaration de cession | 40,00 € |

Les services de contrôle technique comprennent la coordination d’un convoyage avec présentation du véhicule au centre. Les services relatifs aux données de police et aux véhicules correspondent à des demandes personnelles autorisées ou à un certificat officiel de situation administrative. Aucun accès direct aux fichiers de police n’est proposé.

## Informations et pièces demandées — immatriculation

- **Changement de titulaire carte grise** : plaque d’immatriculation, VIN, numéro de formule, identité du titulaire, nom, prénom, lieu et date de naissance de l’acquéreur et adresse de livraison. Aucun champ générique de nom complet du client ni d’adresse e-mail n’est demandé pour cette prestation. Pièces jointes facultatives : carte grise, pièce d’identité de l’acquéreur et cession de vente.
- **WW simple** et **Modification d’un dossier WW** : adresse postale complète du titulaire uniquement à saisir. Deux photos obligatoires : carte grise et pièce d’identité du titulaire (JPG/PNG). Aucun champ de nom, d’identité rédigée ou d’e-mail supplémentaire.

Les informations à saisir restent obligatoires. Pour le changement de titulaire, toutes les pièces jointes sont facultatives ; les pièces WW restent obligatoires. La migration `20261021020000_vehicle_service_forms` met à jour les trois formulaires existants en base sans changer leurs tarifs ni les dossiers déjà déposés. Le catalogue de démonstration applique cette révision une seule fois et conserve ensuite les modifications faites dans le panel admin.

Le changement de titulaire suit le parcours : dépôt gratuit du dossier → proposition de prix par l’admin → acceptation ou refus du revendeur → paiement du devis accepté → traitement. Aucun débit ni facture crypto avant acceptation. La migration `20261021040000_order_quotes` active ce mode et rend les pièces facultatives pour les nouvelles demandes, en préservant les prix convenus sur les anciens dossiers.


## Formulaires complémentaires

- **Variante carte grise sans justificatif de contrôle technique joint** : mêmes informations et trois pièces facultatives, sur devis. La recevabilité du dossier dépend des règles applicables au véhicule ; aucune dispense d’une obligation de contrôle technique n’est promise.
- **Contrôle technique avec convoyage** : carte grise et vidéo du véhicule obligatoires, kilométrage obligatoire. La présentation du véhicule au centre agréé reste nécessaire.
- **Ameli** : attestation de droits obligatoire, sans collecte d’identifiant ni de mot de passe. Le dépôt de l’attestation constitue une demande d’assistance, sans remboursement garanti.
- **Demande personnelle d’accès aux données de police** : nom, prénom et date de naissance obligatoires du demandeur concerné. Aucun accès direct à un fichier ni recherche sur un tiers.
- **Situation administrative du véhicule** : plaque d’immatriculation obligatoire pour une demande concernant un véhicule dont le demandeur est propriétaire ou mandataire. Ce service ne consulte pas les fichiers de police.

La migration `20261021050000_service_intake_forms` remplace uniquement les formulaires concernés et ajoute la variante carte grise. Prix existants, commandes, documents et instantanés précédents sont conservés. Les nouveaux dépôts utilisent les exigences actualisées.

Vidéo : MP4/MOV, 25 Mo maximum sur le serveur ; documents PDF/JPEG/PNG, 10 Mo. Chaque fichier est stocké en privé, accessible au titulaire et à l’admin. Le format est contrôlé d’après son contenu et une vidéo n’est acceptée que pour un champ vidéo. La démonstration enregistre seulement le nom du fichier vidéo et son type ; elle ne transmet ni ne conserve le contenu vidéo. Les autres pièces de démonstration restent limitées à 2 Mo dans le navigateur. Utiliser des fichiers fictifs pour la démo.


## Classement et tarifs actualisés

Le catalogue s’ouvre sur sept rubriques de services, avec recherche et accès rapides. Les rubriques regroupant plusieurs sous-catégories peuvent être affinées. Le mode « Tout afficher » permet de retrouver toutes les prestations. Les sous-catégories restent configurables dans le panel admin.

- **Comptabilité et formalités** : création/modification ; comptabilité/dépôt des comptes ; mise en sommeil/reprise/cessation ; corrections RNE/régularisations.
- **Automobile** : cartes grises/WW ; importation/douanes ; contrôle technique/levées de restrictions ; situation du véhicule/leasing.
- **Assistance** : dossiers/rendez-vous ; permis/examens ; remboursements ; demandes personnelles d’accès ; offres professionnelles CEDEO.

WW simple : **50 €**. WW modifié : **80 €**. CEDEO −40 % : **sur devis**, avec dépôt, proposition admin, acceptation ou refus et paiement avant traitement. Les deux formulaires WW demandent uniquement les photos de carte grise et d’identité, plus l’adresse postale du titulaire. Les photos sont contrôlées comme JPEG ou PNG ; un PDF ne peut pas satisfaire un champ photo.

Pour les deux changements de titulaire, le libellé est désormais **Identité du titulaire**, sans restriction à un nom/prénom : une dénomination de société peut être saisie. Les autres informations, pièces et dossiers existants sont conservés.

La migration `20261021060000_catalogue_categories_ww_prices` ajoute `Service.subcategory`, applique les tarifs et formulaires explicitement demandés et classe les services existants. Elle ne change pas les prix déjà convenus sur les commandes. Le catalogue de démonstration applique les nouveaux tarifs une seule fois ; les modifications ultérieures de l’admin sont conservées.


## Dédouanement suisse — original et rendez-vous

Le dépôt demande uniquement **le kilométrage entier et une photo obligatoire de la carte grise (JPEG/PNG)**, sans nom générique, e-mail, VIN ni autre pièce. Le dossier est gratuit à déposer, puis l’admin propose un prix. Le revendeur accepte ou refuse ; aucun paiement avant son accord.

Après acceptation, l’admin fixe la date, l’heure et l’adresse de récupération de la carte grise **originale en physique**, visibles dans le dossier. Le paiement reste nécessaire avant traitement. Le suivi distingue rendez-vous, original récupéré, prêt à restituer et original restitué. La confirmation de restitution clôt le dossier payé, sans imposer un livrable numérique. Un dossier annulé peut toujours suivre la restitution de son original déjà récupéré.

La migration `20261021070000_swiss_original_document` met à jour le service et ajoute le suivi de garde. Les commandes anciennes, leurs prix et leurs instantanés restent inchangés, sans ajout rétroactif d’un suivi d’original. Voir [SWISS-CUSTOMS.md](SWISS-CUSTOMS.md).


## Révision des offres et délais

| Prestation | Prix | Délai indicatif |
| --- | --- | --- |
| Véhicule — certificat de situation administrative | 70 € | Préparation sous 24 à 48 h |
| Données de police — demande d’accès personnelle | 200 € | Préparation sous 24 à 48 h |
| Changement de titulaire sans justificatif de contrôle technique joint | Sur devis | 24 à 48 h |
| Accompagnement au remboursement Ameli | Sur devis | 15 jours |
| Contrôle technique avec convoyage | 180 € | 24 à 48 h |
| WW simple | 50 € | 24 à 48 h |
| Modification WW | 80 € | 24 à 48 h |
| CEDEO −40 % | Sur devis | 24 à 48 h |

Pour les demandes d’accès officielles, 24 à 48 h désigne la préparation de la demande, sans engagement sur le délai de réponse de l’autorité. Les 15 jours Ameli concernent l’accompagnement ; la décision et le délai de remboursement restent ceux de la CPAM. Ameli demande l’attestation de droits, sans identifiant ni mot de passe.

Les formulaires demeurent ceux décrits ci-dessus : plaque seule pour le certificat de situation administrative ; nom, prénom et date de naissance pour la demande d’accès personnelle ; informations véhicule/acquéreur et trois pièces facultatives pour la variante carte grise ; carte grise, kilométrage et vidéo obligatoires pour le contrôle technique ; deux photos et adresse postale pour les WW. Les délais restent indicatifs et les frais externes précisés dans les descriptions sont conservés.

La migration `20261021080000_service_offers_prices_delays` actualise les offres futures uniquement. Elle ne modifie ni les prix et devis des commandes déposées, ni leurs pièces, ni les formulaires personnalisés. Le catalogue de démonstration applique une révision `offerVersion` une seule fois, puis conserve les réglages ultérieurs de l’admin.


## Catalogue simplifié — interface revendeur

Le catalogue dispose d’un écran dédié. Le solde, le grand visuel de marque et les statistiques restent sur le tableau de bord. Le premier écran du catalogue met en avant la recherche, sept rubriques précises avec leur nombre réel de services, puis six raccourcis. Le bouton « Tout afficher » rend l’intégralité des services actifs accessible, y compris ceux créés par l’administrateur.

Les cartes affichent un intitulé court, une explication, le délai configuré, le nombre de pièces requises ou facultatives, le tarif et une action claire. Les descriptions complètes, conditions, champs et documents sont disponibles dans la fiche « Détails », avec accès direct au formulaire de commande. Les devis ne sont jamais présentés comme un prix fixe nul. Les titres et descriptions personnalisés par l’admin sont conservés dans l’interface.

La recherche ignore les accents et accepte les termes usuels. Les filtres par rubrique, sous-catégorie et type de tarif se combinent ; le tri alphabétique ou par prix s’applique à la sélection. Les services sans sous-catégorie valide restent accessibles dans « Autres prestations ». La vue rapide se complète avec d’autres offres actives si une prestation épinglée est désactivée.

Cette refonte est visuelle et fonctionnelle côté navigation : aucun changement des tarifs, des exigences documentaires, des commandes, du portefeuille ou des règles de paiement. Modes clair et sombre, navigation clavier, focus du résultat et affichage mobile sont conservés.


## Rubriques et guide Komi

Les catégories techniques de la base restent inchangées. La navigation les présente en sept rubriques : Carte grise & immatriculation, Régularisation & procédures automobiles, Informations véhicule & particulier, Remboursements & assurances, Démarches administratives, Permis de conduire et Avantages & réductions. Les services personnalisés suivent leur sous-catégorie ; une sous-catégorie absente ou incompatible est rattachée à une rubrique de repli pour rester accessible. Chaque service apparaît une seule fois.

Komi est un guide local, accessible sur toutes les pages via son bouton flottant et depuis le catalogue. Il aide à trouver une prestation, affiche les documents et informations configurés, explique le devis puis ouvre le formulaire. Il donne aussi accès au suivi et au portefeuille, avec des conseils adaptés à la page et aux étapes de dépôt. Il ne lit pas les valeurs des formulaires, ne valide pas les dossiers et n’appelle aucun service de conversation externe. Les modifications du catalogue admin s’appliquent au guide.

Les animations sont courtes, peuvent être désactivées dans le guide et respectent `prefers-reduced-motion`. Le bouton laisse l’accès à la navigation mobile ; le guide utilise le dialogue accessible commun avec verrouillage du défilement, touche Échap et restauration du focus.


## Révision du 24 octobre — sept rubriques, 35 prestations

1. **Carte grise & immatriculation** : changement de titulaire et variante, WW simple/modifié, régularisation de carte grise, fin de leasing avec mise à jour de carte grise, homologation et déclaration d’achat.
2. **Régularisation & procédures automobiles** : levée VE/VEI/RSV, levée d’immobilisation, mainlevée d’opposition/saisie, dédouanement suisse et autres formalités douanières, contrôle technique avec présentation du véhicule.
3. **Informations véhicule & particulier** : certificat officiel de situation administrative et demande d’accès à ses propres données. Les termes usuels « fiche infos véhicule » et « fiche police recherche » sont reconnus par la recherche.
4. **Remboursements & assurances** : Ameli, bris de glace et mutuelle, sur justificatifs réels.
5. **Démarches administratives** : récépissé, logement, séjour, rendez-vous et toutes les formalités de société existantes.
6. **Permis de conduire** : code, création du numéro NEPH et accompagnement à la réservation d’une date d’examen officielle.
7. **Avantages & réductions** : CEDEO −40 %, sur devis, selon l’accord commercial.

Les six nouveaux formulaires proposent une base de pièces et champs modifiables dans l’admin. Les prestations sans tarif fourni utilisent le parcours sur devis existant, avec acceptation ou refus avant paiement. Les nouveaux dossiers de récépissé préparent une demande à la préfecture ; l’application ne délivre pas le document. Les demandes NEPH passent par les démarches officielles, sans collecte de mot de passe. Les libellés « écrasement » correspondent aux régularisations officielles de carte grise et au transfert autorisé après leasing.

La remise CEDEO d’origine passe une seule fois de 30 % à 40 %. Les titres et descriptions personnalisés restent conservés. Le leasing quitte l’ancienne sous-catégorie « documents véhicule » pour l’immatriculation, sans changement du tarif ni des commandes. Les services personnalisés ou sans sous-catégorie valide restent accessibles, et les prestations désactivées restent visibles dans l’admin. Komi reprend automatiquement les sept rubriques et les nouvelles fiches.
