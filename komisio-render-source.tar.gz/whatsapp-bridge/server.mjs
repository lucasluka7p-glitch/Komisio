import { createServer } from 'node:http';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { mkdir } from 'node:fs/promises';
import { authorized, BridgeError, IncomingQueue, MAX_HTTP_BYTES, normalizeIncoming, SendReceipts, signPayload } from './core.mjs';

async function readBody(request, limit) {
  if (Number(request.headers['content-length'] || 0) > limit) throw new BridgeError(413, 'Requête trop volumineuse.');
  let size = 0; const chunks = [];
  for await (const chunk of request) { size += chunk.length; if (size > limit) throw new BridgeError(413, 'Requête trop volumineuse.'); chunks.push(chunk); }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { throw new BridgeError(400, 'JSON invalide.'); }
}
/** Exported independently from whatsapp-web.js: tests never initialize a browser or account. */
export function createBridgeHttp({ secret, state, receipts, queue, groups = async () => [] }) {
  return createServer(async (request, response) => {
    response.setHeader('content-type', 'application/json; charset=utf-8');
    response.setHeader('cache-control', 'no-store');
    response.setHeader('x-content-type-options', 'nosniff');
    const reply = (status, value) => { response.statusCode = status; response.end(JSON.stringify(value)); };
    try {
      if (!authorized(request.headers.authorization, secret)) return reply(401, { error: 'Accès refusé.', attempted: false });
      const url = new URL(request.url, 'http://bridge.internal');
      if (request.method === 'GET' && url.pathname === '/status') {
        const pending = await queue.counts();
        return reply(200, { configured: true, connected: state.connected, status: state.status, ...(state.qr ? { qr: state.qr } : {}), ...(state.error ? { error: state.error } : {}), ...pending });
      }
      if (request.method === 'GET' && url.pathname === '/groups') {
        if (!state.connected) throw new BridgeError(503, 'WhatsApp est déconnecté.');
        return reply(200, { groups: (await groups()).slice(0, 200) });
      }
      if (request.method === 'POST' && url.pathname === '/send') return reply(200, await receipts.dispatch(await readBody(request, MAX_HTTP_BYTES)));
      return reply(404, { error: 'Route inconnue.', attempted: false });
    } catch (error) {
      if (error instanceof BridgeError) return reply(error.status, { error: error.message, attempted: error.attempted });
      // Provider exceptions may contain QR, document content, paths or account identifiers.
      return reply(500, { error: 'Erreur du connecteur. Vérifiez son état.', attempted: true });
    }
  });
}
export function readConfiguration(env = process.env) {
  const secret = env.WHATSAPP_BRIDGE_SECRET || '';
  if (secret.length < 32) throw new Error('WHATSAPP_BRIDGE_SECRET doit contenir au moins 32 caractères.');
  const target = new URL(env.APP_API_URL || 'http://127.0.0.1:3000');
  if (!['http:', 'https:'].includes(target.protocol) || target.username || target.password || target.search || target.hash) throw new Error('APP_API_URL invalide.');
  const port = Number(env.BRIDGE_PORT || 3104);
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('BRIDGE_PORT invalide.');
  return { secret, target: new URL('/api/whatsapp/bridge', target), directory: resolve(env.WHATSAPP_DATA_DIR || '.private/whatsapp'), port, host: env.BRIDGE_HOST || '127.0.0.1', chromium: env.CHROMIUM_EXECUTABLE_PATH || undefined };
}
export async function startBridge(env = process.env) {
  const config = readConfiguration(env);
  process.umask(0o077);
  await mkdir(config.directory, { recursive: true, mode: 0o700 });
  const { default: WhatsApp } = await import('whatsapp-web.js');
  const { Client, LocalAuth, MessageMedia } = WhatsApp;
  const state = { connected: false, status: 'STARTING', qr: null, error: null };
  const client = new Client({
    authStrategy: new LocalAuth({ clientId: 'komisio', dataPath: config.directory + '/auth' }),
    puppeteer: { headless: true, ...(config.chromium ? { executablePath: config.chromium } : {}), args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'] },
    takeoverOnConflict: false,
    qrMaxRetries: 0,
    deviceName: 'Komisio dossiers',
  });
  const queue = new IncomingQueue(config.directory + '/inbox', async payload => {
    const raw = JSON.stringify(payload);
    const response = await fetch(config.target, { method: 'POST', headers: { 'content-type': 'application/json', 'x-komisio-signature': signPayload(raw, config.secret) }, body: raw, redirect: 'error', signal: AbortSignal.timeout(20000) });
    // Read no response body: upstream validation errors can contain personal data.
    await response.body?.cancel();
    if (response.ok) return 'ACKNOWLEDGED';
    if ([400,401,403,404,409,413,422].includes(response.status)) { state.error = 'Un message a été refusé par le serveur. Vérifiez les associations et la configuration.'; return 'REJECTED'; }
    return 'RETRY';
  });
  const receipts = new SendReceipts(config.directory + '/sent', async value => {
    if (value.target.endsWith('@g.us')) { const chat = await client.getChatById(value.target); if (!chat?.isGroup) throw new Error('Unknown group'); }
    const content = value.media ? new MessageMedia(value.media.mimeType, value.media.base64, value.media.filename) : value.text;
    const options = value.media ? { caption: value.text || undefined, sendMediaAsDocument: true, sendSeen: false, linkPreview: false } : { sendSeen: false, linkPreview: false };
    let timer;
    try { return await Promise.race([client.sendMessage(value.target, content, options), new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('Send timeout')), 30000); })]); } finally { clearTimeout(timer); }
  }, { ready: () => state.connected });
  let allowlist = [], allowlistUntil = 0;
  async function isAllowed(phone, groupId) {
    if (Date.now() >= allowlistUntil) {
      try {
        const endpoint = new URL('/api/whatsapp/bridge/bindings', config.target);
        const response = await fetch(endpoint, { headers: { authorization: `Bearer ${config.secret}` }, redirect: 'error', signal: AbortSignal.timeout(7000) });
        if (!response.ok) throw new Error();
        const raw = await response.text(); if (raw.length > 200000) throw new Error();
        const data = JSON.parse(raw); if (!Array.isArray(data.bindings)) throw new Error();
        allowlist = data.bindings.slice(0,1000); allowlistUntil = Date.now() + 15000;
      } catch { allowlist = []; allowlistUntil = Date.now() + 3000; return false; }
    }
    return allowlist.some(binding => binding.phone === phone && (binding.groupId || null) === groupId);
  }
  let receiving = false; const incoming = [];
  async function receive() {
    if (receiving) return;
    receiving = true;
    try {
      while (incoming.length) {
        const message = incoming.shift();
        try { const payload = await normalizeIncoming(client, message, Date.now(), isAllowed); if (payload) await queue.enqueue(payload); }
        catch { state.error = 'Un document n’a pas été reçu : vérifiez le format, la taille et la file de réception.'; }
      }
      await queue.process();
    } finally { receiving = false; }
  }
  client.on('qr', value => { state.qr = value; state.status = 'QR_REQUIRED'; state.connected = false; state.error = null; });
  client.on('authenticated', () => { state.qr = null; state.status = 'AUTHENTICATED'; });
  client.on('ready', () => { state.connected = true; state.qr = null; state.status = 'READY'; state.error = null; });
  client.on('auth_failure', () => { state.connected = false; state.qr = null; state.status = 'AUTH_FAILED'; state.error = 'Authentification échouée. Reconnectez l’appareil WhatsApp.'; });
  client.on('disconnected', () => { state.connected = false; state.qr = null; state.status = 'DISCONNECTED'; state.error = 'WhatsApp est déconnecté. Redémarrez le connecteur puis vérifiez le QR.'; });
  client.on('message', message => {
    if (message.fromMe || message.isStatus || !['chat', 'image', 'document', 'video'].includes(message.type)) return;
    if (incoming.length >= 50) { state.error = 'Trop de messages en attente. Réessayez plus tard.'; return; }
    incoming.push(message); void receive().catch(() => { state.error = 'File de réception indisponible.'; });
  });
  const server = createBridgeHttp({ secret: config.secret, state, receipts, queue, groups: async () => (await client.getChats()).filter(chat => chat.isGroup).map(chat => ({ id: chat.id._serialized, name: String(chat.name || '').slice(0, 120) })) });
  server.requestTimeout = 35000; server.headersTimeout = 10000; server.keepAliveTimeout = 5000;
  await new Promise(resolve => server.listen(config.port, config.host, resolve));
  const worker = setInterval(() => void queue.process().catch(() => { state.error = 'File de réception indisponible.'; }), 5000);
  let stopping = false;
  const stop = async () => { if (stopping) return; stopping = true; clearInterval(worker); state.connected = false; state.qr = null; server.close(); try { await client.destroy(); } catch {} };
  process.once('SIGTERM', () => void stop()); process.once('SIGINT', () => void stop());
  // Initialization happens only on explicit `npm start`; importing/testing is inert.
  void client.initialize().catch(() => { state.connected = false; state.qr = null; state.status = 'START_FAILED'; state.error = 'Le navigateur WhatsApp n’a pas démarré. Vérifiez Chromium et le volume privé.'; });
  console.log('Connecteur Komisio démarré. Consultez le QR dans le panel admin.');
  return { server, stop, state };
}
if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  startBridge().catch(() => { console.error('Le connecteur WhatsApp ne peut pas démarrer. Vérifiez sa configuration privée.'); process.exitCode = 1; });
}
