# Connecteur Komisio — numéro WhatsApp ordinaire

Ce pont relie un numéro par **WhatsApp Web / Appareils connectés**. Il n’utilise pas l’API Meta et ne facture pas de message Meta. Il est non officiel : déconnexions, évolutions de WhatsApp et restrictions du numéro restent possibles.

Le pont doit rester allumé. Aucun compte n’est connecté pendant les tests ; `npm test` n’initialise jamais WhatsApp ni Chromium.

## Déploiement conseillé : même machine que Komisio

Depuis la racine du projet, configurer `.env.production` selon `DEPLOYMENT.md`, puis ajouter un `WHATSAPP_BRIDGE_SECRET` aléatoire de 32 caractères minimum. Il doit être identique côté application et pont. `deploy:init` le génère pour un nouveau fichier de configuration.

```sh
docker compose --env-file .env.production -f compose.yaml -f compose.whatsapp.yaml up -d --build
```

Le fichier complémentaire active le transport WEB et l’OCR local. Il installe un service `whatsapp` sur le réseau privé Compose, sans publier le port 3104 sur Internet. Les sessions et files du pont sont conservées dans le volume `whatsapp-session`. Le serveur principal installe Tesseract français et Poppler dans son image Docker.

1. Se connecter au véritable serveur Komisio comme administrateur.
2. Ouvrir **Admin → WhatsApp**, scanner le QR depuis **WhatsApp → Appareils connectés**.
3. Créer/activer les comptes et grilles dans **Clients & tarifs**, puis rattacher chaque numéro autorisé.
4. Pour un groupe : charger les groupes du numéro connecté, sélectionner le bon groupe et confirmer le numéro expéditeur. Un groupe reste associé à un seul compte client ; plusieurs expéditeurs de ce même client peuvent être autorisés.
5. Envoyer `/aide`, puis une commande de démarche depuis le numéro/groupe autorisé. Les comptes non rattachés sont ignorés avant le téléchargement de leurs documents.

Le fichier `.env.example` de ce dossier permet également un démarrage natif : `npm ci` puis `npm start`, avec Chromium installé et `CHROMIUM_EXECUTABLE_PATH` configuré. L’application principale doit être accessible via `APP_API_URL`, et l’application doit accéder au pont via `WHATSAPP_BRIDGE_URL`. Deux machines séparées nécessitent cette connectivité dans les deux sens ; un QR seul ne crée pas de tunnel réseau.

## Protocole privé

- `/status` : état et QR (secret de connexion), lecture authentifiée seulement.
- `/groups` : groupes du compte connecté, lecture authentifiée seulement.
- `/send` : envoi avec clé d’idempotence et destinataire précis. PDF/JPEG/PNG et MP4/MOV limités à 10 Mo.
- Tous les appels privés exigent `Authorization: Bearer WHATSAPP_BRIDGE_SECRET`.
- Les événements entrants sont signés HMAC SHA-256 vers `/api/whatsapp/bridge`.
- La liste des numéros/groupes autorisés est relue sur `/api/whatsapp/bridge/bindings` avant de télécharger des documents. Sans accès à cette liste, le pont ne traite pas de nouveau document.
- Les réceptions sont conservées au maximum 24 h avant abandon ; après accusé du serveur, les documents sont retirés du pont. Les reçus de déduplication n’en conservent pas le contenu.
- Un envoi au résultat inconnu reste bloqué. Vérifier WhatsApp avant toute intervention opérateur ; ne pas effacer le journal pour forcer une répétition.

Ne partagez ni QR, ni session LocalAuth, ni secret du pont. Le QR est relayé uniquement à l’admin du serveur et n’est pas conservé dans PostgreSQL. Une sauvegarde du volume de session est une sauvegarde d’accès au compte WhatsApp.

La version Sites publique est une démonstration. Elle ne peut pas exécuter ce pont ni connecter un numéro réel. Les détails des commandes et de la validation OCR figurent dans `WHATSAPP.md` à la racine.
