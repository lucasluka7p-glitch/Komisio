import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readdir, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { authorized, BridgeError, digest, IncomingQueue, mediaPayload, normalizeIncoming, outgoingInput, SendReceipts, senderPhone, signPayload } from '../core.mjs';
import { createBridgeHttp, readConfiguration } from '../server.mjs';

const secret = 'fictitious-bridge-secret-for-tests-only-123';
const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jhFYAAAAASUVORK5CYII=', 'base64');
test('bridge authentication and raw-payload signatures reject missing or modified secrets', () => {
  assert.equal(authorized(undefined, secret), false); assert.equal(authorized('Bearer wrong', secret), false); assert.equal(authorized('Bearer ' + secret, secret), true);
  assert.notEqual(signPayload('{"text":"one"}', secret), signPayload('{"text":"two"}', secret));
  assert.throws(() => readConfiguration({ WHATSAPP_BRIDGE_SECRET: 'short' }));
  assert.equal(readConfiguration({ WHATSAPP_BRIDGE_SECRET: secret, APP_API_URL: 'http://app:3000' }).target.href, 'http://app:3000/api/whatsapp/bridge');
});
test('phone identities use WhatsApp JIDs and verified LID mapping, never a typed number or LID digits', async () => {
  assert.equal(await senderPhone({}, '33600000001@c.us'), '33600000001');
  assert.equal(await senderPhone({}, '33600000001@lid'), null);
  assert.equal(await senderPhone({ getContactLidAndPhone: async () => [{ lid: '123456789012345@lid', pn: '33600000001@c.us' }] }, '123456789012345@lid'), '33600000001');
  assert.equal(await senderPhone({ getContactLidAndPhone: async () => [{ lid: 'different@lid', pn: '33600000001@c.us' }] }, '123456789012345@lid'), null);
});
test('incoming messages preserve sender and exact group, filter loops/stale messages, and bound media before download', async () => {
  const now = 1700000000000, message = { from: '120363123456789@g.us', author: '33600000001@c.us', timestamp: Math.floor(now / 1000), id: { _serialized: 'test-id' }, type: 'chat', body: '/cg' };
  const input = await normalizeIncoming({}, message, now);
  assert.equal(input.sender, '33600000001'); assert.equal(input.groupId, message.from); assert.equal(input.id, 'web:test-id');
  assert.equal(await normalizeIncoming({}, { ...message, fromMe: true }, now), null);
  assert.equal(await normalizeIncoming({}, { ...message, from: 'status@broadcast' }, now), null);
  assert.equal(await normalizeIncoming({}, { ...message, timestamp: 1 }, now), null);
  let downloads = 0;
  const media = { ...message, type: 'image', hasMedia: true, _data: { size: png.length }, downloadMedia: async () => { downloads++; return { data: png.toString('base64'), mimetype: 'image/png', filename: '../../test.png' }; } };
  assert.equal(await normalizeIncoming({}, media, now, async () => false), null); assert.equal(downloads, 0);
  const normalized = await normalizeIncoming({}, media, now); assert.equal(normalized.media.filename, 'test.png'); assert.equal(downloads, 1);
  await assert.rejects(normalizeIncoming({}, { ...media, _data: { size: 11 * 1024 * 1024 } }, now), /10 Mo/); assert.equal(downloads, 1);
  await assert.rejects(normalizeIncoming({}, { ...media, _data: {} }, now), /taille/);
});
test('outbound destination and document validation accepts only bounded known formats', () => {
  assert.equal(outgoingInput({ idempotencyKey: 'message:1', to: '33600000001', text: 'Test' }).target, '33600000001@c.us');
  assert.equal(outgoingInput({ idempotencyKey: 'message:2', to: '120363123456789@g.us', text: 'Test' }).target, '120363123456789@g.us');
  assert.throws(() => outgoingInput({ idempotencyKey: 'message:2', to: 'https://example.test', text: 'Test' }));
  assert.throws(() => outgoingInput({ idempotencyKey: '../../escape', to: '33600000001', text: 'Test' }));
  assert.equal(mediaPayload({ base64: png.toString('base64'), mimeType: 'image/png', fileName: 'piece.png' }).filename, 'piece.png');
  assert.throws(() => mediaPayload({ base64: png.toString('base64'), mimeType: 'application/pdf', fileName: 'piece.pdf' }));
  assert.throws(() => mediaPayload({ base64: Buffer.from('invalid').toString('base64'), mimeType: 'image/png' }));
});
test('durable send receipts dispatch once, survive restart, reject conflicting payloads and block ambiguity', async () => {
  const root = await mkdtemp(join(tmpdir(), 'bridge-send-')); let sent = 0;
  try {
    const input = { idempotencyKey: 'send-1', to: '33600000001', text: 'Test fictif' };
    const send = async () => { sent++; await new Promise(r => setTimeout(r, 20)); return { id: { _serialized: 'wa-send-1' } }; };
    const journal = new SendReceipts(root, send);
    const results = await Promise.allSettled([journal.dispatch(input), journal.dispatch(input)]);
    assert.equal(sent, 1); assert.ok(results.some(result => result.status === 'fulfilled'));
    assert.equal((await new SendReceipts(root, send).dispatch(input)).id, 'wa-send-1'); assert.equal(sent, 1);
    await assert.rejects(journal.dispatch({ ...input, text: 'Autre message' }), /autre message/);
    const ambiguous = new SendReceipts(root, async () => { sent++; throw new Error('Lost response'); });
    await assert.rejects(ambiguous.dispatch({ ...input, idempotencyKey: 'send-2' }), error => error instanceof BridgeError && error.attempted);
    await assert.rejects(new SendReceipts(root, send).dispatch({ ...input, idempotencyKey: 'send-2' }), /Résultat inconnu/); assert.equal(sent, 2);
    assert.equal((await readFile(join(root, digest('send-2') + '.json'), 'utf8')).includes('Test fictif'), false);
    await assert.rejects(new SendReceipts(root, send, { ready: () => false }).dispatch({ ...input, idempotencyKey: 'send-3' }), error => error.status === 503 && error.attempted === false);
  } finally { await rm(root, { recursive: true, force: true }); }
});
test('inbound private queue deduplicates, retries in FIFO order, deletes acknowledged documents, and enforces capacity', async () => {
  const root = await mkdtemp(join(tmpdir(), 'bridge-inbox-')); let now = 1700000000000, failing = true; const seen = [];
  try {
    const queue = new IncomingQueue(root, async input => { seen.push(input.id); return failing ? 'RETRY' : 'ACKNOWLEDGED'; }, { now: () => now, maxJobs: 2 });
    const first = { id: 'one', type: 'document', text: 'private-data', media: { base64: png.toString('base64') } };
    assert.equal(await queue.enqueue(first), true); assert.equal(await queue.enqueue(first), false);
    assert.equal(await queue.enqueue({ id: 'two' }), true); await assert.rejects(queue.enqueue({ id: 'three' }), /pleine/);
    await queue.process(); assert.deepEqual(seen, ['one']); assert.equal((await queue.counts()).pending, 2);
    now += 10000; failing = false; await queue.process(); assert.deepEqual(seen, ['one', 'one', 'two']); assert.equal((await queue.counts()).pending, 0);
    assert.equal(await queue.enqueue(first), false);
    const receipts = await readdir(join(root, 'seen')); for (const name of receipts) assert.equal((await readFile(join(root, 'seen', name), 'utf8')).includes('private-data'), false);
  } finally { await rm(root, { recursive: true, force: true }); }
});
test('protected HTTP status never exposes QR to unauthenticated requests and mock sends need no WhatsApp session', async () => {
  const root = await mkdtemp(join(tmpdir(), 'bridge-http-')); const state = { connected: true, status: 'READY', qr: 'fictitious-qr-secret' };
  const receipts = new SendReceipts(join(root, 'sent'), async () => ({ id: 'mock-send-id' }));
  const queue = new IncomingQueue(join(root, 'inbox'), async () => 'ACKNOWLEDGED'); const server = createBridgeHttp({ secret, state, receipts, queue });
  try {
    await new Promise(resolve => server.listen(0, '127.0.0.1', resolve)); const base = `http://127.0.0.1:${server.address().port}`;
    const forbidden = await fetch(base + '/status'); assert.equal(forbidden.status, 401); assert.equal((await forbidden.text()).includes('fictitious-qr-secret'), false);
    const status = await fetch(base + '/status', { headers: { authorization: 'Bearer ' + secret } }); assert.equal(status.headers.get('cache-control'), 'no-store'); assert.equal((await status.json()).qr, 'fictitious-qr-secret');
    const send = await fetch(base + '/send', { method: 'POST', headers: { authorization: 'Bearer ' + secret, 'content-type': 'application/json' }, body: JSON.stringify({ idempotencyKey: 'mock-http-send', to: '33600000001', text: 'Test' }) });
    assert.equal(send.status, 200); assert.equal((await send.json()).id, 'mock-send-id');
  } finally { await new Promise(resolve => server.close(resolve)); await rm(root, { recursive: true, force: true }); }
});
