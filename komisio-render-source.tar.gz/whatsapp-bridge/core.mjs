import { createHash, createHmac, timingSafeEqual } from 'node:crypto';
import { mkdir, open, readFile, readdir, rename, stat, unlink, writeFile } from 'node:fs/promises';
import { basename, join } from 'node:path';

export const MAX_MEDIA_BYTES = 10 * 1024 * 1024;
export const MAX_HTTP_BYTES = 14 * 1024 * 1024 + 64 * 1024;
const GROUP = /^\d{5,25}(?:-\d{5,25})?@g\.us$/;
const PHONE = /^[1-9]\d{5,14}$/;
export class BridgeError extends Error {
  constructor(status, message, attempted = false) { super(message); this.status = status; this.attempted = attempted; }
}
export function authorized(header, secret) {
  if (typeof secret !== 'string' || secret.length < 32) return false;
  const a = Buffer.from(header || ''), b = Buffer.from('Bearer ' + secret);
  return a.length === b.length && timingSafeEqual(a, b);
}
export function signPayload(raw, secret) { return 'sha256=' + createHmac('sha256', secret).update(raw).digest('hex'); }
export const digest = value => createHash('sha256').update(value).digest('hex');
export function safeFileName(name) {
  return basename(String(name || 'document')).replace(/[\x00-\x1f\x7f]/g, '').slice(0, 160) || 'document';
}
export function mediaPayload(input) {
  if (!input || typeof input !== 'object' || typeof input.base64 !== 'string' || input.base64.length > Math.ceil(MAX_MEDIA_BYTES / 3) * 4 || !/^[A-Za-z0-9+/]*={0,2}$/.test(input.base64) || input.base64.length % 4 !== 0) throw new BridgeError(400, 'Document invalide ou trop volumineux.');
  const bytes = Buffer.from(input.base64, 'base64');
  if (!bytes.length || bytes.length > MAX_MEDIA_BYTES || bytes.toString('base64') !== input.base64) throw new BridgeError(400, 'Document invalide.');
  const mimeType = bytes.subarray(0, 5).toString() === '%PDF-' ? 'application/pdf'
    : bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10])) ? 'image/png'
    : bytes.length >= 3 && bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255 ? 'image/jpeg'
    : bytes.length >= 16 && bytes.toString('ascii', 4, 8) === 'ftyp' && ['isom','iso2','mp41','mp42','avc1','M4V ','qt  '].includes(bytes.toString('ascii', 8, 12)) ? (bytes.toString('ascii', 8, 12) === 'qt  ' ? 'video/quicktime' : 'video/mp4') : null;
  if (!mimeType || input.mimeType !== mimeType) throw new BridgeError(400, 'Formats acceptés : PDF, JPEG, PNG, MP4 et MOV (10 Mo maximum).');
  return { base64: input.base64, mimeType, filename: safeFileName(input.filename || input.fileName) };
}
export function outgoingInput(input) {
  if (!input || typeof input !== 'object' || !/^[A-Za-z0-9:._-]{1,200}$/.test(input.idempotencyKey || '')) throw new BridgeError(400, 'Identifiant d’envoi invalide.');
  if (typeof input.to !== 'string') throw new BridgeError(400, 'Destinataire invalide.');
  const target = input.groupId || input.to;
  if (!PHONE.test(target) && !GROUP.test(target)) throw new BridgeError(400, 'Destinataire invalide.');
  if (input.groupId && !GROUP.test(input.groupId)) throw new BridgeError(400, 'Groupe invalide.');
  if (input.groupId && input.to !== input.groupId && !PHONE.test(input.to)) throw new BridgeError(400, 'Destinataire invalide.');
  const text = input.text ?? '';
  if (typeof text !== 'string' || text.length > 4000) throw new BridgeError(400, 'Message invalide.');
  const media = input.media ? mediaPayload(input.media) : null;
  if (!text.trim() && !media) throw new BridgeError(400, 'Message vide.');
  return { idempotencyKey: input.idempotencyKey, target: GROUP.test(target) ? target : target + '@c.us', text, media };
}

/** Resolve a sender only from a phone JID or the documented LID→PN resolver. */
export async function senderPhone(client, sender) {
  if (typeof sender !== 'string') return null;
  const direct = sender.match(/^([1-9]\d{5,14})@(?:c\.us|s\.whatsapp\.net)$/);
  if (direct) return direct[1];
  if (!/^\d{5,25}@lid$/.test(sender) || typeof client.getContactLidAndPhone !== 'function') return null;
  const records = await client.getContactLidAndPhone([sender]);
  const record = records?.find(item => item.lid === sender);
  return typeof record?.pn === 'string' ? record.pn.match(/^([1-9]\d{5,14})@(?:c\.us|s\.whatsapp\.net)$/)?.[1] || null : null;
}
export async function normalizeIncoming(client, message, now = Date.now(), isAllowed = async () => true) {
  if (!message || message.fromMe || message.isStatus || typeof message.from !== 'string' || message.from.includes('broadcast') || !['chat','image','document','video'].includes(message.type)) return null;
  const groupId = GROUP.test(message.from) ? message.from : null;
  if (!groupId && !/^[1-9]\d{5,14}@c\.us$/.test(message.from) && !/^\d{5,25}@lid$/.test(message.from)) return null;
  const phone = await senderPhone(client, groupId ? message.author : message.from);
  if (!phone || !await isAllowed(phone, groupId)) return null;
  const timestamp = Number(message.timestamp);
  if (!Number.isSafeInteger(timestamp) || timestamp > Math.floor(now / 1000) + 60 || timestamp < Math.floor(now / 1000) - 86400) return null;
  const id = message.id?._serialized;
  if (typeof id !== 'string' || !id || id.length > 400) return null;
  const payload = { id: 'web:' + id, sender: phone, groupId, timestamp, type: message.type === 'chat' ? 'text' : message.type, text: String(message.body || '').slice(0, 4000) };
  if (message.type !== 'chat') {
    if (!message.hasMedia) return null;
    // Unknown or excessive sizes are not downloaded into the browser process.
    const expectedSize = Number(message.rawData?.size ?? message._data?.size ?? message.rawData?.fileSize ?? message._data?.fileSize);
    if (!Number.isSafeInteger(expectedSize) || expectedSize <= 0 || expectedSize > MAX_MEDIA_BYTES) throw new BridgeError(413, 'Document sans taille vérifiable ou supérieur à 10 Mo.');
    const downloaded = await message.downloadMedia();
    if (!downloaded) throw new BridgeError(503, 'Document momentanément indisponible.');
    payload.media = mediaPayload({ base64: downloaded.data, mimeType: downloaded.mimetype, filename: downloaded.filename || 'document' });
  }
  if (payload.type === 'text' && !payload.text.trim()) return null;
  return payload;
}
async function privateDirectory(path) { await mkdir(path, { recursive: true, mode: 0o700 }); }
async function atomicJson(path, object) {
  const temp = path + '.tmp-' + process.pid + '-' + Math.random().toString(36).slice(2);
  const handle = await open(temp, 'wx', 0o600);
  try { await handle.writeFile(JSON.stringify(object)); await handle.sync(); } finally { await handle.close(); }
  await rename(temp, path);
}
async function readJson(path) {
  try { return JSON.parse(await readFile(path, 'utf8')); } catch (error) { if (error.code === 'ENOENT') return null; throw error; }
}

/** Disk-backed at-most-one dispatch. Uncertain sends stay blocked after a crash. */
export class SendReceipts {
  constructor(directory, send, { ready = () => true, maxReceipts = 100000 } = {}) { this.directory = directory; this.send = send; this.ready = ready; this.maxReceipts = maxReceipts; this.inFlight = new Map(); }
  async dispatch(input) {
    const value = outgoingInput(input), hash = digest(JSON.stringify({ target: value.target, text: value.text, media: value.media }));
    await privateDirectory(this.directory);
    const file = join(this.directory, digest(value.idempotencyKey) + '.json');
    if (this.inFlight.has(file)) { const previous = await this.inFlight.get(file); if (previous.hash !== hash) throw new BridgeError(409, 'Identifiant déjà utilisé pour un autre message.', true); return { id: previous.id, status: 'SENT' }; }
    const previous = await readJson(file).catch(() => { throw new BridgeError(409, 'Envoi à rapprocher manuellement.', true); });
    if (previous) {
      if (previous.hash !== hash) throw new BridgeError(409, 'Identifiant déjà utilisé pour un autre message.', true);
      if (previous.status !== 'SENT') throw new BridgeError(409, 'Résultat inconnu : vérifiez WhatsApp avant tout nouvel envoi.', true);
      return { id: previous.id, status: 'SENT' };
    }
    if (!this.ready()) throw new BridgeError(503, 'WhatsApp est déconnecté.', false);
    if ((await readdir(this.directory)).filter(name => name.endsWith('.json')).length >= this.maxReceipts) throw new BridgeError(503, 'Journal d’envoi plein. Archivage opérateur nécessaire.', false);
    // Exclusive creation precedes the side effect, including between processes.
    let claim;
    try { claim = await open(file, 'wx', 0o600); } catch (error) { if (error.code === 'EEXIST') throw new BridgeError(409, 'Un envoi existe déjà. Vérifiez son état.', true); throw error; }
    try { await claim.writeFile(JSON.stringify({ status: 'SENDING', hash, at: Date.now() })); await claim.sync(); } finally { await claim.close(); }
    const task = (async () => {
      try {
        const sent = await this.send(value);
        const id = sent?.id?._serialized || sent?.id;
        if (typeof id !== 'string' || !id) throw new Error('Missing send receipt');
        const result = { status: 'SENT', id, hash, at: Date.now() }; await atomicJson(file, result); return result;
      } catch {
        await atomicJson(file, { status: 'UNKNOWN', hash, at: Date.now() });
        throw new BridgeError(409, 'Résultat inconnu : vérifiez WhatsApp avant tout nouvel envoi.', true);
      }
    })();
    this.inFlight.set(file, task);
    try { const result = await task; return { id: result.id, status: 'SENT' }; } finally { this.inFlight.delete(file); }
  }
}

/** Private documents are retained only until backend acknowledgement or 24h expiry. */
export class IncomingQueue {
  constructor(directory, forward, { maxJobs = 50, maxBytes = 100 * 1024 * 1024, now = () => Date.now() } = {}) { this.directory = directory; this.forward = forward; this.maxJobs = maxJobs; this.maxBytes = maxBytes; this.now = now; this.running = false; }
  async initialize() { await privateDirectory(join(this.directory, 'pending')); await privateDirectory(join(this.directory, 'seen')); }
  async enqueue(payload) {
    await this.initialize();
    const key = digest(payload.id), seen = join(this.directory, 'seen', key + '.json'), file = join(this.directory, 'pending', key + '.json');
    if (await readJson(seen) || await readJson(file)) return false;
    const files = (await readdir(join(this.directory, 'pending'))).filter(name => name.endsWith('.json'));
    let total = 0, latest = -1; for (const name of files) { const path = join(this.directory, 'pending', name); total += (await stat(path)).size; const queued = await readJson(path); latest = Math.max(latest, queued?.at || 0); }
    const job = { payload, at: Math.max(this.now(), latest + 1), attempts: 0, nextAt: this.now() }, raw = JSON.stringify(job);
    if (files.length >= this.maxJobs || total + Buffer.byteLength(raw) > this.maxBytes) throw new BridgeError(503, 'File de réception pleine. Réessayez après traitement.');
    try { const handle = await open(file, 'wx', 0o600); try { await handle.writeFile(raw); await handle.sync(); } finally { await handle.close(); } } catch (error) { if (error.code === 'EEXIST') return false; throw error; }
    return true;
  }
  async process() {
    if (this.running) return;
    this.running = true;
    try {
      await this.initialize();
      const files = (await readdir(join(this.directory, 'pending'))).filter(name => name.endsWith('.json'));
      const jobs = [];
      for (const name of files) { try { const value = await readJson(join(this.directory, 'pending', name)); if (value) jobs.push({ name, ...value }); } catch {} }
      jobs.sort((a,b) => a.at - b.at);
      // One FIFO lane: never overtake a command with a later document on retry.
      for (const job of jobs.slice(0, 10)) {
        if (job.nextAt > this.now()) break;
        const file = join(this.directory, 'pending', job.name);
        let status;
        if (job.at < this.now() - 86400_000) status = 'EXPIRED';
        else {
          try { status = await this.forward(job.payload); } catch { status = 'RETRY'; }
        }
        if (status !== 'RETRY') {
          await atomicJson(join(this.directory, 'seen', job.name), { status, at: this.now() });
          await unlink(file);
        } else {
          await atomicJson(file, { payload: job.payload, at: job.at, attempts: job.attempts + 1, nextAt: this.now() + Math.min(300000, 5000 * 2 ** Math.min(job.attempts, 6)) });
          break;
        }
      }
      // Inbox dedupe receipts have no content. Backend provides permanent message-id dedupe.
      for (const name of (await readdir(join(this.directory, 'seen'))).filter(name => name.endsWith('.json'))) {
        const file = join(this.directory, 'seen', name);
        if ((await stat(file)).mtimeMs < this.now() - 7 * 86400_000) await unlink(file);
      }
    } finally { this.running = false; }
  }
  async counts() { await this.initialize(); return { pending: (await readdir(join(this.directory, 'pending'))).filter(name => name.endsWith('.json')).length }; }
}
