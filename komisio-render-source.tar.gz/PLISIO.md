# Paiements et retraits Plisio

## Contrat fournisseur

Sources officielles consultées le 24 octobre 2026 : [factures et callbacks](https://plisio.net/documentation/endpoints/create-an-invoice), [détails d’opération](https://plisio.net/documentation/endpoints/transaction-details), [retraits](https://plisio.net/documentation/endpoints/withdrawal-mass-withdrawal), [estimation des frais](https://plisio.net/documentation/endpoints/fee-estimation), [devises](https://plisio.net/documentation/appendices/supported-cryptocurrencies).

`PAYMENT_PROVIDER=PLISIO` et `PLISIO_API_KEY` pilotent les nouvelles factures. Les anciennes factures NOWPayments conservent leur fournisseur, sans modification de prix, de statut ni de journal. Conservez leurs anciennes clés jusqu’à leur réconciliation si elles existent.

### Encaissements

- Création serveur via `GET /invoices/new` : prix EUR de la base, référence marchande unique égale à `Payment.id`, monnaie/réseau imposés, `return_existing=1`, URL de callback avec `json=true`.
- Codes : USDT TRC20 → `USDT_TRX`, USDT ERC20 → `USDT`, Bitcoin → `BTC`, Ethereum → `ETH`, Solana → `SOL`.
- La facture hébergée est stockée dans `Payment.invoiceUrl` et utilisée par le bouton et le QR code. Aucun abonnement White Label n’est supposé nécessaire et aucune adresse n’est inventée.
- Le callback JSON vérifie `verify_hash` en HMAC SHA-1 selon le protocole Node publié : ordre des clés conservé, retrait de `verify_hash`, comparaison constante. Il ne réutilise pas le protocole SHA-512 trié de NOWPayments.
- Avant tout crédit : référence, type invoice, devise EUR, montant EUR exact, réseau crypto, montant reçu et montant total sont contrôlés. La confirmation API authentifiée doit aussi indiquer `completed`. Les statuts partiels, mismatch ou erreurs ne sont pas crédités automatiquement.
- Le journal, le crédit et le passage d’une commande payée en traitement restent atomiques et idempotents. Une réponse perdue à la création peut être récupérée par le callback signé, sans recréer une facture. Un simple retour navigateur ne valide rien.

La facture standard peut ne pas fournir toutes les métadonnées de prix dans l’API d’opérations. Le reçu signé reste alors nécessaire : un polling voyant `completed` sans reçu vérifiable ne crédite pas le portefeuille. Le callback doit donc être réellement accessible et testé sur l’hébergement retenu.

### Retraits USDT TRC20

L’API admin `/api/admin/withdrawals/:id/plisio` accepte `quote`, `send`, `reconcile` et `link` (identifiant d’opération requis pour link).

1. `quote` lit le taux EUR/USDT de `/currencies/EUR` et estime les frais via `/operations/fee/USDT_TRX`. Les frais EUR sont arrondis au centime supérieur, le net USDT vers le bas à six décimales. Aucune commission plateforme.
2. Le revendeur accepte la version du devis et l’adresse ; la réserve EUR est débitée une seule fois.
3. L’admin déclenche l’envoi via Plisio après vérification des frais et du solde du compte. Si les frais ont augmenté au-delà du devis, aucun transfert n’est lancé et un nouveau devis est nécessaire.
4. L’application revendique atomiquement l’envoi, puis effectue **une tentative applicative** de `GET /operations/withdraw` hors transaction SQL. Une réponse inconnue garde la réserve et interdit le renvoi automatique.
5. Une opération reçue est vérifiée sur le réseau `USDT_TRX`, la destination et le montant net. Un hash connu passe le dossier à `SENT` ; la confirmation API `completed` avec au moins une confirmation le clôture. Aucun second débit.
6. Pour une réponse perdue, l’admin retrouve l’opération dans Plisio. Le rattachement contrôle identifiant, type, réseau, adresse, montant et fenêtre temporelle, puis reste audité. Un délai ne provoque jamais un remboursement automatique.

Le compte marchand doit disposer du solde USDT TRC20 nécessaire et ses paramètres Request IP doivent autoriser les requêtes de l’hébergement. Les autres cryptos encaissées ne sont pas automatiquement converties en USDT. Les flags `WITHDRAWALS_ENABLED` et `PLISIO_PAYOUTS_ENABLED` restent désactivés tant que ces paramètres et une recette réelle ne sont pas vérifiés.

Le reçu initial d’envoi est conservé pour contrôler les réponses API standard moins détaillées. Si Plisio ne fournit pas le nombre de confirmations, le transfert reste envoyé et l’admin peut attester la confirmation après vérification sur TRON. Une opération inconnue sans métadonnées vérifiables exige une réconciliation opérateur ; elle ne déclenche ni nouvel envoi ni libération automatique.

Les routes manuelles existantes restent disponibles pour les retraits qui n’ont pas été envoyés via Plisio. Une opération Plisio déjà lancée ne doit jamais être répétée manuellement sans réconciliation.
