# Dédouanement suisse

## Parcours

1. Le revendeur renseigne uniquement le kilométrage (entier positif ou nul, 8 chiffres maximum) et joint une photo JPEG/PNG de la carte grise. Les validations et le stockage privé existants s’appliquent. Aucun PDF ne remplace la photo.
2. Le dossier est déposé sans débit en `AWAITING_QUOTE`. L’admin propose le prix total, et le revendeur accepte ou refuse la version du devis.
3. Dès acceptation, l’admin fixe un rendez-vous futur de récupération, avec adresse et instructions facultatives. Le champ date/heure utilise le fuseau de l’appareil de l’admin, annoncé à côté du champ ; l’affichage et la notification sont en heure de Paris. Le rendez-vous peut être modifié avant récupération. Il est visible dans le dossier, sans connexion à un agenda externe.
4. L’admin confirme la récupération **réelle de l’original physique**, distincte de la photo jointe. Le traitement ne commence qu’après paiement confirmé.
5. Après la démarche, l’admin confirme que la carte grise est prête à restituer, puis confirme sa remise physique. Cette dernière action termine automatiquement le dossier payé. Aucun PDF de livrable n’est imposé pour ce parcours.

Le revendeur voit les étapes et leurs dates. Les notifications Telegram sont ajoutées à l’outbox à chaque action admin. L’accord sur le devis avertit également l’admin qu’un rendez-vous est à fixer. Aucun message réel n’est envoyé par les tests.

## Données et sécurité

`OriginalDocument` est une relation facultative de `Order`. Elle porte le statut (`TO_SCHEDULE`, `APPOINTMENT_SET`, `COLLECTED`, `READY_FOR_RETURN`, `RETURNED`), les coordonnées du rendez-vous, les dates de garde et une version croissante. Elle est créée uniquement pour les nouveaux dossiers du service `douane-suisse` ; les anciens dossiers conservent leur traitement et leur prix.

`POST /api/admin/orders/:id/original-document` est réservé aux admins authentifiés, avec contrôle d’origine et JSON strict :

- Rendez-vous : `{action: "schedule", expectedVersion, appointmentAt, location, note?}`. Date ISO avec fuseau obligatoire, normalisée en UTC ; adresse de 3 à 1 000 caractères ; instructions jusqu’à 2 000 caractères.
- Garde : `{action: "collect" | "ready" | "return", expectedVersion, confirmed: true}`. La case de confirmation est liée à l’action et à la version affichées.

Le serveur vérifie l’état du devis, l’ordre des étapes, le paiement avant finalisation et les versions concurrentes. La répétition exacte de la dernière action ne duplique ni événement ni notification. Toutes les écritures de garde, d’événements, d’audit et d’outbox sont atomiques en transaction sérialisable. Le suivi est exposé dans les lectures existantes réservées au propriétaire et aux admins.

L’API générique de changement de statut ne peut pas terminer un dossier dont l’original n’est pas restitué, même si un livrable numérique est présent. Après annulation, un original déjà récupéré peut être rendu ; le dossier reste `CANCELLED` et aucune opération financière supplémentaire n’est créée. Les remboursements d’annulation restent gérés par la route existante.

## Installation et vérification

Appliquer `npx prisma migrate deploy` puis `npm run db:seed` pour une nouvelle installation. La migration ne modifie aucune commande existante. La révision du catalogue local remplace le formulaire et le tarif suisse une seule fois, puis conserve les changements ultérieurs de l’admin.

La suite PostgreSQL `tests/order-quotes.integration.test.ts` couvre photo obligatoire, devis, acceptation, rendez-vous avant paiement, versions périmées, droits admin, transitions, garde non payable avant accord, clôture après restitution idempotente et restitution après annulation. Exécution sur une base jetable nommée `forma_quotes_test` avec `ORDER_QUOTE_TEST_DATABASE_URL`.

La publication Sites reste une démonstration statique : rendez-vous et garde y sont simulés dans le navigateur. Le code serveur est fourni séparément et doit être déployé/configuré avant l’usage réel.
