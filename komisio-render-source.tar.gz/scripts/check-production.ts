import { configurationIssues } from '../lib/server/configuration';
const issues=configurationIssues(process.env,true);
if(issues.length){console.error('Configuration incomplète :\n'+issues.map(issue=>'• '+issue).join('\n'));process.exitCode=1;}else console.log('Configuration de production complète. Vérifiez ensuite /api/health sur le serveur.');
