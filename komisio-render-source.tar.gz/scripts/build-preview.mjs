/** Build a separate static demonstration. Production Next/API sources stay intact. */
import { cp, mkdir, rm, symlink, writeFile } from "node:fs/promises";
import { execFileSync } from "node:child_process";
import path from "node:path";
const root = process.cwd();
const stage = path.join(root, "preview-build");
await rm(stage, { recursive: true, force: true });
await mkdir(stage, { recursive: true });
for (const entry of [
  "app",
  "components",
  "lib/catalog.ts",
  "lib/pricing.ts",
  "lib/vehicle-estimate.ts",
  "lib/whatsapp-public.ts",
  "lib/catalogue-view.ts",
  "lib/appearance.ts",
  "lib/withdrawals.ts",
  "lib/original-document.ts",
  "tsconfig.json",
  "next-env.d.ts",
  "postcss.config.mjs",
]) {
  await cp(path.join(root, entry), path.join(stage, entry), {
    recursive: true,
    filter: (source) => !source.startsWith(path.join(root, "app", "api")),
  });
}
try {
  await cp(path.join(root, "public"), path.join(stage, "public"), {
    recursive: true,
  });
} catch (error) {
  if (error.code !== "ENOENT") throw error;
}
await symlink(
  path.join(root, "node_modules"),
  path.join(stage, "node_modules"),
  "dir",
);
await writeFile(
  path.join(stage, "package.json"),
  JSON.stringify({
    name: "forma-private-demo",
    version: "1.0.0",
    private: true,
  }),
);
await writeFile(
  path.join(stage, "next.config.mjs"),
  "export default { output:'export', trailingSlash:true, poweredByHeader:false, images:{unoptimized:true}, experimental:{cpus:2}};\n",
);
execFileSync(
  process.execPath,
  [path.join(root, "node_modules/next/dist/bin/next"), "build"],
  {
    cwd: stage,
    stdio: "inherit",
    env: {
      ...process.env,
      NEXT_PUBLIC_DEMO_MODE: "true",
      NEXT_TELEMETRY_DISABLED: "1",
    },
  },
);
await rm(path.join(root, "out"), { recursive: true, force: true });
await cp(path.join(stage, "out"), path.join(root, "out"), { recursive: true });
console.log(
  "Static demo generated in out/. Full Next.js APIs are delivered in the source project.",
);
