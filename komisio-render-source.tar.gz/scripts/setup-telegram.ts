import { configurationIssues } from '../lib/server/configuration';
import { configureTelegramBot } from '../lib/server/telegram-setup';
async function main() {
const issues=configurationIssues(process.env,true);
if(issues.length) { console.error(issues.join('\n'));process.exit(1); }
const health=await fetch(`${new URL(process.env.APP_URL!).origin}/api/health`,{signal:AbortSignal.timeout(10000)});
if(!health.ok)throw Error('Le serveur HTTPS doit être prêt avant l’activation du bot.');
const configured=await configureTelegramBot();
console.log(`Bot @${configured.botUsername} raccordé. Ouvrez sa conversation et envoyez /start.`);
}
main().catch(() => { console.error("Raccordement Telegram échoué. Vérifiez le nom du bot, son token et l’accès HTTPS du serveur."); process.exitCode=1; });
