import { spawn,spawnSync } from 'node:child_process';
if(!process.env.APP_URL && process.env.RENDER_EXTERNAL_URL)process.env.APP_URL=process.env.RENDER_EXTERNAL_URL;
if(!process.env.MINI_APP_URL && process.env.APP_URL)process.env.MINI_APP_URL=process.env.APP_URL;
// Free web instances have no separate paid worker or persistent local disk.
function run(args){const r=spawnSync(process.execPath,args,{stdio:'inherit'});if(r.status!==0)process.exit(r.status||1);}
run(['node_modules/tsx/dist/cli.mjs','scripts/check-production.ts']);
run(['node_modules/prisma/build/index.js','migrate','deploy']);
run(['node_modules/tsx/dist/cli.mjs','prisma/seed.ts']);
const env={...process.env,HOSTNAME:'0.0.0.0'};
const server=spawn(process.execPath,['.next/standalone/server.js'],{env,stdio:'inherit'});
const worker=spawn(process.execPath,['scripts/notification-worker.mjs'],{env:{...env,APP_INTERNAL_URL:`http://127.0.0.1:${process.env.PORT||3000}`},stdio:'inherit'});
let stopping=false;
function stop(){if(stopping)return;stopping=true;server.kill('SIGTERM');worker.kill('SIGTERM');}
process.on('SIGTERM',stop);process.on('SIGINT',stop);
server.on('exit',code=>{stop();process.exitCode=code||0;});
