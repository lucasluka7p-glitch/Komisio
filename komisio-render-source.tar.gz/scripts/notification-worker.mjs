import { setTimeout as delay } from 'node:timers/promises';
const url = new URL('/api/cron/notifications', process.env.APP_INTERNAL_URL || 'http://app:3000');
if(!process.env.CRON_SECRET || process.env.CRON_SECRET.length < 32)throw Error('CRON_SECRET requis');
let stopped=false;
process.on('SIGTERM',()=>{stopped=true;});process.on('SIGINT',()=>{stopped=true;});
while(!stopped) {
 try {
  const response=await fetch(url,{method:'POST',headers:{authorization:`Bearer ${process.env.CRON_SECRET}`},signal:AbortSignal.timeout(65000)});
  if(!response.ok)console.error(`Notification worker: HTTP ${response.status}`);
 }catch { console.error('Notification worker: serveur indisponible, nouvel essai au prochain passage.'); }
 if(!stopped)await delay(30000);
}
