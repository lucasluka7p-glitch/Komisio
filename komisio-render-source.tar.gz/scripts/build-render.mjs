import { cp,mkdir } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
execFileSync('npm',['run','build'],{stdio:'inherit'});
await mkdir('.next/standalone/.next',{recursive:true});
await cp('.next/static','.next/standalone/.next/static',{recursive:true});
await cp('public','.next/standalone/public',{recursive:true});
