/** Disposable PostgreSQL integration suite. Never reads or changes a production database. */
import { spawnSync } from 'node:child_process';
import { readdirSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import { setTimeout as delay } from 'node:timers/promises';
const name = `komisio-test-${randomUUID().slice(0,8)}`;
const dockerEnv = { ...process.env };
for (const key of ['DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH']) delete dockerEnv[key];
function docker(args, quiet = false) {
 const result = spawnSync('docker', ['--host=unix:///var/run/docker.sock', ...args], { env: dockerEnv, encoding: 'utf8', stdio: quiet ? 'pipe' : 'inherit' });
 if (result.status !== 0) throw Error(`Docker operation failed: ${args[0]} ${result.stderr?.slice(0,500) || ''}`);
 return result.stdout?.trim();
}
function run(args, env) {
 const r=spawnSync(process.execPath,args,{env:{...process.env,...env},stdio:'inherit'});
 if(r.status!==0) throw Error(`Check failed: ${args[0]}`);
}
let created=false;
try {
 docker(['run','--detach','--name',name,'--publish','127.0.0.1::5432','--env','POSTGRES_HOST_AUTH_METHOD=trust','postgres:16-alpine'],true); created=true;
 let ready=false;
 for(let i=0;i<30;i++){try{docker(['exec',name,'pg_isready','-h','127.0.0.1','-U','postgres'],true);ready=true;break;}catch{await delay(500);}}
 if(!ready)throw Error('Test PostgreSQL did not become ready');
 const port=docker(['port',name,'5432/tcp'],true).split(':').at(-1);
 const urls={};
 for(const database of ['forma_quotes_test','forma_withdrawals_test','komisio_http_test','komisio_plisio_test','komisio_clients_test','komisio_whatsapp_test']){
  docker(['exec',name,'createdb','-U','postgres',database],true);
  const url=`postgresql://postgres@127.0.0.1:${port}/${database}`; urls[database]=url;
  run(['node_modules/prisma/build/index.js','migrate','deploy'],{DATABASE_URL:url});
  run(['node_modules/tsx/dist/cli.mjs','prisma/seed.ts'],{DATABASE_URL:url});
 }
 const tests=readdirSync('tests').filter(file=>file.endsWith('.test.ts')&&(!process.env.TEST_FILE||file===process.env.TEST_FILE)).map(file=>`tests/${file}`);
 if(!tests.length)throw Error('No matching tests');
 run(['node_modules/tsx/dist/cli.mjs','--test','--test-concurrency=1',...tests],{ORDER_QUOTE_TEST_DATABASE_URL:urls.forma_quotes_test,WITHDRAWAL_TEST_DATABASE_URL:urls.forma_withdrawals_test,HTTP_TEST_DATABASE_URL:urls.komisio_http_test,PLISIO_TEST_DATABASE_URL:urls.komisio_plisio_test,CLIENT_TEST_DATABASE_URL:urls.komisio_clients_test,WHATSAPP_TEST_DATABASE_URL:urls.komisio_whatsapp_test});
} finally { if(created)docker(['rm','--force','--volumes',name],true); }
