import { randomBytes } from 'node:crypto';
import { writeFileSync, readFileSync } from 'node:fs';
const secret=()=>randomBytes(32).toString('hex');
const template=readFileSync('.env.example','utf8')
 .replace('DATABASE_URL="postgresql://forma:password@localhost:5432/forma?schema=public"','DATABASE_URL="postgresql://komisio:REPLACE_USING_POSTGRES_PASSWORD@postgres:5432/komisio"')
 .replace('SESSION_SECRET=""',`SESSION_SECRET="${secret()}"`)
 .replace('CRON_SECRET=""',`CRON_SECRET="${secret()}"`)
 .replace('WHATSAPP_BRIDGE_SECRET=""',`WHATSAPP_BRIDGE_SECRET="${secret()}"`)
 .replace('TELEGRAM_WEBHOOK_SECRET=""',`TELEGRAM_WEBHOOK_SECRET="${secret()}"`);
try { writeFileSync('.env.production',`POSTGRES_PASSWORD="${secret()}"\nKOMISIO_DOMAIN=""\n${template}`,{flag:'wx',mode:0o600});console.log('.env.production créé avec secrets locaux distincts. Complétez le domaine, le bot Telegram et Plisio dans ce fichier privé.'); }
catch(error) { if(error.code==='EEXIST'){console.error('.env.production existe déjà ; aucun secret remplacé.');process.exitCode=1;}else throw error; }
