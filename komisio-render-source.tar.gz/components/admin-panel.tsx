"use client";
import { ClientAccounts } from "./client-accounts";
import { WhatsAppPanel } from "./whatsapp-panel";
import { catalogueSections, serviceSection, normalizeCatalogueQuery } from "@/lib/catalogue-view";
import { OperationsPanel } from "./operations-panel";
import { OrderQuote } from "./order-quote";
import { OriginalDocumentPanel } from "./original-document";
import { assertOriginalDocumentReturned } from "@/lib/original-document";
import { WithdrawalsPanel } from "./withdrawals-panel";

import { useEffect, useMemo, useState, type FormEvent } from "react";
import {
  ArrowDownLeft,
  ArrowUpRight,
  ArrowRight,
  CheckCircle2,
  ChevronRight,
  Download,
  FileText,
  FolderOpen,
  Layers,
  LoaderCircle,
  Plus,
  Search,
  Settings2,
  ShieldCheck,
  TrendingUp,
  Upload,
  Users,
  Wallet,
} from "lucide-react";
import {
  categories, subcategories, subcategoryLabel,
  dateFR,
  euro,
  statusLabels,
  servicePrice, orderPrice, isPaidStatus,
  type Attachment,
  type Category,
  type Order,
  type OrderStatus,
  type Service,
} from "@/lib/catalog";
import { Modal, Status } from "@/components/ui";
import "./admin.css";

type Props = {
  services: Service[];
  orders: Order[];
  balance: number;
  onUpdateServices: (services: Service[]) => void;
  onUpdateOrder: (order: Order) => void;
  onBalanceChange: (amount: number, reason: string) => void;
  notify: (message: string, error?: boolean) => void;
  isLive?: boolean;
};
type Reseller = {
  id: string;
  name: string;
  username: string;
  telegramId: string;
  balance: number;
  revenue: number;
  orders: number;
  joinedAt?: string;
};
type Adjustment = {
  id: string;
  userName: string;
  amount: number;
  reason: string;
  date: string;
};
type Tab = "overview" | "orders" | "catalog" | "resellers" | "finances" | "whatsapp";
const tabs: { id: Tab; label: string }[] = [
  { id: "overview", label: "Vue d’ensemble" },
  { id: "orders", label: "Commandes" },
  { id: "catalog", label: "Catalogue" },
  { id: "resellers", label: "Clients & tarifs" },
  { id: "whatsapp", label: "WhatsApp" },
  { id: "finances", label: "Finances" },
];
const api = async (path: string, options?: RequestInit) => {
  const response = await fetch(path, {
    ...options,
    headers: {
      ...(options?.body instanceof FormData
        ? {}
        : { "Content-Type": "application/json" }),
      ...options?.headers,
    },
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok)
    throw new Error(
      typeof data.error === "string"
        ? data.error
        : data.error?.message ||
          data.message ||
          "La demande n’a pas pu être traitée.",
    );
  return data;
};
const readFile = (file: File) =>
  new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
const slugify = (text: string) =>
  text
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
const servicePayload = (service: Service) => {
  const extra = service as Service & { slug?: string; documentKeys?: string[] };
  return {
    slug: extra.slug || slugify(service.title),
    name: service.title,
    description: service.description,
    category: service.category.toUpperCase(),
    subcategory: service.subcategory || null,
    priceCents: service.requiresQuote ? 0 : service.price,
    requiresQuote: !!service.requiresQuote,
    turnaround: service.delay,
    active: service.active,
    fields: service.fields,
    requiredDocuments: service.documents.map((label, index) => ({
      key: extra.documentKeys?.[index] || `doc_${index}`,
      label,
      required: service.documentRequired?.[index] !== false,
      type: service.documentTypes?.[index] || "document",
    })),
  };
};
const newService = (): Service => ({
  id: "",
  title: "",
  description: "",
  category: "formalites",
  price: 4900,
  delay: "24 à 48 h",
  icon: "folder",
  active: true,
  documents: [],
  fields: [],
});
const download = (href: string, name: string) => {
  const a = document.createElement("a");
  a.href = href;
  a.download = name;
  a.rel = "noopener";
  a.click();
};
const csvCell = (value: unknown) => {
  const text = String(value ?? "");
  return (
    '"' +
    (/^[=+\-@]/.test(text) ? "'" + text : text).replaceAll('"', '""') +
    '"'
  );
};
const exportCsv = (name: string, rows: unknown[][]) => {
  const blob = new Blob(
    ["\uFEFF" + rows.map((row) => row.map(csvCell).join(";")).join("\r\n")],
    { type: "text/csv;charset=utf-8;" },
  );
  const href = URL.createObjectURL(blob);
  download(href, name);
  setTimeout(() => URL.revokeObjectURL(href), 1000);
};

export default function AdminPanel({
  services,
  orders,
  balance,
  onUpdateServices,
  onUpdateOrder,
  onBalanceChange,
  notify,
  isLive = false,
}: Props) {
  const [clientRefresh, setClientRefresh] = useState(0);
  const [tab, setTab] = useState<Tab>("overview");
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("all");
  const [selected, setSelected] = useState<Order | null>(null);
  const [nextStatus, setNextStatus] = useState<OrderStatus>("PROCESSING");
  const [note, setNote] = useState("");
  const [deliverable, setDeliverable] = useState<Attachment | undefined>();
  const [editing, setEditing] = useState<Service | null>(null);
  const [docLines, setDocLines] = useState("");
  const [fieldLines, setFieldLines] = useState("");
  const [resellers, setResellers] = useState<Reseller[]>([]);
  const [adjusting, setAdjusting] = useState<Reseller | null>(null);
  const [adjustAmount, setAdjustAmount] = useState("");
  const [adjustReason, setAdjustReason] = useState("");
  const [adjustType, setAdjustType] = useState<"credit" | "debit">("credit");
  const [adjustKey, setAdjustKey] = useState("");
  const [adjustments, setAdjustments] = useState<Adjustment[]>([]);
  const [transactions, setTransactions] = useState<Record<string, unknown>[]>(
    [],
  );
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    if (!isLive) {
      try {
        setAdjustments(
          JSON.parse(localStorage.getItem("forma-admin-adjustments") || "[]"),
        );
      } catch {}
      return;
    }
    setLoading(true);
    api("/api/admin/payments")
      .then((data) =>
        setTransactions(Array.isArray(data) ? data : data.payments || []),
      )
      .catch((error) => notify(error.message, true));
    api("/api/admin/users")
      .then((data) => {
        const users = (Array.isArray(data) ? data : data.users || []).filter(
          (user: Record<string, unknown>) => user.role !== "ADMIN",
        );
        setResellers(
          users.map((user: Record<string, unknown>) => ({
            id: String(user.id),
            name: String(
              user.name ||
                [user.firstName, user.lastName].filter(Boolean).join(" ") ||
                user.username ||
                "Revendeur",
            ),
            username: String(user.username || ""),
            telegramId: String(user.telegramId || ""),
            balance: Number(user.balanceCents ?? user.balance ?? 0),
            revenue: Number(
              user.revenueCents ??
                (Array.isArray(user.orders)
                  ? user.orders
                      .filter(
                        (o: Record<string, unknown>) =>
                          o.paidAt && o.status !== "CANCELLED",
                      )
                      .reduce(
                        (sum: number, o: Record<string, unknown>) =>
                          sum + Number(o.priceCents),
                        0,
                      )
                  : 0),
            ),
            orders: Number(
              user.orderCount ??
                (user._count as { orders?: number } | undefined)?.orders ??
                0,
            ),
            joinedAt: String(user.createdAt || ""),
          })),
        );
        setAdjustments(
          users
            .flatMap((user: Record<string, unknown>) =>
              (Array.isArray(user.ledger) ? user.ledger : [])
                .filter(
                  (entry: Record<string, unknown>) =>
                    entry.kind === "ADMIN_ADJUSTMENT",
                )
                .map((entry: Record<string, unknown>) => ({
                  id: String(entry.id),
                  userName: String(
                    user.firstName || user.username || "Revendeur",
                  ),
                  amount: Number(entry.amountCents),
                  reason: String(entry.reason),
                  date: String(entry.createdAt),
                })),
            )
            .sort((a: Adjustment, b: Adjustment) =>
              b.date.localeCompare(a.date),
            ),
        );
      })
      .catch((error) => notify(error.message, true))
      .finally(() => setLoading(false));
  }, [isLive]);
  const demoResellers: Reseller[] = useMemo(() => {
    const users = new Map<string, Reseller>();
    orders.forEach((order) => {
      const id = order.userId || "demo";
      const existing = users.get(id) || {
        id,
        name: order.userName || "Thomas Dubois",
        username: "thomas_dubois",
        telegramId: "782 104 563",
        balance: id === "demo" ? balance : 0,
        revenue: 0,
        orders: 0,
      };
      existing.orders++;
      if (isPaidStatus(order.status))
        existing.revenue += order.amount;
      users.set(id, existing);
    });
    if (!users.size)
      users.set("demo", {
        id: "demo",
        name: "Thomas Dubois",
        username: "thomas_dubois",
        telegramId: "782 104 563",
        balance,
        revenue: 0,
        orders: 0,
      });
    return [...users.values()];
  }, [orders, balance]);
  const users = isLive ? resellers : demoResellers;
  const selectedClosed = selected
    ? ["COMPLETED", "CANCELLED", "QUOTE_REJECTED"].includes(selected.status)
    : false;
  const revenue = orders
    .filter((o) => isPaidStatus(o.status))
    .reduce((sum, o) => sum + o.amount, 0);
  const processing = orders.filter((o) => o.status === "PROCESSING").length;
  const needsAction = orders.filter(
    (o) => o.status === "ACTION_REQUIRED",
  ).length;
  const shownOrders = orders.filter(
    (o) =>
      (filter === "all" || o.status === filter) &&
      `${o.reference} ${o.customerName} ${o.serviceTitle} ${o.userName || ""}`
        .toLocaleLowerCase("fr")
        .includes(query.toLocaleLowerCase("fr")),
  );
  const shownServices = services.filter(service =>
    (filter === "all" || serviceSection(service).id === filter) && normalizeCatalogueQuery(`${service.title} ${service.description} ${subcategoryLabel(service)} ${serviceSection(service).label}`)
      .includes(normalizeCatalogueQuery(query)),
  ).sort((a, b) => catalogueSections.findIndex(section => section.id === serviceSection(a).id) - catalogueSections.findIndex(section => section.id === serviceSection(b).id) || a.title.localeCompare(b.title, "fr"));
  const openOrder = (order: Order) => {
    setSelected(order);
    setNextStatus(order.status);
    setNote(order.note || "");
    setDeliverable(order.deliverable);
  };
  const openService = (service: Service) => {
    setEditing({ ...service });
    setDocLines(
      service.documents
        .map(
          (label, index) =>
            `${label} | ${service.documentRequired?.[index] === false ? "optionnel" : "obligatoire"} | ${service.documentTypes?.[index] || "document"}`,
        )
        .join("\n"),
    );
    setFieldLines(
      service.fields
        .map(
          (f) =>
            `${f.key} | ${f.label} | ${f.required ? "obligatoire" : "optionnel"} | ${f.type || "text"}${f.type === "select" ? ` | ${(f.options || []).join(", ")}` : ""}`,
        )
        .join("\n"),
    );
  };
  const allowedStatuses = (order: Order): OrderStatus[] =>
    ["AWAITING_QUOTE", "QUOTE_PROPOSED"].includes(order.status)
      ? [order.status, "CANCELLED"]
      : order.status === "AWAITING_PAYMENT"
      ? ["AWAITING_PAYMENT", "CANCELLED"]
      : ["COMPLETED", "CANCELLED", "QUOTE_REJECTED"].includes(order.status)
        ? [order.status]
        : ["PROCESSING", "ACTION_REQUIRED", "COMPLETED", "CANCELLED"];
  const changeTab = (value: Tab) => {
    setTab(value);
    setQuery("");
    setFilter("all");
  };
  async function attachDeliverable(file: File) {
    if (!selected) return;
    if (["COMPLETED", "CANCELLED", "QUOTE_REJECTED"].includes(selected.status)) return;
    const maxMegabytes = isLive ? 8 : 2;
    if (
      !["application/pdf", "image/jpeg", "image/png"].includes(file.type) ||
      !file.size ||
      file.size > maxMegabytes * 1024 * 1024
    ) {
      notify(
        `Choisissez un PDF, JPG ou PNG de moins de ${maxMegabytes} Mo${isLive ? "." : " pour la démonstration."}`,
        true,
      );
      return;
    }
    setBusy(true);
    try {
      if (isLive) {
        const form = new FormData();
        form.set("file", file);
        form.set("orderId", selected.id);
        form.set("kind", "DELIVERABLE");
        form.set("fieldKey", "deliverable");
        form.set("serviceId", selected.serviceId);
        const data = await api("/api/documents", {
          method: "POST",
          body: form,
        });
        const doc = data.document || data;
        setDeliverable({
          id: doc.id,
          name: doc.fileName || doc.originalName || doc.name || file.name,
          fieldKey: "deliverable",
          type: file.type,
        });
      } else {
        setDeliverable({
          id: crypto.randomUUID(),
          name: file.name,
          fieldKey: "deliverable",
          data: await readFile(file),
          type: file.type,
        });
      }
      notify(
        "Livrable ajouté. Enregistrez les modifications pour le partager.",
      );
    } catch (error) {
      notify((error as Error).message, true);
    } finally {
      setBusy(false);
    }
  }
  async function saveOrder(event: FormEvent) {
    event.preventDefault();
    if (!selected) return;
    if (nextStatus === "ACTION_REQUIRED" && !note.trim()) {
      notify("Précisez l’action ou le document attendu dans le message.", true);
      return;
    }
    if (nextStatus === "COMPLETED") {
      try { assertOriginalDocumentReturned(selected.originalDocument); } catch (error) { notify((error as Error).message, true); return; }
    }
    if (nextStatus === "COMPLETED" && !selected.originalDocument && !deliverable) {
      notify("Ajoutez un livrable avant de terminer ce dossier.", true);
      return;
    }
    setBusy(true);
    try {
      if (isLive)
        await api(`/api/admin/orders/${selected.id}`, {
          method: "PATCH",
          body: JSON.stringify({
            status: nextStatus,
            note,
            deliverableId: deliverable?.id,
          }),
        });
      onUpdateOrder({ ...selected, status: nextStatus, note, deliverable });
      if (
        isLive &&
        nextStatus === "CANCELLED" &&
        ["PROCESSING", "ACTION_REQUIRED"].includes(selected.status)
      ) {
        setResellers((current) =>
          current.map((user) =>
            user.id === selected.userId
              ? {
                  ...user,
                  balance: user.balance + selected.amount,
                  revenue: Math.max(0, user.revenue - selected.amount),
                }
              : user,
          ),
        );
      }
      setSelected(null);
      notify(
        isLive
          ? "Dossier mis à jour. Notification Telegram mise en file d’envoi."
          : "Dossier mis à jour dans la démonstration.",
      );
    } catch (error) {
      notify((error as Error).message, true);
    } finally {
      setBusy(false);
    }
  }
  async function saveService(event: FormEvent) {
    event.preventDefault();
    if (!editing) return;
    const fields = fieldLines
      .split("\n")
      .map((l) => l.trim())
      .filter(Boolean)
      .map((line, index) => {
        const parts = line.split("|").map((v) => v.trim());
        const key = parts.length > 1 ? parts[0] : `field_${index + 1}`;
        const existing = editing.fields.find((field) => field.key === key);
        const type = parts[3] || existing?.type || "text";
        const options =
          type === "select"
            ? parts.length > 4
              ? parts[4] === existing?.options?.join(", ")
                ? existing.options
                : parts[4]
                    .split(",")
                    .map((option) => option.trim())
                    .filter(Boolean)
              : existing?.options || []
            : undefined;
        return {
          ...existing,
          key,
          label: parts.length > 1 ? parts[1] : parts[0],
          required: parts[2] !== "optionnel",
          type,
          options,
        };
      });
    if (
      fields.some(
        (field) =>
          !["text", "email", "date", "textarea", "select", "number"].includes(field.type),
      )
    ) {
      notify("Types acceptés : text, email, date, textarea, select ou number.", true);
      return;
    }
    if (
      fields.some(
        (field) =>
          field.type === "select" &&
          (!field.options?.length ||
            field.options.length > 50 ||
            field.options.some((option) => !option || option.length > 150)),
      )
    ) {
      notify(
        "Chaque liste select nécessite 1 à 50 options de 150 caractères maximum.",
        true,
      );
      return;
    }
    if (
      fields.some(
        (f) =>
          !f.label ||
          f.label.length > 150 ||
          !/^[a-zA-Z][a-zA-Z0-9_]{0,49}$/.test(f.key),
      ) ||
      new Set(fields.map((f) => f.key)).size !== fields.length
    ) {
      notify(
        "Chaque champ doit avoir une clé unique sans espace et un libellé.",
        true,
      );
      return;
    }
    if (!editing.requiresQuote && (editing.price < 100 || !Number.isSafeInteger(editing.price))) {
      notify("Le tarif doit être d’au moins 1 €.", true);
      return;
    }
    const documentRows = docLines
      .split("\n")
      .map((line) => line.trim())
      .filter(Boolean)
      .map((line) => {
        const [label, flag, type = "document"] = line.split("|").map((part) => part.trim());
        return { label, required: flag !== "optionnel", type };
      });
    const documents = documentRows.map((doc) => doc.label);
    if (
      fields.length > 30 ||
      documents.length > 20 ||
      documents.some((label) => !label || label.length > 150) ||
      documentRows.some(doc => !["document", "image", "video"].includes(doc.type)) ||
      new Set(documents).size !== documents.length
    ) {
      notify(
        "Limites du formulaire : 30 champs, 20 documents, 150 caractères par libellé.",
        true,
      );
      return;
    }
    const existingKeys = (editing as Service & { documentKeys?: string[] })
      .documentKeys;
    const documentKeys = documents.map((label) => {
      const index = editing.documents.indexOf(label);
      return index >= 0
        ? existingKeys?.[index] || `doc_${index}`
        : `doc_${crypto.randomUUID().replaceAll("-", "").slice(0, 12)}`;
    });
    setBusy(true);
    try {
      let updated: Service = {
        ...editing,
        price: editing.requiresQuote ? 0 : editing.price,
        id: editing.id || `service-${crypto.randomUUID()}`,
        fields,
        documents,
      };
      Object.assign(updated, {
        documentKeys,
        documentRequired: documentRows.map((doc) => doc.required),
        documentTypes: documentRows.map((doc) => doc.type),
      });
      if (isLive) {
        const payload = servicePayload(updated);
        const data = await api(
          editing.id
            ? `/api/admin/services/${editing.id}`
            : "/api/admin/services",
          {
            method: editing.id ? "PATCH" : "POST",
            body: JSON.stringify(payload),
          },
        );
        const raw = data.service || data;
        updated = {
          ...updated,
          id: String(raw.id),
          title: raw.name || updated.title,
          category: String(
            raw.category || updated.category,
          ).toLowerCase() as Category,
          price: Number(raw.priceCents ?? updated.price),
        };
        Object.assign(updated, {
          slug: raw.slug,
          documentKeys: (raw.requiredDocuments || []).map(
            (doc: { key: string }) => doc.key,
          ),
          documentTypes: (raw.requiredDocuments || []).map((doc: { type?: string }) => doc.type || "document"),
          documentRequired: (raw.requiredDocuments || []).map(
            (doc: { required: boolean }) => doc.required,
          ),
        });
      }
      onUpdateServices(
        editing.id
          ? services.map((s) => (s.id === editing.id ? updated : s))
          : [...services, updated],
      );
      setEditing(null);
      notify("Le catalogue a été mis à jour.");
    } catch (error) {
      notify((error as Error).message, true);
    } finally {
      setBusy(false);
    }
  }
  async function toggleService(service: Service) {
    setBusy(true);
    try {
      if (isLive)
        await api(`/api/admin/services/${service.id}`, {
          method: "PATCH",
          body: JSON.stringify({ active: !service.active }),
        });
      onUpdateServices(
        services.map((s) =>
          s.id === service.id ? { ...s, active: !s.active } : s,
        ),
      );
      notify(service.active ? "Service désactivé." : "Service réactivé.");
    } catch (error) {
      notify((error as Error).message, true);
    } finally {
      setBusy(false);
    }
  }
  async function adjustBalance(event: FormEvent) {
    event.preventDefault();
    if (!adjusting) return;
    const amount =
      Math.round(Number(adjustAmount) * 100) *
      (adjustType === "credit" ? 1 : -1);
    if (
      !Number.isSafeInteger(amount) ||
      amount === 0 ||
      Math.abs(amount) > 1_000_000 ||
      adjustReason.trim().length < 3
    ) {
      notify(
        "Indiquez un montant de 0,01 à 10 000 € et un motif d’au moins 3 caractères.",
        true,
      );
      return;
    }
    if (adjusting.balance + amount < 0) {
      notify("Le débit dépasse le solde disponible.", true);
      return;
    }
    setBusy(true);
    try {
      let entryId = crypto.randomUUID();
      let entryDate = new Date().toISOString();
      if (isLive) {
        const result = await api(`/api/admin/users/${adjusting.id}/balance`, {
          method: "POST",
          body: JSON.stringify({
            amountCents: amount,
            reason: adjustReason,
            idempotencyKey: adjustKey,
          }),
        });
        setResellers(
          resellers.map((u) =>
            u.id === adjusting.id
              ? { ...u, balance: Number(result.user.balanceCents) }
              : u,
          ),
        );
        entryId = result.entry?.id || entryId;
        entryDate = result.entry?.createdAt || entryDate;
      } else {
        const demoClients = JSON.parse(localStorage.getItem("komisio-demo-clients") || "[]");
        if (demoClients.some((client: { id: string }) => client.id === adjusting.id)) {
          localStorage.setItem("komisio-demo-clients", JSON.stringify(demoClients.map((client: { id: string; balanceCents: number }) => client.id === adjusting.id ? { ...client, balanceCents: client.balanceCents + amount } : client)));
        } else onBalanceChange(amount, adjustReason);
      }
      setClientRefresh(value => value + 1);
      const next = [
        {
          id: entryId,
          userName: adjusting.name,
          amount,
          reason: adjustReason,
          date: entryDate,
        },
        ...adjustments.filter((entry) => entry.id !== entryId),
      ];
      setAdjustments(next);
      if (!isLive) {
        try {
          localStorage.setItem("forma-admin-adjustments", JSON.stringify(next));
        } catch {
          notify(
            "Ajustement effectué. Le journal ne peut pas être conservé dans ce navigateur.",
            true,
          );
        }
      }
      setAdjusting(null);
      setAdjustAmount("");
      setAdjustReason("");
      notify("Ajustement du portefeuille enregistré.");
    } catch (error) {
      notify((error as Error).message, true);
    } finally {
      setBusy(false);
    }
  }
  const exportOrders = () =>
    exportCsv("forma-commandes.csv", [
      [
        "Référence",
        "Service",
        "Client",
        "Revendeur",
        "Montant EUR",
        "Statut",
        "Date",
      ],
      ...shownOrders.map((o) => [
        o.reference,
        o.serviceTitle,
        o.customerName,
        o.userName || "",
        (o.amount / 100).toFixed(2),
        statusLabels[o.status],
        o.createdAt,
      ]),
    ]);
  const orderTable = (
    <div className="table-scroll">
      <table
        aria-label="Dossiers et commandes"
        role="table"
        className="data-table admin-order-table"
      >
        <thead role="rowgroup">
          <tr role="row">
            <th scope="col" role="columnheader">
              Dossier / prestation
            </th>
            <th scope="col" role="columnheader">
              Client final
            </th>
            <th scope="col" role="columnheader">
              Revendeur
            </th>
            <th scope="col" role="columnheader">
              Montant
            </th>
            <th scope="col" role="columnheader">
              Statut
            </th>
            <th scope="col" role="columnheader">
              <span className="sr-only">Consulter</span>
            </th>
          </tr>
        </thead>
        <tbody role="rowgroup">
          {shownOrders
            .slice(0, tab === "overview" ? 6 : undefined)
            .map((order) => (
              <tr role="row" key={order.id} onClick={() => openOrder(order)}>
                <td role="cell" data-label="Dossier">
                  <button
                    className="admin-order-link"
                    onClick={(e) => {
                      e.stopPropagation();
                      openOrder(order);
                    }}
                  >
                    <strong>#{order.reference}</strong>
                    <span>{order.serviceTitle}</span>
                  </button>
                </td>
                <td role="cell" data-label="Client final">
                  {order.customerName}
                  <small>{dateFR(order.createdAt)}</small>
                </td>
                <td role="cell" data-label="Revendeur">
                  {order.userName ||
                    users.find((u) => u.id === order.userId)?.name ||
                    "Revendeur"}
                </td>
                <td role="cell" data-label="Montant" className="admin-money">
                  {orderPrice(order)}
                </td>
                <td role="cell" data-label="Statut">
                  <Status status={order.status} />
                </td>
                <td role="cell" data-label="Action">
                  <button
                    type="button"
                    className="admin-row-action"
                    aria-label={`Voir le dossier ${order.reference}`}
                    onClick={(event) => {
                      event.stopPropagation();
                      openOrder(order);
                    }}
                  >
                    <span>Voir le dossier</span>
                    <ChevronRight size={17} />
                  </button>
                </td>
              </tr>
            ))}
        </tbody>
      </table>
      {!shownOrders.length && (
        <div className="admin-empty">
          <FolderOpen size={28} />
          <strong>Aucun dossier trouvé</strong>
          <p>Essayez un autre nom, numéro ou statut.</p>
        </div>
      )}
    </div>
  );
  return (
    <div className="admin-panel">
      <div className="page-heading admin-title">
        <div>
          <div className="admin-eyebrow">
            <ShieldCheck size={14} /> KOMISIO · ADMINISTRATION
          </div>
          <h1>Pilotez votre activité.</h1>
          <p>Vos commandes, vos partenaires et vos finances au même endroit.</p>
        </div>
        <button className="button button-secondary" onClick={exportOrders}>
          <Download size={16} />
          Exporter les commandes
        </button>
      </div>
      <nav className="admin-tabs" aria-label="Sections administration">
        {tabs.map((item) => (
          <button
            key={item.id}
            className={tab === item.id ? "active" : ""}
            aria-current={tab === item.id ? "page" : undefined}
            onClick={() => changeTab(item.id)}
          >
            {item.label}
            {item.id === "orders" && <span>{orders.length}</span>}
          </button>
        ))}
      </nav>
      {loading && (
        <div className="admin-loading">
          <LoaderCircle size={17} className="spin" />
          Chargement des partenaires…
        </div>
      )}
      {(tab === "overview" || tab === "finances") && (
        <div className="stats-grid admin-stats">
          <div className="stat-card">
            <div className="admin-stat-label">
              Chiffre d’affaires
              <TrendingUp size={17} />
            </div>
            <strong>{euro(revenue)}</strong>
            <small>Commandes payées, hors annulations</small>
          </div>
          <div className="stat-card">
            <div className="admin-stat-label">
              Dossiers en cours
              <FolderOpen size={17} />
            </div>
            <strong>{processing.toString().padStart(2, "0")}</strong>
            <small>
              {needsAction} dossier{needsAction > 1 ? "s" : ""} avec une action
              requise
            </small>
          </div>
          <div className="stat-card">
            <div className="admin-stat-label">
              Revendeurs
              <Users size={17} />
            </div>
            <strong>{users.length.toString().padStart(2, "0")}</strong>
            <small>Partenaires inscrits sur la plateforme</small>
          </div>
          <div className="stat-card">
            <div className="admin-stat-label">
              Encours portefeuilles
              <Wallet size={17} />
            </div>
            <strong>
              {euro(users.reduce((sum, u) => sum + u.balance, 0))}
            </strong>
            <small>Solde disponible des partenaires</small>
          </div>
        </div>
      )}
      {(tab === "overview" || tab === "orders") && (
        <section className="panel admin-section">
          <div className="section-heading">
            <div>
              <h2>
                {tab === "overview"
                  ? "Derniers dossiers"
                  : "Toutes les commandes"}
              </h2>
              <p>
                {tab === "overview"
                  ? "Gardez un œil sur les demandes de vos partenaires."
                  : `${shownOrders.length} dossier${shownOrders.length > 1 ? "s" : ""} dans votre sélection`}
              </p>
            </div>
            {tab === "overview" ? (
              <button
                className="admin-text-button"
                onClick={() => changeTab("orders")}
              >
                Tout voir
                <ArrowRight size={15} />
              </button>
            ) : (
              <span className="admin-count">{orders.length} au total</span>
            )}
          </div>
          <div className="admin-filters">
            <label className="admin-search">
              <Search size={17} />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Rechercher un dossier, un client…"
                aria-label="Rechercher les commandes"
              />
            </label>
            <select
              className="input admin-select"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              aria-label="Filtrer par statut"
            >
              <option value="all">Tous les statuts</option>
              {Object.entries(statusLabels).map(([value, label]) => (
                <option key={value} value={value}>
                  {label}
                </option>
              ))}
            </select>
          </div>
          {orderTable}
        </section>
      )}
      {tab === "overview" && (
        <div className="admin-bottom-grid">
          <section className="panel admin-quick">
            <div className="admin-quick-icon">
              <Layers size={23} />
            </div>
            <div>
              <h3>Un catalogue à votre image</h3>
              <p>
                {services.filter((s) => s.active).length} prestations actives.
                Adaptez vos tarifs et les documents requis.
              </p>
              <button
                className="admin-text-button"
                onClick={() => changeTab("catalog")}
              >
                Gérer les services
                <ArrowRight size={15} />
              </button>
            </div>
          </section>
          <section className="panel admin-quick">
            <div className="admin-quick-icon olive">
              <Users size={23} />
            </div>
            <div>
              <h3>Votre réseau de partenaires</h3>
              <p>
                Créez les accès clients et personnalisez chaque prix avant de partager leurs identifiants.
              </p>
              <button
                className="admin-text-button"
                onClick={() => changeTab("resellers")}
              >
                Créer et gérer les accès
                <ArrowRight size={15} />
              </button>
            </div>
          </section>
        </div>
      )}
      {tab === "catalog" && (
        <section className="panel admin-section">
          <div className="section-heading">
            <div>
              <h2>Votre catalogue de services</h2>
              <p>Tarifs revendeurs, formulaires et documents requis.</p>
            </div>
            <button
              className="button button-primary"
              onClick={() => openService(newService())}
            >
              <Plus size={17} />
              Ajouter un service
            </button>
          </div>
          <div className="admin-filters">
            <label className="admin-search">
              <Search size={17} />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Rechercher une prestation…"
                aria-label="Rechercher une prestation"
              />
            </label>
            <select className="input" aria-label="Filtrer le catalogue par catégorie" value={filter} onChange={event => setFilter(event.target.value)}><option value="all">Toutes les rubriques</option>{catalogueSections.map(section => <option key={section.id} value={section.id}>{section.label}</option>)}</select>
            <span className="admin-count">
              {services.filter((s) => s.active).length} services actifs
            </span>
          </div>
          <div className="table-scroll">
            <table
              aria-label="Catalogue des prestations"
              role="table"
              className="data-table"
            >
              <thead role="rowgroup">
                <tr role="row">
                  <th scope="col" role="columnheader">
                    Prestation
                  </th>
                  <th scope="col" role="columnheader">
                    Catégorie
                  </th>
                  <th scope="col" role="columnheader">
                    Tarif revendeur
                  </th>
                  <th scope="col" role="columnheader">
                    Disponibilité
                  </th>
                  <th scope="col" role="columnheader">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody role="rowgroup">
                {shownServices.map((service) => (
                  <tr role="row" key={service.id}>
                    <td role="cell" data-label="Prestation">
                      <strong>{service.title}</strong>
                      <small>
                        {service.documents.length} documents ·{" "}
                        {service.fields.length} champs
                      </small>
                    </td>
                    <td role="cell" data-label="Catégorie">
                      {serviceSection(service).label}
                      <small>{subcategoryLabel(service)}</small>
                    </td>
                    <td
                      role="cell"
                      data-label="Tarif revendeur"
                      className="admin-money"
                    >
                      {servicePrice(service)}
                    </td>
                    <td role="cell" data-label="Disponibilité">
                      <button
                        className={`admin-toggle ${service.active ? "on" : ""}`}
                        disabled={busy}
                        aria-label={`${service.active ? "Désactiver" : "Activer"} ${service.title}`}
                        aria-pressed={service.active}
                        onClick={() => toggleService(service)}
                      >
                        <span />
                        {service.active ? "Actif" : "Inactif"}
                      </button>
                    </td>
                    <td role="cell" data-label="Actions">
                      <button
                        className="button button-secondary admin-small-button"
                        onClick={() => openService(service)}
                      >
                        <Settings2 size={14} />
                        Modifier
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {!shownServices.length && (
              <div className="admin-empty">
                <Layers size={28} />
                <strong>Aucune prestation trouvée</strong>
              </div>
            )}
          </div>
        </section>
      )}
      {tab === "resellers" && <ClientAccounts refreshKey={clientRefresh} services={services} isLive={isLive} notify={notify} onAdjust={(id, name, clientBalance) => { setAdjusting({ id, name, balance: clientBalance, username: "", telegramId: "", revenue: 0, orders: 0 }); setAdjustKey(crypto.randomUUID()); setAdjustType("credit"); setAdjustAmount(""); setAdjustReason(""); }} onChanged={() => { api("/api/admin/users").then(data => setResellers(data.filter((u: any) => u.role !== "ADMIN").map((u: any) => ({ id: u.id, name: u.firstName, username: u.username || "", telegramId: u.telegramId || "", balance: u.balanceCents, revenue: u.orders.filter((o: any) => o.paidAt && o.status !== "CANCELLED").reduce((sum: number, o: any) => sum + o.priceCents, 0), orders: u._count.orders })))).catch(error => notify(error.message, true)); }} />}
      {tab === "overview" && <OperationsPanel isLive={isLive} notify={notify} />}
      {tab === "whatsapp" && <WhatsAppPanel services={services} isLive={isLive} notify={notify} />}
      {tab === "finances" && (
        <>
          <WithdrawalsPanel admin isLive={isLive} balance={balance} onBalanceChange={onBalanceChange} notify={notify} />
          <section className="panel admin-section">
            <div className="section-heading">
              <div>
                <h2>Journal financier</h2>
                <p>
                  Les règlements des commandes et les mouvements de
                  portefeuille.
                </p>
              </div>
              <button
                className="button button-secondary"
                onClick={() =>
                  exportCsv("forma-finances.csv", [
                    ["Date", "Libellé", "Montant EUR", "Statut"],
                    ...orders
                      .filter(
                        (o) =>
                          isPaidStatus(o.status),
                      )
                      .map((o) => [
                        o.createdAt,
                        `Commande #${o.reference} · ${o.serviceTitle}`,
                        (o.amount / 100).toFixed(2),
                        "Confirmé",
                      ]),
                    ...adjustments.map((a) => [
                      a.date,
                      a.reason,
                      (a.amount / 100).toFixed(2),
                      "Ajustement",
                    ]),
                  ])
                }
              >
                <Download size={16} />
                Exporter le journal
              </button>
            </div>
            <div className="table-scroll">
              <table
                aria-label="Journal financier"
                role="table"
                className="data-table"
              >
                <thead role="rowgroup">
                  <tr role="row">
                    <th scope="col" role="columnheader">
                      Opération
                    </th>
                    <th scope="col" role="columnheader">
                      Partenaire
                    </th>
                    <th scope="col" role="columnheader">
                      Date
                    </th>
                    <th scope="col" role="columnheader">
                      Montant
                    </th>
                    <th scope="col" role="columnheader">
                      Statut
                    </th>
                  </tr>
                </thead>
                <tbody role="rowgroup">
                  {adjustments.map((a) => (
                    <tr role="row" key={a.id}>
                      <td role="cell" data-label="Opération">
                        <div className="admin-movement">
                          <span
                            className={a.amount > 0 ? "positive" : "negative"}
                          >
                            {a.amount > 0 ? (
                              <ArrowDownLeft size={17} />
                            ) : (
                              <ArrowUpRight size={17} />
                            )}
                          </span>
                          <div>
                            <strong>
                              {a.amount > 0 ? "Crédit manuel" : "Débit manuel"}
                            </strong>
                            <small>{a.reason}</small>
                          </div>
                        </div>
                      </td>
                      <td role="cell" data-label="Partenaire">
                        {a.userName}
                      </td>
                      <td role="cell" data-label="Date">
                        {dateFR(a.date)}
                      </td>
                      <td
                        role="cell"
                        data-label="Montant"
                        className="admin-money"
                      >
                        {a.amount > 0 ? "+" : ""}
                        {euro(a.amount)}
                      </td>
                      <td role="cell" data-label="Statut">
                        <span className="admin-paid">
                          <CheckCircle2 size={13} />
                          Enregistré
                        </span>
                      </td>
                    </tr>
                  ))}
                  {orders
                    .filter(
                      (o) =>
                        isPaidStatus(o.status),
                    )
                    .map((order) => (
                      <tr role="row" key={order.id}>
                        <td role="cell" data-label="Opération">
                          <div className="admin-movement">
                            <span className="positive">
                              <ArrowDownLeft size={17} />
                            </span>
                            <div>
                              <strong>Règlement · #{order.reference}</strong>
                              <small>{order.serviceTitle}</small>
                            </div>
                          </div>
                        </td>
                        <td role="cell" data-label="Partenaire">
                          {order.userName || "Revendeur"}
                        </td>
                        <td role="cell" data-label="Date">
                          {dateFR(order.createdAt)}
                        </td>
                        <td
                          role="cell"
                          data-label="Montant"
                          className="admin-money"
                        >
                          +{orderPrice(order)}
                        </td>
                        <td role="cell" data-label="Statut">
                          <span className="admin-paid">
                            <CheckCircle2 size={13} />
                            Confirmé
                          </span>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
              {!orders.length && !adjustments.length && (
                <div className="admin-empty">
                  <Wallet size={28} />
                  <strong>Aucun mouvement à afficher</strong>
                </div>
              )}
            </div>
          </section>
          {isLive && transactions.length > 0 && (
            <section className="panel admin-section">
              <div className="section-heading">
                <div>
                  <h2>Transactions crypto</h2>
                  <p>Historique des paiements reçus par la passerelle.</p>
                </div>
              </div>
              <div className="table-scroll">
                <table
                  aria-label="Transactions crypto"
                  role="table"
                  className="data-table"
                >
                  <thead role="rowgroup">
                    <tr role="row">
                      <th scope="col" role="columnheader">
                        Référence
                      </th>
                      <th scope="col" role="columnheader">
                        Devise
                      </th>
                      <th scope="col" role="columnheader">
                        Montant
                      </th>
                      <th scope="col" role="columnheader">
                        Statut
                      </th>
                      <th scope="col" role="columnheader">
                        Date
                      </th>
                    </tr>
                  </thead>
                  <tbody role="rowgroup">
                    {transactions.map((tx, index) => (
                      <tr role="row" key={String(tx.id || index)}>
                        <td role="cell" data-label="Référence">
                          {String(tx.providerPaymentId || tx.id)}
                        </td>
                        <td role="cell" data-label="Devise">
                          {String(
                            tx.payCurrency || tx.currency || "Crypto",
                          ).toUpperCase()}
                        </td>
                        <td role="cell" data-label="Montant">
                          {euro(Number(tx.amountCents || 0))}
                        </td>
                        <td role="cell" data-label="Statut">
                          {String(tx.status || "PENDING")}
                        </td>
                        <td role="cell" data-label="Date">
                          {tx.createdAt ? dateFR(String(tx.createdAt)) : "—"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          )}
        </>
      )}
      {selected && (
        <Modal
          wide
          title={`Dossier #${selected.reference}`}
          subtitle={selected.serviceTitle}
          onClose={() => !busy && setSelected(null)}
        >
          <OrderQuote order={selected} live={isLive} admin notify={notify} onUpdate={updated => { onUpdateOrder(updated); setSelected(updated); setNextStatus(updated.status); setNote(updated.note || ""); }} />
          <OriginalDocumentPanel key={selected.id} order={selected} live={isLive} admin disabled={busy} onBusyChange={setBusy} notify={notify} onUpdate={updated => { onUpdateOrder(updated); setSelected(updated); setNextStatus(updated.status); setNote(updated.note || ""); }} />
          <form onSubmit={saveOrder} className="admin-order-form">
            <div className="admin-detail-top">
              <div>
                <span>CLIENT FINAL</span>
                <strong>{selected.customerName}</strong>
                <p>
                  {selected.customerEmail || "Adresse e-mail non renseignée"}
                </p>
              </div>
              <div>
                <span>REVENDEUR</span>
                <strong>{selected.userName || "Partenaire"}</strong>
                <p>Créé le {dateFR(selected.createdAt)}</p>
              </div>
              <div>
                <span>MONTANT DU DOSSIER</span>
                <strong>{orderPrice(selected)}</strong>
                <Status status={selected.status} />
              </div>
            </div>
            {Object.keys(selected.fields).length > 0 && (
              <div className="admin-detail-fields">
                {Object.entries(selected.fields).map(([key, value]) => (
                  <div key={key}>
                    <span>
                      {services
                        .find((s) => s.id === selected.serviceId)
                        ?.fields.find((f) => f.key === key)?.label || key}
                    </span>
                    <strong>{value || "—"}</strong>
                  </div>
                ))}
              </div>
            )}
            <h3>Pièces jointes du revendeur</h3>
            <div className="admin-document-list">
              {selected.documents.length ? (
                selected.documents.map((doc) => (
                  <a
                    key={doc.id}
                    className="admin-document"
                    href={doc.data || `/api/documents/${doc.id}`}
                    onClick={event => { if (!isLive && !doc.data) { event.preventDefault(); notify("En démonstration, ce fichier n’a pas été transmis."); } }}
                    download={doc.name}
                  >
                    <FileText size={18} />
                    <span>{doc.name}</span>
                    <Download size={16} />
                  </a>
                ))
              ) : (
                <p className="admin-muted">
                  Aucun document joint à ce dossier
                  {isLive ? "" : " de démonstration"}.
                </p>
              )}
            </div>
            <div className="admin-form-row">
              <label className="form-field">
                Statut du dossier
                <select
                  className="input"
                  value={nextStatus}
                  disabled={busy || selectedClosed}
                  onChange={(e) => setNextStatus(e.target.value as OrderStatus)}
                >
                  {allowedStatuses(selected).map((value) => (
                    <option key={value} value={value}>
                      {statusLabels[value]}
                    </option>
                  ))}
                </select>
              </label>
              <div className="form-field">
                <span>Livrable final</span>
                <label className="admin-file-picker">
                  <Upload size={17} />
                  <span>
                    {deliverable?.name || "Ajouter le document final"}
                  </span>
                  <input
                    type="file"
                    accept=".pdf,.jpg,.jpeg,.png"
                    disabled={busy || selectedClosed}
                    aria-label="Ajouter le livrable final"
                    onChange={(e) =>
                      e.target.files?.[0] &&
                      attachDeliverable(e.target.files[0])
                    }
                  />
                </label>
                <small>
                  PDF, JPG ou PNG · {isLive ? "8" : "2"} Mo maximum
                  {isLive ? "" : " en démo"}
                </small>
              </div>
            </div>
            <label className="form-field">
              Message au revendeur
              <textarea
                className="input"
                rows={3}
                value={note}
                disabled={busy || selectedClosed}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Précisez les documents manquants ou les prochaines étapes…"
                maxLength={4000}
              />
            </label>
            <p className="admin-info">
              <ShieldCheck size={15} />
              {isLive
                ? "Le revendeur sera notifié sur Telegram après l’enregistrement."
                : "En démonstration, la modification est visible dans le suivi revendeur."}
            </p>
            <div className="admin-modal-actions">
              <button
                type="button"
                className="button button-secondary"
                disabled={busy}
                onClick={() => setSelected(null)}
              >
                Annuler
              </button>
              <button
                className="button button-primary"
                disabled={
                  busy || ["COMPLETED", "CANCELLED", "QUOTE_REJECTED"].includes(selected.status)
                }
              >
                {busy && <LoaderCircle size={16} className="spin" />}
                {["COMPLETED", "CANCELLED", "QUOTE_REJECTED"].includes(selected.status)
                  ? "Dossier clôturé"
                  : "Enregistrer les modifications"}
              </button>
            </div>
          </form>
        </Modal>
      )}
      {editing && (
        <Modal
          wide
          title={editing.id ? "Modifier la prestation" : "Nouvelle prestation"}
          subtitle="Définissez le tarif et les informations nécessaires au traitement."
          onClose={() => !busy && setEditing(null)}
        >
          <form className="admin-service-form" onSubmit={saveService}>
            <label className="form-field">
              Nom du service
              <input
                className="input"
                required
                minLength={3}
                maxLength={120}
                value={editing.title}
                onChange={(e) =>
                  setEditing({ ...editing, title: e.target.value })
                }
                placeholder="Ex. Création de société"
              />
            </label>
            <label className="form-field">
              Description
              <textarea
                className="input"
                required
                minLength={10}
                maxLength={1000}
                rows={2}
                value={editing.description}
                onChange={(e) =>
                  setEditing({ ...editing, description: e.target.value })
                }
              />
            </label>
            <div className="admin-form-row">
              <label className="form-field">
                Catégorie
                <select
                  className="input"
                  value={editing.category}
                  onChange={(e) =>
                    setEditing({
                      ...editing,
                      category: e.target.value as Category,
                      subcategory: null,
                    })
                  }
                >
                  {categories
                    .filter((c) => c.id !== "all")
                    .map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.label}
                      </option>
                    ))}
                </select>
              </label>
              <label className="form-field">Sous-catégorie<select className="input" value={editing.subcategory || ""} onChange={event => setEditing({ ...editing, subcategory: event.target.value || null })}><option value="">Autres prestations</option>{subcategories.filter(group => group.category === editing.category).map(group => <option key={group.id} value={group.id}>{group.label}</option>)}</select></label>
              <label className="consent"><input type="checkbox" checked={!!editing.requiresQuote} onChange={event => setEditing({ ...editing, requiresQuote: event.target.checked, price: event.target.checked ? 0 : 3900 })} /><span>Tarif sur devis après dépôt du dossier</span></label>
              <label className="form-field">
                Tarif revendeur (€)
                <input
                  className="input"
                  type="number"
                  min="1"
                  max="100000"
                  step="0.01"
                  required
                  disabled={!!editing.requiresQuote}
                  value={editing.price / 100}
                  onChange={(e) =>
                    setEditing({
                      ...editing,
                      price: Math.round(Number(e.target.value) * 100),
                    })
                  }
                />
              </label>
            </div>
            <label className="form-field">
              Délai indicatif
              <input
                className="input"
                required
                value={editing.delay}
                maxLength={80}
                onChange={(e) =>
                  setEditing({ ...editing, delay: e.target.value })
                }
              />
            </label>
            <label className="form-field">
              Documents à fournir
              <textarea
                className="input"
                rows={3}
                value={docLines}
                onChange={(e) => setDocLines(e.target.value)}
                placeholder={"Pièce d’identité\nJustificatif de domicile"}
              />
              <small>
                Une ligne : libellé | obligatoire ou optionnel | document, image ou video.
                Une vidéo accepte MP4 ou MOV (25 Mo).
              </small>
            </label>
            <label className="form-field">
              Champs du formulaire
              <textarea
                className="input admin-monospace"
                rows={3}
                value={fieldLines}
                onChange={(e) => setFieldLines(e.target.value)}
                placeholder={
                  "company | Nom de la société | obligatoire | text\nlegalForm | Forme juridique | obligatoire | select | SAS, SASU, SARL"
                }
              />
              <small>
                Une ligne : clé | Libellé | obligatoire/optionnel | type |
                options séparées par virgules. Types : text, email, date,
                textarea, select, number. Les options concernent les listes select.
              </small>
            </label>
            <label className="admin-check">
              <input
                type="checkbox"
                checked={editing.active}
                onChange={(e) =>
                  setEditing({ ...editing, active: e.target.checked })
                }
              />
              Visible dans le catalogue revendeur
            </label>
            <div className="admin-modal-actions">
              <button
                type="button"
                className="button button-secondary"
                disabled={busy}
                onClick={() => setEditing(null)}
              >
                Annuler
              </button>
              <button className="button button-primary" disabled={busy}>
                {busy && <LoaderCircle size={16} className="spin" />}Enregistrer
                la prestation
              </button>
            </div>
          </form>
        </Modal>
      )}
      {adjusting && (
        <Modal
          title="Ajuster le portefeuille"
          subtitle={adjusting.name}
          onClose={() => !busy && setAdjusting(null)}
        >
          <form onSubmit={adjustBalance} className="admin-service-form">
            <div className="admin-balance-summary">
              <span>Solde disponible</span>
              <strong>{euro(adjusting.balance)}</strong>
            </div>
            <div className="admin-adjust-type">
              <button
                type="button"
                className={adjustType === "credit" ? "active" : ""}
                onClick={() => setAdjustType("credit")}
              >
                <Plus size={16} />
                Créditer
              </button>
              <button
                type="button"
                className={adjustType === "debit" ? "active" : ""}
                onClick={() => setAdjustType("debit")}
              >
                <ArrowUpRight size={16} />
                Débiter
              </button>
            </div>
            <label className="form-field">
              Montant (€)
              <input
                className="input"
                type="number"
                min="0.01"
                max="10000"
                step="0.01"
                required
                value={adjustAmount}
                onChange={(e) => setAdjustAmount(e.target.value)}
                placeholder="0,00"
              />
            </label>
            <label className="form-field">
              Motif de l’ajustement
              <textarea
                className="input"
                rows={2}
                required
                maxLength={500}
                value={adjustReason}
                onChange={(e) => setAdjustReason(e.target.value)}
                placeholder="Ex. Geste commercial, remboursement…"
              />
            </label>
            <p className="admin-info">
              <ShieldCheck size={15} />
              Ce mouvement sera conservé dans le journal financier.
            </p>
            <div className="admin-modal-actions">
              <button
                type="button"
                className="button button-secondary"
                disabled={busy}
                onClick={() => setAdjusting(null)}
              >
                Annuler
              </button>
              <button className="button button-primary" disabled={busy}>
                {busy && <LoaderCircle size={16} className="spin" />}Confirmer
                l’ajustement
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
