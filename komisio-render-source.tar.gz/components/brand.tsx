/** Komisio identity shared by navigation, loading screens and the brand illustration. */
export function BrandMark({ className = "" }: { className?: string }) {
  return <img className={`komisio-mark ${className}`} src="/brand/komisio-mark.png" width={80} height={80} alt="" aria-hidden="true" />;
}
export function Brand({ className = "" }: { className?: string }) {
  return <span className={`komisio-brand ${className}`} role="img" aria-label="Komisio"><BrandMark /><span className="komisio-wordmark" aria-hidden="true">omis<span className="komisio-green-i">ı</span>o</span></span>;
}
