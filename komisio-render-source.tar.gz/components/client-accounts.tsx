"use client";
import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, ArrowRight, Check, Copy, Download, KeyRound, LoaderCircle, Plus, Search, Settings2, ShieldCheck, Users, Wallet } from "lucide-react";
import { euro, type Service } from "@/lib/catalog";
import { catalogueSections, serviceSection } from "@/lib/catalogue-view";
import { newClientRules, resolvePrice, pricingHint, carteGriseIds, type PriceRule } from "@/lib/pricing";
import { Modal } from "./ui";
import "./client-accounts.css";

type Client = { id: string; firstName: string; login: string | null; telegramId: string | null; username?: string | null; accessReady: boolean; disabled: boolean; pricingVersion: number; credentialVersion: number; defaultDiscountBps: number; servicePrices: PriceRule[]; balanceCents: number; _count?: { orders: number }; role?: string };
type Credentials = { login: string; password: string };
type Props = { services: Service[]; isLive: boolean; notify: (text: string, error?: boolean) => void; onAdjust: (id: string, name: string, balance: number) => void; onChanged?: () => void; refreshKey?: number };
const call = async (path: string, method = "GET", value?: unknown) => {
  const response = await fetch(path, { method, headers: { "Content-Type": "application/json" }, ...(value ? { body: JSON.stringify(value) } : {}) });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "La demande a échoué.");
  return data;
};
const cents = (value: string) => Math.round(Number(value.replace(",", ".")) * 100);
export function ClientAccounts({ services, isLive, notify, onAdjust, onChanged, refreshKey = 0 }: Props) {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [editor, setEditor] = useState<Client | "new" | null>(null);
  const [step, setStep] = useState(0);
  const [name, setName] = useState("");
  const [login, setLogin] = useState("");
  const [telegram, setTelegram] = useState("");
  const [discount, setDiscount] = useState(0);
  const [rules, setRules] = useState<PriceRule[]>([]);
  const [serviceSearch, setServiceSearch] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [credentials, setCredentials] = useState<Credentials | null>(null);
  const [actionClient, setActionClient] = useState<Client | null>(null);
  async function reload() {
    if (isLive) setClients((await call("/api/admin/users")).filter((u: Client) => u.role !== "ADMIN"));
  }
  useEffect(() => {
    let active = true;
    if (isLive) call("/api/admin/users").then(data => { if (active) setClients(data.filter((u: Client) => u.role !== "ADMIN")); }).catch(e => notify(e.message, true)).finally(() => { if (active) setLoading(false); });
    else { try { setClients(JSON.parse(localStorage.getItem("komisio-demo-clients") || "[]")); } catch {} setLoading(false); }
    return () => { active = false; };
  }, [isLive, refreshKey]);
  const saveLocal = (next: Client[]) => { setClients(next); if (!isLive) localStorage.setItem("komisio-demo-clients", JSON.stringify(next)); };
  const visible = useMemo(() => clients.filter(client => `${client.firstName} ${client.login || ""} ${client.telegramId || ""}`.toLowerCase().includes(query.toLowerCase())), [clients, query]);
  function open(client: Client | "new") {
    setEditor(client); setStep(0); setError(""); setServiceSearch("");
    setName(client === "new" ? "" : client.firstName); setLogin(client === "new" ? "" : client.login || ""); setTelegram(client === "new" ? "" : client.telegramId || "");
    setDiscount(client === "new" ? 0 : client.defaultDiscountBps); setRules(client === "new" ? newClientRules(services) : client.servicePrices || []);
  }
  const changeRule = (service: Service, mode: string) => {
    setRules(current => [...current.filter(rule => rule.serviceId !== service.id), ...(mode === "INHERIT" ? [] : [{ serviceId: service.id, mode: mode as PriceRule["mode"], priceCents: mode === "FIXED" ? Math.max(service.price || 100, carteGriseIds.includes(service.id) ? 6000 : 100) : null, discountBps: mode === "DISCOUNT" ? 5000 : 0, minimumCents: carteGriseIds.includes(service.id) ? 6000 : 0 }])]);
  };
  const patchRule = (id: string, patch: Partial<PriceRule>) => setRules(current => current.map(rule => rule.serviceId === id ? { ...rule, ...patch } : rule));
  function validateIdentity() {
    if (name.trim().length < 2) throw new Error("Indiquez le nom du client ou de sa société.");
    if (!/^[a-z0-9][a-z0-9._-]{2,63}$/.test(login)) throw new Error("Identifiant : 3 à 64 caractères, lettres minuscules, chiffres, point, tiret ou underscore.");
    if (editor === "new" && telegram && !/^[1-9]\d{4,15}$/.test(telegram)) throw new Error("L’ID Telegram est un numéro, pas un @pseudo. Vous pouvez le laisser vide.");
  }
  function validatePricing() {
    if (!Number.isInteger(discount) || discount < 0 || discount > 10000) throw new Error("La remise générale doit être comprise entre 0 et 100 %.");
    for (const service of services) {
      const rule = rules.find(rule => rule.serviceId === service.id);
      const result = resolvePrice({ id: service.id, priceCents: service.price, requiresQuote: !!service.requiresQuote }, { defaultDiscountBps: discount, pricingVersion: 0 }, rule);
      if (!Number.isSafeInteger(result.priceCents) || (rule?.mode === "FIXED" && (!rule.priceCents || rule.priceCents > 10_000_000)) || (rule && (!Number.isSafeInteger(rule.minimumCents) || rule.minimumCents < 0 || rule.minimumCents > 10_000_000)) || (carteGriseIds.includes(service.id) && rule && (rule.minimumCents < 6000 || (rule.priceCents !== null && rule.priceCents < 6000)))) throw new Error(`Vérifiez le tarif de « ${service.title} ». Minimum carte grise : 60 €.`);
    }
  }
  function next() { try { if (step === 0) validateIdentity(); else validatePricing(); setError(""); setStep(value => Math.min(2, value + 1)); } catch (e) { setError((e as Error).message); } }
  async function save(activate: boolean) {
    if (busy || !editor) return;
    try {
      validateIdentity(); validatePricing(); setBusy(true); setError("");
      const pricing = { defaultDiscountBps: discount, prices: rules };
      if (isLive) {
        const result = editor === "new" ? await call("/api/admin/users", "POST", { name, login, telegramId: telegram || null, pricing, activate }) : await call(`/api/admin/users/${editor.id}`, "PATCH", { name, login, expectedVersion: editor.pricingVersion, pricing });
        if (result.credentials) setCredentials(result.credentials);
        await reload(); onChanged?.();
      } else {
        if (clients.some(client => client.login === login && (editor === "new" || client.id !== editor.id))) throw new Error("Cet identifiant existe déjà.");
        const client: Client = { ...(editor === "new" ? { id: crypto.randomUUID(), balanceCents: 0, credentialVersion: 0, accessReady: activate, disabled: false } : editor), firstName: name, login, telegramId: telegram || null, defaultDiscountBps: discount, pricingVersion: (editor === "new" ? 0 : editor.pricingVersion) + 1, servicePrices: rules };
        saveLocal([...clients.filter(item => item.id !== client.id), client]);
        if (activate && editor === "new") setCredentials({ login, password: "DEMO-" + crypto.randomUUID().slice(0, 14) });
      }
      setEditor(null); notify(isLive ? activate ? "Client créé, tarifs enregistrés et accès généré." : "Compte et grille enregistrés." : "Compte enregistré en démonstration. Aucun accès réel créé.");
    } catch (e) { setError((e as Error).message); } finally { setBusy(false); }
  }
  async function access(client: Client, action: "activate" | "reset" | "suspend" | "resume") {
    if (busy) return;
    setBusy(true);
    try {
      if (isLive) { const result = await call(`/api/admin/users/${client.id}/access`, "POST", { action, expectedVersion: client.credentialVersion }); if (result.credentials) setCredentials(result.credentials); await reload(); onChanged?.(); }
      else { saveLocal(clients.map(item => item.id === client.id ? { ...item, accessReady: true, disabled: action === "suspend", credentialVersion: item.credentialVersion + 1 } : item)); if (action === "activate" || action === "reset") setCredentials({ login: client.login!, password: "DEMO-" + crypto.randomUUID().slice(0, 14) }); }
      setActionClient(null); notify(isLive ? "Accès client mis à jour." : "Accès simulé dans ce navigateur.");
    } catch (e) { notify((e as Error).message, true); } finally { setBusy(false); }
  }
  function exportClients() {
    const cell = (value: unknown) => '"' + String(value ?? "").replace(/^[=+\-@]/, "'$&").replaceAll('"', '""') + '"';
    const rows = [["Client", "Identifiant", "Telegram", "Accès", "Solde EUR", "Remise générale %", "Tarifs personnalisés"], ...clients.map(client => [client.firstName, client.login, client.telegramId, client.disabled ? "Suspendu" : client.accessReady ? "Actif" : "Brouillon", (client.balanceCents / 100).toFixed(2), client.defaultDiscountBps / 100, client.servicePrices?.length || 0])];
    const url = URL.createObjectURL(new Blob(["\uFEFF" + rows.map(row => row.map(cell).join(";")).join("\r\n")], { type: "text/csv;charset=utf-8;" }));
    const anchor = document.createElement("a"); anchor.href = url; anchor.download = "komisio-clients.csv"; anchor.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  async function copyAccess() {
    if (!credentials) return;
    try { await navigator.clipboard.writeText(`Votre accès Komisio${isLive ? "" : " — DÉMONSTRATION"}\nLien : ${window.location.origin}\nIdentifiant : ${credentials.login}\nMot de passe temporaire : ${credentials.password}\nChoisissez votre mot de passe personnel à la première connexion.`); notify("Accès copié. Vous pouvez le transmettre au client."); } catch { notify("La copie n’est pas disponible. Sélectionnez les identifiants ci-dessous.", true); }
  }
  return <section className="client-accounts">
    <div className="client-hero panel"><div><span className="client-kicker"><ShieldCheck size={15} /> VOTRE RÉSEAU, VOS CONDITIONS</span><h2>Un accès. Une grille. Votre client.</h2><p>Préparez chaque compte et ses tarifs avant de remettre les identifiants.</p><div className="client-steps-inline"><span>1. Créer le compte</span><ArrowRight size={14} /><span>2. Régler les prix</span><ArrowRight size={14} /><span>3. Remettre l’accès</span></div></div><button className="button button-primary" onClick={() => open("new")}><Plus size={18} /> Nouveau client</button></div>
    {!isLive && <p className="client-demo-note">Mode démonstration · comptes et grilles conservés uniquement dans ce navigateur. Les identifiants générés ici ne permettent aucune connexion réelle.</p>}
    <div className="client-list-heading"><strong>{clients.length} client{clients.length !== 1 ? "s" : ""}</strong><button className="button button-secondary" onClick={exportClients}><Download size={15} /> Exporter</button><label className="client-search"><Search size={17} /><input aria-label="Rechercher un client" placeholder="Nom, société, identifiant…" value={query} onChange={e => setQuery(e.target.value)} /></label></div>
    {loading ? <div className="admin-empty"><LoaderCircle className="spin" /> Chargement des clients…</div> : <div className="client-card-grid">{visible.map(client => <article className="client-account-card panel" key={client.id}><header><div className="client-avatar">{client.firstName.slice(0, 2).toUpperCase()}</div><span className={`client-access-status ${client.disabled ? "suspended" : client.accessReady ? "active" : "draft"}`}>{client.disabled ? "Suspendu" : client.accessReady ? "Actif" : "Brouillon"}</span></header><h3>{client.firstName}</h3><p className="client-identifier">{client.login || "Identifiant à configurer"}</p><dl><div><dt>Solde</dt><dd>{euro(client.balanceCents)}</dd></div><div><dt>Tarifs personnalisés</dt><dd>{client.servicePrices?.length || 0}</dd></div><div><dt>Remise générale</dt><dd>{client.defaultDiscountBps / 100} %</dd></div></dl><small>{client.telegramId ? `Telegram relié · ${client.username ? "@" + client.username : client.telegramId}` : "Telegram pourra être relié à la première connexion"}</small><footer><button className="button button-secondary" onClick={() => open(client)}><Settings2 size={15} /> Compte & tarifs</button><button className="button button-secondary" onClick={() => setActionClient(client)}><KeyRound size={15} /> Accès</button><button className="client-wallet-button" aria-label={`Ajuster le solde de ${client.firstName}`} onClick={() => onAdjust(client.id, client.firstName, client.balanceCents)}><Wallet size={17} /></button></footer></article>)}</div>}
    {!loading && !visible.length && <div className="admin-empty panel"><Users size={30} /><strong>{query ? "Aucun client trouvé" : "Votre prochain client commence ici"}</strong><p>Créez son compte et ses conditions, puis partagez son accès.</p>{!query && <button className="button button-primary" onClick={() => open("new")}><Plus size={16} /> Créer mon premier client</button>}</div>}
    {editor && <Modal title={editor === "new" ? "Créer un accès client" : `Compte de ${editor.firstName}`} subtitle="La grille s’applique aux nouveaux dossiers. Les commandes existantes conservent leur prix." wide onClose={() => { if (!busy) setEditor(null); }}>
      <ol className="client-wizard-steps">{["Compte", "Tarifs", "Accès"].map((label, index) => <li key={label} className={step === index ? "current" : step > index ? "done" : ""} aria-current={step === index ? "step" : undefined}><span>{step > index ? <Check size={14} /> : index + 1}</span>{label}</li>)}</ol>
      <form onSubmit={e => { e.preventDefault(); if (step < 2) next(); else void save(false); }}>
      {step === 0 && <div className="client-identity-fields"><label className="form-field">Nom du client ou de la société<input autoComplete="off" required minLength={2} maxLength={128} value={name} onChange={e => setName(e.target.value)} placeholder="Ex. Garage Martin" /></label><label className="form-field">Identifiant de connexion<input autoComplete="off" required minLength={3} maxLength={64} pattern="[a-z0-9][a-z0-9._-]{2,63}" value={login} onChange={e => setLogin(e.target.value.toLowerCase())} placeholder="ex. garage.martin" /><small>Un identifiant unique à communiquer au client.</small></label>{editor === "new" ? <label className="form-field">ID Telegram · facultatif<input inputMode="numeric" value={telegram} onChange={e => setTelegram(e.target.value)} placeholder="Laisser vide si vous ne l’avez pas" /><small>Le client pourra relier Telegram en utilisant ses identifiants dans la Mini App.</small></label> : <p className="client-demo-note">{telegram ? `Compte Telegram associé : ${telegram}` : "Telegram n’est pas encore relié à ce client."}</p>}<div className="client-tip"><img src="/brand/komi-mascot.webp" alt="" /><p>Le mot de passe est généré à la dernière étape, une fois les tarifs prêts. Le client devra le changer à sa première connexion.</p></div></div>}
      {step === 1 && <div className="client-pricing-editor"><div className="client-pricing-toolbar"><label className="form-field">Remise générale sur le catalogue (%)<input type="number" inputMode="decimal" min={0} max={100} step="0.01" value={discount / 100} onChange={e => setDiscount(cents(e.target.value))} /></label><p>Chaque tarif personnalisé ci-dessous remplace la remise générale pour cette prestation.</p></div><div className="client-cg-presets"><div><strong>Cartes grises · minimum 60 €</strong><small>Remise appliquée au montant de référence vérifié lors du devis.</small></div><div>{[50, 55, 60].map(percent => <button type="button" className="button button-secondary" key={percent} onClick={() => setRules(current => [...current.filter(rule => !carteGriseIds.includes(rule.serviceId)), ...services.filter(service => carteGriseIds.includes(service.id)).map(service => ({ serviceId: service.id, mode: "DISCOUNT" as const, priceCents: null, discountBps: percent * 100, minimumCents: 6000 }))])}>−{percent} %</button>)}</div></div><label className="client-search"><Search size={16} /><input aria-label="Rechercher une démarche dans la grille" value={serviceSearch} onChange={e => setServiceSearch(e.target.value)} placeholder="Rechercher une démarche…" /></label>
        {catalogueSections.map((section, index) => { const matches = services.filter(service => serviceSection(service).id === section.id && service.title.toLowerCase().includes(serviceSearch.toLowerCase())); if (!matches.length) return null; return <details key={`${section.id}-${!!serviceSearch}`} className="client-price-group" open={serviceSearch ? true : index === 0 ? true : undefined}><summary>{section.label}<span>{matches.length}</span></summary><div>{matches.map(service => { const rule = rules.find(item => item.serviceId === service.id); let result; try { result = resolvePrice({ id: service.id, priceCents: service.price, requiresQuote: !!service.requiresQuote }, { defaultDiscountBps: discount, pricingVersion: 0 }, rule); } catch { result = null; } return <div className="client-price-row" key={service.id}><div className="client-price-title"><strong>{service.title}</strong><small>Catalogue : {service.requiresQuote ? "sur devis" : euro(service.price)}{!service.active ? " · désactivé" : ""}</small></div><label className="form-field">Type de tarif<select aria-label={`Mode tarifaire · ${service.title}`} value={rule?.mode || "INHERIT"} onChange={e => changeRule(service, e.target.value)}><option value="INHERIT">Grille générale</option><option value="FIXED">Prix fixe</option><option value="DISCOUNT">Remise en %</option><option value="QUOTE">Sur devis</option></select></label>{rule?.mode === "FIXED" && <label className="form-field">Prix (€)<input aria-label={`Prix · ${service.title}`} inputMode="decimal" type="number" step="0.01" min={carteGriseIds.includes(service.id) ? 60 : 1} max={100000} value={rule.priceCents ? rule.priceCents / 100 : ""} onChange={e => patchRule(service.id, { priceCents: cents(e.target.value) })} /></label>}{rule?.mode === "DISCOUNT" && <label className="form-field">Remise (%)<input aria-label={`Remise · ${service.title}`} inputMode="decimal" type="number" step="0.01" min={0} max={100} value={rule.discountBps / 100} onChange={e => patchRule(service.id, { discountBps: cents(e.target.value) })} /></label>}{rule && <label className="form-field">Minimum (€)<input aria-label={`Minimum · ${service.title}`} type="number" inputMode="decimal" min={carteGriseIds.includes(service.id) ? 60 : 0} max={100000} step="0.01" value={rule.minimumCents / 100} onChange={e => patchRule(service.id, { minimumCents: cents(e.target.value) })} /></label>}<div className="client-effective-price"><small>Ce client verra</small><strong>{result ? result.requiresQuote ? "Sur devis" : euro(result.priceCents) : "À vérifier"}</strong>{result?.requiresQuote && <small>{pricingHint(result.pricing)}</small>}</div></div>; })}</div></details>; })}
      </div>}
      {step === 2 && <div className="client-access-review"><div className="client-review-icon"><KeyRound size={29} /></div><h3>{editor === "new" ? "Prêt à lui ouvrir les portes ?" : "Ses conditions sont prêtes"}</h3><p><strong>{name}</strong> se connectera avec l’identifiant <strong>{login}</strong>.</p><div className="client-review-stats"><span><strong>{services.length}</strong> prestations configurées</span><span><strong>{rules.length}</strong> tarifs personnalisés</span><span><strong>{discount / 100} %</strong> remise générale</span></div><p>Le mot de passe temporaire sera affiché une seule fois. Aucun envoi automatique : vous choisissez comment remettre l’accès.</p><p className="client-demo-note">Les prix sur devis sont confirmés avant paiement. Une nouvelle grille concerne seulement les futurs dossiers.</p></div>}
      {error && <p role="alert" className="client-error">{error}</p>}
      <div className="client-wizard-footer">{step > 0 && <button type="button" className="button button-secondary" disabled={busy} onClick={() => { setStep(value => value - 1); setError(""); }}><ArrowLeft size={16} /> Retour</button>}{step < 2 ? <button className="button button-primary">{step === 0 ? "Configurer les tarifs" : "Vérifier l’accès"}<ArrowRight size={16} /></button> : <><button className="button button-secondary" disabled={busy}>{busy ? "Enregistrement…" : editor === "new" ? "Enregistrer en brouillon" : "Enregistrer la grille"}</button>{editor === "new" && <button type="button" className="button button-primary" disabled={busy} onClick={() => void save(true)}><KeyRound size={16} /> {busy ? "Création…" : "Créer et générer l’accès"}</button>}</>}</div>
      </form>
    </Modal>}
    {actionClient && <Modal title={`Accès de ${actionClient.firstName}`} onClose={() => { if (!busy) setActionClient(null); }}><div className="client-access-actions"><p>Identifiant : <strong>{actionClient.login || "À configurer dans Compte & tarifs"}</strong></p>{actionClient.accessReady ? <><button className="button button-secondary" disabled={busy || !actionClient.login} onClick={() => void access(actionClient, "reset")}><KeyRound size={16} /> Générer un nouveau mot de passe</button><small>Les sessions actuelles seront fermées. Le client devra choisir un nouveau mot de passe personnel.</small><button className="button button-secondary" disabled={busy} onClick={() => void access(actionClient, actionClient.disabled ? "resume" : "suspend")}>{actionClient.disabled ? "Réactiver cet accès" : "Suspendre cet accès"}</button></> : <><p>Vérifiez sa grille avant de générer ses identifiants.</p><button className="button button-primary" disabled={busy || !actionClient.login || actionClient.pricingVersion < 1} onClick={() => void access(actionClient, "activate")}><KeyRound size={16} /> Générer et activer l’accès</button></>}</div></Modal>}
    {credentials && <Modal title={isLive ? "Son accès est prêt" : "Accès de démonstration"} subtitle="Copiez ces identifiants avant de fermer. Le mot de passe ne sera plus affiché." onClose={() => setCredentials(null)}><div className="client-credentials"><ShieldCheck size={30} /><p>{isLive ? "Transmettez cet accès directement à votre client." : "Ces identifiants sont fictifs : ils ne créent pas de connexion réelle."}</p><label>Identifiant<input readOnly value={credentials.login} onFocus={e => e.currentTarget.select()} /></label><label>Mot de passe temporaire<input readOnly autoComplete="off" value={credentials.password} onFocus={e => e.currentTarget.select()} /></label><small>Changement obligatoire à la première connexion.</small><button className="button button-primary" onClick={() => void copyAccess()}><Copy size={17} /> Copier l’accès à transmettre</button><button className="button button-secondary" onClick={() => setCredentials(null)}>J’ai conservé l’accès</button></div></Modal>}
  </section>;
}
