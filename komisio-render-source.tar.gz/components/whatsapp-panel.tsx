"use client";
import { useEffect, useState, type FormEvent } from "react";
import { Check, Link2, LoaderCircle, MessageCircle, Plus, QrCode, RefreshCw, ShieldCheck, Smartphone, Unplug, Users } from "lucide-react";
import { QRCodeSVG } from "qrcode.react";
import type { Service } from "@/lib/catalog";
import { Modal } from "./ui";
import { WhatsAppDrafts, whatsappCall, type WhatsAppDraftView } from "./whatsapp-drafts";
import "./whatsapp-panel.css";
type Binding = { id: string; userId: string; phone: string; groupId?: string | null; active: boolean; user?: { firstName?: string; login?: string | null } };
type Job = { id: string; status: string; error?: string | null; attempts?: number };
type Summary = { configured: boolean; transport?: "WEB" | "CLOUD"; groupsEnabled: boolean; bindings: Binding[]; drafts: WhatsAppDraftView[]; jobs: Job[]; outbox: Job[]; issues?: string[] };
type Bridge = { transport: "WEB" | "CLOUD"; configured: boolean; connected: boolean; qr?: string | null; status: string; error?: string | null };
const initial: Summary = { configured: false, transport: "WEB", groupsEnabled: true, bindings: [], drafts: [], jobs: [], outbox: [] };
const demoKey = "komisio-whatsapp-demo-bindings";
const commands = [{ command: "/cg", label: "Carte grise", text: "Envoyez la carte grise et les pièces du dossier." }, { command: "/fiche po", label: "Fiche véhicule", text: "Transmettez la plaque du véhicule concerné." }, { command: "/ecra", label: "Régularisation", text: "Joignez la carte grise et les justificatifs." }, { command: "/ww", label: "WW simple", text: "Carte grise, identité et adresse du titulaire." }];
export function WhatsAppPanel({ services, isLive, notify }: { services: Service[]; isLive: boolean; notify: (message: string, error?: boolean) => void }) {
  const [summary, setSummary] = useState<Summary>(initial);
  const [bridge, setBridge] = useState<Bridge | null>(null);
  const [clients, setClients] = useState<{ id: string; firstName: string; login?: string | null; disabled?: boolean; accessReady?: boolean; role?: string }[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState("");
  const [editing, setEditing] = useState(false);
  const [userId, setUserId] = useState("");
  const [phone, setPhone] = useState("");
  const [availableGroups, setAvailableGroups] = useState<{id:string;name:string}[]>([]);
  const [groupId, setGroupId] = useState("");
  const [group, setGroup] = useState(false);
  const [verified, setVerified] = useState(false);
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState("");
  async function refresh(includeClients = true) {
    try {
      if (isLive) {
        const [raw, users] = await Promise.all([whatsappCall("/api/admin/whatsapp"), includeClients ? whatsappCall("/api/admin/users") : Promise.resolve(null)]);
        setSummary({ ...initial, ...raw }); if (users) setClients((Array.isArray(users) ? users : users.users || []).filter((user: { role?: string }) => user.role !== "ADMIN"));
        try { setBridge(await whatsappCall("/api/admin/whatsapp/bridge")); } catch { setBridge(null); }
      } else {
        let bindings: Binding[] = []; try { bindings = JSON.parse(localStorage.getItem(demoKey) || "[]"); } catch {}
        let users: typeof clients = []; try { users = JSON.parse(localStorage.getItem("komisio-demo-clients") || "[]"); } catch {}
        setSummary({ ...initial, bindings }); setClients(users);
      }
      setError("");
    } catch (e) { setError((e as Error).message); } finally { setLoaded(true); }
  }
  useEffect(() => { void refresh(); if (isLive) { const timer = setInterval(() => void refresh(false), 10000); return () => { clearInterval(timer); setBridge(null); }; } }, [isLive]);
  function newBinding() { setUserId(""); setPhone(""); setGroupId(""); setGroup(false); setVerified(false); setFormError(""); setEditing(true); }
  async function save(event: FormEvent) {
    event.preventDefault(); if (busy) return;
    const number = phone.replace(/[\s()+.-]/g, "");
    if (!userId || !/^[1-9]\d{6,14}$/.test(number) || !verified || (group && !groupId.trim())) { setFormError("Choisissez un client, vérifiez son numéro international et confirmez le rattachement. Renseignez l’identifiant du groupe si utilisé."); return; }
    if (group && !summary.groupsEnabled) { setFormError("Le traitement des groupes doit être activé sur le serveur avant ce rattachement."); return; }
    setBusy(true); setFormError("");
    try {
      if (isLive) { await whatsappCall("/api/admin/whatsapp", { action: "bind", userId, phone: number, ...(group ? { groupId: groupId.trim() } : {}) }); await refresh(); }
      else {
        const user = clients.find(client => client.id === userId); const binding: Binding = { id: crypto.randomUUID(), userId, phone: number, groupId: group ? groupId.trim() : null, active: true, user: { firstName: user?.firstName, login: user?.login } };
        const bindings = [binding, ...summary.bindings]; localStorage.setItem(demoKey, JSON.stringify(bindings)); setSummary({ ...summary, bindings });
      }
      setEditing(false); notify(isLive ? "Numéro rattaché au compte client." : "Rattachement simulé. Aucun numéro réel connecté.");
    } catch (e) { setFormError((e as Error).message); } finally { setBusy(false); }
  }
  async function disable(binding: Binding) {
    if (busy) return; setBusy(true);
    try {
      if (isLive) { await whatsappCall("/api/admin/whatsapp", { action: "disable_binding", id: binding.id }); await refresh(); }
      else { const bindings = summary.bindings.map(item => item.id === binding.id ? { ...item, active: false } : item); localStorage.setItem(demoKey, JSON.stringify(bindings)); setSummary({ ...summary, bindings }); }
      notify(isLive ? "Rattachement désactivé. Ce numéro ne peut plus déposer de dossier." : "Désactivation simulée.");
    } catch (e) { notify((e as Error).message, true); } finally { setBusy(false); }
  }
  const web = (bridge?.transport || summary.transport) !== "CLOUD";
  const received = summary.jobs.filter(job => !["DONE", "COMPLETED", "PROCESSED", "IGNORED"].includes(job.status));
  return <div className="wa-admin">
    <section className="wa-admin-hero panel"><div><span className="wa-eyebrow"><MessageCircle size={15} /> UN CANAL EN PLUS, LE MÊME COMPTE</span><h2>Vos revendeurs restent sur WhatsApp.</h2><p>Une commande, des photos, un dossier prérempli. Les tarifs et le suivi restent liés au bon compte client.</p><div className="wa-flow"><span>Documents</span><Arrow /><span>Lecture OCR</span><Arrow /><span>Vérification</span><Arrow /><span>Dossier</span></div></div><div className="wa-admin-mascot"><img src="/brand/komi-mascot.webp" alt="" /></div></section>
    {!isLive && <p className="wa-notice">Aperçu de configuration : le bot n’est pas connecté dans cette démo. Aucun QR de connexion, message ou OCR réel n’est généré ici.</p>}
    {error && <p role="alert" className="wa-error">{error}</p>}
    <div className="wa-admin-grid"><section className="wa-connection panel"><header><div><span className="wa-card-icon"><Smartphone size={22} /></span><h3>{web ? "Connexion WhatsApp Web" : "WhatsApp Cloud API"}</h3></div><span className={`wa-state ${isLive && bridge?.connected ? "connected" : ""}`}>{!isLive ? "Démonstration" : bridge?.connected ? "Session connectée" : "À raccorder"}</span></header>
      {web ? <><p>Utilisez un numéro dédié et reliez-le par QR code dans les appareils connectés WhatsApp. Le pont doit rester démarré pour recevoir les messages et les groupes.</p>{isLive && bridge?.qr && !bridge.connected ? <div className="wa-private-qr"><QRCodeSVG value={bridge.qr} size={196} includeMargin /><strong>Scannez depuis WhatsApp</strong><span>Réglages → Appareils connectés → Connecter un appareil.</span><small>QR privé : il autorise la connexion au compte. Ne le partagez pas.</small></div> : <div className="wa-connection-note">{isLive && bridge?.connected ? <Check size={19} /> : <QrCode size={23} />}<span>{!isLive ? "Le QR réel apparaîtra ici sur le serveur raccordé." : bridge?.connected ? "La session du pont est connectée. Vérifiez ensuite le rattachement de chaque revendeur." : "Démarrez le pont WhatsApp sur votre hébergement pour afficher le QR de connexion ici."}</span></div>}{bridge?.error && <p className="wa-error">{bridge.error}</p>}</> : <><p>Le mode Cloud utilise le compte WhatsApp Business, son numéro API et un webhook signé. Les groupes officiels nécessitent une éligibilité spécifique.</p><div className="wa-connection-note"><ShieldCheck size={20} /><span>{summary.configured ? "Les paramètres serveur sont présents. Validez l’envoi et la réception sur votre compte avant l’ouverture." : "Renseignez les secrets Meta dans les variables de l’hébergement. Aucune clé ne se saisit dans ce panneau."}</span></div></>}
      <button className="button button-secondary" onClick={() => void refresh()} disabled={busy}><RefreshCw size={15} /> Vérifier l’état</button>
    </section><section className="wa-commands panel"><h3><MessageCircle size={19} /> Des commandes faciles à retenir</h3><div>{commands.map(item => <article key={item.command}><code>{item.command}</code><span><strong>{item.label}</strong><small>{item.text}</small></span></article>)}</div><p><code>/aide</code> pour la liste complète · <code>/voir</code> pour le récapitulatif · <code>/valider</code> après contrôle · <code>/annuler</code> pour arrêter le brouillon.</p></section></div>
    <section className="wa-bindings panel"><header><div><h3><Link2 size={19} /> Numéros et groupes rattachés</h3><p>Vous choisissez le compte associé. Aucun compte n’est créé à partir d’un simple message.</p></div><button className="button button-primary" onClick={newBinding}><Plus size={16} /> Rattacher un revendeur</button></header>{!loaded ? <p className="wa-loading"><LoaderCircle className="spin" size={18} /> Chargement…</p> : summary.bindings.length ? <div className="wa-binding-list">{summary.bindings.map(binding => <article key={binding.id}><span className="wa-card-icon"><Users size={19} /></span><div><strong>{binding.user?.firstName || clients.find(client => client.id === binding.userId)?.firstName || "Compte client"}</strong><small>+{binding.phone}{binding.groupId ? ` · Groupe : ${binding.groupId}` : " · Conversation privée"}</small><small>{binding.active ? "Autorisé à déposer" : "Rattachement désactivé"}</small></div>{binding.active && <button className="button button-secondary" onClick={() => void disable(binding)} disabled={busy}><Unplug size={14} /> Désactiver</button>}</article>)}</div> : <div className="wa-empty"><Link2 size={25} /><strong>Chaque message doit retrouver le bon compte</strong><p>Commencez par créer le client et sa grille, puis rattachez son numéro WhatsApp. Pour un groupe, autorisez aussi son identifiant précis.</p></div>}</section>
    <WhatsAppDrafts services={services} isLive={isLive} admin notify={notify} />
    {isLive && <section className="wa-activity panel"><h3>Réception et envoi des messages</h3><p>Le serveur conserve les traitements pour éviter les doublons et permettre la reprise après interruption.</p><div className="wa-activity-stats"><span><strong>{received.length}</strong> réceptions à traiter ou contrôler</span><span><strong>{summary.outbox.filter(item => !["SENT", "DONE", "COMPLETED"].includes(item.status)).length}</strong> réponses à envoyer ou contrôler</span><span><strong>{summary.bindings.filter(binding => binding.active).length}</strong> rattachements actifs</span></div>{[...received, ...summary.outbox.filter(item => item.error)].slice(0, 10).map((item, index) => <div className="wa-job" key={item.id + index}><strong>{item.status}</strong><span>{item.error || "Traitement enregistré"}</span>{typeof item.attempts === "number" && <small>{item.attempts} tentative{item.attempts !== 1 ? "s" : ""}</small>}</div>)}</section>}
    {editing && <Modal title="Rattacher un revendeur à WhatsApp" subtitle="Le compte et sa grille doivent déjà être créés." onClose={() => { if (!busy) setEditing(false); }}><form className="wa-binding-form" onSubmit={save}><label className="form-field">Compte client<select required value={userId} onChange={e => setUserId(e.target.value)}><option value="">Choisir le revendeur</option>{clients.map(client => <option key={client.id} value={client.id} disabled={client.disabled || client.accessReady === false}>{client.firstName}{client.login ? ` · ${client.login}` : ""}{client.disabled ? " · suspendu" : client.accessReady === false ? " · brouillon" : ""}</option>)}</select></label>{!clients.length && <p className="wa-notice">Créez d’abord le compte dans « Clients & tarifs ». Les comptes créés dans la démo restent locaux à ce navigateur.</p>}<label className="form-field">Numéro WhatsApp du revendeur<input type="tel" autoComplete="off" value={phone} onChange={e => setPhone(e.target.value)} placeholder="Numéro international, avec indicatif pays" required /><small>Indiquez le numéro qui enverra les documents, pas celui du bot.</small></label><label className="consent"><input type="checkbox" checked={group} onChange={e => setGroup(e.target.checked)} disabled={!summary.groupsEnabled} /><span>Autoriser ce revendeur dans un groupe précis</span></label>{group && web && isLive && <><button type="button" className="button button-secondary" disabled={busy || !bridge?.connected} onClick={async () => { try { const value = await whatsappCall("/api/admin/whatsapp/groups"); setAvailableGroups(value.groups || []); } catch(e) { setFormError((e as Error).message); } }}>Charger mes groupes WhatsApp</button>{availableGroups.length > 0 && <label className="form-field">Choisir le groupe<select value={groupId} onChange={e => setGroupId(e.target.value)}><option value="">Sélectionner…</option>{availableGroups.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>}</>}
      {group && <label className="form-field">Identifiant exact du groupe<input required value={groupId} onChange={e => setGroupId(e.target.value)} maxLength={200} placeholder={web ? "Identifiant WhatsApp se terminant par @g.us" : "Identifiant du groupe officiel"} /><small>Le numéro expéditeur et le groupe doivent tous les deux correspondre. Un nom de groupe seul ne suffit pas.</small></label>}{!summary.groupsEnabled && <p className="wa-notice">Les groupes ne sont pas activés dans cette configuration. La conversation privée reste disponible.</p>}<label className="consent"><input type="checkbox" checked={verified} onChange={e => setVerified(e.target.checked)} required /><span>J’ai vérifié que ce numéro appartient à ce revendeur et j’autorise le dépôt sur son compte.</span></label>{formError && <p className="wa-error" role="alert">{formError}</p>}<button className="button button-primary" disabled={busy || !clients.length}>{busy ? <LoaderCircle className="spin" size={16} /> : <Link2 size={16} />} Enregistrer le rattachement</button></form></Modal>}
  </div>;
}
function Arrow() { return <span aria-hidden="true">→</span>; }
