"use client";
import { useEffect, useState, type FormEvent } from "react";
import { ArrowRight, Calculator, Check, ChevronDown, ExternalLink, MessageCircle, RotateCcw } from "lucide-react";
import { euro, type Service } from "@/lib/catalog";
import { quotePrice, pricingHint, type PricingSnapshot } from "@/lib/pricing";
import { estimateVehicleTax, officialVehicleSimulator, vehicleRates } from "@/lib/vehicle-estimate";
import "./home-vehicle-estimator.css";

type EstimateResult = {
  estimate: ReturnType<typeof estimateVehicleTax>;
  commercialAmountCents: number | null;
  pricing: PricingSnapshot;
  requiresQuote: boolean;
  serviceId: string;
};
export function HomeVehicleEstimator({ services, live, onSelect, whatsappUrl, onSupport }: { services: Service[]; live: boolean; onSelect: (service: Service) => void; whatsappUrl: string | null; onSupport: () => void }) {
  const offers = services.filter(service => service.active && ["carte-grise", "carte-grise-sans-ct"].includes(service.id));
  const [serviceId, setServiceId] = useState("carte-grise");
  const [region, setRegion] = useState("");
  const [power, setPower] = useState("");
  const [first, setFirst] = useState("");
  const [ordinary, setOrdinary] = useState(false);
  const [result, setResult] = useState<EstimateResult | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [details, setDetails] = useState(false);
  const selected = offers.find(service => service.id === serviceId) || offers[0];
  // A new client grid invalidates an on-screen result before another estimate is requested.
  const pricingVersion = selected?.pricing?.version;
  useEffect(() => { setResult(null); }, [pricingVersion, selected?.price, selected?.requiresQuote]);
  const clear = () => { setResult(null); setError(""); setDetails(false); };
  function reset() { setRegion(""); setPower(""); setFirst(""); setOrdinary(false); clear(); }
  async function calculate(event: FormEvent) {
    event.preventDefault();
    if (busy || !selected) return;
    setBusy(true); setError(""); setResult(null);
    const input = { serviceId: selected.id, region, fiscalPower: Number(power), firstRegistration: first, ordinaryFrenchUsedCar: ordinary };
    try {
      let next: EstimateResult;
      if (live) {
        const response = await fetch("/api/vehicle-estimate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(input) });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "L’estimation est momentanément indisponible.");
        next = data;
      } else {
        const estimate = estimateVehicleTax(input);
        const pricing: PricingSnapshot = { mode: "DISCOUNT", basePriceCents: 0, discountBps: 5000, minimumCents: 6000, source: "CLIENT", version: 0 };
        next = { estimate, pricing, commercialAmountCents: quotePrice(estimate.referenceCents, pricing), requiresQuote: true, serviceId: selected.id };
      }
      setResult(next);
    } catch (reason) { setError((reason as Error).message); }
    finally { setBusy(false); }
  }
  if (!offers.length) return null;
  return <section className="home-cg-section" aria-labelledby="home-cg-heading">
    <div className="home-cg-card">
      <header className="home-cg-intro"><div><span className="home-cg-kicker"><Calculator size={15} /> ESTIMATION EXPRESS</span><h2 id="home-cg-heading">Combien pour cette carte grise ?</h2><p>3 infos de la carte grise. Une estimation, sans créer de dossier.</p></div><span className="home-cg-badge"><Check size={13} /> Sans frais</span></header>
      {offers.length > 1 && <div className="home-cg-variants" role="group" aria-label="Démarche à estimer">{offers.map(service => <button type="button" key={service.id} aria-pressed={selected?.id === service.id} disabled={busy} onClick={() => { setServiceId(service.id); clear(); }}>{service.id === "carte-grise" ? "Carte grise" : "Sans CT joint"}</button>)}</div>}
      <form onSubmit={calculate} className="home-cg-form">
        <div className="home-cg-fields">
          <label className="home-cg-region"><span>Région du nouveau titulaire</span><select required value={region} disabled={busy} onChange={event => { setRegion(event.target.value); clear(); }}><option value="">Choisir la région</option>{vehicleRates.map(rate => <option key={rate.id} value={rate.id}>{rate.name}</option>)}</select></label>
          <label className="home-cg-power"><span>Puissance fiscale <small>P.6</small></span><input required type="number" inputMode="numeric" min={1} max={1000} step={1} value={power} placeholder="Ex. 6" disabled={busy} onChange={event => { setPower(event.target.value); clear(); }} /></label>
          <label className="home-cg-date"><span>1re immatriculation <small>B</small></span><input required type="date" min="1900-01-01" max={new Date().toISOString().slice(0, 10)} value={first} disabled={busy} onChange={event => { setFirst(event.target.value); clear(); }} /></label>
        </div>
        <label className="home-cg-scope"><input type="checkbox" required checked={ordinary} disabled={busy} onChange={event => { setOrdinary(event.target.checked); clear(); }} /><span>Voiture d’occasion essence/diesel, déjà immatriculée en France, sans importation, malus résiduel, transformation ou exonération particulière.</span></label>
        <div className="home-cg-form-actions"><button className="button button-primary" disabled={busy}>{busy ? "Calcul en cours…" : "Estimer le prix"}<ArrowRight size={17} /></button><button type="button" className="home-cg-reset" onClick={reset} disabled={busy}><RotateCcw size={14} /> Nouveau véhicule</button></div>
      </form>
      {error && <div role="alert" className="home-cg-error"><p>{error}</p><a href={officialVehicleSimulator} target="_blank" rel="noopener noreferrer">Utiliser le simulateur officiel <ExternalLink size={14} /></a></div>}
      {result && <div className="home-cg-result" role="status" aria-live="polite"><div className="home-cg-result-prices"><div><span>Taxes de référence estimées</span><strong>{euro(result.estimate.referenceCents)}</strong></div><div className="home-cg-personal"><span>{live ? "Votre tarif indicatif" : "Exemple de tarif · démo"}</span><strong>{result.commercialAmountCents === null ? "Sur devis" : euro(result.commercialAmountCents)}</strong><small>{result.commercialAmountCents === null ? "Votre interlocuteur confirme le prix après étude." : pricingHint(result.pricing, result.requiresQuote)}</small></div></div><p>{live ? "Indication à confirmer avant commande. La remise commerciale ne modifie pas les taxes dues à l’État." : "Démonstration : remise d’exemple de 50 %, minimum 60 €. Votre grille réelle sera appliquée après connexion."}</p><button type="button" className="home-cg-result-detail" aria-expanded={details} onClick={() => setDetails(value => !value)}>Voir le détail du calcul <ChevronDown size={15} /></button>{details && <dl className="home-cg-calculation"><div><dt>Taxe régionale{result.estimate.oldVehicle ? " · ancienneté prise en compte" : ""}</dt><dd>{euro(result.estimate.regionalCents)}</dd></div><div><dt>Taxe fixe</dt><dd>{euro(result.estimate.fixedCents)}</dd></div><div><dt>Acheminement</dt><dd>{euro(result.estimate.deliveryCents)}</dd></div><div><dt>Barème intégré</dt><dd>2026 · jusqu’au 31/12</dd></div></dl>}<div className="home-cg-result-actions"><button type="button" className="button button-secondary" onClick={() => { const offer = offers.find(service => service.id === result.serviceId); if (offer) onSelect(offer); }}>Préparer le dossier <ArrowRight size={15} /></button><a href={officialVehicleSimulator} target="_blank" rel="noopener noreferrer">Comparer au simulateur officiel <ExternalLink size={13} /></a></div></div>}
      <footer className="home-cg-footer"><span>Import, électrique, utilitaire ou autre cas ?</span><a href={officialVehicleSimulator} target="_blank" rel="noopener noreferrer">Simulateur officiel <ExternalLink size={13} /></a></footer>
    </div>
    <div className="home-whatsapp-help"><span className="home-whatsapp-icon"><MessageCircle size={20} /></span><div><strong>Un souci sur un dossier ?</strong><p>Écrivez à l’équipe, avec sa référence.</p></div>{whatsappUrl ? <a className="home-whatsapp-action" href={whatsappUrl} target="_blank" rel="noopener noreferrer">WhatsApp <ArrowRight size={15} /></a> : <button type="button" className="home-whatsapp-action" onClick={onSupport}>WhatsApp <ArrowRight size={15} /></button>}</div>
  </section>;
}
