"use client";
import { useRef, useState, type FormEvent } from "react";
import { CalendarDays, CheckCircle2 } from "lucide-react";
import { isPaidStatus, type Order } from "@/lib/catalog";
import { advanceOriginalDocument, originalDocumentLabels, type OriginalDocumentAction } from "@/lib/original-document";

type Props = { order: Order; live: boolean; admin?: boolean; disabled?: boolean; onBusyChange?: (busy: boolean) => void; onUpdate: (order: Order) => void; notify: (message: string, error?: boolean) => void };
const dateTime = (value: string) => new Intl.DateTimeFormat("fr-FR", { dateStyle: "medium", timeStyle: "short", timeZone: "Europe/Paris" }).format(new Date(value)) + " (Paris)";
const localInput = (value?: string | null) => {
  if (!value) return "";
  const date = new Date(value);
  return new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
};

export function OriginalDocumentPanel({ order, live, admin = false, disabled = false, onBusyChange, onUpdate, notify }: Props) {
  const original = order.originalDocument;
  const [appointment, setAppointment] = useState(localInput(original?.appointmentAt));
  const [location, setLocation] = useState(original?.location || "");
  const [note, setNote] = useState(original?.note || "");
  const [confirmed, setConfirmed] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const saving = useRef(false);
  if (!original) return null;
  const cancelled = order.status === "CANCELLED";
  const closed = ["COMPLETED", "QUOTE_REJECTED"].includes(order.status);
  const accepted = !order.requiresQuote || !!order.quoteAcceptedAt;
  const canSchedule = admin && accepted && !closed && !cancelled && ["TO_SCHEDULE", "APPOINTMENT_SET"].includes(original.status);
  const action = !admin || closed ? null : original.status === "APPOINTMENT_SET" && !cancelled ? "collect" : original.status === "COLLECTED" && (cancelled || isPaidStatus(order.status)) ? "ready" : original.status === "READY_FOR_RETURN" ? "return" : null;
  const consentKey = `${original.version}:${action}`;
  const actionLabel = action === "collect" ? "Confirmer la récupération" : action === "ready" ? "Marquer prête à restituer" : "Confirmer la restitution";
  const confirmationLabel = action === "collect" ? "Je confirme avoir récupéré la carte grise originale en physique." : action === "ready" ? (cancelled ? "La carte grise est disponible pour être rendue malgré l’annulation." : "La démarche est effectuée et la carte grise peut être rendue.") : "Je confirme avoir rendu la carte grise originale à son destinataire.";
  async function change(input: OriginalDocumentAction) {
    if (saving.current || disabled) return;
    saving.current = true; setBusy(true); onBusyChange?.(true);
    try {
      let updated: Order;
      if (live) {
        const response = await fetch(`/api/admin/orders/${order.id}/original-document`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(input) });
        const raw = await response.json();
        if (!response.ok) throw new Error(raw.error || "Impossible de mettre à jour le suivi.");
        updated = { ...order, status: raw.status, originalDocument: raw.originalDocument, note: raw.events?.at(-1)?.note || order.note };
      } else {
        const result = advanceOriginalDocument({ ...order, paid: isPaidStatus(order.status), originalDocument: order.originalDocument! }, input);
        updated = { ...order, status: result.status, originalDocument: result.originalDocument };
      }
      onUpdate(updated); setConfirmed(null);
      notify(live ? "Suivi mis à jour. Notification Telegram mise en file d’envoi." : "Suivi mis à jour dans la démonstration.");
    } catch (error) { notify((error as Error).message, true); }
    finally { saving.current = false; setBusy(false); onBusyChange?.(false); }
  }
  function schedule(event: FormEvent) {
    event.preventDefault();
    const parsed = new Date(appointment);
    if (!Number.isFinite(parsed.getTime())) { notify("Choisissez une date de rendez-vous valide.", true); return; }
    void change({ action: "schedule", expectedVersion: original!.version, appointmentAt: parsed.toISOString(), location: location.trim(), note: note.trim() });
  }
  const steps = Object.entries(originalDocumentLabels);
  const currentIndex = steps.findIndex(([key]) => key === original.status);
  return <section className="original-panel" aria-label="Suivi de la carte grise originale" aria-busy={busy}>
    <div className="original-heading"><CalendarDays size={22} /><div><h3>Carte grise originale</h3><p>{!accepted ? (cancelled || order.status === "QUOTE_REJECTED" ? "Dossier clôturé, aucun rendez-vous à prévoir." : "Le rendez-vous de récupération sera fixé après votre accord sur le devis.") : "Suivez la récupération et la restitution de votre document original."}</p></div></div>
    <ol className="original-steps">{steps.map(([key, label], index) => <li key={key} className={index <= currentIndex ? "reached" : ""} aria-current={index === currentIndex ? "step" : undefined}><span>{index < currentIndex ? <CheckCircle2 size={17} /> : index + 1}</span><div><strong>{label}</strong>{key === "COLLECTED" && original.collectedAt && <small>{dateTime(original.collectedAt)}</small>}{key === "READY_FOR_RETURN" && original.readyAt && <small>{dateTime(original.readyAt)}</small>}{key === "RETURNED" && original.returnedAt && <small>{dateTime(original.returnedAt)}</small>}</div></li>)}</ol>
    {original.appointmentAt && <div className="original-appointment"><strong>Rendez-vous de récupération</strong><time dateTime={original.appointmentAt}>{dateTime(original.appointmentAt)}</time><p>{original.location}</p>{original.note && <p>{original.note}</p>}<small>Préparez la carte grise originale pour la remise en main propre.</small></div>}
    {accepted && original.status === "TO_SCHEDULE" && !cancelled && <p>L’équipe vous communiquera ici la date et le lieu du rendez-vous.</p>}
    {cancelled && ["COLLECTED", "READY_FOR_RETURN"].includes(original.status) && <p>Le dossier est annulé. La restitution de l’original reste à effectuer.</p>}
    {original.status === "COLLECTED" && order.status === "AWAITING_PAYMENT" && <p>Original récupéré. Le traitement commencera après confirmation du paiement.</p>}
    {canSchedule && <form className="original-form" onSubmit={schedule}>
      <label className="form-field">Date et heure de récupération<input required type="datetime-local" value={appointment} onChange={event => setAppointment(event.target.value)} disabled={busy || disabled} /><small>Heure de votre appareil ({Intl.DateTimeFormat().resolvedOptions().timeZone}). Le rendez-vous sera affiché en heure de Paris.</small></label>
      <label className="form-field">Lieu / adresse du rendez-vous<textarea required minLength={3} maxLength={1000} value={location} onChange={event => setLocation(event.target.value)} disabled={busy || disabled} /></label>
      <label className="form-field">Instructions (facultatives)<textarea maxLength={2000} value={note} onChange={event => setNote(event.target.value)} disabled={busy || disabled} /></label>
      <button className="button button-primary" disabled={busy || disabled}>{busy ? "Enregistrement…" : original.status === "APPOINTMENT_SET" ? "Modifier le rendez-vous" : "Fixer le rendez-vous"}</button>
    </form>}
    {action && <div className="original-form"><label className="consent"><input type="checkbox" checked={confirmed === consentKey} onChange={event => setConfirmed(event.target.checked ? consentKey : null)} disabled={busy || disabled} /><span>{confirmationLabel}</span></label><button type="button" className="button button-primary" disabled={busy || disabled || confirmed !== consentKey} onClick={() => void change({ action, expectedVersion: original.version, confirmed: true })}>{busy ? "Enregistrement…" : actionLabel}</button></div>}
  </section>;
}
