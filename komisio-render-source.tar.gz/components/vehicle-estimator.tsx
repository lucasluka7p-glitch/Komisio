"use client";
import { useState } from "react";
import { Calculator, ExternalLink } from "lucide-react";
import { estimateVehicleTax, officialVehicleSimulator, vehicleRates, type VehicleEstimateInput } from "@/lib/vehicle-estimate";
import { euro } from "@/lib/catalog";
export function VehicleEstimator({ onUse }: { onUse: (referenceCents: number, input: VehicleEstimateInput) => void }) {
  const [region, setRegion] = useState("");
  const [power, setPower] = useState("");
  const [first, setFirst] = useState("");
  const [ordinary, setOrdinary] = useState(false);
  const [result, setResult] = useState<ReturnType<typeof estimateVehicleTax> | null>(null);
  const [error, setError] = useState("");
  const clear = () => { setResult(null); setError(""); };
  return <details className="vehicle-estimator"><summary><Calculator size={18} /> Estimer le montant de référence · gratuit</summary><div>
    <p>Voiture particulière essence ou diesel déjà immatriculée en France. Saisissez les données de la carte grise : une plaque seule ne suffit pas.</p>
    <div className="client-form-grid"><label className="form-field">Région du nouveau titulaire<select value={region} onChange={e => { setRegion(e.target.value); clear(); }}><option value="">Choisir la région</option>{vehicleRates.map(rate => <option key={rate.id} value={rate.id}>{rate.name}</option>)}</select></label><label className="form-field">Puissance fiscale · P.6<input type="number" min={1} max={1000} inputMode="numeric" value={power} onChange={e => { setPower(e.target.value); clear(); }} /></label><label className="form-field">Première immatriculation · B<input type="date" value={first} max={new Date().toISOString().slice(0, 10)} onChange={e => { setFirst(e.target.value); clear(); }} /></label></div>
    <label className="consent"><input type="checkbox" checked={ordinary} onChange={e => { setOrdinary(e.target.checked); clear(); }} /><span>Je confirme : voiture particulière d’occasion en France, essence ou diesel, sans importation, malus résiduel, exonération ou transformation.</span></label>
    <button type="button" className="button button-secondary" onClick={() => { try { setResult(estimateVehicleTax({ region, fiscalPower: Number(power), firstRegistration: first, ordinaryFrenchUsedCar: ordinary })); setError(""); } catch (e) { setResult(null); setError((e as Error).message); } }}>Calculer l’estimation</button>
    {error && <p role="alert" className="client-error">{error}</p>}
    {result && <div className="client-price-preview"><strong>{euro(result.referenceCents)} · référence estimée</strong><span>Taxe régionale : {euro(result.regionalCents)}{result.oldVehicle ? " (réduction d’ancienneté appliquée)" : ""} + taxe fixe : 11 € + acheminement : 2,76 €.</span><span>Barème 2026, à confirmer avant d’envoyer le devis. La remise commerciale ne modifie pas les taxes dues à l’État.</span><button type="button" className="button button-primary" onClick={() => onUse(result.referenceCents, { region, fiscalPower: Number(power), firstRegistration: first, ordinaryFrenchUsedCar: ordinary })}>Utiliser comme référence du devis</button></div>}
    <a className="text-link" href={officialVehicleSimulator} target="_blank" rel="noopener noreferrer">Vérifier dans le simulateur officiel <ExternalLink size={14} /></a>
  </div></details>;
}
