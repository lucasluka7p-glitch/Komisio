"use client";
import { X, Check, AlertCircle } from "lucide-react";
import { useEffect, useId, useRef, type ReactNode } from "react";
import { statusLabels, type OrderStatus } from "@/lib/catalog";

type OpenModal = { id: string; element: HTMLElement };
const openModals: OpenModal[] = [];
let restorePageScroll: (() => void) | null = null;
let pageOpener: HTMLElement | null = null;

function isTopModal(id: string) {
  return openModals.at(-1)?.id === id;
}

function lockPageScroll() {
  if (restorePageScroll) return;
  const body = document.body;
  const scrollX = window.scrollX;
  const scrollY = window.scrollY;
  const location = window.location.href;
  const previous = {
    overflow: body.style.overflow,
    position: body.style.position,
    top: body.style.top,
    left: body.style.left,
    right: body.style.right,
    width: body.style.width,
    paddingRight: body.style.paddingRight,
  };
  const scrollbar = Math.max(
    0,
    window.innerWidth - document.documentElement.clientWidth,
  );
  const paddingRight =
    Number.parseFloat(window.getComputedStyle(body).paddingRight) || 0;
  Object.assign(body.style, {
    overflow: "hidden",
    position: "fixed",
    top: `-${scrollY}px`,
    left: "0",
    right: "0",
    width: "100%",
    ...(scrollbar ? { paddingRight: `${paddingRight + scrollbar}px` } : {}),
  });
  restorePageScroll = () => {
    Object.assign(body.style, previous);
    window.scrollTo({
      left: location === window.location.href ? scrollX : 0,
      top: location === window.location.href ? scrollY : 0,
      behavior: "instant",
    });
    restorePageScroll = null;
  };
}

function updateModalStack() {
  for (const entry of openModals) {
    const active = isTopModal(entry.id);
    entry.element.inert = !active;
    entry.element.setAttribute("aria-modal", active ? "true" : "false");
    if (active) entry.element.removeAttribute("aria-hidden");
    else entry.element.setAttribute("aria-hidden", "true");
  }
}

function focusableElements(dialog: HTMLElement) {
  return Array.from(
    dialog.querySelectorAll<HTMLElement>(
      'a[href], button, input:not([type="hidden"]), select, textarea, summary, [tabindex]:not([tabindex="-1"])',
    ),
  ).filter(
    (element) =>
      element.tabIndex >= 0 &&
      !element.matches(":disabled") &&
      !element.closest('[hidden], [inert], [aria-hidden="true"]') &&
      element.getClientRects().length > 0 &&
      window.getComputedStyle(element).visibility !== "hidden",
  );
}

export function Status({ status }: { status: OrderStatus }) {
  return (
    <span className={`status status-${status.toLowerCase()}`}>
      <i aria-hidden="true" />
      {statusLabels[status]}
    </span>
  );
}
export function Modal({
  title,
  subtitle,
  children,
  onClose,
  wide = false,
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
  onClose: () => void;
  wide?: boolean;
}) {
  const id = useId();
  const titleId = `${id}-title`;
  const descriptionId = `${id}-description`;
  const dialogRef = useRef<HTMLElement>(null);
  const closeRef = useRef(onClose);
  const lastFocusedRef = useRef<HTMLElement | null>(null);
  // Capture before children with autoFocus commit, so closing restores the opener.
  const openerRef = useRef<HTMLElement | null>(
    typeof document !== "undefined" &&
      document.activeElement instanceof HTMLElement
      ? document.activeElement
      : null,
  );
  closeRef.current = onClose;

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    if (!openModals.length) pageOpener = openerRef.current;
    lockPageScroll();
    openModals.push({ id, element: dialog });
    // Preserve an explicitly focused form input; otherwise announce the dialog
    // without opening a mobile keyboard before the user chooses a field.
    if (!dialog.contains(document.activeElement))
      dialog.focus({ preventScroll: true });
    updateModalStack();

    const keydown = (event: KeyboardEvent) => {
      if (!isTopModal(id) || event.defaultPrevented) return;
      if (event.key === "Escape") {
        event.preventDefault();
        event.stopPropagation();
        closeRef.current();
        return;
      }
      if (event.key !== "Tab") return;
      const elements = focusableElements(dialog);
      const first = elements[0];
      const last = elements.at(-1);
      const active = document.activeElement;
      if (!first || !last) {
        event.preventDefault();
        dialog.focus({ preventScroll: true });
      } else if (
        event.shiftKey &&
        (active === first || active === dialog || !dialog.contains(active))
      ) {
        event.preventDefault();
        last.focus();
      } else if (
        !event.shiftKey &&
        (active === last || active === dialog || !dialog.contains(active))
      ) {
        event.preventDefault();
        first.focus();
      }
    };
    const focusin = (event: FocusEvent) => {
      if (!isTopModal(id)) return;
      const target = event.target;
      if (target instanceof HTMLElement && dialog.contains(target)) {
        lastFocusedRef.current = target;
      } else {
        const previous = lastFocusedRef.current;
        if (previous?.isConnected && dialog.contains(previous))
          previous.focus({ preventScroll: true });
        else dialog.focus({ preventScroll: true });
      }
    };
    document.addEventListener("keydown", keydown);
    document.addEventListener("focusin", focusin);
    return () => {
      const wasTop = isTopModal(id);
      const index = openModals.findIndex((entry) => entry.id === id);
      if (index !== -1) openModals.splice(index, 1);
      document.removeEventListener("keydown", keydown);
      document.removeEventListener("focusin", focusin);
      updateModalStack();
      if (!openModals.length) restorePageScroll?.();
      if (wasTop) {
        const parent = openModals.at(-1)?.element;
        const opener = openerRef.current;
        if (opener?.isConnected && (!parent || parent.contains(opener)))
          opener.focus({ preventScroll: true });
        else parent?.focus({ preventScroll: true });
        if (!parent && !opener?.isConnected && pageOpener?.isConnected)
          pageOpener.focus({ preventScroll: true });
      }
      if (!openModals.length) pageOpener = null;
    };
  }, [id]);

  return (
    <div
      className="modal-overlay"
      onClick={(event) => {
        if (event.target === event.currentTarget && isTopModal(id))
          closeRef.current();
      }}
    >
      <section
        ref={dialogRef}
        className={`modal ${wide ? "modal-wide" : ""}`}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={subtitle ? descriptionId : undefined}
        tabIndex={-1}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="modal-heading">
          <div>
            <h2 id={titleId}>{title}</h2>
            {subtitle && <p id={descriptionId}>{subtitle}</p>}
          </div>
          <button
            type="button"
            className="icon-button"
            aria-label="Fermer la fenêtre"
            onClick={() => closeRef.current()}
          >
            <X size={20} aria-hidden="true" />
          </button>
        </div>
        {children}
      </section>
    </div>
  );
}
export function Toast({
  text,
  error = false,
}: {
  text: string;
  error?: boolean;
}) {
  return (
    <div
      className={`toast ${error ? "toast-error" : ""}`}
      role={error ? "alert" : "status"}
      aria-atomic="true"
    >
      {error ? (
        <AlertCircle size={18} aria-hidden="true" />
      ) : (
        <Check size={18} aria-hidden="true" />
      )}{" "}
      {text}
    </div>
  );
}
