"use client";
import { useEffect,useState,type FormEvent } from 'react';
import { Activity,RefreshCw } from 'lucide-react';
import { euro } from '@/lib/catalog';
type State={configurationIssues:string[];notifications:{pending:number;failed:number};invoices:{id:string;amountCents:number;payCurrency:string}[];withdrawalsEnabled:boolean};
export function OperationsPanel({isLive,notify}:{isLive:boolean;notify:(text:string,error?:boolean)=>void}) {
 const [data,setData]=useState<State|null>(null),[busy,setBusy]=useState(false),[error,setError]=useState('');
 async function request(url:string,body?:unknown){const r=await fetch(url,{method:body?'POST':'GET',headers:body?{'Content-Type':'application/json'}:undefined,body:body?JSON.stringify(body):undefined});const value=await r.json();if(!r.ok)throw Error(value.error||'Vérification indisponible.');return value;}
 async function refresh(){try{setError('');setData(await request('/api/admin/operations'));}catch(e){setError((e as Error).message);}}
 useEffect(()=>{if(isLive)void refresh();},[isLive]);
 async function retry(){setBusy(true);try{const r=await request('/api/admin/operations',{action:'retry_notifications'});notify(`${r.retried} notification(s) remise(s) en file.`);await refresh();}catch(e){notify((e as Error).message,true);}finally{setBusy(false);}}
 async function configureBot(){setBusy(true);try{const r=await request('/api/admin/operations',{action:'configure_telegram'});notify(`Bot @${r.botUsername} raccordé.`);}catch(e){notify((e as Error).message,true);}finally{setBusy(false);}}
 async function link(e:FormEvent<HTMLFormElement>,id:string){e.preventDefault();const form=e.currentTarget;const providerPaymentId=String(new FormData(form).get('providerPaymentId')||'');setBusy(true);try{await request(`/api/admin/payments/${id}/link`,{providerPaymentId});notify('Facture vérifiée et rattachée.');await refresh();}catch(e){notify((e as Error).message,true);}finally{setBusy(false);}}
 return <section className="panel admin-section"><div className="section-heading"><div><h2><Activity size={19}/> État de la plateforme</h2><p>Connexions, notifications et factures à vérifier.</p></div>{isLive&&<button className="button button-secondary" disabled={busy} onClick={()=>void refresh()}><RefreshCw size={15}/>Actualiser</button>}</div>
 {!isLive?<div className="notice"><p>Version de démonstration : les connexions de production ne sont pas activées.</p></div>:<>
 {error&&<p role="alert">{error}</p>}{!data&&!error&&<p>Vérification en cours…</p>}{data&&<>
 <button className="button button-secondary" disabled={busy} onClick={()=>void configureBot()}>Raccorder le bot Telegram</button>
 <p style={{marginTop:12}}>{data.configurationIssues.length?'Configuration à compléter :':'Configuration complète.'}</p>{data.configurationIssues.length>0&&<ul>{data.configurationIssues.map(issue=><li key={issue}>{issue}</li>)}</ul>}
 <p style={{marginTop:12,fontSize:13}}>Notifications : {data.notifications.pending} en attente · {data.notifications.failed} en échec. Retraits : {data.withdrawalsEnabled?'activés':'désactivés'}.</p>
 {data.notifications.failed>0&&<button className="button button-secondary" style={{marginTop:12}} disabled={busy} onClick={()=>void retry()}>Relancer les notifications en échec</button>}
 {data.invoices.length>0&&<details style={{marginTop:18}}><summary style={{cursor:'pointer',padding:'12px 0'}}>Factures en attente de synchronisation ({data.invoices.length})</summary><p style={{fontSize:12,lineHeight:1.8}}>Retrouvez la facture dans la passerelle avec sa référence locale. Le serveur vérifiera le montant, la devise et le propriétaire avant de la rattacher.</p>{data.invoices.map(invoice=><form key={invoice.id} onSubmit={e=>void link(e,invoice.id)} style={{display:'flex',flexWrap:'wrap',gap:10,padding:'16px 0',borderBottom:'1px solid var(--line)'}}><div style={{width:'100%',overflowWrap:'anywhere',fontSize:12}}>{invoice.id} · {euro(invoice.amountCents)} · {invoice.payCurrency}</div><input className="input" aria-label={`Identifiant fournisseur pour ${invoice.id}`} name="providerPaymentId" required maxLength={100} placeholder="Identifiant fournisseur" style={{flex:'1 1 180px',minWidth:0}}/><button className="button button-secondary" disabled={busy}>Vérifier et rattacher</button></form>)}</details>}
 </>}
 </>}
 </section>;
}
