"use client";
import { VehicleEstimator } from "./vehicle-estimator";
import { quotePrice, pricingHint, carteGriseIds } from "@/lib/pricing";
import type { VehicleEstimateInput } from "@/lib/vehicle-estimate";
import "./client-accounts.css";
import { useState, type FormEvent } from "react";
import { FileText, Check, X } from "lucide-react";
import { euro, type Order } from "@/lib/catalog";
type Props = { order: Order; live: boolean; admin?: boolean; onUpdate: (order: Order) => void; notify: (message: string, error?: boolean) => void };
export function OrderQuote({ order, live, admin = false, onUpdate, notify }: Props) {
  const [price, setPrice] = useState((order.quoteReferenceCents || order.amount) > 0 ? ((order.quoteReferenceCents || order.amount) / 100).toFixed(2) : "");
  const [vehicleEstimate, setVehicleEstimate] = useState<VehicleEstimateInput | null>(null);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [confirmed, setConfirmed] = useState<string | null>(null);
  const consentKey = `${order.quoteVersion}:${order.amount}`;
  const referenceCents = Math.round(Number(price.replace(",", ".")) * 100);
  let netCents: number | null = null;
  try { if (Number.isSafeInteger(referenceCents) && referenceCents >= 100 && referenceCents <= 10_000_000) netCents = quotePrice(referenceCents, order.pricingSnapshot); } catch {}
  const pending = ["AWAITING_QUOTE", "QUOTE_PROPOSED"].includes(order.status);
  if (!order.requiresQuote || (!pending && order.status !== "QUOTE_REJECTED")) return null;
  async function change(action: "propose" | "accept" | "reject") {
    if (busy) return;
    setBusy(true);
    try {
      let amountCents = order.amount;
      if (action === "propose") {
        if (!/^\d+(?:[.,]\d{1,2})?$/.test(price)) throw new Error("Saisissez un prix avec deux décimales maximum.");
        amountCents = Math.round(Number(price.replace(",", ".")) * 100);
        if (!Number.isSafeInteger(amountCents) || amountCents < 100 || amountCents > 10_000_000) throw new Error("Le prix doit être compris entre 1 € et 100 000 €.");
      }
      let updated: Order;
      if (live) {
        const response = await fetch(`/api/${admin ? "admin/" : ""}orders/${order.id}/quote`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(action === "propose" ? { amountCents, expectedVersion: order.quoteVersion ?? 0, note, ...(vehicleEstimate ? { vehicleEstimate } : {}) } : { action, quoteVersion: order.quoteVersion }) });
        const raw = await response.json();
        if (!response.ok) throw new Error(raw.error || "Le devis n’a pas pu être mis à jour.");
        updated = { ...order, status: raw.status, amount: raw.priceCents, pricingSnapshot: raw.pricingSnapshot, quoteReferenceCents: raw.quoteReferenceCents, quoteVersion: raw.quoteVersion, quoteAcceptedAt: raw.quoteAcceptedAt, note: raw.events?.at(-1)?.note || order.note };
      } else {
        const finalCents = action === "propose" ? quotePrice(amountCents, order.pricingSnapshot) : amountCents;
        updated = { ...order, amount: finalCents, ...(action === "propose" ? { quoteReferenceCents: amountCents } : {}), status: action === "propose" ? "QUOTE_PROPOSED" : action === "accept" ? "AWAITING_PAYMENT" : "QUOTE_REJECTED", quoteVersion: (order.quoteVersion ?? 0) + (action === "propose" ? 1 : 0), quoteAcceptedAt: action === "accept" ? new Date().toISOString() : null,
          note: action === "propose" ? `Prix proposé : ${euro(finalCents)}.${note ? ` ${note}` : ""}` : action === "accept" ? "Devis accepté. Le traitement commencera après paiement." : "Devis refusé. Aucun paiement effectué." };
      }
      onUpdate(updated);
      setConfirmed(null);
      notify(action === "propose" ? "Prix proposé au revendeur." : action === "accept" ? "Devis accepté. Vous pouvez maintenant régler." : "Devis refusé. Aucun montant débité.");
    } catch (error) { notify((error as Error).message, true); }
    finally { setBusy(false); }
  }
  return <section className="order-quote-panel">
    <div className="order-quote-heading"><FileText size={22} /><div><h3>{order.status === "AWAITING_QUOTE" ? "Dossier en attente de devis" : order.status === "QUOTE_PROPOSED" ? (admin ? "Prix proposé au revendeur" : "Une proposition de prix vous attend") : "Devis refusé"}</h3><p>{order.status === "AWAITING_QUOTE" ? "Le dossier est déposé. Aucun paiement ne sera demandé avant votre accord sur le prix." : order.status === "QUOTE_PROPOSED" ? (admin ? "Le revendeur peut accepter ou refuser ce prix. Vous pouvez le revoir avant son accord." : "Vérifiez le montant, puis acceptez pour accéder au paiement ou refusez la proposition.") : "Cette proposition est clôturée. Aucun paiement n’est demandé."}</p></div></div>
    {order.status === "QUOTE_PROPOSED" && <div className="order-quote-price"><span>Prix total proposé</span><strong>{euro(order.amount)}</strong></div>}
    {admin && pending && carteGriseIds.includes(order.serviceId) && <VehicleEstimator onUse={(cents, input) => { setPrice((cents / 100).toFixed(2)); setVehicleEstimate(input); }} />}
    {admin && pending ? <form className="order-quote-form" onSubmit={(event: FormEvent) => { event.preventDefault(); void change("propose"); }}>
      <label className="form-field">{order.pricingSnapshot?.discountBps ? "Montant de référence avant remise (€)" : "Montant de référence du devis (€)"}<input required inputMode="decimal" value={price} onChange={event => { setPrice(event.target.value); setVehicleEstimate(null); }} placeholder="Montant du devis" /></label>
      {netCents !== null && <div className="client-price-preview"><strong>Prix proposé au client : {euro(netCents)}</strong><span>{pricingHint(order.pricingSnapshot) || "Tarif de ce dossier"}</span></div>}
      <label className="form-field">Message au revendeur (facultatif)<textarea maxLength={4000} value={note} onChange={event => setNote(event.target.value)} placeholder="Précisions sur la proposition…" /></label>
      <p>Le traitement et le paiement resteront bloqués jusqu’à l’acceptation du revendeur. Le prix ne pourra plus être modifié après son accord.</p>
      <button className="button button-primary" disabled={busy}>{busy ? "Envoi…" : order.status === "QUOTE_PROPOSED" ? "Envoyer une nouvelle proposition" : "Proposer ce prix"}</button>
    </form> : !admin && order.status === "QUOTE_PROPOSED" ? <div className="order-quote-actions">
      <label className="consent"><input type="checkbox" checked={confirmed === consentKey} onChange={event => setConfirmed(event.target.checked ? consentKey : null)} /><span>J’accepte le prix de {euro(order.amount)}. Je réglerai ensuite pour lancer la démarche.</span></label>
      <div><button className="button button-primary" disabled={busy || confirmed !== consentKey} onClick={() => void change("accept")}><Check size={17} /> Accepter le devis</button><button className="button button-secondary" disabled={busy} onClick={() => void change("reject")}><X size={17} /> Refuser</button></div>
    </div> : null}
  </section>;
}
