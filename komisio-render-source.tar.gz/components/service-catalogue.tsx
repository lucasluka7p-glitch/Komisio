"use client";
import { useEffect, useRef, useState } from "react";
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUpRight, Building2, CarFront, ClipboardCheck, CreditCard, Gauge, Gift, Info, Check, ChevronRight, Clock, FileText, FolderCheck, Layers, ListFilter, Search, ShieldCheck, Sparkles, X } from "lucide-react";
import { pricingHint } from "@/lib/pricing";
import { euro, servicePrice, subcategories, usesStructuredCustomer, type Service } from "@/lib/catalog";
import { attachmentSummary, catalogueGroupLabels, catalogueSections, serviceSection, type CatalogueSectionId, findCatalogueServices, quickCatalogueServices, serviceSummary, shortServiceTitle } from "@/lib/catalogue-view";
import { KomiAvatar } from "./komi-guide";
import { Modal } from "./ui";
import "./service-catalogue.css";
const sectionIcons = { immatriculation: CarFront, automobile: Gauge, informations: Info, permis: ClipboardCheck, remboursements: CreditCard, administratif: FolderCheck, "offres-pro": Gift };
const suggestions = ["Carte grise", "WW", "Création", "CEDEO"];
export function ServiceCatalogue({ services, onSelect, onHelp }: { services: Service[]; onSelect: (service: Service) => void; onHelp: () => void }) {
  const [category, setCategory] = useState<"all" | CatalogueSectionId>("all");
  const [group, setGroup] = useState("all");
  const [query, setQuery] = useState("");
  const [pricing, setPricing] = useState("all");
  const [sort, setSort] = useState("recommended");
  const [showAll, setShowAll] = useState(false);
  const [preview, setPreview] = useState<Service | null>(null);
  const heading = useRef<HTMLHeadingElement>(null);
  const moveToResults = useRef(false);
  const previewFields = preview ? [...(!usesStructuredCustomer(preview.id) ? [{ key: "_clientName", label: "Nom complet du client", required: true }, { key: "_clientEmail", label: "Adresse e-mail", required: false }] : []), ...preview.fields] : [];
  const active = services.filter(service => service.active);
  const landing = category === "all" && !query.trim() && pricing === "all" && !showAll;
  const filtered = findCatalogueServices(services, { category: "all", section: category, group, query, pricing, sort });
  const visible = landing ? quickCatalogueServices(services) : filtered;
  const section = catalogueSections.find(item => item.id === category);
  const groups = subcategories.filter(item => active.some(service => serviceSection(service).id === category && service.subcategory === item.id && item.category === service.category));
  const hasOther = category !== "all" && active.some(service => serviceSection(service).id === category && !subcategories.some(item => item.category === service.category && item.id === service.subcategory));
  useEffect(() => {
    if (!moveToResults.current) return;
    moveToResults.current = false;
    heading.current?.focus({ preventScroll: true });
    heading.current?.scrollIntoView({ block: "start", behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth" });
  }, [category, showAll]);
  function browse(next: "all" | CatalogueSectionId) {
    if (next === category && showAll) {
      heading.current?.focus({ preventScroll: true });
      heading.current?.scrollIntoView({ block: "start", behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth" });
    } else moveToResults.current = true;
    setCategory(next); setGroup("all"); setQuery(""); setPricing("all"); setShowAll(true);
  }
  function reset() {
    setCategory("all"); setGroup("all"); setQuery(""); setPricing("all"); setShowAll(false); setSort("recommended");
    window.scrollTo({ top: 0, behavior: "instant" });
  }
  return <section className="catalogue-explorer" aria-label="Catalogue des services">
    <header className="catalogue-intro">
      <div><div className="catalogue-kicker"><span /> LE CATALOGUE KOMISIO</div><h1>Un besoin.<br className="catalogue-mobile-break" /> <span>Le bon service.</span></h1><p>Chaque démarche à sa place. Trouvez la vôtre en quelques secondes.</p></div>
      <span className="catalogue-total"><Layers size={15} /> {active.length} services à votre disposition</span>
    </header>
    <button type="button" className="komi-catalogue-invite" onClick={onHelp}><KomiAvatar /><span><small>UN COUP DE MAIN ?</small><strong>Komi vous aide à trouver le bon service.</strong><span>Je vous guide et vous aide à préparer les bonnes pièces.</span></span><span className="komi-invite-action">Me guider <ArrowRight size={16} /></span></button>
    <div className="catalogue-search-wrap">
      <label className="catalogue-search"><Search size={22} aria-hidden="true" /><input type="search" aria-label="Rechercher un service" placeholder="Carte grise, WW, création de société…" value={query} onChange={event => setQuery(event.target.value)} />{query && <button type="button" onClick={() => setQuery("")} aria-label="Effacer la recherche"><X size={18} /></button>}<span className="catalogue-search-hint">Trouvez votre démarche</span></label>
      <div className="catalogue-suggestions"><span>Accès direct</span>{suggestions.map(value => <button type="button" key={value} onClick={() => { setCategory("all"); setGroup("all"); setPricing("all"); setQuery(value); }}>{value}<ArrowUpRight size={12} /></button>)}</div>
    </div>
    <div className="catalogue-universe-title"><h2>Nos services, bien rangés</h2>{!landing && <button type="button" onClick={reset}><ArrowLeft size={14} /> Retour à l’accueil</button>}</div>
    <nav className={`catalogue-universes ${!landing ? "is-compact" : ""}`} aria-label="Rubriques de services">
      {catalogueSections.map(item => {
        const Icon = sectionIcons[item.id]; const count = active.filter(service => serviceSection(service).id === item.id).length;
        return <button key={item.id} type="button" data-section={item.id} data-tone={item.tone} aria-pressed={category === item.id} aria-label={`Explorer ${item.label} · ${count} services`} onClick={() => browse(item.id)} className={`catalogue-universe ${category === item.id ? "is-selected" : ""}`}>
          <span className="catalogue-universe-icon"><Icon size={25} strokeWidth={1.7} /></span><span className="catalogue-universe-content"><strong>{item.label}</strong><span>{item.description}</span><small>{count} service{count > 1 ? "s" : ""} <ArrowRight size={13} /></small></span><ChevronRight size={18} className="catalogue-universe-arrow" />
        </button>;
      })}
    </nav>
    {category !== "all" && (groups.length > 1 || hasOther) && <div className="catalogue-subgroups" role="group" aria-label="Affiner la catégorie"><button type="button" aria-pressed={group === "all"} onClick={() => setGroup("all")}>Tout afficher</button>{groups.map(item => <button type="button" key={item.id} aria-pressed={group === item.id} onClick={() => setGroup(item.id)}>{catalogueGroupLabels[item.id] || item.label}</button>)}{hasOther && <button type="button" aria-pressed={group === "other"} onClick={() => setGroup("other")}>Autres prestations</button>}</div>}
    <div className="catalogue-results-heading">
      <div><div className="catalogue-results-kicker">{landing ? <><Sparkles size={14} /> POUR COMMENCER</> : <><ListFilter size={14} /> VOTRE SÉLECTION</>}</div><h2 ref={heading} tabIndex={-1}>{landing ? "Les essentiels" : query.trim() ? "Résultats de recherche" : (group !== "all" ? catalogueGroupLabels[group] || (group === "other" ? "Autres prestations" : "Services") : section?.label) || "Tous les services"}<span aria-live="polite" aria-atomic="true">{visible.length}</span></h2><p>{landing ? "Un raccourci vers vos démarches du quotidien." : `${visible.length} service${visible.length > 1 ? "s" : ""}${query.trim() ? ` pour « ${query.trim()} »` : " dans cette sélection"}.`}</p></div>
      {landing ? <button type="button" className="catalogue-see-all" onClick={() => browse("all")}>Tout afficher ({active.length}) <ArrowRight size={16} /></button> : <label className="catalogue-sort"><span>Trier par</span><select aria-label="Trier les services" value={sort} onChange={event => setSort(event.target.value)}><option value="recommended">Sélection Komisio</option><option value="name">Nom de A à Z</option><option value="price">Prix croissant</option></select></label>}
    </div>
    {!landing && <div className="catalogue-result-tools"><div className="catalogue-pricing" role="group" aria-label="Type de tarif">{[{ id: "all", label: "Tous les tarifs" }, { id: "fixed", label: "Prix fixe" }, { id: "quote", label: "Sur devis" }].map(item => <button type="button" key={item.id} aria-pressed={pricing === item.id} onClick={() => setPricing(item.id)}>{pricing === item.id && <Check size={13} />}{item.label}</button>)}</div><button type="button" className="catalogue-clear" onClick={reset}>Réinitialiser</button></div>}
    <div className="catalogue-grid">{visible.map(service => {
      const family = serviceSection(service);
      const Icon = sectionIcons[family.id];
      return <article key={service.id} className="catalogue-card" data-service={service.id} data-section={family.id} data-tone={family.tone}>
        <div className="catalogue-card-top"><span className="catalogue-card-icon"><Icon size={21} strokeWidth={1.7} /></span><span>{family?.label}</span>{service.requiresQuote && <span className="catalogue-quote-tag">Sur devis</span>}</div>
        <h3>{shortServiceTitle(service)}</h3><p className="catalogue-card-description">{serviceSummary(service)}</p>
        <div className="catalogue-card-facts"><span><Clock size={14} />{service.delay}</span><span><FileText size={14} />{attachmentSummary(service)}</span></div>
        {service.pricing && pricingHint(service.pricing, !!service.requiresQuote) && <p className="catalogue-client-pricing">{pricingHint(service.pricing, !!service.requiresQuote)}</p>}
        <div className="catalogue-card-price"><div><small>{service.requiresQuote ? "Prix après étude du dossier" : "Tarif partenaire"}</small><strong>{service.requiresQuote ? "Sur devis" : euro(service.price)}{!service.requiresQuote && <span> / dossier</span>}</strong></div><button type="button" onClick={() => setPreview(service)} aria-label={`Voir les détails de ${service.title}`}>Détails <ArrowUpRight size={14} /></button></div>
        <button type="button" className="catalogue-card-action" aria-label={(service.requiresQuote ? "Déposer un dossier pour " : "Commander ") + service.title} onClick={() => onSelect(service)}>{service.requiresQuote ? "Demander un devis" : "Choisir ce service"}<ArrowRight size={16} /></button>
      </article>;
    })}</div>
    {!visible.length && <div className="catalogue-empty"><Search size={28} /><h3>Aucun service trouvé</h3><p>Essayez un mot plus simple ou élargissez votre sélection.</p><button type="button" className="button button-secondary" onClick={reset}>Réinitialiser les filtres</button></div>}
    {landing && active.length > visible.length && <button type="button" className="catalogue-explore-all" onClick={() => browse("all")}>Explorer les {active.length} services <ArrowDown size={16} /></button>}
    <div className="catalogue-guidance"><span className="catalogue-guidance-icon"><ShieldCheck size={23} /></span><div><strong>Un dossier clair, dès le départ.</strong><p>Consultez les pièces à préparer dans « Détails ». Pour un service sur devis, vous validez le prix avant de payer.</p></div></div>
    {preview && <Modal title={preview.title} subtitle="Tout savoir avant de commencer" onClose={() => setPreview(null)} wide>
      <div className="catalogue-detail-overview"><div><small>{preview.requiresQuote ? "PROPOSITION APRÈS ÉTUDE" : "TARIF PARTENAIRE"}</small><strong>{servicePrice(preview)}</strong></div><div><small>DÉLAI INDICATIF</small><strong><Clock size={16} />{preview.delay}</strong></div></div>
      <p className="catalogue-detail-description">{preview.description}</p>
      <div className="catalogue-detail-columns"><section><h3><FileText size={17} /> Pièces à préparer</h3>{preview.documents.length ? <ul>{preview.documents.map((document,index) => <li key={preview.documentKeys?.[index] || `${index}-${document}`}><span>{document}</span><small>{preview.documentRequired?.[index] === false ? "Facultative" : "Requise"}</small></li>)}</ul> : <p>Aucune pièce jointe demandée au dépôt.</p>}</section><section><h3><FolderCheck size={17} /> Informations du dossier</h3>{previewFields.length ? <ul>{previewFields.map(field => <li key={field.key}><span>{field.label}</span><small>{field.required ? "À renseigner" : "Facultatif"}</small></li>)}</ul> : <p>Les pièces suffisent pour préparer votre dossier.</p>}</section></div>
      {preview.requiresQuote && <div className="catalogue-detail-note"><ShieldCheck size={18} /><p>Le dépôt ne déclenche aucun débit. Vous pourrez accepter ou refuser le prix proposé avant tout paiement.</p></div>}
      <div className="modal-footer"><button type="button" className="button button-secondary" onClick={() => setPreview(null)}>Retour</button><button type="button" className="button button-primary" onClick={() => { setPreview(null); onSelect(preview); }}>Préparer mon dossier <ArrowRight size={16} /></button></div>
    </Modal>}
  </section>;
}
