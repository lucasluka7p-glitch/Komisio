"use client";
import { useEffect, useRef, useState, type FormEvent } from "react";
import { ArrowUpRight, RefreshCw, ShieldCheck, ExternalLink, Clock } from "lucide-react";
import { Modal } from "./ui";
import { euro, dateFR } from "@/lib/catalog";
import { withdrawalLabels, reservedStatuses, type WithdrawalView } from "@/lib/withdrawals";

type Props = {
  isLive: boolean; admin?: boolean; balance: number;
  onBalanceChange: (amount: number, reason: string) => void;
  onRefresh?: () => Promise<void>;
  notify: (message: string, error?: boolean) => void;
};
const storageKey = "forma-demo-withdrawals-v1";
function cents(value: string) {
  if (!/^\d+(?:[.,]\d{1,2})?$/.test(value)) throw new Error("Saisissez un montant avec deux décimales maximum.");
  const [whole, fraction = ""] = value.replace(",", ".").split(".");
  const amount = Number(whole) * 100 + Number(fraction.padEnd(2, "0"));
  if (!Number.isSafeInteger(amount) || amount > 10_000_000) throw new Error("Montant trop élevé (maximum 100 000 €).");
  return amount;
}
async function call(path: string, values?: object) {
  const response = await fetch(path, { cache: "no-store", ...(values ? { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(values) } : {}) });
  const data = await response.json();
  if (!response.ok) throw new Error(data.issues?.[0]?.message || data.error || "Demande impossible.");
  return data;
}
export function WithdrawalsPanel({ isLive, admin = false, balance, onBalanceChange, onRefresh, notify }: Props) {
  const [plisioEnabled,setPlisioEnabled] = useState(false);
  const [operationId,setOperationId] = useState("");
  const [items, setItems] = useState<WithdrawalView[]>([]);
  const [enabled, setEnabled] = useState(!isLive);
  const [loaded, setLoaded] = useState(false);
  const [loadError, setLoadError] = useState("");
  const [busy, setBusy] = useState(false);
  const [creating, setCreating] = useState(false);
  const [selected, setSelected] = useState<WithdrawalView | null>(null);
  const [amount, setAmount] = useState("");
  const [address, setAddress] = useState("");
  const [fee, setFee] = useState("");
  const [rate, setRate] = useState("");
  const [source, setSource] = useState("");
  const [note, setNote] = useState("");
  const [hash, setHash] = useState("");
  const [checked, setChecked] = useState(false);
  const requestKey = useRef("");
  const base = admin ? "/api/admin/withdrawals" : "/api/withdrawals";
  async function refresh() {
    try {
      if (isLive) {
        const result = await call(base);
        setItems(result.withdrawals);
        if (admin) setPlisioEnabled(result.plisioEnabled === true);
        if (!admin) setEnabled(result.enabled);
      } else setItems(JSON.parse(localStorage.getItem(storageKey) || "[]"));
      setLoadError(""); setLoaded(true);
    } catch (error) { setLoadError(error instanceof Error ? error.message : "Chargement impossible."); }
  }
  useEffect(() => {
    void refresh();
    if (isLive) { const timer = setInterval(() => void refresh(), 15000); return () => clearInterval(timer); }
    // Reload on navigation: the demo shares this history between partner and admin.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isLive, admin]);
  const current = selected ? items.find(item => item.id === selected.id) || selected : null;
  const reserved = items.filter(w => reservedStatuses.includes(w.status)).reduce((sum, w) => sum + w.amountCents, 0);
  function saveDemo(next: WithdrawalView[]) { localStorage.setItem(storageKey, JSON.stringify(next)); setItems(next); }
  function open(w: WithdrawalView) { setSelected(w); setFee(w.feeCents === null ? "" : (w.feeCents / 100).toFixed(2)); setRate(w.exchangeRate || ""); setSource(w.quoteSource || ""); setNote(""); setHash(""); setChecked(false); }
  async function create(event: FormEvent) {
    event.preventDefault(); if (busy) return;
    setBusy(true);
    try {
      const amountCents = cents(amount);
      if (amountCents < 1 || amountCents > balance) throw new Error("Montant supérieur au solde disponible ou nul.");
      const destination = address.trim();
      if (!/^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(destination)) throw new Error("Saisissez une adresse TRON (TRC20) valide.");
      if (!checked) throw new Error("Vérifiez l’adresse et le réseau avant de continuer.");
      if (!requestKey.current) requestKey.current = crypto.randomUUID();
      if (isLive) await call(base, { amountCents, address: destination, currency: "usdttrc20", idempotencyKey: requestKey.current });
      else {
        if (items.filter(w => ["REQUESTED", "QUOTED"].includes(w.status)).length >= 5) throw new Error("Cinq demandes sont déjà en attente.");
        saveDemo([{ id: requestKey.current, amountCents, address: destination, currency: "usdttrc20", status: "REQUESTED", quoteVersion: 0, feeCents: null, exchangeRate: null, netAmount: null, quoteSource: null, quoteExpiresAt: null, txHash: null, note: null, createdAt: new Date().toISOString() }, ...items]);
      }
      setCreating(false); requestKey.current = "";
      if (isLive) await refresh();
      notify("Demande enregistrée. Vous confirmerez après réception des frais. Aucun débit pour le moment.");
    } catch (error) { notify((error as Error).message, true); }
    finally { setBusy(false); }
  }
  async function act(action: string, values: Record<string, unknown> = {}) {
    if (!current || busy) return;
    setBusy(true);
    try {
      if (isLive) { await call(`${base}/${current.id}`, { action, ...values }); await refresh(); await onRefresh?.(); }
      else {
        let next = { ...current };
        let change = 0;
        if (action === "quote") {
          const feeCents = Number(values.feeCents), exchangeRate = Number(values.exchangeRate);
          if (feeCents >= current.amountCents || !Number.isFinite(exchangeRate) || exchangeRate <= 0) throw new Error("Frais trop élevés ou taux invalide.");
          next = { ...next, feeCents, exchangeRate: String(values.exchangeRate), netAmount: (Math.floor((current.amountCents - feeCents) / 100 * exchangeRate * 1e6) / 1e6).toFixed(6), quoteSource: String(values.source), quoteExpiresAt: new Date(Date.now() + 15 * 60_000).toISOString(), quoteVersion: next.quoteVersion + 1, status: "QUOTED" };
        } else if (action === "accept") {
          if (current.status !== "QUOTED" || !current.quoteExpiresAt || new Date(current.quoteExpiresAt).getTime() <= Date.now()) throw new Error("Le devis est expiré ou indisponible.");
          if (balance < current.amountCents) throw new Error("Solde disponible insuffisant.");
          next.status = "APPROVED"; change = -current.amountCents;
        } else if (action === "cancel" || action === "reject") {
          if (!["REQUESTED", "QUOTED", "APPROVED"].includes(current.status)) throw new Error("L’envoi a déjà commencé.");
          if (current.status === "APPROVED") change = current.amountCents;
          next.status = action === "cancel" ? "CANCELLED" : "REJECTED"; next.note = String(values.note || "Annulé par le titulaire.");
        } else if (action === "fail") { next.status = "FAILED"; next.note = String(values.note); change = current.amountCents; }
        else if (action === "process") next.status = "PROCESSING";
        else if (action === "sent") { next.status = "SENT"; next.txHash = String(values.txHash).toLowerCase(); }
        else if (action === "complete") { next.status = "COMPLETED"; next.note = String(values.note); }
        saveDemo(items.map(w => w.id === next.id ? next : w));
        if (change) onBalanceChange(change, `${change < 0 ? "Réservation" : "Libération"} du retrait ${current.id.slice(-8)}`);
      }
      setSelected(null); notify(isLive ? "Retrait mis à jour." : "Simulation mise à jour. Aucune crypto envoyée.");
    } catch (error) { notify((error as Error).message, true); }
    finally { setBusy(false); }
  }
  async function plisio(action: string) {
    if (!current || busy) return;
    setBusy(true);
    try { await call(`/api/admin/withdrawals/${current.id}/plisio`,{ action, ...(action === "link" ? { operationId } : {}) }); await refresh(); notify("Retrait Plisio mis à jour."); } catch(error) { notify((error as Error).message,true); } finally { setBusy(false); }
  }
  const expired = current?.quoteExpiresAt ? new Date(current.quoteExpiresAt).getTime() <= Date.now() : true;
  return <section className="panel withdrawal-panel">
    <div className="section-heading"><div><div className="eyebrow">RETRAITS CRYPTO</div><h2>{admin ? "Gérer les retraits" : "Votre argent, disponible"}</h2><p>Demandes 24 h/24 · USDT sur TRC20 · validation admin</p></div>
      {admin ? <button className="button button-secondary" onClick={() => void refresh()}><RefreshCw size={16} /> Actualiser</button> : <button className="button button-primary" disabled={!loaded || !enabled} onClick={() => { setCreating(true); setAmount(""); setAddress(""); setChecked(false); requestKey.current = ""; }}><ArrowUpRight size={17} /> Retirer</button>}
    </div>
    <div className="withdrawal-notice"><ShieldCheck size={19} /><p>{!isLive ? "Mode démonstration : aucun retrait réel. Testez les frais dans Admin → Finances." : !enabled && !admin ? "Les retraits seront disponibles après activation du service." : "Aucune commission plateforme. Les frais réseau, prestataire et conversion sont présentés avant votre confirmation. Le délai dépend du traitement et du réseau."}</p></div>
    {!admin && reserved > 0 && <p className="withdrawal-reserved"><Clock size={16} /> {euro(reserved)} réservés pour vos retraits, déjà déduits du solde disponible.</p>}
    {loadError && <p role="alert">{loadError} <button className="button button-secondary" onClick={() => void refresh()}>Réessayer</button></p>}
    {!loaded && !loadError && <p role="status">Chargement des retraits…</p>}
    {loaded && !items.length && <div className="withdrawal-empty"><ArrowUpRight size={25} /><strong>Aucun retrait pour le moment</strong><p>Vos demandes et leurs confirmations apparaîtront ici.</p></div>}
    <div className="withdrawal-list">{items.map(w => <button key={w.id} className="withdrawal-row" onClick={() => open(w)}><span className="withdrawal-icon"><ArrowUpRight size={20} /></span><span><strong>{euro(w.amountCents)} <small>→ USDT TRC20</small></strong><span>{admin && w.user ? `${w.user.firstName} · ` : ""}{dateFR(w.createdAt)} · #{w.id.slice(-8)}</span></span><span className={`withdrawal-badge withdrawal-${w.status.toLowerCase()}`}>{withdrawalLabels[w.status]}</span></button>)}</div>
    {creating && <Modal title="Retirer de mon portefeuille" subtitle="Recevez un devis avant de confirmer votre retrait." onClose={() => !busy && setCreating(false)}><form onSubmit={create} className="withdrawal-form">
      <div className="withdrawal-summary"><span>Solde disponible</span><strong>{euro(balance)}</strong></div>
      <label className="form-field">Montant total à débiter (€)<input required inputMode="decimal" value={amount} onChange={e => { setAmount(e.target.value); requestKey.current = ""; }} placeholder="100,00" /></label>
      <label className="form-field">Crypto et réseau<input readOnly value="USDT · TRON (TRC20)" /></label>
      <label className="form-field">Adresse de réception<input required autoComplete="off" spellCheck={false} value={address} onChange={e => { setAddress(e.target.value); setChecked(false); requestKey.current = ""; }} placeholder="T…" /><small>Utilisez une adresse compatible USDT sur TRON.</small></label>
      <label className="withdrawal-check"><input type="checkbox" checked={checked} onChange={e => setChecked(e.target.checked)} required /><span>J’ai vérifié l’adresse et le réseau TRC20.</span></label>
      <p className="withdrawal-help">Aucun débit à cette étape. Vous verrez les frais et le montant net à recevoir avant d’accepter. Le solde sera réservé à votre confirmation.</p>
      <button className="button button-primary" disabled={busy}>{busy ? "Enregistrement…" : "Demander les frais du retrait"}</button>
    </form></Modal>}
    {current && <Modal title={`Retrait #${current.id.slice(-8)}`} subtitle={withdrawalLabels[current.status]} onClose={() => !busy && setSelected(null)}><div className="withdrawal-form">
      <div className="withdrawal-summary"><span>Montant total</span><strong>{euro(current.amountCents)}</strong></div>
      <div className="withdrawal-destination"><span>USDT · TRON (TRC20)</span><code>{current.address}</code></div>
      {current.feeCents !== null && <div className="withdrawal-quote"><div><span>Frais totaux déduits</span><strong>{euro(current.feeCents)}</strong></div><div><span>Commission plateforme</span><strong>0 €</strong></div><div><span>Montant net à recevoir</span><strong>{current.netAmount} USDT</strong></div><small>Taux : 1 € = {current.exchangeRate} USDT · Source : {current.quoteSource}</small>{current.status === "QUOTED" && <small>{expired ? "Devis expiré — un nouveau devis est nécessaire." : `Valable jusqu’à ${new Date(current.quoteExpiresAt!).toLocaleTimeString("fr-FR")}`}</small>}</div>}
      {current.note && <p className="withdrawal-help">{current.note}</p>}
      {current.txHash && <a className="withdrawal-explorer" target="_blank" rel="noopener noreferrer" href={`https://tronscan.org/#/transaction/${current.txHash}`}><ExternalLink size={17} /> Consulter la transaction sur TRON<code>{current.txHash}</code></a>}
      {!admin && current.status === "QUOTED" && <><label className="withdrawal-check"><input type="checkbox" checked={checked} onChange={e => setChecked(e.target.checked)} /><span>J’accepte les frais et confirme l’adresse ci-dessus.</span></label><button className="button button-primary" disabled={busy || !checked || expired} onClick={() => void act("accept", { quoteVersion: current.quoteVersion })}>Confirmer · réserver {euro(current.amountCents)}</button></>}
      {!admin && ["REQUESTED", "QUOTED", "APPROVED"].includes(current.status) && <button className="button button-secondary" disabled={busy} onClick={() => void act("cancel")}>Annuler le retrait</button>}
      {admin && isLive && plisioEnabled && <div className="withdrawal-plisio">
        {["REQUESTED","QUOTED"].includes(current.status) && <button className="button button-primary" disabled={busy} onClick={() => void plisio("quote")}>Calculer les frais avec Plisio</button>}
        {current.status === "APPROVED" && <button className="button button-primary" disabled={busy} onClick={() => void plisio("send")}>Envoyer via Plisio · {current.netAmount} USDT</button>}
        {current.provider === "PLISIO" && ["PROCESSING","SENT"].includes(current.status) && <><p className="withdrawal-help">{current.providerTransferId ? `Opération Plisio : ${current.providerTransferId}` : "Réponse d’envoi inconnue : retrouvez l’opération dans Plisio avant toute autre action."}</p><button className="button button-secondary" disabled={busy} onClick={() => void plisio("reconcile")}>Vérifier l’état Plisio</button>{!current.providerTransferId && <form className="withdrawal-form" onSubmit={event => { event.preventDefault(); void plisio("link"); }}><label className="form-field">Identifiant d’opération Plisio<input required maxLength={100} value={operationId} onChange={event => setOperationId(event.target.value)} /></label><button className="button button-secondary" disabled={busy}>Vérifier et rattacher</button></form>}</>}
      </div>}
      {admin && ["REQUESTED", "QUOTED"].includes(current.status) && <form className="withdrawal-form" onSubmit={event => { event.preventDefault(); try { void act("quote", { feeCents: cents(fee), exchangeRate: rate.replace(",", "."), source }); } catch (error) { notify((error as Error).message, true); } }}><p className="withdrawal-help">Renseignez les frais et le taux vérifiés auprès du prestataire. Le devis sera valable 15 minutes. Aucun ajout de marge.</p><label className="form-field">Frais totaux (€)<input required inputMode="decimal" value={fee} onChange={e => setFee(e.target.value)} placeholder="Frais vérifiés" /></label><label className="form-field">Taux : USDT pour 1 €<input required inputMode="decimal" value={rate} onChange={e => setRate(e.target.value)} placeholder="Taux vérifié" /></label><label className="form-field">Référence du devis prestataire<input required minLength={3} maxLength={250} value={source} onChange={e => setSource(e.target.value)} /></label><button className="button button-primary" disabled={busy}>Proposer les frais au revendeur</button></form>}
      {admin && current.status === "APPROVED" && <><p className="withdrawal-help">Vérifiez les fonds disponibles, le montant net et l’adresse. Cliquez avant d’effectuer l’envoi externe : l’annulation sera alors bloquée pour éviter un remboursement pendant l’envoi.</p><button className="button button-primary" disabled={busy} onClick={() => void act("process")}>Prendre en charge l’envoi manuel</button></>}
      {admin && current.status === "PROCESSING" && current.provider === "PLISIO" && <details><summary>Réconcilier manuellement un transfert déjà lancé</summary><form className="withdrawal-form" onSubmit={event=>{event.preventDefault();void act("sent",{txHash:hash});}}><p className="withdrawal-help">Retrouvez le transfert existant dans Plisio et sur TRON. Vérifiez réseau, destinataire et montant. Aucun nouvel envoi ne doit être effectué.</p><label className="form-field">Hash du transfert existant<input required pattern="[a-fA-F0-9]{64}" value={hash} onChange={event=>setHash(event.target.value)}/></label><label className="withdrawal-check"><input required type="checkbox" checked={checked} onChange={event=>setChecked(event.target.checked)}/><span>J’ai vérifié que ce transfert correspond à ce retrait.</span></label><button className="button button-secondary" disabled={busy||!checked}>Enregistrer le transfert vérifié</button></form></details>}
      {admin && current.status === "PROCESSING" && current.provider !== "PLISIO" && <form className="withdrawal-form" onSubmit={e => { e.preventDefault(); void act("sent", { txHash: hash }); }}><p className="withdrawal-help">Effectuez l’envoi depuis votre prestataire, puis renseignez sa transaction. Aucun envoi n’est déclenché par ce formulaire. En cas d’erreur ou de délai, réconciliez l’opération avant toute nouvelle tentative.</p><label className="form-field">Hash de transaction TRON<input required pattern="[a-fA-F0-9]{64}" value={hash} onChange={e => setHash(e.target.value)} spellCheck={false} /></label><button className="button button-primary" disabled={busy}>Enregistrer la transaction envoyée</button></form>}
      {admin && current.status === "SENT" && <form className="withdrawal-form" onSubmit={e => { e.preventDefault(); void act("complete", { note }); }}><label className="form-field">Preuve de vérification réseau<textarea required minLength={3} maxLength={1000} value={note} onChange={e => setNote(e.target.value)} placeholder="Vérifiez réussite, réseau, jeton, adresse et montant reçu." /></label><button className="button button-primary" disabled={busy}>Confirmer après vérification sur le réseau</button></form>}
      {admin && ["PROCESSING", "SENT"].includes(current.status) && <form className="withdrawal-form" onSubmit={e => { e.preventDefault(); void act("fail", { note, confirmedNoFundsMoved: true }); }}><p className="withdrawal-help">Réconciliation d’un échec définitif uniquement. Un retard ou une réponse inconnue ne justifie pas une libération du solde.</p><label className="form-field">Preuve d’échec et référence de vérification<textarea required minLength={20} maxLength={1000} value={note} onChange={e => setNote(e.target.value)} /></label><label className="withdrawal-check"><input required type="checkbox" checked={checked} onChange={e => setChecked(e.target.checked)} /><span>J’ai vérifié auprès du prestataire et du réseau qu’aucun transfert n’a abouti et qu’aucun envoi ne reste en attente.</span></label><button className="button button-secondary" disabled={busy || !checked}>Constater l’échec et libérer le solde</button></form>}
      {admin && ["REQUESTED", "QUOTED", "APPROVED"].includes(current.status) && <form className="withdrawal-form" onSubmit={e => { e.preventDefault(); void act("reject", { note }); }}><label className="form-field">Motif de refus<input required minLength={3} maxLength={1000} value={note} onChange={e => setNote(e.target.value)} /></label><button className="button button-secondary" disabled={busy}>Refuser{current.status === "APPROVED" ? " et libérer le solde" : " la demande"}</button></form>}
    </div></Modal>}
  </section>;
}
