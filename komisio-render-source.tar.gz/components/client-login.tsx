"use client";
import { useState, type FormEvent } from "react";
import { ArrowRight, Eye, EyeOff, KeyRound } from "lucide-react";
import { Brand } from "./brand";
import { ThemeToggle } from "./theme-toggle";
import "./client-accounts.css";
export function ClientLogin({ message, changePassword = false, onLogin, onChangePassword, onCancel, onSignOut }: { message?: string; changePassword?: boolean; onLogin: (login: string, password: string) => Promise<void>; onChangePassword: (current: string, next: string) => Promise<void>; onCancel?: () => void; onSignOut: () => Promise<void> }) {
  const [login, setLogin] = useState("");
  const [password, setPassword] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [visible, setVisible] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function submit(event: FormEvent) {
    event.preventDefault(); if (busy) return;
    setBusy(true); setError("");
    try {
      if (changePassword) { if (next.length < 12 || next !== confirm) throw new Error("Choisissez un mot de passe d’au moins 12 caractères et confirmez-le à l’identique."); await onChangePassword(password, next); }
      else await onLogin(login, password);
      setPassword(""); setNext(""); setConfirm("");
    } catch (e) { setError((e as Error).message); } finally { setBusy(false); }
  }
  return <main className="client-login-page"><section className="client-login-card"><div className="client-login-top"><Brand /><ThemeToggle /></div><h1>{changePassword ? "Un mot de passe rien qu’à vous." : "Votre espace partenaire."}</h1><p>{changePassword ? "Pour activer votre accès, remplacez le mot de passe temporaire par votre mot de passe personnel." : "Connectez-vous avec l’accès remis par votre interlocuteur Komisio."}</p>{message && !changePassword && <p className="client-demo-note">{message}</p>}<form onSubmit={submit}>{!changePassword && <label className="form-field">Identifiant<input autoComplete="username" autoCapitalize="none" spellCheck={false} required maxLength={64} value={login} onChange={e => setLogin(e.target.value.toLowerCase())} placeholder="Votre identifiant client" /></label>}<label className="form-field">{changePassword ? "Mot de passe actuel ou temporaire" : "Mot de passe"}<div className="client-password-wrap"><input autoComplete="current-password" type={visible ? "text" : "password"} required maxLength={256} value={password} onChange={e => setPassword(e.target.value)} /><button type="button" aria-label={visible ? "Masquer le mot de passe" : "Afficher le mot de passe"} onClick={() => setVisible(value => !value)}>{visible ? <EyeOff size={18} /> : <Eye size={18} />}</button></div></label>{changePassword && <><label className="form-field">Nouveau mot de passe<input autoComplete="new-password" type="password" required minLength={12} maxLength={128} value={next} onChange={e => setNext(e.target.value)} /><small>12 caractères minimum</small></label><label className="form-field">Confirmer le nouveau mot de passe<input autoComplete="new-password" type="password" required minLength={12} maxLength={128} value={confirm} onChange={e => setConfirm(e.target.value)} /></label></>}{error && <p role="alert" className="client-error">{error}</p>}<button className="button button-primary full-width" disabled={busy}>{busy ? "Connexion…" : changePassword ? "Activer mon espace" : "Me connecter"}<ArrowRight size={17} /></button>{changePassword && (onCancel ? <button type="button" className="button button-secondary" disabled={busy} onClick={onCancel}>Annuler</button> : <button type="button" className="button button-secondary" disabled={busy} onClick={() => void onSignOut().catch(e => setError(e.message))}>Utiliser un autre accès</button>)}</form><div className="client-login-helper"><img src="/brand/komi-mascot.webp" alt="" /><p>{changePassword ? "Vos tarifs personnalisés vous attendent juste après cette étape." : "Pas encore d’accès ou mot de passe oublié ? Votre interlocuteur Komisio peut créer ou renouveler vos identifiants."}</p></div></section></main>;
}
