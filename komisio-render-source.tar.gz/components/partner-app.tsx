"use client";
import { ClientLogin } from "./client-login";
import { OrderQuote } from "./order-quote";
import { Brand, BrandMark } from "./brand";
import { ThemeToggle } from "./theme-toggle";
import { KomiGuide, KomiStepHelp } from "./komi-guide";
import { ServiceCatalogue } from "./service-catalogue";
import { HomeVehicleEstimator } from "./home-vehicle-estimator";
import { WhatsAppDrafts } from "./whatsapp-drafts";
import { validateWhatsAppSupportUrl } from "@/lib/whatsapp-public";
import { OriginalDocumentPanel } from "./original-document";
import { WithdrawalsPanel } from "./withdrawals-panel";
import { useState, useEffect, useRef, type FormEvent } from "react";
import {
  LayoutDashboard,
  Layers,
  FolderOpen,
  Wallet,
  ArrowUpRight,
  ArrowRight,
  Plus,
  Search,
  Bell,
  ChevronDown,
  ChevronRight,
  Clock,
  ShieldCheck,
  Building2,
  FilePenLine,
  ChartNoAxesCombined,
  CarFront,
  ContactRound,
  FolderCheck,
  Headphones,
  Send,
  Check,
  CheckCheck,
  ArrowDownLeft,
  ArrowUpLeft,
  Upload,
  Download,
  FileText,
  X,
  Menu,
  Settings,
  LogOut,
  Copy,
  ExternalLink,
  CheckCircle2,
  ArrowLeft,
  LifeBuoy,
  Mail,
  LoaderCircle,
  Info,
  SlidersHorizontal,
  Sparkles,
  LockKeyhole,
  MessageCircle,
} from "lucide-react";
import { QRCodeSVG } from "qrcode.react";
import {
  initialServices,
  mergeDemoServices,
  initialOrders,
  initialTransactions,
  euro,
  dateFR,
  statusLabels,
  servicePrice, orderPrice, isPaidStatus,
  isVehicleTransferService, usesStructuredCustomer, serviceCustomerName,
  type Service,
  type Order,
  type Transaction,
  type Attachment,
  type OrderStatus,
} from "@/lib/catalog";
import { Modal, Status, Toast } from "./ui";
import AdminPanel from "./admin-panel";
import "./komisio-theme.css";
import "./appearance.css";
type Page = "catalogue" | "dashboard" | "orders" | "wallet" | "admin";
type Payment = {
  provider?: string;
  id: string;
  amount: number;
  currency: string;
  address?: string;
  payAmount?: string | number;
  url?: string;
  status: string;
  createdAt: number;
  expiresAt?: string;
};
export async function api(path: string, options: RequestInit = {}) {
  const r = await fetch(path, {
    ...options,
    headers: {
      ...(options.body instanceof FormData
        ? {}
        : { "Content-Type": "application/json" }),
      ...options.headers,
    },
  });
  const d = await r.json();
  if (!r.ok) throw Error(d.error || d.message || "Une erreur est survenue.");
  return d;
}
export function saveDownload(name: string, data: string, type = "text/plain") {
  const a = document.createElement("a");
  a.href = data.startsWith("data:")
    ? data
    : URL.createObjectURL(new Blob([data], { type }));
  a.download = name;
  a.click();
  if (!data.startsWith("data:")) URL.revokeObjectURL(a.href);
}
function mapService(s: any): Service {
  return {
    ...s,
    title: s.name || s.title,
    catalogUpdatedAt: s.updatedAt,
    category: String(s.category).toLowerCase(),
    price: s.priceCents ?? s.price,
    documents: (s.requiredDocuments || s.documents || []).map((d: any) =>
      typeof d === "string" ? d : d.label,
    ),
    documentKeys: s.requiredDocuments?.map((d: any) => d.key),
    documentRequired: s.requiredDocuments?.map((d: any) => d.required),
    documentTypes: s.requiredDocuments?.map((d: any) => d.type || "document"),
    fields: s.fields || [],
    delay: s.turnaround || s.delay || "48 à 72 h",
    icon:
      s.icon ||
      (s.category === "AUTOMOBILE"
        ? "car"
        : s.category === "ASSISTANCE"
          ? "folder"
          : "building"),
  };
}
function mapOrder(o: any): Order {
  const docs = o.documents || [];
  const delivery = docs.filter((d: any) => d.kind === "DELIVERABLE").at(-1);
  return {
    ...o,
    reference: String(o.number ?? o.reference ?? o.id.slice(-5)),
    serviceTitle: o.serviceName || o.service?.name || o.serviceTitle,
    amount: o.priceCents ?? o.amountCents ?? o.amount,
    documents: docs
      .filter((d: any) => d.kind !== "DELIVERABLE")
      .map((d: any) => ({
        ...d,
        name: d.fileName || d.originalName || d.name,
      })),
    deliverable: delivery
      ? { ...delivery, name: delivery.fileName }
      : o.deliverable,
    note:
      [...(o.events || [])].reverse().find((e: any) => e.note)?.note || o.note,
    userName: o.user?.firstName || o.userName,
    documentDefinitions: o.formSnapshot?.requiredDocuments,
  };
}
function mapLedger(entries: any[]): Transaction[] {
  return entries.map((t) => ({
    id: t.id,
    label: t.reason,
    amount: t.amountCents,
    date: t.createdAt,
    status: "CONFIRMED",
    currency:
      t.kind === "TOPUP"
        ? "Recharge crypto"
        : t.kind === "ADMIN_ADJUSTMENT"
          ? "Ajustement manuel"
          : t.kind === "REFUND"
            ? "Remboursement EUR"
            : "Portefeuille EUR",
  }));
}
export default function PartnerApp({
  initialPage = "catalogue",
}: {
  initialPage?: Page;
}) {
  const [page, setPage] = useState<Page>(initialPage),
    [services, setServices] = useState(initialServices),
    [orders, setOrders] = useState(initialOrders),
    [balance, setBalance] = useState(125000),
    [transactions, setTransactions] = useState(initialTransactions),
    [ready, setReady] = useState(false),
    [live, setLive] = useState(false),
    [authError, setAuthError] = useState(""),
    [mustChangePassword, setMustChangePassword] = useState(false),
    [profile, setProfile] = useState({
      firstName: "Thomas",
      lastName: "Dubois",
      username: "thomas_dubois",
      role: "DEMO",
      mustChangePassword: false,
      login: "",
      telegramId: "",
    }),
    [selectedService, setSelectedService] = useState<Service | null>(null),
    [selectedOrder, setSelectedOrder] = useState<Order | null>(null),
    [recharge, setRecharge] = useState(false),
    [support, setSupport] = useState(false),
    [notifications, setNotifications] = useState(false),
    [menu, setMenu] = useState(false),
    [compact, setCompact] = useState(false),
    [account, setAccount] = useState(false),
    [toast, setToast] = useState<{ text: string; error: boolean } | null>(null),
    [orderFilter, setOrderFilter] = useState("all"),
    [orderQuery, setOrderQuery] = useState(""),
    [payment, setPayment] = useState<Payment | null>(null);
  const telegramRef = useRef<(typeof import("@twa-dev/sdk"))["default"] | null>(
    null,
  );
  useEffect(() => {
    const root = document.documentElement;
    let expandedHeight = window.innerHeight;
    const measure = () => {
      const height = window.visualViewport?.height || window.innerHeight;
      const editable =
        document.activeElement?.matches("input,textarea,select") || false;
      if (!editable) expandedHeight = window.innerHeight;
      root.style.setProperty("--visual-height", `${height}px`);
      root.style.setProperty(
        "--visual-offset-top",
        `${window.visualViewport?.offsetTop || 0}px`,
      );
      root.dataset.keyboardOpen = String(
        editable && expandedHeight - height > 150,
      );
    };
    measure();
    window.visualViewport?.addEventListener("resize", measure);
    window.visualViewport?.addEventListener("scroll", measure);
    window.addEventListener("resize", measure);
    document.addEventListener("focusin", measure);
    document.addEventListener("focusout", measure);
    return () => {
      window.visualViewport?.removeEventListener("resize", measure);
      window.visualViewport?.removeEventListener("scroll", measure);
      window.removeEventListener("resize", measure);
      document.removeEventListener("focusin", measure);
      document.removeEventListener("focusout", measure);
      delete root.dataset.keyboardOpen;
    };
  }, []);
  useEffect(() => {
    const fromLocation = (): Page => {
      if (window.location.pathname.startsWith("/admin")) return "admin";
      const view = new URLSearchParams(window.location.search).get("view");
      return ["dashboard", "orders", "wallet"].includes(view || "")
        ? (view as Page)
        : "catalogue";
    };
    const sync = () => {
      setPage(fromLocation());
      setMenu(false);
      setNotifications(false);
      setSelectedService(null);
      setSelectedOrder(null);
      setPayment(null);
      setRecharge(false);
      setSupport(false);
      setAccount(false);
    };
    sync();
    window.addEventListener("popstate", sync);
    return () => window.removeEventListener("popstate", sync);
  }, []);
  useEffect(() => {
    const media = window.matchMedia("(max-width: 800px)");
    const update = () => {
      setCompact(media.matches);
      if (!media.matches) setMenu(false);
    };
    update();
    media.addEventListener("change", update);
    return () => media.removeEventListener("change", update);
  }, []);
  useEffect(() => {
    if (!menu || !compact) return;
    const drawer = document.getElementById("partner-sidebar");
    const opener = document.activeElement as HTMLElement | null;
    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const controls = () =>
      Array.from(
        drawer?.querySelectorAll<HTMLElement>(
          "a[href], button:not(:disabled)",
        ) || [],
      );
    controls()[0]?.focus({ preventScroll: true });
    const close = (event: KeyboardEvent) => {
      if (event.defaultPrevented) return;
      if (event.key === "Escape") {
        event.preventDefault();
        setMenu(false);
      }
      if (event.key === "Tab") {
        const items = controls(),
          first = items[0],
          last = items.at(-1);
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last?.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first?.focus();
        }
      }
    };
    document.addEventListener("keydown", close);
    return () => {
      document.removeEventListener("keydown", close);
      document.body.style.overflow = oldOverflow;
      if (drawer?.contains(document.activeElement))
        opener?.focus({ preventScroll: true });
    };
  }, [menu, compact]);
  useEffect(() => {
    const sdk = telegramRef.current;
    if (!ready || !sdk?.initData) return;
    const visible =
      page !== "catalogue" ||
      !!(
        selectedService ||
        selectedOrder ||
        payment ||
        recharge ||
        support ||
        account ||
        menu
      );
    if (visible) sdk.BackButton.show();
    else sdk.BackButton.hide();
    const back = () => {
      if (payment) setPayment(null);
      else if (selectedService) setSelectedService(null);
      else if (selectedOrder) setSelectedOrder(null);
      else if (recharge) setRecharge(false);
      else if (support) setSupport(false);
      else if (account) setAccount(false);
      else if (menu) setMenu(false);
      else if (window.history.state?.formaPage) window.history.back();
      else navigate("catalogue");
    };
    sdk.BackButton.onClick(back);
    return () => {
      sdk.BackButton.offClick(back);
    };
  }, [
    ready,
    page,
    selectedService,
    selectedOrder,
    payment,
    recharge,
    support,
    account,
    menu,
  ]);
  const notify = (text: string, error = false) => {
    setToast({ text, error });
    window.setTimeout(() => setToast(null), 4500);
  };
  async function loadLiveSession() {
    const me = await api("/api/me");
    setProfile({ ...me.user, lastName: me.user.lastName || "" });
    setMustChangePassword(!!me.user.mustChangePassword);
    setAuthError("");
    if (me.user.mustChangePassword) { setLive(true); return; }
    const [catalog, ord] = await Promise.all([
      api(me.user.role === "ADMIN" ? "/api/admin/services" : "/api/catalog"),
      api(me.user.role === "ADMIN" ? "/api/admin/orders" : "/api/orders"),
    ]);
    setTransactions(mapLedger(me.ledger || [])); setBalance(me.user.balanceCents ?? 0);
    setServices((catalog.services || catalog).map(mapService)); setOrders((ord.orders || ord).map(mapOrder));
    setLive(true);
  }
  async function passwordLogin(login: string, password: string) {
    const initData = telegramRef.current?.initData;
    await api("/api/auth/password", { method: "POST", body: JSON.stringify({ login, password, ...(initData ? { initData } : {}) }) });
    await loadLiveSession();
  }
  async function changePassword(currentPassword: string, password: string) {
    await api("/api/auth/change-password", { method: "POST", body: JSON.stringify({ currentPassword, password }) });
    await loadLiveSession();
  }
  useEffect(() => {
    let cancelled = false;
    let detachTelegram = () => {};
    (async () => {
      let initData = "";
      try {
        const sdk = (await import("@twa-dev/sdk")).default;
        if (cancelled) return;
        telegramRef.current = sdk;
        initData = sdk.initData;
        const updateInsets = () => {
          const root = document.documentElement;
          root.style.setProperty(
            "--tg-height",
            `${sdk.viewportStableHeight || window.innerHeight}px`,
          );
          root.style.setProperty(
            "--tg-safe-top",
            `${sdk.safeAreaInset?.top || 0}px`,
          );
          root.style.setProperty(
            "--tg-safe-bottom",
            `${sdk.safeAreaInset?.bottom || 0}px`,
          );
          root.style.setProperty(
            "--tg-content-safe-top",
            `${sdk.contentSafeAreaInset?.top || 0}px`,
          );
          root.style.setProperty(
            "--tg-content-safe-bottom",
            `${sdk.contentSafeAreaInset?.bottom || 0}px`,
          );
        };
        updateInsets();
        sdk.onEvent("viewportChanged", updateInsets);
        sdk.onEvent("safeAreaChanged", updateInsets);
        sdk.onEvent("contentSafeAreaChanged", updateInsets);
        detachTelegram = () => {
          sdk.offEvent("viewportChanged", updateInsets);
          sdk.offEvent("safeAreaChanged", updateInsets);
          sdk.offEvent("contentSafeAreaChanged", updateInsets);
        };
        if (initData) {
          sdk.ready();
          sdk.expand();
          const chromeColor = document.documentElement.dataset.theme === "dark" ? "#081426" : "#f4f7fc";
          sdk.setHeaderColor(chromeColor);
          sdk.setBackgroundColor(chromeColor);
        }
      } catch {}
      if (process.env.NEXT_PUBLIC_DEMO_MODE === "true") {
        try {
          const saved = JSON.parse(localStorage.getItem("forma-demo-v1") || "null");
          if (saved) {
            setServices(Array.isArray(saved.services) ? mergeDemoServices(saved.services) : initialServices);
            setOrders(saved.orders || initialOrders); setBalance(saved.balance ?? 125000); setTransactions(saved.transactions || initialTransactions);
          }
        } catch {}
      } else {
        try {
          try { await loadLiveSession(); }
          catch {
            if (!initData) throw new Error("Accès réservé aux clients disposant d’identifiants Komisio.");
            await api("/api/auth/telegram", { method: "POST", body: JSON.stringify({ initData }) });
            await loadLiveSession();
          }
        } catch (e) { if (!cancelled) setAuthError(e instanceof Error ? e.message : "Connexion impossible."); }
      }
      setReady(true);
    })();
    return () => {
      cancelled = true;
      detachTelegram();
    };
  }, []);
  useEffect(() => {
    if (ready && !live && !authError) {
      try {
        localStorage.setItem(
          "forma-demo-v1",
          JSON.stringify({ services, orders, balance, transactions }),
        );
      } catch {
        notify(
          "Stockage local saturé. Réduisez la taille des pièces jointes.",
          true,
        );
      }
    }
  }, [ready, live, authError, services, orders, balance, transactions]);
  useEffect(() => {
    if (!live || !payment || payment.status === "CONFIRMED") return;
    const timer = setInterval(async () => {
      try {
        const d = await api("/api/payments/" + payment.id);
        const p = d.payment || d;
        setPayment((old) =>
          old
            ? {
                ...old,
                ...toPayment(p, old.amount, old.currency),
                createdAt: old.createdAt,
              }
            : null,
        );
        if (p.status === "CONFIRMED") {
          const me = await api("/api/me");
          setBalance(me.user?.balanceCents ?? me.balanceCents);
          setTransactions(mapLedger(me.ledger || []));
          const ord = await api(
            profile.role === "ADMIN" ? "/api/admin/orders" : "/api/orders",
          );
          setOrders((ord.orders || ord).map(mapOrder));
          notify("Paiement confirmé. Votre espace a été mis à jour.");
        }
      } catch {}
    }, 6000);
    return () => clearInterval(timer);
  }, [live, payment?.id, payment?.status, profile.role]);
  useEffect(() => {
    if (!live) return;
    const timer = setInterval(async () => {
      try {
        const [me, ord, catalogue] = await Promise.all([
          api("/api/me"),
          api(profile.role === "ADMIN" ? "/api/admin/orders" : "/api/orders"),
          api(profile.role === "ADMIN" ? "/api/admin/services" : "/api/catalog"),
        ]);
        setServices((catalogue.services || catalogue).map(mapService));
        const updated = (ord.orders || ord).map(mapOrder);
        setOrders(updated);
        setBalance(me.user.balanceCents);
        setTransactions(mapLedger(me.ledger || []));
        setSelectedOrder((old) =>
          old ? updated.find((o: Order) => o.id === old.id) || old : null,
        );
      } catch {}
    }, 15000);
    return () => clearInterval(timer);
  }, [live, profile.role]);
  const [komiOpen, setKomiOpen] = useState(false);
  const [telegramBotUrl, setTelegramBotUrl] = useState<string | null>(null);
  const [whatsappUrl, setWhatsAppUrl] = useState<string | null>(null);
  useEffect(() => {
    if (!authError && !live) return;
    let active = true;
    fetch("/api/config").then(response => response.json()).then(config => {
      if (active && typeof config.telegramBotUrl === "string" && /^https:\/\/t\.me\/[a-zA-Z0-9_]+$/.test(config.telegramBotUrl)) setTelegramBotUrl(config.telegramBotUrl);
      if (active) setWhatsAppUrl(validateWhatsAppSupportUrl(config.whatsappSupportUrl));
    }).catch(() => {});
    return () => { active = false; };
  }, [authError, live]);
  function navigate(p: Page) {
    if (p !== page) {
      const target =
        p === "admin" ? "/admin/" : p === "catalogue" ? "/" : `/?view=${p}`;
      window.history.pushState(
        { formaPage: true },
        "",
        target + window.location.hash,
      );
    }
    setPage(p);
    setMenu(false);
    setNotifications(false);
    window.scrollTo({ top: 0, behavior: "instant" });
  }
  function updateOrder(o: Order) {
    const previous = orders.find((x) => x.id === o.id);
    if (
      !live &&
      o.status === "CANCELLED" &&
      previous &&
      isPaidStatus(previous.status)
    )
      balanceChange(
        previous.amount,
        "Remboursement du dossier #" + o.reference,
      );
    setOrders((prev) => prev.map((x) => (x.id === o.id ? o : x)));
    if (selectedOrder?.id === o.id) setSelectedOrder(o);
  }
  function balanceChange(amount: number, reason: string) {
    setBalance((b) => b + amount);
    setTransactions((t) => [
      {
        id: crypto.randomUUID(),
        label: reason,
        amount,
        date: new Date().toISOString(),
        status: "CONFIRMED",
        currency: "Ajustement manuel",
      },
      ...t,
    ]);
  }
  async function onCreated(order: Order) {
    setOrders((prev) => [order, ...prev]);
    if (order.status === "PROCESSING" && !live) {
      setBalance((b) => b - order.amount);
      setTransactions((t) => [
        {
          id: crypto.randomUUID(),
          label: order.serviceTitle + " · #" + order.reference,
          amount: -order.amount,
          date: new Date().toISOString(),
          status: "CONFIRMED",
          currency: "Portefeuille EUR",
        },
        ...t,
      ]);
    }
    if (live) {
      const me = await api("/api/me");
      setBalance(me.user?.balanceCents ?? me.balanceCents);
      setTransactions(mapLedger(me.ledger || []));
    }
    setSelectedService(null);
    setSelectedOrder(order);
    navigate("orders");
    notify("Votre dossier #" + order.reference + " a été créé.");
  }
  const nav = [
    { id: "dashboard", label: "Tableau de bord", icon: LayoutDashboard },
    { id: "catalogue", label: "Catalogue des services", icon: Layers },
    { id: "orders", label: "Mes dossiers", icon: FolderOpen },
    { id: "wallet", label: "Mon portefeuille", icon: Wallet },
  ];
  const pageTitles: Record<Page, string> = {
    dashboard: "Tableau de bord",
    catalogue: "Catalogue des services",
    orders: "Mes dossiers",
    wallet: "Mon portefeuille",
    admin: "Administration",
  };
  const visibleOrders = orders.filter(
    (o) =>
      (orderFilter === "all" || o.status === orderFilter) &&
      (!orderQuery ||
        (o.reference + " " + o.serviceTitle + " " + o.customerName)
          .toLowerCase()
          .includes(orderQuery.toLowerCase())),
  );
  const actionOrders = orders.filter((o) => o.status === "ACTION_REQUIRED");
  if (!ready)
    return (
      <main className="auth-screen">
        <div className="brand"><Brand /></div>
        <LoaderCircle className="spin" size={25} />
        <p>Préparation de votre espace partenaire…</p>
      </main>
    );
  if (authError || mustChangePassword)
    return <ClientLogin key={mustChangePassword ? "change-password" : "login"} message={authError} changePassword={mustChangePassword} onLogin={passwordLogin} onChangePassword={changePassword} onCancel={mustChangePassword && !profile.mustChangePassword ? () => setMustChangePassword(false) : undefined} onSignOut={async () => { await api("/api/auth/logout", { method: "POST", body: "{}" }); setMustChangePassword(false); setLive(false); setAuthError("Connectez-vous avec les identifiants remis par votre interlocuteur."); }} />;
  return (
    <div className={`app-shell view-${page}`}>
      {menu && <div className="sidebar-scrim" onClick={() => setMenu(false)} />}
      <aside
        id="partner-sidebar"
        inert={compact && !menu}
        aria-hidden={compact && !menu ? true : undefined}
        className={"sidebar " + (menu ? "is-open" : "")}
      >
        <a
          className="brand"
          href="/"
          onClick={(e) => {
            e.preventDefault();
            navigate("catalogue");
          }}
        >
          <Brand />
        </a>
        <div className="workspace-switch">
          <div className="workspace-logo">
            <BrandMark />
          </div>
          <div>
            <strong>Espace partenaire</strong>
            <span>Votre activité, simplifiée</span>
          </div>
          <ChevronDown size={15} />
        </div>
        <div className="nav-caption">VOTRE ESPACE</div>
        <nav>
          {nav.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              className={"nav-item " + (page === id ? "active" : "")}
              onClick={() => navigate(id as Page)}
            >
              <Icon size={19} strokeWidth={1.7} />
              <span>{label}</span>
              {id === "orders" && actionOrders.length > 0 && (
                <b className="nav-count">{actionOrders.length}</b>
              )}
              {page === id && <span className="nav-active-dot" />}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="help-card">
            <span className="help-icon">
              <Headphones size={21} />
            </span>
            <strong>Une question ?</strong>
            <p>
              Notre équipe vous accompagne
              <br />à chaque étape.
            </p>
            <button
              onClick={() => {
                setMenu(false);
                setSupport(true);
              }}
            >
              Contacter le support <ArrowUpRight size={15} />
            </button>
          </div>
          <button
            className="nav-item"
            onClick={() => {
              navigate("admin");
            }}
          >
            <Settings size={18} strokeWidth={1.7} />
            <span>Administration</span>
            <ArrowUpRight size={14} />
          </button>
          <div className="sidebar-foot">
            <span className="online-dot" /> Tous les services opérationnels
          </div>
        </div>
      </aside>
      <div className="main-shell">
        <header className="topbar">
          <button
            className="mobile-menu icon-button"
            aria-label="Ouvrir le menu"
            aria-expanded={menu}
            aria-controls="partner-sidebar"
            onClick={() => setMenu(!menu)}
          >
            <Menu size={22} />
          </button>
          <a
            className="mobile-brand"
            href="/"
            aria-label="Komisio, catalogue"
            onClick={(e) => {
              e.preventDefault();
              navigate("catalogue");
            }}
          >
            <Brand />
            <small>ESPACE PARTENAIRE</small>
          </a>
          <div className="breadcrumb">
            Espace partenaire <ChevronRight size={13} />
            <strong>{pageTitles[page]}</strong>
          </div>
          <div className="header-actions">
            <ThemeToggle />
            <span className="secure-tag">
              <ShieldCheck size={14} /> Espace sécurisé
            </span>
            <div className="header-divider" />
            <button
              className="bell-button icon-button"
              aria-label="Notifications"
              aria-expanded={notifications}
              onClick={() => setNotifications(!notifications)}
            >
              <Bell size={19} />
              {actionOrders.length > 0 && <i />}
            </button>
            <button
              className="profile-button"
              aria-label="Mon compte partenaire"
              onClick={() => setAccount(true)}
            >
              <span className="avatar">
                {profile.firstName?.[0] || "P"}
                {profile.lastName?.[0] || ""}
              </span>
              <div>
                <strong>
                  {profile.firstName} {profile.lastName}
                </strong>
                <span>Partenaire revendeur</span>
              </div>
              <ChevronDown size={14} />
            </button>
          </div>
          {notifications && (
            <div className="notifications-popover">
              <h3>
                Vos notifications <span>{actionOrders.length}</span>
              </h3>
              {actionOrders.length ? (
                actionOrders.map((o) => (
                  <button
                    key={o.id}
                    onClick={() => {
                      setSelectedOrder(o);
                      setNotifications(false);
                    }}
                  >
                    <span className="notification-dot" />
                    <div>
                      <strong>Un document est attendu</strong>
                      <p>
                        Dossier #{o.reference} · {o.customerName}
                      </p>
                      <small>
                        Consulter la demande <ArrowRight size={12} />
                      </small>
                    </div>
                  </button>
                ))
              ) : (
                <p className="muted">
                  Vous êtes à jour. Aucune action en attente.
                </p>
              )}
            </div>
          )}
        </header>
        <main className="main-content">
          {page === "admin" ? (
            live && profile.role !== "ADMIN" ? (
              <section className="empty-state panel">
                <LockKeyhole size={30} />
                <h2>Accès réservé aux administrateurs</h2>
                <p>
                  Votre compte Telegram ne dispose pas des droits
                  d’administration.
                </p>
                <button
                  className="button button-primary"
                  onClick={() => navigate("catalogue")}
                >
                  Revenir au catalogue
                </button>
              </section>
            ) : (
              <AdminPanel
                services={services}
                orders={orders}
                balance={balance}
                onUpdateServices={setServices}
                onUpdateOrder={updateOrder}
                onBalanceChange={balanceChange}
                notify={notify}
                isLive={live}
              />
            )
          ) : (
            <>
              {page !== "catalogue" && <div className="page-heading">
                <div>
                  <div className="eyebrow">VOTRE PARTENAIRE AU QUOTIDIEN</div>
                  <h1>
                    {page === "dashboard" ? (
                      <>
                        Bonjour {profile.firstName}
                        <span className="greeting-dot">.</span>{" "}
                        <span className="wave">☀</span>
                      </>
                    ) : (
                      pageTitles[page]
                    )}
                  </h1>
                  <p>
                    {page === "dashboard"
                      ? "Un seul espace pour toutes les démarches de vos clients."
                      : page === "orders"
                        ? "Retrouvez et suivez tous vos dossiers, à chaque étape."
                        : "Gérez votre solde et retrouvez vos transactions en toute simplicité."}
                  </p>
                </div>
                <div className="heading-date">
                  <span className="online-dot" />{" "}
                  {live ? "Connecté à Telegram" : new Intl.DateTimeFormat("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(new Date())}
                </div>
              </div>}
              {page === "dashboard" && (
                <>
                  <div className="welcome-grid">
                    <section className="hero-panel">
                      <div className="hero-copy">
                        <span className="hero-label">
                          <span /> BIENVENUE CHEZ KOMISIO
                        </span>
                        <h2>
                          Vos contacts.
                          <br />
                          <span>De la valeur.</span>
                        </h2>
                        <p>
                          Vous créez les opportunités.
                          <br />
                          Nous faisons avancer les dossiers de vos clients.
                        </p>
                        <button
                          className="hero-link"
                          onClick={() => navigate("catalogue")}
                        >
                          Explorer les services <ArrowRight size={17} />
                        </button>
                      </div>
                      <div className="hero-art komisio-hero-art" aria-hidden="true">
                        <div className="komisio-orbit komisio-orbit-one" />
                        <div className="komisio-orbit komisio-orbit-two" />
                        <div className="komisio-app-icon"><BrandMark /></div>
                        <div className="komisio-art-dot" />
                        <div className="komisio-art-chip"><CheckCircle2 size={17} /><span>Chaque contact compte.</span></div>
                      </div>
                    </section>
                    <section className="wallet-card">
                      <div className="wallet-card-title">
                        <span>
                          <Wallet size={17} /> Votre portefeuille
                        </span>
                        <span className="currency-tag">EUR</span>
                      </div>
                      <div className="wallet-amount">
                        {euro(balance)}
                        <span>Solde disponible</span>
                      </div>
                      <button
                        className="button button-primary"
                        onClick={() => setRecharge(true)}
                      >
                        <Plus size={17} />
                        <span className="label-desktop">
                          Recharger mon solde
                        </span>
                        <span className="label-mobile">Recharger</span>
                        <ArrowUpRight size={17} />
                      </button>
                      <div className="wallet-coins">
                        <div className="coin-stack">
                          <i className="coin usdt">₮</i>
                          <i className="coin bitcoin">₿</i>
                          <i className="coin ethereum">♦</i>
                        </div>
                        <span>USDT, BTC, ETH & SOL</span>
                        <ShieldCheck size={13} />
                      </div>
                    </section>
                  </div>
                  <div className="activity-strip">
                    <div className="activity-item">
                      <span className="activity-icon lavender">
                        <FolderOpen size={20} />
                      </span>
                      <div>
                        <span>Dossiers en cours</span>
                        <strong>
                          {orders
                            .filter((o) => o.status === "PROCESSING")
                            .length.toString()
                            .padStart(2, "0")}
                          <small>En traitement</small>
                        </strong>
                      </div>
                      <div className="tiny-chart">
                        <i />
                        <i />
                        <i />
                        <i />
                        <i />
                        <i />
                      </div>
                    </div>
                    <div className="activity-item">
                      <span className="activity-icon mint">
                        <FolderCheck size={20} />
                      </span>
                      <div>
                        <span>Dossiers terminés</span>
                        <strong>
                          {orders
                            .filter((o) => o.status === "COMPLETED")
                            .length.toString()
                            .padStart(2, "0")}
                          <small className="green-text">
                            <ArrowUpRight size={12} /> Ce mois-ci
                          </small>
                        </strong>
                      </div>
                    </div>
                    <button
                      className="activity-item action-activity"
                      onClick={() => {
                        setOrderFilter("ACTION_REQUIRED");
                        navigate("orders");
                      }}
                    >
                      <span className="activity-icon peach">
                        <Clock size={20} />
                      </span>
                      <div>
                        <span>Votre attention est requise</span>
                        <strong>
                          {actionOrders.length.toString().padStart(2, "0")}
                          <small>Document à compléter</small>
                        </strong>
                      </div>
                      <ArrowUpRight size={18} />
                    </button>
                  </div>
                </>
              )}
              {page === "catalogue" && <><HomeVehicleEstimator services={services} live={live} onSelect={setSelectedService} whatsappUrl={whatsappUrl} onSupport={() => setSupport(true)} /><ServiceCatalogue services={services} onSelect={setSelectedService} onHelp={() => setKomiOpen(true)} /></>}
              {page === "orders" && <WhatsAppDrafts services={services} isLive={live} notify={notify} onSubmitted={() => { if (live) void loadLiveSession().catch(error => notify(error.message, true)); }} />}
              {(page === "orders" || page === "dashboard") && (
                <section className="panel orders-panel reseller-orders">
                  <div className="section-heading">
                    <div>
                      <h2>
                        {page === "dashboard"
                          ? "Vos derniers dossiers"
                          : "Tous vos dossiers"}{" "}
                        <span className="count-pill">{orders.length}</span>
                      </h2>
                      <p>Un suivi transparent du début à la fin.</p>
                    </div>
                    <button
                      className="button button-primary"
                      onClick={() => navigate("catalogue")}
                    >
                      <Plus size={16} /> Nouveau dossier
                    </button>
                  </div>
                  <div className="orders-toolbar">
                    <div className="category-tabs">
                      {[
                        { id: "all", label: "Tous" },
                        { id: "PROCESSING", label: "En cours" },
                        { id: "ACTION_REQUIRED", label: "Action requise" },
                        { id: "COMPLETED", label: "Terminés" },
                        { id: "AWAITING_QUOTE", label: "À chiffrer" },
                        { id: "QUOTE_PROPOSED", label: "Devis reçus" },
                        { id: "QUOTE_REJECTED", label: "Devis refusés" },
                        { id: "AWAITING_PAYMENT", label: "À payer" },
                      ].map((t) => (
                        <button
                          key={t.id}
                          className={orderFilter === t.id ? "selected" : ""}
                          onClick={() => setOrderFilter(t.id)}
                        >
                          {t.label}
                        </button>
                      ))}
                    </div>
                    <label className="search-box">
                      <Search size={16} />
                      <input
                        value={orderQuery}
                        onChange={(e) => setOrderQuery(e.target.value)}
                        type="search"
                        aria-label="Rechercher un dossier"
                        placeholder="Client, service, référence…"
                      />
                    </label>
                  </div>
                  <div className="table-scroll">
                    <table className="data-table" role="table">
                      <thead role="rowgroup">
                        <tr role="row">
                          <th scope="col" role="columnheader">
                            Dossier / Service
                          </th>
                          <th scope="col" role="columnheader">
                            Client final
                          </th>
                          <th scope="col" role="columnheader">
                            Date
                          </th>
                          <th scope="col" role="columnheader">
                            Montant
                          </th>
                          <th scope="col" role="columnheader">
                            Statut
                          </th>
                          <th />
                        </tr>
                      </thead>
                      <tbody role="rowgroup">
                        {visibleOrders.map((o) => (
                          <tr
                            role="row"
                            key={o.id}
                            onClick={() => setSelectedOrder(o)}
                          >
                            <td
                              role="cell"
                              data-label="Dossier"
                              className="card-row-title"
                            >
                              <strong>#{o.reference}</strong>
                              <span>{o.serviceTitle}</span>
                            </td>
                            <td role="cell" data-label="Client">
                              {o.customerName}
                            </td>
                            <td role="cell" data-label="Date">
                              {dateFR(o.createdAt)}
                            </td>
                            <td
                              role="cell"
                              data-label="Montant"
                              className="table-amount"
                            >
                              {orderPrice(o)}
                            </td>
                            <td role="cell" data-label="Statut">
                              <Status status={o.status} />
                            </td>
                            <td role="cell" className="card-row-action">
                              <button
                                className="button button-secondary"
                                aria-label={"Voir le dossier " + o.reference}
                                onClick={(event) => {
                                  event.stopPropagation();
                                  setSelectedOrder(o);
                                }}
                              >
                                Voir le dossier <ArrowUpRight size={17} />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  {!visibleOrders.length && (
                    <div className="empty-state">
                      <FolderOpen size={30} />
                      <h3>Aucun dossier dans cette sélection</h3>
                      <p>Vos nouvelles commandes apparaîtront ici.</p>
                    </div>
                  )}
                </section>
              )}
              {page === "wallet" && (
                <>
                  <div className="wallet-overview">
                    <section className="balance-panel">
                      <div className="eyebrow">VOTRE SOLDE DISPONIBLE</div>
                      <h2>{euro(balance)}</h2>
                      <p>Votre portefeuille partenaire est libellé en euros.</p>
                      <button
                        className="button button-primary"
                        onClick={() => setRecharge(true)}
                      >
                        <Plus size={17} /> Recharger mon portefeuille
                      </button>
                      <div className="balance-safe">
                        <ShieldCheck size={16} /> Validation des paiements après
                        confirmation du réseau
                      </div>
                    </section>
                    <section className="wallet-info panel">
                      <span className="service-icon">
                        <Wallet size={23} />
                      </span>
                      <h3>La crypto, en toute simplicité.</h3>
                      <p>
                        Rechargez en USDT (TRC20 ou ERC20), Bitcoin, Ethereum ou
                        Solana. Le montant confirmé est crédité en euros pour
                        régler vos dossiers.
                      </p>
                      <div className="payment-methods">
                        <span>₮ USDT</span>
                        <span>₿ BTC</span>
                        <span>♦ ETH</span>
                        <span>≋ SOL</span>
                      </div>
                      <small>
                        Le taux et les frais du réseau sont indiqués à la
                        création de votre paiement.
                      </small>
                    </section>
                  </div>
                  <WithdrawalsPanel isLive={live} balance={balance} onBalanceChange={balanceChange} notify={notify} onRefresh={async () => {
                    const me = await api("/api/me");
                    setBalance(me.user.balanceCents);
                    setTransactions(mapLedger(me.ledger || []));
                  }} />
                  <section className="panel transaction-panel reseller-transactions">
                    <div className="section-heading">
                      <div>
                        <h2>Historique des transactions</h2>
                        <p>
                          Retrouvez tous les mouvements de votre portefeuille.
                        </p>
                      </div>
                      <button
                        className="button button-secondary"
                        onClick={() =>
                          saveDownload(
                            "transactions-komisio.csv",
                            "Date;Libellé;Montant EUR;Statut\n" +
                              transactions
                                .map((t) =>
                                  [t.date, t.label, t.amount / 100, t.status]
                                    .map(
                                      (v) =>
                                        '\"' +
                                        String(v)
                                          .replace(/^[=+@-]/, "' $&")
                                          .replaceAll('\"', '\"\"') +
                                        '\"',
                                    )
                                    .join(";"),
                                )
                                .join("\n"),
                            "text/csv;charset=utf-8",
                          )
                        }
                      >
                        <Download size={15} /> Exporter
                      </button>
                    </div>
                    <div className="table-scroll">
                      <table className="data-table" role="table">
                        <thead role="rowgroup">
                          <tr role="row">
                            <th scope="col" role="columnheader">
                              Transaction
                            </th>
                            <th scope="col" role="columnheader">
                              Date
                            </th>
                            <th scope="col" role="columnheader">
                              Moyen de paiement
                            </th>
                            <th scope="col" role="columnheader">
                              Montant
                            </th>
                            <th scope="col" role="columnheader">
                              Statut
                            </th>
                          </tr>
                        </thead>
                        <tbody role="rowgroup">
                          {transactions.map((t) => (
                            <tr role="row" key={t.id}>
                              <td
                                role="cell"
                                data-label="Transaction"
                                className="card-row-title"
                              >
                                <div className="transaction-name">
                                  <span
                                    className={
                                      "transaction-icon " +
                                      (t.amount > 0 ? "credit" : "debit")
                                    }
                                  >
                                    {t.amount > 0 ? (
                                      <ArrowDownLeft size={18} />
                                    ) : (
                                      <ArrowUpRight size={18} />
                                    )}
                                  </span>
                                  <strong>{t.label}</strong>
                                </div>
                              </td>
                              <td role="cell" data-label="Date">
                                {dateFR(t.date)}
                              </td>
                              <td role="cell" data-label="Paiement">
                                {t.currency}
                              </td>
                              <td
                                role="cell"
                                data-label="Montant"
                                className={
                                  t.amount > 0
                                    ? "green-text table-amount"
                                    : "table-amount"
                                }
                              >
                                {t.amount > 0 ? "+" : ""}
                                {euro(t.amount)}
                              </td>
                              <td role="cell" data-label="Statut">
                                <span
                                  className={
                                    "status " +
                                    (t.status === "CONFIRMED"
                                      ? "status-completed"
                                      : "status-awaiting_payment")
                                  }
                                >
                                  <i />
                                  {t.status === "CONFIRMED"
                                    ? "Confirmé"
                                    : t.status === "PENDING"
                                      ? "En attente"
                                      : "Expiré"}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </section>
                </>
              )}
            </>
          )}
          <footer className="page-footer">
            <span>© 2026 Komisio. Vos contacts ont de la valeur.</span>
            <div>
              <span className="demo-tag">
                <i />
                {live ? "Connecté à Telegram" : "Mode démonstration"}
              </span>
              <button
                onClick={() => {
                  setMenu(false);
                  setSupport(true);
                }}
              >
                Besoin d’aide ? <ArrowUpRight size={12} />
              </button>
            </div>
          </footer>
        </main>
      </div>
      <nav className="mobile-bottom-nav" aria-label="Navigation principale">
        {nav.map(({ id, icon: Icon }) => (
          <button
            key={id}
            aria-current={page === id ? "page" : undefined}
            className={page === id ? "active" : ""}
            onClick={() => navigate(id as Page)}
          >
            <span className="bottom-nav-icon">
              <Icon size={22} strokeWidth={page === id ? 2.2 : 1.7} />
              {id === "orders" && actionOrders.length > 0 && (
                <b>{actionOrders.length}</b>
              )}
            </span>
            <span>
              {
                {
                  dashboard: "Accueil",
                  catalogue: "Services",
                  orders: "Dossiers",
                  wallet: "Portefeuille",
                }[id]
              }
            </span>
          </button>
        ))}
      </nav>
      <KomiGuide page={page} services={services} open={komiOpen} onOpenChange={setKomiOpen} onSelect={setSelectedService} onNavigate={navigate} actionCount={actionOrders.length} />
      {selectedService && (
        <OrderWizard
          service={selectedService}
          balance={balance}
          live={live}
          onClose={() => setSelectedService(null)}
          onCreated={onCreated}
          notify={notify}
          onPayment={setPayment}
        />
      )}
      {selectedOrder && (
        <OrderDetail
          order={selectedOrder}
          live={live}
          onClose={() => setSelectedOrder(null)}
          onUpdate={updateOrder}
          notify={notify}
          balance={balance}
          onWalletPay={async o => {
            if (live) {
              const raw = await api(`/api/orders/${o.id}/pay`, { method: "POST" });
              updateOrder(mapOrder(raw.order || raw));
              const me = await api("/api/me"); setBalance(me.user.balanceCents); setTransactions(mapLedger(me.ledger || []));
            } else {
              if (balance < o.amount) throw new Error("Solde insuffisant. Rechargez votre portefeuille ou choisissez la crypto.");
              balanceChange(-o.amount, `Paiement du dossier #${o.reference}`);
              updateOrder({ ...o, status: "PROCESSING" });
            }
          }}
          onPay={async (o) => {
            if (live) {
              try {
                const d = await api("/api/payments", {
                  method: "POST",
                  body: JSON.stringify({
                    orderId: o.id,
                    amountCents: o.amount,
                    payCurrency: "usdttrc20",
                    idempotencyKey: crypto.randomUUID(),
                  }),
                });
                setPayment(toPayment(d.payment || d, o.amount, "usdttrc20"));
              } catch (e) {
                notify((e as Error).message, true);
              }
            } else {
              setPayment({
                id: "demo-" + o.id,
                amount: o.amount,
                currency: "usdttrc20",
                status: "PENDING",
                createdAt: Date.now(),
              });
            }
          }}
        />
      )}
      {recharge && (
        <RechargeModal
          live={live}
          onClose={() => setRecharge(false)}
          onPayment={(p) => {
            setRecharge(false);
            setPayment(p);
          }}
          notify={notify}
        />
      )}
      {payment && (
        <PaymentModal
          payment={payment}
          live={live}
          onClose={() => setPayment(null)}
          onDemoConfirm={() => {
            if (payment.id.includes("order-")) {
              const id = payment.id.replace("demo-", "");
              const order = orders.find((o) => o.id === id);
              if (order) updateOrder({ ...order, status: "PROCESSING" });
            } else {
              balanceChange(
                payment.amount,
                "Rechargement simulé · " + payment.currency.toUpperCase(),
              );
            }
            setPayment({ ...payment, status: "CONFIRMED" });
            notify("Simulation validée. Aucun paiement réel n’a été effectué.");
          }}
          notify={notify}
        />
      )}
      {support && (
        <Modal
          title="Un partenaire à votre écoute"
          subtitle="Nous vous aidons à faire avancer vos dossiers."
          onClose={() => setSupport(false)}
        >
          <div className="support-hero">
            <Headphones size={32} />
            <h3>Comment pouvons-nous vous aider ?</h3>
            <p>
              Pour une demande sur un dossier, indiquez sa référence. Notre
              équipe est disponible du lundi au vendredi, de 9 h à 18 h.
            </p>
          </div>
          <div className="notice">
            <Info size={18} />
            <p>
              {live
                ? "Envoyez votre question au bot : elle sera transmise à l’équipe. Vous pouvez aussi répondre directement depuis le suivi du dossier."
                : "Vous explorez la démonstration. Configurez le compte de support dans votre déploiement pour activer la mise en relation."}
            </p>
          </div>
          {whatsappUrl ? <a className="button full-width support-whatsapp-button" href={whatsappUrl} target="_blank" rel="noopener noreferrer"><MessageCircle size={17} /> Écrire sur WhatsApp <ArrowUpRight size={15} /></a> : <div className="support-whatsapp-unconfigured"><strong>Assistance WhatsApp</strong>{live ? "Le numéro de l’équipe n’est pas encore configuré. Votre interlocuteur doit l’activer pour recevoir vos messages." : "Le bouton ouvrira WhatsApp dès que le numéro de l’équipe sera configuré sur la version réelle."}</div>}
          {live && telegramBotUrl && <a className="button button-primary full-width" href={`${telegramBotUrl}?start=support`} target="_blank" rel="noopener noreferrer">Contacter le support Telegram <Send size={16} /></a>}
          <button
            className="button button-secondary full-width"
            onClick={() => setSupport(false)}
          >
            C’est compris <Check size={16} />
          </button>
        </Modal>
      )}
      {account && (
        <Modal
          title="Votre compte partenaire"
          onClose={() => setAccount(false)}
        >
          <div className="account-profile">
            <span className="avatar large-avatar">
              {profile.firstName?.[0]}
              {profile.lastName?.[0]}
            </span>
            <h3>
              {profile.firstName} {profile.lastName}
            </h3>
            <p>{profile.login || (profile.username ? "@" + profile.username : "Compte partenaire")}</p>
          </div>
          <div className="notice">
            <ShieldCheck size={19} />
            <p>
              {live
                ? profile.telegramId ? "Votre compte est relié à Telegram. Retrouvez ici vos tarifs personnalisés et vos dossiers." : "Votre accès et vos tarifs sont gérés par votre interlocuteur Komisio. Connectez-vous avec les mêmes identifiants dans la Mini App pour relier Telegram."
                : "Profil de démonstration. Les données et documents de cet espace sont enregistrés dans ce navigateur."}
            </p>
          </div>
          {live && <>{profile.login && <button className="button button-secondary full-width" onClick={() => { setAccount(false); setMustChangePassword(true); }}>Changer mon mot de passe</button>}<button className="button button-secondary full-width" onClick={async () => { try { await api("/api/auth/logout", { method: "POST", body: "{}" }); setLive(false); setAccount(false); setOrders([]); setServices([]); setBalance(0); setTransactions([]); setAuthError("Vous êtes déconnecté."); } catch (e) { notify((e as Error).message, true); } }}><LogOut size={16} /> Me déconnecter</button></>}
          {!live && (
            <button
              className="button button-secondary full-width"
              onClick={() => {
                localStorage.removeItem("forma-demo-v1");
                setServices(initialServices);
                setOrders(initialOrders);
                setBalance(125000);
                setTransactions(initialTransactions);
                setAccount(false);
                notify("La démonstration a été réinitialisée.");
              }}
            >
              Réinitialiser la démonstration
            </button>
          )}
        </Modal>
      )}
      {toast && <Toast text={toast.text} error={toast.error} />}
    </div>
  );
}
function toPayment(p: any, amount: number, currency: string): Payment {
  return {
    id: p.id,
    provider: p.provider,
    amount: p.amountCents ?? amount,
    currency: p.payCurrency || currency,
    address: p.payAddress || p.pay_address,
    payAmount: p.payAmount ?? p.pay_amount,
    url: p.invoiceUrl || p.invoice_url,
    status: p.status || "PENDING",
    createdAt: Date.now(),
    expiresAt: p.expiresAt,
  };
}
function readAttachment(file: File, key: string, kind: "document" | "image" | "video" = "document"): Promise<Attachment> {
  if (kind === "video") {
    if (!file.size || file.size > 25 * 1024 * 1024) return Promise.reject(new Error("Vidéo : 25 Mo maximum."));
    if (!["video/mp4", "video/quicktime"].includes(file.type) && !/\.(mp4|mov)$/i.test(file.name)) return Promise.reject(new Error("Choisissez une vidéo MP4 ou MOV."));
    // A static demo cannot transmit a large video. Keep metadata without filling browser storage.
    return Promise.resolve({ id: crypto.randomUUID(), name: file.name, fieldKey: key, type: file.type || "video/mp4" });
  }
  return new Promise((resolve, reject) => {
    if (file.size > 2 * 1024 * 1024)
      return reject(
        Error("En démonstration, chaque document est limité à 2 Mo."),
      );
    if (!(kind === "image" ? ["image/jpeg", "image/png"] : ["application/pdf", "image/jpeg", "image/png"]).includes(file.type))
      return reject(Error(kind === "image" ? "Photos acceptées : JPG et PNG." : "Formats acceptés : PDF, JPG et PNG."));
    const reader = new FileReader();
    reader.onload = () =>
      resolve({
        id: crypto.randomUUID(),
        name: file.name,
        fieldKey: key,
        data: String(reader.result),
        type: file.type,
      });
    reader.onerror = () => reject(Error("Impossible de lire le document."));
    reader.readAsDataURL(file);
  });
}
function OrderWizard({
  service,
  balance,
  live,
  onClose,
  onCreated,
  notify,
  onPayment,
}: {
  service: Service;
  balance: number;
  live: boolean;
  onClose: () => void;
  onCreated: (order: Order) => void;
  notify: (m: string, e?: boolean) => void;
  onPayment: (p: Payment) => void;
}) {
  const [step, setStep] = useState(usesStructuredCustomer(service.id) && service.fields.length === 0 ? (service.documents.length ? 1 : 2) : 0),
    [name, setName] = useState(""),
    [email, setEmail] = useState(""),
    [fields, setFields] = useState<Record<string, string>>({}),
    [docs, setDocs] = useState<Attachment[]>([]),
    [method, setMethod] = useState<"WALLET" | "CRYPTO">("WALLET"),
    [payCurrency, setPayCurrency] = useState("usdttrc20"),
    [consent, setConsent] = useState(false),
    [busy, setBusy] = useState(false);
  const key = useRef(crypto.randomUUID());
  const formRef = useRef<HTMLFormElement>(null);
  const isVehicleTransfer = isVehicleTransferService(service.id);
  const structuredCustomer = usesStructuredCustomer(service.id);
  const requiresQuote = !!service.requiresQuote;
  const customerName = serviceCustomerName(service.id, fields, name);
  const visibleSteps = [
    { id: 0, label: structuredCustomer ? "Informations du dossier" : "Informations client" },
    { id: 1, label: "Documents" },
    { id: 2, label: requiresQuote ? "Envoi du dossier" : "Validation & paiement" },
  ].filter(item => item.id === 2 || (item.id === 0 ? !structuredCustomer || service.fields.length > 0 : service.documents.length > 0));
  const stepIndex = visibleSteps.findIndex(item => item.id === step);
  useEffect(() => {
    const modal = formRef.current?.closest(".modal");
    if (modal) modal.scrollTo({ top: 0, behavior: "auto" });
  }, [step]);
  async function upload(file: File, fieldKey: string) {
    setBusy(true);
    try {
      let attachment: Attachment;
      if (live) {
        const body = new FormData();
        body.append("file", file);
        body.append("serviceId", service.id);
        body.append("fieldKey", fieldKey);
        const d = await api("/api/documents", { method: "POST", body });
        const a = d.document || d;
        attachment = { id: a.id, name: a.fileName || file.name, fieldKey };
      } else attachment = await readAttachment(file, fieldKey, service.documentTypes?.[service.documentKeys?.indexOf(fieldKey) ?? -1] || "document");
      setDocs((prev) => [
        ...prev.filter((d) => d.fieldKey !== fieldKey),
        attachment,
      ]);
      notify(!live && attachment.type?.startsWith("video/") ? "Vidéo sélectionnée. En démo, aucun fichier vidéo n’est transmis." : "Document ajouté.");
    } catch (e) {
      notify((e as Error).message, true);
    } finally {
      setBusy(false);
    }
  }
  async function submit(e: FormEvent) {
    e.preventDefault();
    if (step < 2) {
      if (
        step === 1 &&
        service.documents.some(
          (label, i) =>
            service.documentRequired?.[i] !== false &&
            !docs.some(
              (d) => d.fieldKey === (service.documentKeys?.[i] || label),
            ),
        )
      ) {
        notify("Ajoutez toutes les pièces demandées pour poursuivre.", true);
        return;
      }
      setStep(visibleSteps[stepIndex + 1]?.id ?? 2);
      return;
    }
    if (!consent) return;
    setBusy(true);
    try {
      if (live) {
        const d = await api("/api/orders", {
          method: "POST",
          body: JSON.stringify({
            serviceId: service.id,
            ...(structuredCustomer ? {} : { customerName: name, customerEmail: email || undefined }),
            fields,
            documentIds: docs.map((d) => d.id),
            expectedPriceCents: service.price,
            expectedRequiresQuote: !!service.requiresQuote,
            expectedPricingVersion: service.pricing?.version,
            expectedServiceUpdatedAt: service.catalogUpdatedAt,
            paymentMethod: method,
            payCurrency,
            idempotencyKey: key.current,
          }),
        });
        const order = mapOrder(d.order || d);
        await onCreated(order);
        if (!requiresQuote && method === "CRYPTO") {
          const invoice = await api("/api/payments", {
            method: "POST",
            body: JSON.stringify({
              orderId: order.id,
              amountCents: order.amount,
              payCurrency,
              idempotencyKey: crypto.randomUUID(),
            }),
          });
          onPayment(
            toPayment(invoice.payment || invoice, order.amount, payCurrency),
          );
        }
      } else {
        if (!requiresQuote && method === "WALLET" && balance < service.price)
          throw Error(
            "Votre solde est insuffisant. Rechargez votre portefeuille ou choisissez la crypto.",
          );
        const id = crypto.randomUUID();
        const order: Order = {
          id: "order-" + id,
          reference: String(Date.now()).slice(-6),
          serviceId: service.id,
          serviceTitle: service.title,
          customerName,
          customerEmail: structuredCustomer ? undefined : email,
          amount: requiresQuote ? 0 : service.price,
          requiresQuote,
          quoteVersion: 0,
          pricingSnapshot: service.pricing ?? null,
          ...(service.id === "douane-suisse" ? { originalDocument: { status: "TO_SCHEDULE" as const, version: 0 } } : {}),
          documentDefinitions: service.documents.map((label, index) => ({ key: service.documentKeys?.[index] || label, label, required: service.documentRequired?.[index] !== false, type: service.documentTypes?.[index] || "document" })),
          status: requiresQuote ? "AWAITING_QUOTE" : method === "WALLET" ? "PROCESSING" : "AWAITING_PAYMENT",
          createdAt: new Date().toISOString(),
          documents: docs,
          fields,
          userName: "Thomas Dubois",
          userId: "demo",
        };
        await onCreated(order);
        if (!requiresQuote && method === "CRYPTO")
          onPayment({
            id: "demo-" + order.id,
            amount: service.price,
            currency: payCurrency,
            status: "PENDING",
            createdAt: Date.now(),
          });
      }
    } catch (e) {
      notify((e as Error).message, true);
    } finally {
      setBusy(false);
    }
  }
  return (
    <Modal
      title="Nouveau dossier"
      subtitle={service.title}
      onClose={onClose}
      wide
    >
      <div
        className="wizard-steps"
        aria-label={`Étape ${stepIndex + 1} sur ${visibleSteps.length}`}
        aria-live="polite"
      >
        {visibleSteps.map((item, i) => (
            <div key={item.id} className={step >= item.id ? "current" : ""}>
              <b>{step > item.id ? <Check size={14} /> : i + 1}</b>
              <span>{item.label}</span>
            </div>
        ))}
      </div>
      <KomiStepHelp service={service} step={step} />
      <form ref={formRef} onSubmit={submit}>
        {step === 0 && (
          <div className="wizard-content">
            <h3>{isVehicleTransfer ? "Informations du véhicule et de l’acquéreur" : structuredCustomer ? "Informations du dossier" : "Parlons de votre client"}</h3>
            <p className="muted">
              {service.id === "douane-suisse" ? service.description : "Les informations permettent à notre équipe de préparer le dossier."}
            </p>
            <div className="form-grid">
              {!structuredCustomer && <>
              <label className="form-field">
                Nom complet du client <span>*</span>
                <input
                  autoComplete="name"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Prénom et nom"
                />
              </label>
              <label className="form-field">
                Adresse e-mail
                <input
                  type="email"
                  autoComplete="email"
                  inputMode="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="client@exemple.fr"
                />
              </label>
              </>}
              {service.fields.map((f) => (
                <label key={f.key} className="form-field">
                  {f.label} {f.required && <span>*</span>}
                  {f.type === "textarea" ? (
                    <textarea
                      required={f.required}
                      value={fields[f.key] || ""}
                      onChange={(e) =>
                        setFields({ ...fields, [f.key]: e.target.value })
                      }
                      placeholder={f.label}
                    />
                  ) : f.type === "select" ? (
                    <select
                      required={f.required}
                      value={fields[f.key] || ""}
                      onChange={(e) =>
                        setFields({ ...fields, [f.key]: e.target.value })
                      }
                    >
                      <option value="">Sélectionner…</option>
                      {f.options?.map((o) => (
                        <option key={o} value={o}>
                          {o}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <input
                      required={f.required}
                      type={
                        f.type === "email"
                          ? "email"
                          : f.type === "date"
                            ? "date"
                            : f.type === "number" ? "number" : "text"
                      }
                      inputMode={f.type === "number" ? "numeric" : undefined}
                      min={f.type === "number" ? 0 : undefined}
                      step={f.type === "number" ? 1 : undefined}
                      maxLength={isVehicleTransfer && ["buyerLastName", "buyerFirstName"].includes(f.key) ? 70 : isVehicleTransfer && f.key === "buyerBirthPlace" ? 200 : undefined}
                      max={(isVehicleTransfer && f.key === "buyerBirthDate") || (service.id === "acces-donnees-personnelles" && f.key === "birthDate") ? new Date().toISOString().slice(0, 10) : undefined}
                      autoComplete={isVehicleTransfer && f.key === "buyerLastName" ? "family-name" : isVehicleTransfer && f.key === "buyerFirstName" ? "given-name" : isVehicleTransfer && f.key === "buyerBirthDate" ? "bday" : undefined}
                      value={fields[f.key] || ""}
                      onChange={(e) =>
                        setFields({ ...fields, [f.key]: e.target.value })
                      }
                      placeholder={f.label}
                    />
                  )}
                </label>
              ))}
            </div>
          </div>
        )}
        {step === 1 && (
          <div className="wizard-content">
            <h3>Les pièces de votre dossier</h3>
            <p className="muted">
              {service.documentTypes?.length && service.documentTypes.every(type => type === "image") ? "Photos JPG ou PNG" : "PDF, JPG ou PNG"} · {live ? "10" : "2"} Mo maximum par document.
              {service.documentTypes?.includes("video") && " Vidéo MP4 ou MOV : 25 Mo maximum."}
            </p>
            {service.id === "remboursement-ameli" && <p className="muted">Attestation de droits obligatoire. Ne transmettez aucun mot de passe Ameli.</p>}
            {requiresQuote && <p className="muted">{service.documents.every((_, index) => service.documentRequired?.[index] === false) ? "Toutes les pièces jointes sont facultatives. Vous pouvez envoyer votre demande de devis sans document." : "Ajoutez les pièces marquées d’un astérisque pour faire étudier votre dossier. L’envoi de la demande de devis ne déclenche aucun paiement."}</p>}
            <div className="upload-list">
              {service.documents.map((label, i) => {
                const fieldKey = service.documentKeys?.[i] || label;
                const d = docs.find((d) => d.fieldKey === fieldKey);
                const video = service.documentTypes?.[i] === "video";
                const image = service.documentTypes?.[i] === "image";
                return (
                  <label
                    className={"upload-zone " + (d ? "has-file" : "")}
                    key={label}
                  >
                    {d ? <CheckCircle2 size={22} /> : <Upload size={22} />}
                    <div>
                      <strong>
                        {label}{" "}
                        {service.documentRequired?.[i] !== false ? <span>*</span> : <small> (facultatif)</small>}
                      </strong>
                      <p>
                        {d ? d.name : "Cliquez pour sélectionner un document"}
                      </p>
                    </div>
                    <span className="upload-action">
                      {d ? "Remplacer" : "Parcourir"}
                    </span>
                    <input
                      type="file"
                      accept={video ? "video/mp4,video/quicktime,.mp4,.mov" : image ? "image/jpeg,image/png,.jpg,.jpeg,.png" : ".pdf,.jpg,.jpeg,.png"}
                      disabled={busy}
                      onChange={(e) => {
                        if (e.target.files?.[0])
                          upload(e.target.files[0], fieldKey);
                      }}
                    />
                  </label>
                );
              })}
            </div>
            <div className="notice">
              <LockKeyhole size={17} />
              <p>
                {live
                  ? "Seuls vous et l’équipe autorisée pouvez accéder aux pièces."
                  : "Mode démo : documents conservés uniquement dans ce navigateur. Utilisez des documents fictifs."}
              </p>
            </div>
          </div>
        )}
        {step === 2 && (
          <div className="wizard-content">
            <div className="order-summary">
              <div>
                <span>VOTRE PRESTATION</span>
                <h3>{service.title}</h3>
                <p>
                  {customerName} · {docs.length} document(s)
                </p>
              </div>
              <strong>{servicePrice(service)}</strong>
            </div>
            {requiresQuote ? <div className="notice"><FileText size={20} /><p>Envoyez votre dossier sans paiement. Après étude, vous recevrez un prix à accepter ou refuser. La démarche commencera uniquement après acceptation et paiement.</p></div> : <>
            <h3>Comment souhaitez-vous régler ?</h3>
            <label
              className={
                "payment-option " + (method === "WALLET" ? "checked" : "")
              }
            >
              <input
                type="radio"
                name="paymentMethod"
                checked={method === "WALLET"}
                onChange={() => setMethod("WALLET")}
              />
              <Wallet size={22} />
              <div>
                <strong>Mon portefeuille partenaire</strong>
                <p>Solde disponible : {euro(balance)}</p>
              </div>
              <span>{method === "WALLET" && <CheckCircle2 size={19} />}</span>
            </label>
            <label
              className={
                "payment-option " + (method === "CRYPTO" ? "checked" : "")
              }
            >
              <input
                type="radio"
                name="paymentMethod"
                checked={method === "CRYPTO"}
                onChange={() => setMethod("CRYPTO")}
              />
              <span className="crypto-symbol">₮</span>
              <div>
                <strong>Paiement direct en crypto</strong>
                <p>USDT, BTC, ETH ou SOL</p>
              </div>
              <span>{method === "CRYPTO" && <CheckCircle2 size={19} />}</span>
            </label>
            {method === "CRYPTO" && (
              <label className="form-field" style={{ marginTop: 18 }}>
                Crypto & réseau
                <select
                  value={payCurrency}
                  onChange={(e) => setPayCurrency(e.target.value)}
                >
                  <option value="usdttrc20">USDT · Tron (TRC20)</option>
                  <option value="usdterc20">USDT · Ethereum (ERC20)</option>
                  <option value="btc">Bitcoin · BTC</option>
                  <option value="eth">Ethereum · ETH</option>
                  <option value="sol">Solana · SOL</option>
                </select>
              </label>
            )}
            </>}
            <label className="consent">
              <input
                type="checkbox"
                required
                checked={consent}
                onChange={(e) => setConsent(e.target.checked)}
              />
              <span>
                Je confirme l’exactitude des informations et être autorisé à
                transmettre les documents de ce client.
              </span>
            </label>
            {!live && (
              <div className="notice">
                <Info size={16} />
                <p>
                  Commande de démonstration. Aucun paiement réel ne sera débité.
                </p>
              </div>
            )}
          </div>
        )}
        <div className="modal-footer">
          <button
            type="button"
            className="button button-secondary"
            disabled={busy}
            onClick={() => (stepIndex === 0 ? onClose() : setStep(visibleSteps[stepIndex - 1].id))}
          >
            {stepIndex === 0 ? (
              "Annuler"
            ) : (
              <>
                <ArrowLeft size={15} /> Retour
              </>
            )}
          </button>
          <button
            type="submit"
            className="button button-primary"
            disabled={busy || (!consent && step === 2)}
          >
            {busy ? <LoaderCircle size={16} className="spin" /> : null}
            {step < 2
              ? "Continuer"
              : requiresQuote
                ? "Envoyer le dossier pour devis"
                : method === "WALLET"
                ? "Valider et régler " + euro(service.price)
                : "Créer le paiement"}
            <ArrowRight size={16} />
          </button>
        </div>
      </form>
    </Modal>
  );
}
function OrderDetail({
  order,
  live,
  onClose,
  onUpdate,
  notify,
  onPay,
  onWalletPay,
  balance,
}: {
  order: Order;
  live: boolean;
  onClose: () => void;
  onUpdate: (o: Order) => void;
  notify: (s: string, e?: boolean) => void;
  onPay: (o: Order) => void;
  onWalletPay: (o: Order) => Promise<void>;
  balance: number;
}) {
  const [response, setResponse] = useState(""),
    [docKey, setDocKey] = useState(
      order.documentDefinitions?.[0]?.key || "complement",
    ),
    [attachments, setAttachments] = useState<Attachment[]>([]),
    [busy, setBusy] = useState(false);
  async function reply(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      if (!response && !attachments.length)
        throw Error("Ajoutez un message ou un document.");
      if (live) {
        const d = await api("/api/orders/" + order.id, {
          method: "PATCH",
          body: JSON.stringify({
            note: response || "Les documents demandés ont été ajoutés.",
          }),
        });
        onUpdate(mapOrder(d.order || d));
      } else
        onUpdate({
          ...order,
          documents: [...order.documents, ...attachments],
          note: "Votre réponse a été envoyée : " + response,
          status: "PROCESSING",
        });
      setResponse("");
      setAttachments([]);
      notify("Votre réponse a été transmise à l’équipe.");
    } catch (e) {
      notify((e as Error).message, true);
    } finally {
      setBusy(false);
    }
  }
  async function attach(file: File) {
    setBusy(true);
    try {
      let d: Attachment;
      if (live) {
        const b = new FormData();
        b.append("file", file);
        b.append("orderId", order.id);
        b.append("serviceId", order.serviceId);
        b.append("fieldKey", docKey);
        const r = await api("/api/documents", { method: "POST", body: b });
        d = {
          id: (r.document || r).id,
          name: file.name,
          fieldKey: "complement",
        };
      } else d = await readAttachment(file, docKey, order.documentDefinitions?.find(def => def.key === docKey)?.type || "document");
      setAttachments((a) => [...a, d]);
    } catch (e) {
      notify((e as Error).message, true);
    } finally {
      setBusy(false);
    }
  }
  function download(d: Attachment) {
    if (live) {
      const a = document.createElement("a");
      a.href = "/api/documents/" + d.id;
      a.download = d.name;
      a.click();
    } else if (d.data) saveDownload(d.name, d.data);
    else notify("Ce dossier d’exemple ne contient pas de pièce réelle.");
  }
  return (
    <Modal
      title={"Dossier #" + order.reference}
      subtitle={order.serviceTitle}
      onClose={onClose}
      wide
    >
      <div className="detail-status">
        <Status status={order.status} />
        <span>Créé le {dateFR(order.createdAt)}</span>
      </div>
      <OrderQuote order={order} live={live} onUpdate={onUpdate} notify={notify} />
      <OriginalDocumentPanel key={order.id} order={order} live={live} onUpdate={onUpdate} notify={notify} />
      <div className="detail-grid">
        <div>
          <small>CLIENT FINAL</small>
          <strong>{order.customerName}</strong>
          <span>{order.customerEmail || "—"}</span>
        </div>
        <div>
          <small>MONTANT DE LA PRESTATION</small>
          <strong>{orderPrice(order)}</strong>
          <span>Tarif partenaire</span>
        </div>
        {Object.entries(order.fields || {}).map(([k, v]) => (
          <div key={k}>
            <small>{k.replace(/([A-Z])/g, " $1").toUpperCase()}</small>
            <strong>{v}</strong>
          </div>
        ))}
      </div>
      {order.note && (
        <div
          className={
            "order-note " +
            (order.status === "ACTION_REQUIRED" ? "warning-note" : "")
          }
        >
          <Info size={19} />
          <div>
            <strong>
              {order.status === "ACTION_REQUIRED"
                ? "Une action est nécessaire"
                : "Message de votre équipe"}
            </strong>
            <p>{order.note}</p>
          </div>
        </div>
      )}
      <h3 className="detail-section-title">
        Documents du dossier{" "}
        <span className="count-pill">{order.documents.length}</span>
      </h3>
      <div className="document-list">
        {order.documents.map((d) => (
          <button key={d.id} onClick={() => download(d)}>
            <FileText size={19} />
            <span>{d.name}</span>
            <Download size={16} />
          </button>
        ))}
        {!order.documents.length && (
          <p className="muted">
            Aucun document joint à ce dossier.
          </p>
        )}
      </div>
      {order.status === "COMPLETED" && (
        <div className="delivery-box">
          <span className="activity-icon mint">
            <FolderCheck size={22} />
          </span>
          <div>
            <strong>Votre dossier est terminé</strong>
            <p>
              {order.originalDocument?.status === "RETURNED" ? "Votre carte grise originale vous a été restituée." : order.deliverable
                ? "Votre livrable est prêt à être téléchargé."
                : "Le livrable sera accessible dès son ajout par votre équipe."}
            </p>
          </div>
          {order.deliverable && (
            <button
              className="button button-primary"
              onClick={() => download(order.deliverable!)}
            >
              <Download size={16} /> Télécharger
            </button>
          )}
        </div>
      )}
      {order.status === "ACTION_REQUIRED" && (
        <form onSubmit={reply} className="response-form">
          <h3>Compléter mon dossier</h3>
          <label className="form-field">
            Votre message
            <textarea
              value={response}
              onChange={(e) => setResponse(e.target.value)}
              placeholder="Un message pour l’équipe…"
            />
          </label>
          {order.documentDefinitions && order.documentDefinitions.length > 0 && (
            <label className="form-field">
              Type de document
              <select
                value={docKey}
                onChange={(e) => setDocKey(e.target.value)}
              >
                {order.documentDefinitions.map((d) => (
                  <option key={d.key} value={d.key}>
                    {d.label}
                  </option>
                ))}
              </select>
            </label>
          )}
          {(!order.documentDefinitions || order.documentDefinitions.length > 0) && <label className="button button-secondary upload-inline">
            <Upload size={16} /> Joindre un document
            <input
              type="file"
              accept={order.documentDefinitions?.find(def => def.key === docKey)?.type === "video" ? "video/mp4,video/quicktime,.mp4,.mov" : order.documentDefinitions?.find(def => def.key === docKey)?.type === "image" ? "image/jpeg,image/png,.jpg,.jpeg,.png" : ".pdf,.png,.jpg,.jpeg"}
              disabled={busy}
              onChange={(e) => {
                if (e.target.files?.[0]) attach(e.target.files[0]);
              }}
            />
          </label>}
          {attachments.map((d) => (
            <p className="attached-filename" key={d.id}>
              <Check size={14} />
              {d.name}
            </p>
          ))}
          <button
            className="button button-primary"
            disabled={busy}
            type="submit"
          >
            {busy ? (
              <LoaderCircle size={16} className="spin" />
            ) : (
              <Send size={15} />
            )}{" "}
            Envoyer le complément
          </button>
        </form>
      )}
      {order.status === "AWAITING_PAYMENT" && (
        <div className="modal-footer">
          <span className="muted">
            {order.requiresQuote ? "Devis accepté. La démarche commencera après paiement confirmé." : "Le traitement débutera après confirmation."}
          </span>
          <button className="button button-secondary" disabled={busy || balance < order.amount} onClick={async () => {
            setBusy(true); try { await onWalletPay(order); notify("Paiement portefeuille confirmé."); } catch (error) { notify((error as Error).message, true); } finally { setBusy(false); }
          }}>Régler avec mon solde</button>
          <button
            className="button button-primary"
            onClick={() => onPay(order)}
          >
            Régler en crypto <ArrowRight size={16} />
          </button>
        </div>
      )}
    </Modal>
  );
}
function RechargeModal({
  live,
  onClose,
  onPayment,
  notify,
}: {
  live: boolean;
  onClose: () => void;
  onPayment: (p: Payment) => void;
  notify: (s: string, e?: boolean) => void;
}) {
  const [amount, setAmount] = useState("250"),
    [currency, setCurrency] = useState("usdttrc20"),
    [busy, setBusy] = useState(false);
  const key = useRef(crypto.randomUUID());
  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const cents = Math.round(Number(amount) * 100);
      if (!Number.isSafeInteger(cents) || cents < 1000 || cents > 1000000)
        throw Error("Choisissez un montant entre 10 et 10 000 €.");
      if (live) {
        const d = await api("/api/payments", {
          method: "POST",
          body: JSON.stringify({
            amountCents: cents,
            payCurrency: currency,
            idempotencyKey: key.current,
          }),
        });
        onPayment(toPayment(d.payment || d, cents, currency));
      } else
        onPayment({
          id: "demo-topup-" + crypto.randomUUID(),
          amount: cents,
          currency,
          status: "PENDING",
          createdAt: Date.now(),
        });
    } catch (e) {
      notify((e as Error).message, true);
    } finally {
      setBusy(false);
    }
  }
  return (
    <Modal
      title="Recharger mon portefeuille"
      subtitle="Choisissez votre montant et votre réseau."
      onClose={onClose}
    >
      <form onSubmit={submit}>
        <label className="form-field">
          Montant à créditer (€)
          <input
            type="number"
            inputMode="decimal"
            min="10"
            max="10000"
            step="0.01"
            required
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
        </label>
        <div className="quick-amounts">
          {[100, 250, 500, 1000].map((n) => (
            <button
              type="button"
              className={Number(amount) === n ? "selected" : ""}
              key={n}
              onClick={() => setAmount(String(n))}
            >
              {n} €
            </button>
          ))}
        </div>
        <label className="form-field">
          Crypto & réseau
          <select
            value={currency}
            onChange={(e) => setCurrency(e.target.value)}
          >
            <option value="usdttrc20">USDT · Tron (TRC20)</option>
            <option value="usdterc20">USDT · Ethereum (ERC20)</option>
            <option value="btc">Bitcoin · BTC</option>
            <option value="eth">Ethereum · ETH</option>
            <option value="sol">Solana · SOL</option>
          </select>
        </label>
        <div className="notice">
          <Info size={18} />
          <p>
            {live
              ? "Le montant crypto exact, l’adresse et le réseau seront affichés à l’étape suivante."
              : "Mode démo : vous pourrez simuler la confirmation sans envoyer de cryptomonnaie."}
          </p>
        </div>
        <div className="modal-footer">
          <button
            type="button"
            className="button button-secondary"
            onClick={onClose}
          >
            Annuler
          </button>
          <button className="button button-primary" disabled={busy}>
            {busy ? <LoaderCircle size={16} className="spin" /> : null}Continuer{" "}
            <ArrowRight size={16} />
          </button>
        </div>
      </form>
    </Modal>
  );
}
function PaymentModal({
  payment: p,
  live,
  onClose,
  onDemoConfirm,
  notify,
}: {
  payment: Payment;
  live: boolean;
  onClose: () => void;
  onDemoConfirm: () => void;
  notify: (s: string, e?: boolean) => void;
}) {
  return (
    <Modal
      title={
        p.status === "CONFIRMED" ? "Paiement confirmé" : "Votre paiement crypto"
      }
      subtitle={
        p.status === "CONFIRMED"
          ? "Votre espace partenaire est à jour."
          : euro(p.amount) + " · " + p.currency.toUpperCase()
      }
      onClose={onClose}
    >
      {p.status === "CONFIRMED" ? (
        <div className="payment-success">
          <span>
            <Check size={34} />
          </span>
          <h3>{live ? "Confirmation reçue" : "Simulation réussie"}</h3>
          <p>
            {live
              ? "Votre paiement a été confirmé par la passerelle."
              : "Aucun transfert de cryptomonnaie n’a eu lieu."}
          </p>
          <button
            className="button button-primary full-width"
            onClick={onClose}
          >
            Retour à mon espace
          </button>
        </div>
      ) : (
        <>
          <div className="payment-status">
            <span className="pending-dot" />
            {["EXPIRED", "FAILED"].includes(p.status)
              ? "Paiement expiré ou échoué"
              : "En attente de confirmation"}
            <span>{live ? "Actualisation automatique" : "Démonstration"}</span>
          </div>
          {["EXPIRED", "FAILED"].includes(p.status) ? (
            <div className="demo-invoice">
              <Info size={32} />
              <h3>Ce paiement n’est plus actif</h3>
              <p>
                Aucun nouveau transfert ne doit être envoyé à cette adresse.
                Créez un nouveau paiement depuis votre portefeuille ou votre
                dossier.
              </p>
            </div>
          ) : live && p.address ? (
            <div className="crypto-invoice">
              <QRCodeSVG value={p.address} size={170} />
              <strong>
                {p.payAmount} {p.currency.toUpperCase()}
              </strong>
              <p>Envoyez uniquement sur le réseau sélectionné.</p>
              <div className="crypto-address">
                <code>{p.address}</code>
                <button
                  className="icon-button"
                  aria-label="Copier l’adresse"
                  onClick={async () => {
                    try {
                      await navigator.clipboard.writeText(p.address!);
                      notify("Adresse copiée.");
                    } catch {
                      notify("Copiez l’adresse affichée.");
                    }
                  }}
                >
                  <Copy size={17} />
                </button>
              </div>
            </div>
          ) : live && p.url ? (
            <div className="crypto-invoice">
              <QRCodeSVG value={p.url} size={170} />
              <a
                href={p.url}
                className="button button-primary"
                target="_blank"
                rel="noopener noreferrer"
              >
                {p.provider === "PLISIO" ? "Payer sur Plisio" : "Ouvrir la facture sécurisée"} <ExternalLink size={16} />
              </a>
            </div>
          ) : live ? (
            <div className="demo-invoice">
              <LoaderCircle size={30} className="spin" />
              <h3>Préparation de votre facture</h3>
              <p>
                La passerelle prépare le paiement. Si cette étape persiste,
                contactez votre équipe avant de créer un autre paiement.
              </p>
            </div>
          ) : (
            <div className="demo-invoice">
              <span className="service-icon">
                <Wallet size={30} />
              </span>
              <h3>Testez le parcours de paiement</h3>
              <p>
                Cette simulation ne génère aucune adresse de dépôt. Le montant
                de <strong>{euro(p.amount)}</strong> sera ajouté au portefeuille
                de démonstration ou affecté au dossier.
              </p>
              <button
                className="button button-primary full-width"
                onClick={onDemoConfirm}
              >
                Simuler la confirmation <CheckCircle2 size={17} />
              </button>
            </div>
          )}
          <div className="notice">
            <ShieldCheck size={17} />
            <p>
              {live
                ? "Le crédit ou la validation du dossier se fait uniquement après confirmation serveur du paiement. Ne fermez pas votre facture avant d’avoir noté sa référence."
                : "Aucun paiement réel. Branchez NOWPayments pour activer les factures et QR codes de paiement."}
            </p>
          </div>
        </>
      )}
    </Modal>
  );
}
