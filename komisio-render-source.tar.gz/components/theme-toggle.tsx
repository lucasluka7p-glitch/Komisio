"use client";
import { useEffect, useRef, useState } from "react";
import { Moon, Sun } from "lucide-react";
import { APPEARANCE_KEY, applyAppearance, appearanceColor, type Appearance } from "@/lib/appearance";

export function ThemeToggle() {
  const [theme, setTheme] = useState<Appearance>("light");
  const explicit = useRef(false);
  function update(next: Appearance) {
    applyAppearance(next);
    setTheme(next);
    // Keep Telegram's surrounding chrome consistent with the website.
    void import("@twa-dev/sdk").then(({ default: sdk }) => {
      if (sdk.initData) {
        sdk.setHeaderColor(appearanceColor(next));
        sdk.setBackgroundColor(appearanceColor(next));
      }
    }).catch(() => {});
  }
  useEffect(() => {
    const system = window.matchMedia("(prefers-color-scheme: dark)");
    let stored: string | null = null;
    try { stored = localStorage.getItem(APPEARANCE_KEY); } catch {}
    explicit.current = stored === "light" || stored === "dark";
    update(explicit.current ? stored as Appearance : system.matches ? "dark" : "light");
    const changed = () => { if (!explicit.current) update(system.matches ? "dark" : "light"); };
    const storage = (event: StorageEvent) => {
      if (event.key !== APPEARANCE_KEY && event.key !== null) return;
      explicit.current = event.newValue === "light" || event.newValue === "dark";
      update(explicit.current ? event.newValue as Appearance : system.matches ? "dark" : "light");
    };
    system.addEventListener("change", changed);
    window.addEventListener("storage", storage);
    return () => { system.removeEventListener("change", changed); window.removeEventListener("storage", storage); };
  }, []);
  function toggle() {
    const next = theme === "dark" ? "light" : "dark";
    explicit.current = true;
    try { localStorage.setItem(APPEARANCE_KEY, next); } catch {}
    update(next);
  }
  const label = theme === "dark" ? "Activer le mode clair" : "Activer le mode sombre";
  return <button type="button" className="theme-toggle" aria-label={label} title={label} aria-pressed={theme === "dark"} onClick={toggle}>
    {theme === "dark" ? <Moon size={18} aria-hidden="true" /> : <Sun size={18} aria-hidden="true" />}<span>{theme === "dark" ? "Sombre" : "Clair"}</span>
  </button>;
}
