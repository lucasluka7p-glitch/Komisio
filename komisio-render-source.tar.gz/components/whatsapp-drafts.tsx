"use client";
import { useEffect, useState } from "react";
import { ArrowRight, Check, CheckCircle2, FileSearch, FileText, LoaderCircle, MessageCircle, RefreshCw, ShieldCheck } from "lucide-react";
import { euro, usesStructuredCustomer, type Service } from "@/lib/catalog";
import { Modal } from "./ui";
import "./whatsapp-drafts.css";

export type WhatsAppDraftFile = { id: string; fileName: string; mimeType: string; fieldKey?: string | null; ocrStatus?: string; warnings?: unknown; };
export type WhatsAppDraftView = { id: string; userId?: string; serviceId: string; status: string; fields: Record<string, string>; customerName?: string | null; version: number; reviewedVersion?: number | null; orderId?: string | null; updatedAt?: string; files?: WhatsAppDraftFile[]; user?: { firstName?: string; login?: string | null }; service?: { id: string; name: string; fields?: Service["fields"]; requiredDocuments?: { key: string; label: string; required: boolean; type?: string }[] }; };
type Detail = { draft: WhatsAppDraftView; pricing?: { priceCents: number; requiresQuote: boolean }; missing?: string[] };
type Props = { services: Service[]; isLive: boolean; notify: (message: string, error?: boolean) => void; admin?: boolean; onSubmitted?: () => void; };
const key = "komisio-whatsapp-demo-drafts";
export async function whatsappCall(path: string, value?: unknown, method = "POST") {
  const response = await fetch(path, { cache: "no-store", ...(value !== undefined ? { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(value) } : {}) });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || data.issues?.[0]?.message || "Impossible de traiter cette demande.");
  return data;
}
const label = (draft: WhatsAppDraftView) => draft.orderId ? "Dossier créé" : draft.status === "CANCELLED" ? "Annulé" : draft.status === "SUBMITTING" ? "Création en cours" : "À vérifier";
const record = (input: unknown): Record<string, string> => Object.fromEntries(Object.entries(input && typeof input === "object" ? input : {}).filter((entry): entry is [string, string] => typeof entry[1] === "string"));
function normalized(raw: any): Detail {
  const draft = raw.draft || raw;
  return { ...raw, draft: { ...draft, fields: record(draft.fields), files: Array.isArray(draft.files) ? draft.files : [] } };
}
export function WhatsAppDrafts({ services, isLive, notify, admin = false, onSubmitted }: Props) {
  const [items, setItems] = useState<WhatsAppDraftView[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [detail, setDetail] = useState<Detail | null>(null);
  const [fields, setFields] = useState<Record<string, string>>({});
  const [name, setName] = useState("");
  const [mapping, setMapping] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [stage, setStage] = useState<"edit" | "review">("edit");
  const [confirmed, setConfirmed] = useState(false);
  async function refresh() {
    try {
      if (isLive) { const raw = await whatsappCall("/api/whatsapp/drafts"); setItems(Array.isArray(raw) ? raw : raw.drafts || []); }
      else { try { setItems(JSON.parse(localStorage.getItem(key) || "[]")); } catch { setItems([]); } }
      setLoadError("");
    } catch (e) { setLoadError((e as Error).message); } finally { setLoading(false); }
  }
  useEffect(() => { void refresh(); if (isLive) { const timer = setInterval(() => void refresh(), 15000); return () => clearInterval(timer); } }, [isLive, admin]);
  function demoSave(next: WhatsAppDraftView[]) { localStorage.setItem(key, JSON.stringify(next)); setItems(next); }
  async function open(draft: WhatsAppDraftView) {
    setBusy(true); setError(""); setStage("edit"); setConfirmed(false);
    try {
      const value = isLive ? normalized(await whatsappCall(`/api/whatsapp/drafts/${draft.id}`)) : { draft };
      setDetail(value); setFields(record(value.draft.fields)); setName(value.draft.customerName || ""); setMapping(Object.fromEntries((value.draft.files || []).map(file => [file.id, file.fieldKey || ""])));
    } catch (e) { notify((e as Error).message, true); } finally { setBusy(false); }
  }
  function demo() {
    const service = services.find(item => item.id === "carte-grise");
    if (!service) return;
    const draft: WhatsAppDraftView = { id: "demo-wa-" + crypto.randomUUID(), serviceId: service.id, status: "DRAFT", version: 1, fields: { registration: "AA-123-AA", vin: "VF000000000000001", holderIdentity: "Société fictive" }, files: [{ id: crypto.randomUUID(), fileName: "carte-grise-fictive.jpg", mimeType: "image/jpeg", fieldKey: "registration_certificate", ocrStatus: "SIMULATED", warnings: ["Exemple fictif : aucun OCR ni envoi WhatsApp n’a été effectué."] }] };
    demoSave([draft, ...items]); void open(draft);
  }
  const current = detail?.draft;
  const service = current ? services.find(item => item.id === current.serviceId) : null;
  const definitions = current?.service?.fields || service?.fields || [];
  const documents = current?.service?.requiredDocuments || service?.documents.map((title, index) => ({ key: service.documentKeys?.[index] || `doc_${index}`, label: title, required: service.documentRequired?.[index] !== false, type: service.documentTypes?.[index] || "document" })) || [];
  const genericName = !!current && !usesStructuredCustomer(current.serviceId);
  const closed = !!current && (!!current.orderId || ["CANCELLED", "SUBMITTED", "SUBMITTING"].includes(current.status));
  const hints = (current?.files || []).flatMap(file => Array.isArray(file.warnings) ? file.warnings.filter((value): value is string => typeof value === "string") : []);
  function demoMissing() {
    return [...definitions.filter(field => field.required && !fields[field.key]?.trim()).map(field => field.label), ...documents.filter(doc => doc.required && !Object.values(mapping).includes(doc.key)).map(doc => doc.label), ...(genericName && name.trim().length < 2 ? ["Nom du client final"] : [])];
  }
  async function review() {
    if (!current || busy || closed) return;
    setBusy(true); setError("");
    try {
      let next: Detail;
      if (isLive) {
        const saved = normalized(await whatsappCall(`/api/whatsapp/drafts/${current.id}`, { action: "update", expectedVersion: current.version, fields, ...(genericName ? { customerName: name } : {}), files: (current.files || []).map(file => ({ id: file.id, fieldKey: mapping[file.id] || null })) }, "PATCH"));
        setDetail(saved);
        if (saved.missing?.length) throw new Error(`À compléter : ${saved.missing.join(" · ")}`);
        next = normalized(await whatsappCall(`/api/whatsapp/drafts/${current.id}`, { action: "review", expectedVersion: saved.draft.version }, "PATCH"));
      } else {
        const missing = demoMissing();
        const draft = { ...current, fields, customerName: name, version: current.version + 1, files: (current.files || []).map(file => ({ ...file, fieldKey: mapping[file.id] || null })) };
        demoSave(items.map(item => item.id === draft.id ? draft : item)); setDetail({ draft, missing });
        if (missing.length) throw new Error(`À compléter : ${missing.join(" · ")}`);
        next = { draft: { ...draft, reviewedVersion: draft.version }, missing: [], pricing: { priceCents: service?.price || 0, requiresQuote: !!service?.requiresQuote } };
      }
      setDetail(next); setStage("review"); setConfirmed(false);
    } catch (e) { setError((e as Error).message); } finally { setBusy(false); }
  }
  async function finish(action: "submit" | "cancel") {
    if (!current || busy || closed || (action === "submit" && !confirmed)) return;
    setBusy(true); setError("");
    try {
      if (isLive) await whatsappCall(`/api/whatsapp/drafts/${current.id}`, { action, expectedVersion: current.version }, "PATCH");
      else demoSave(items.map(item => item.id === current.id ? { ...current, status: action === "submit" ? "SUBMITTED" : "CANCELLED", ...(action === "submit" ? { orderId: "demo-order-" + crypto.randomUUID() } : {}) } : item));
      await refresh(); setDetail(null); if (action === "submit") onSubmitted?.();
      notify(!isLive ? "Action simulée. Aucun dossier réel ni débit créé." : action === "submit" ? "Dossier créé sur votre compte. Aucun paiement n’a été déclenché." : "Brouillon annulé.");
    } catch (e) { setError((e as Error).message); } finally { setBusy(false); }
  }
  return <section className="wa-drafts panel" aria-label={admin ? "Brouillons reçus sur WhatsApp" : "Mes brouillons WhatsApp"}>
    <header className="wa-drafts-heading"><div><span className="wa-eyebrow"><MessageCircle size={14} /> DE WHATSAPP À VOTRE COMPTE</span><h2>{admin ? "Brouillons des revendeurs" : "Vos dossiers reçus sur WhatsApp"}</h2><p>Les documents préparent le dossier. Vous vérifiez les informations avant sa création.</p></div><button type="button" className="button button-secondary" onClick={() => void refresh()} disabled={loading || busy}><RefreshCw size={15} /> Actualiser</button></header>
    {!isLive && <p className="wa-notice">Démonstration uniquement : aucune connexion WhatsApp et aucun document réel traité.</p>}
    {loadError && <p className="wa-error" role="alert">{loadError}</p>}
    {loading ? <p className="wa-loading"><LoaderCircle className="spin" size={18} /> Chargement des brouillons…</p> : items.length ? <div className="wa-draft-list">{items.map(draft => <button className="wa-draft-card" key={draft.id} onClick={() => void open(draft)} disabled={busy}><span className="wa-draft-icon"><FileSearch size={23} /></span><span><strong>{draft.service?.name || services.find(item => item.id === draft.serviceId)?.title || "Dossier WhatsApp"}</strong><small>{admin && draft.user?.firstName ? `${draft.user.firstName} · ` : ""}{draft.files?.length || 0} document{draft.files?.length === 1 ? "" : "s"} · {label(draft)}</small></span><ArrowRight size={17} /></button>)}</div> : <div className="wa-empty"><MessageCircle size={28} /><strong>Aucun brouillon pour le moment</strong><p>Sur WhatsApp : choisissez une démarche avec une commande, envoyez les documents, puis vérifiez le récapitulatif.</p>{!isLive && <button className="button button-secondary" onClick={demo}>Essayer un dossier fictif</button>}</div>}
    {current && <Modal title={closed ? "Dossier WhatsApp" : stage === "review" ? "Vérifiez avant de créer le dossier" : "Vérifier la lecture des documents"} subtitle={current.service?.name || service?.title || "Dossier WhatsApp"} onClose={() => { if (!busy) setDetail(null); }} wide>
      <div className="wa-review-intro"><ShieldCheck size={20} /><p>Une lecture automatique peut se tromper. Vérifiez chaque valeur et l’attribution des pièces. Aucun paiement automatique.</p></div>
      {closed ? <div className="wa-closed"><CheckCircle2 size={28} /><strong>{label(current)}</strong><p>{current.orderId ? "Le dossier a été transmis. Retrouvez son suivi dans vos commandes." : "Ce brouillon est clôturé."}</p></div> : stage === "edit" ? <>
        {!service && !current.service && <p className="wa-error">La définition de cette prestation est indisponible. Actualisez le catalogue avant de continuer.</p>}
        <div className="wa-field-grid">{genericName && <label className="form-field">Nom du client final<input maxLength={150} value={name} onChange={e => setName(e.target.value)} required /></label>}{definitions.map(field => <label className="form-field" key={field.key}>{field.label}{field.required && <small>Obligatoire</small>}{field.type === "select" ? <select value={fields[field.key] || ""} onChange={e => setFields(value => ({ ...value, [field.key]: e.target.value }))}><option value="">Choisir…</option>{field.options?.map(option => <option key={option} value={option}>{option}</option>)}</select> : field.type === "textarea" ? <textarea maxLength={5000} value={fields[field.key] || ""} onChange={e => setFields(value => ({ ...value, [field.key]: e.target.value }))} /> : <input type={field.type === "date" ? "date" : field.type === "email" ? "email" : "text"} inputMode={field.type === "number" ? "numeric" : undefined} maxLength={5000} value={fields[field.key] || ""} onChange={e => setFields(value => ({ ...value, [field.key]: e.target.value }))} />}</label>)}</div>
        <section className="wa-files"><h3><FileText size={18} /> Pièces reçues</h3>{current.files?.length ? current.files.map(file => <div className="wa-file" key={file.id}><div><strong>{file.fileName}</strong><small>{file.ocrStatus === "SIMULATED" ? "Lecture fictive" : ["DONE", "COMPLETED", "SUCCEEDED"].includes(file.ocrStatus || "") ? "Lecture effectuée · à contrôler" : file.ocrStatus === "FAILED" ? "Lecture indisponible · saisie manuelle" : "Lecture / traitement en cours ou à vérifier"}</small>{isLive && <a href={`/api/whatsapp/drafts/${current.id}/files/${file.id}`} target="_blank" rel="noopener noreferrer">Consulter le document privé</a>}</div><label className="form-field">Type de pièce<select aria-label={`Type de pièce pour ${file.fileName}`} value={mapping[file.id] || ""} onChange={e => setMapping(value => ({ ...value, [file.id]: e.target.value }))}><option value="">À identifier</option>{documents.map(doc => <option key={doc.key} value={doc.key}>{doc.label}{doc.required ? " · requise" : " · facultative"}</option>)}</select></label></div>) : <p>Aucune pièce reçue. Envoyez les documents depuis WhatsApp.</p>}</section>
        {hints.length > 0 && <details className="wa-ocr-warnings"><summary>Points à contrôler après lecture ({hints.length})</summary><ul>{hints.map((hint, index) => <li key={index}>{hint}</li>)}</ul></details>}
        <div className="wa-checklist"><strong>Pièces attendues</strong>{documents.map(doc => <span key={doc.key} className={Object.values(mapping).includes(doc.key) ? "complete" : ""}>{Object.values(mapping).includes(doc.key) ? <Check size={15} /> : <span aria-hidden="true">○</span>}{doc.label}<small>{doc.required ? "Requise" : "Facultative"}</small></span>)}</div>
      </> : <><dl className="wa-summary">{genericName && <div><dt>Client final</dt><dd>{name}</dd></div>}{definitions.map(field => <div key={field.key}><dt>{field.label}</dt><dd>{fields[field.key] || "Non renseigné"}</dd></div>)}{current.files?.map(file => <div key={file.id}><dt>{documents.find(doc => doc.key === mapping[file.id])?.label || "Pièce à classer"}</dt><dd>{file.fileName}</dd></div>)}</dl><div className="wa-price-summary"><span>{detail?.pricing?.requiresQuote ? "Dossier sur devis" : "Prix personnel du dossier"}</span><strong>{detail?.pricing?.requiresQuote ? "Prix proposé après étude" : detail?.pricing ? euro(detail.pricing.priceCents) : "Vérifié par le serveur avant création"}</strong><small>La création ne débite pas votre portefeuille. Le paiement restera à effectuer après vérification ou acceptation du devis.</small></div><label className="consent"><input type="checkbox" checked={confirmed} onChange={e => setConfirmed(e.target.checked)} /><span>J’ai vérifié les informations et les pièces. Je souhaite créer ce dossier sur mon compte.</span></label></>}
      {error && <p className="wa-error" role="alert">{error}</p>}
      {!closed && <footer className="wa-review-actions"><button type="button" className="button button-secondary" disabled={busy} onClick={() => void open(current)}><RefreshCw size={15} /> Recharger le brouillon</button>{stage === "review" && <button type="button" className="button button-secondary" disabled={busy} onClick={() => { setStage("edit"); setConfirmed(false); }}>Corriger</button>}<button type="button" className="button button-primary" disabled={busy || (stage === "review" ? !confirmed : !service && !current.service)} onClick={() => void (stage === "edit" ? review() : finish("submit"))}>{busy ? <LoaderCircle className="spin" size={16} /> : <Check size={16} />}{stage === "edit" ? "Enregistrer et vérifier" : "Créer le dossier sans paiement"}</button><button type="button" className="wa-cancel" disabled={busy} onClick={() => void finish("cancel")}>Annuler ce brouillon</button></footer>}
    </Modal>}
  </section>;
}
