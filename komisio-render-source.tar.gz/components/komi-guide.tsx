"use client";
import { useEffect, useState } from "react";
import { ArrowLeft, ArrowRight, Check, FileText, FolderOpen, MessageCircle, Pause, Play, Search, ShieldCheck, Wallet } from "lucide-react";
import { euro, servicePrice, usesStructuredCustomer, type Service } from "@/lib/catalog";
import { catalogueSections, findCatalogueServices, serviceSection, shortServiceTitle, type CatalogueSectionId } from "@/lib/catalogue-view";
import { Modal } from "./ui";
import "./komi-guide.css";

type GuidePage = "catalogue" | "dashboard" | "orders" | "wallet" | "admin";
export function KomiAvatar({ small = false }: { small?: boolean }) {
  return <span className={`komi-avatar ${small ? "is-small" : ""}`} aria-hidden="true"><img src="/brand/komi-mascot.webp" alt="" width="180" height="180" draggable={false} /></span>;
}
const contextCopy: Record<GuidePage, { title: string; text: string }> = {
  catalogue: { title: "On trouve le bon service ?", text: "Choisissez un besoin. Je vous montre les prestations et les pièces à préparer avant de commencer." },
  dashboard: { title: "Prêt pour votre prochaine démarche ?", text: "Je vous aide à trouver un service, préparer un dossier ou rejoindre votre suivi." },
  orders: { title: "Un dossier à suivre ?", text: "Ouvrez un dossier pour consulter son historique. « Action requise » indique qu’une réponse ou une pièce est attendue. Un devis doit être accepté avant le paiement." },
  wallet: { title: "Votre portefeuille, simplement.", text: "Rechargez depuis cette page ou consultez vos opérations. Pour un retrait, le montant, les frais et le montant net sont affichés avant votre confirmation. Le traitement suit le statut de la demande." },
  admin: { title: "Un espace de travail bien rangé.", text: "Gérez les services dans Catalogue, les dossiers dans Commandes et les mouvements dans Finances. Les tarifs et les pièces se configurent par prestation." },
};
export function KomiGuide({ page, services, open, onOpenChange, onSelect, onNavigate, actionCount }: {
  page: GuidePage; services: Service[]; open: boolean; onOpenChange: (open: boolean) => void;
  onSelect: (service: Service) => void; onNavigate: (page: GuidePage) => void; actionCount: number;
}) {
  const [mode, setMode] = useState<"home" | "find">("home");
  const [section, setSection] = useState<"all" | CatalogueSectionId>("all");
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<Service | null>(null);
  const [motion, setMotion] = useState(true);
  useEffect(() => {
    try { const enabled = localStorage.getItem("komisio-mascot-motion") !== "off"; setMotion(enabled); document.documentElement.dataset.komiMotion = enabled ? "on" : "off"; } catch {}
  }, []);
  useEffect(() => { if (open) { setMode("home"); setSelected(null); setQuery(""); setSection("all"); } }, [open, page]);
  function toggleMotion() {
    const enabled = !motion; setMotion(enabled); document.documentElement.dataset.komiMotion = enabled ? "on" : "off";
    try { localStorage.setItem("komisio-mascot-motion", enabled ? "on" : "off"); } catch {}
  }
  function navigate(next: GuidePage) { onOpenChange(false); onNavigate(next); }
  const found = findCatalogueServices(services, { category: "all", section, group: "all", query, pricing: "all", sort: "recommended" });
  const copy = contextCopy[page];
  return <>
    <button type="button" className="komi-launcher" onClick={() => onOpenChange(true)} aria-label="Ouvrir Komi, le guide des services" aria-haspopup="dialog" aria-expanded={open}><KomiAvatar small /><span><strong>Komi</strong><small>Votre guide</small></span><MessageCircle size={16} /></button>
    {open && <Modal title="Un coup de main avec Komi" subtitle="Votre guide Komisio" onClose={() => onOpenChange(false)}>
      <div className="komi-panel">
        <div className="komi-welcome"><KomiAvatar /><div><span className="komi-eyebrow">ON AVANCE ENSEMBLE</span><h3>{selected ? "Voici ce qu’il faut préparer." : mode === "find" ? "De quoi avez-vous besoin ?" : copy.title}</h3><p>{selected ? shortServiceTitle(selected) : mode === "find" ? "Un besoin, une rubrique, puis les bonnes pièces. Je vous accompagne." : copy.text}</p></div></div>
        {selected ? <>
          <button className="komi-back" type="button" onClick={() => setSelected(null)}><ArrowLeft size={15} /> Retour aux services</button>
          <div className="komi-service-summary"><span>{serviceSection(selected).label}</span><strong>{servicePrice(selected)}</strong><small>{selected.delay} · délai indicatif</small></div>
          <section className="komi-checklist"><h4><FileText size={16} /> Les pièces à préparer</h4>{selected.documents.length ? <ul>{selected.documents.map((doc, index) => <li key={index}><Check size={15} /><span>{doc}</span><small>{selected.documentRequired?.[index] === false ? "Facultative" : "Requise"}</small></li>)}</ul> : <p>Aucune pièce jointe demandée pour cette prestation.</p>}</section>
          <section className="komi-checklist"><h4>Les informations à avoir sous la main</h4><p>{[...(!usesStructuredCustomer(selected.id) ? ["Nom du client"] : []), ...selected.fields.map(field => field.label)].join(" · ") || "Aucune information supplémentaire à saisir."}</p></section>
          <div className="komi-tip"><ShieldCheck size={18} /><p>{selected.requiresQuote ? "Vous envoyez le dossier sans débit. L’équipe vous propose un prix : vous pouvez l’accepter ou le refuser. Le paiement vient après votre acceptation." : `Le tarif de prestation est de ${euro(selected.price)}. Le récapitulatif du dossier permet de vérifier les informations avant le paiement.`}</p></div>
          <button type="button" className="komi-primary" onClick={() => { onOpenChange(false); onSelect(selected); }}>Préparer ce dossier <ArrowRight size={17} /></button>
        </> : mode === "find" ? <>
          <button className="komi-back" type="button" onClick={() => setMode("home")}><ArrowLeft size={15} /> Retour au guide</button>
          <label className="komi-search"><Search size={18} /><input type="search" placeholder="Carte grise, remboursement…" aria-label="Chercher avec Komi" value={query} onChange={event => setQuery(event.target.value)} /></label>
          <div className="komi-section-pills" role="group" aria-label="Choisir un besoin avec Komi"><button type="button" aria-pressed={section === "all"} onClick={() => setSection("all")}>Tous</button>{catalogueSections.map(item => <button type="button" key={item.id} aria-pressed={section === item.id} onClick={() => setSection(item.id)}>{item.label}</button>)}</div>
          <p className="komi-result-count" role="status">{found.length} service{found.length > 1 ? "s" : ""} disponible{found.length > 1 ? "s" : ""}</p>
          <div className="komi-service-list">{found.map(service => <button key={service.id} type="button" onClick={() => setSelected(service)}><span><strong>{shortServiceTitle(service)}</strong><small>{servicePrice(service)} · {service.delay}</small></span><ArrowRight size={16} /></button>)}{!found.length && <p>Aucun résultat. Essayez un autre mot ou la rubrique « Tous ».</p>}</div>
        </> : <>
          <button type="button" className="komi-task komi-task-featured" onClick={() => setMode("find")}><Search size={21} /><span><strong>Trouver mon service</strong><small>La bonne rubrique, les pièces et le tarif</small></span><ArrowRight size={18} /></button>
          <button type="button" className="komi-task" onClick={() => navigate("orders")}><FolderOpen size={21} /><span><strong>Suivre mes dossiers</strong><small>{actionCount ? `${actionCount} dossier${actionCount > 1 ? "s" : ""} avec une action à consulter` : "Statuts, devis et documents au même endroit"}</small></span><ArrowRight size={18} /></button>
          <button type="button" className="komi-task" onClick={() => navigate("wallet")}><Wallet size={21} /><span><strong>Gérer mon portefeuille</strong><small>Rechargement, historique et demande de retrait</small></span><ArrowRight size={18} /></button>
          <div className="komi-tip"><ShieldCheck size={18} /><p>Je vous guide dans l’application. Les tarifs et les pièces affichés viennent du catalogue ; je ne valide pas les dossiers à la place de l’équipe.</p></div>
        </>}
        <footer className="komi-panel-footer"><span>Un guide, toujours à portée de main.</span><button type="button" onClick={toggleMotion} aria-pressed={motion}>{motion ? <Pause size={13} /> : <Play size={13} />} Animations {motion ? "actives" : "en pause"}</button></footer>
      </div>
    </Modal>}
  </>;
}
/** Small contextual companion inside the order flow; never reads or transmits field values. */
export function KomiStepHelp({ service, step }: { service: Service; step: number }) {
  const [expanded, setExpanded] = useState(false);
  const text = step === 0 ? "Gardez les informations du dossier à portée de main. Les champs marqués d’un astérisque sont nécessaires pour continuer."
    : step === 1 ? "Vérifiez que vos documents sont lisibles et complets. Une pièce indiquée « Facultative » peut être ajoutée plus tard."
    : service.requiresQuote ? "L’envoi du dossier ne débite pas votre portefeuille. Vous recevrez un prix à accepter ou refuser avant de payer."
    : "Relisez le récapitulatif et le montant avant de confirmer. Un paiement crypto reste en attente jusqu’à sa confirmation.";
  return <aside className="komi-step-help"><KomiAvatar small /><div><button type="button" onClick={() => setExpanded(!expanded)} aria-expanded={expanded}>Le conseil de Komi <span>{expanded ? "Masquer" : "Voir le conseil"}</span></button>{expanded && <p>{text}</p>}</div></aside>;
}
