> **Tarification individuelle :** les nouveaux dossiers conservent la grille du client. L’admin propose un montant de référence ; le serveur applique sa remise et son minimum avant acceptation. Minimum carte grise : 60 €. L’estimateur gratuit des cas courants est décrit dans [CLIENT-ACCESS.md](./CLIENT-ACCESS.md). Les anciens dossiers sans instantané conservent leur ancien fonctionnement.

# Commandes sur devis

Le service « Changement de titulaire carte grise » et sa variante sans justificatif de contrôle technique joint utilisent un prix **sur devis**. Toutes ses pièces jointes sont facultatives ; les informations du véhicule et de l’acquéreur restent requises. CEDEO, l’accompagnement Ameli et le dédouanement suisse fonctionnent également sur devis, avec leurs propres pièces requises. Le dédouanement suisse ajoute un rendez-vous de récupération et un suivi de restitution de l’original : voir [SWISS-CUSTOMS.md](SWISS-CUSTOMS.md).

## Parcours

1. Le revendeur renseigne les informations et joint les pièces disponibles, puis clique sur **Envoyer le dossier pour devis**. Aucun paiement ni débit. Le dossier passe à `AWAITING_QUOTE` et l’admin reçoit une notification Telegram via l’outbox.
2. Dans Admin → Commandes, l’admin consulte le dossier et renseigne le prix total ainsi qu’un éventuel message. Le statut devient `QUOTE_PROPOSED`, le devis prend une nouvelle version et le revendeur est notifié.
3. Le revendeur accepte cette version ou refuse. L’acceptation passe le dossier à `AWAITING_PAYMENT`, sans débit automatique. Le refus mène à `QUOTE_REJECTED`, état terminal sans paiement. Une nouvelle demande peut ensuite être déposée.
4. Le devis accepté peut être réglé avec le portefeuille ou en crypto. Le dossier devient `PROCESSING` seulement lorsque le paiement est confirmé. L’admin ne peut pas lancer le traitement par un simple changement de statut avant paiement.

Le prix peut être revu uniquement avant acceptation. Toute réponse portant sur une ancienne version est refusée. Une fois accepté, le prix est figé. Les doubles acceptations, refus et paiements ne créent pas de double débit. Une course entre acceptation et refus produit une seule décision. Aucun délai d’expiration supplémentaire n’est imposé au devis.

## Données et API

La migration `20261021040000_order_quotes` ajoute `Service.requiresQuote`, `Order.requiresQuote`, `quoteVersion`, `quoteAcceptedAt` et les trois statuts. Elle remplace les contraintes de prix strictement positif pour permettre zéro uniquement comme prix de service sur devis ou de dossier à chiffrer, jamais comme paiement gratuit. Une contrainte exige l’acceptation avant traitement d’un dossier sur devis. Les commandes déjà déposées conservent leur ancien prix, leurs statuts et leurs pièces.

- `POST /api/orders` peut créer un dossier sur devis sans moyen de paiement. Les pièces sont validées selon la configuration facultative. Le prix et le mode sont déterminés par le serveur.
- `POST /api/admin/orders/:id/quote` : `{amountCents, expectedVersion, note?}`. Admin uniquement ; montant de 1 € à 100 000 €, en centimes entiers. `expectedVersion` empêche une proposition d’écraser une modification concurrente.
- `POST /api/orders/:id/quote` : `{action: "accept" | "reject", quoteVersion}`. Titulaire uniquement.
- Les routes de paiement portefeuille et crypto refusent les dossiers à chiffrer, les devis non acceptés et les devis refusés. Les factures utilisent le prix enregistré du devis accepté, sans accepter un montant fourni par le navigateur comme tarif.
- Le catalogue admin peut configurer « Sur devis » ; le tarif initial doit alors être zéro. Les prix fixes restent positifs. Les indicateurs de chiffre d’affaires excluent les propositions non payées.

Transactions PostgreSQL sérialisables, journal d’événements, audit et outbox Telegram sont utilisés. Le service de dépôt crypto existant reste distinct des retraits.

## Vérification et mise en ligne

Exécuter `npx prisma migrate deploy`, puis le seed pour une installation neuve. La migration met aussi à jour le service existant sans écraser les anciennes commandes. Le catalogue local de démonstration migre sa configuration une fois, puis préserve les changements ultérieurs de l’admin.

`npm test` et `npm run build`. Tests intégrés : base PostgreSQL jetable **forma_quotes_test**, migrations appliquées et catalogue initialisé, puis `ORDER_QUOTE_TEST_DATABASE_URL=postgresql://.../forma_quotes_test npm test`. Cette suite refuse un autre nom de base ; elle teste dépôt sans pièces, absence de débit/facture, droits d’accès, anciennes versions, décisions concurrentes, paiement portefeuille idempotent, montant crypto issu du devis et déclenchement du traitement après confirmation. La passerelle crypto est simulée, sans envoi de fonds ni notification Telegram réelle.

La publication Sites reste une démonstration statique locale au navigateur. Le serveur, PostgreSQL, Telegram et le prestataire doivent être configurés pour recevoir des dossiers réels.
