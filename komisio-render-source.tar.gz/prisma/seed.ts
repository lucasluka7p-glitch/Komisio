import { PrismaClient } from "@prisma/client";
import { initialServices } from "../lib/catalog";
const prisma = new PrismaClient();
async function main() {
  for (const service of initialServices) {
    const data = {
      slug: service.id,
      name: service.title,
      description: service.description,
      category: service.category.toUpperCase(),
      subcategory: service.subcategory || null,
      priceCents: service.price,
      requiresQuote: !!service.requiresQuote,
      turnaround: service.delay,
      active: service.active,
      fields: service.fields.map((field) => ({
        ...field,
        type: field.type ?? "text",
      })),
      requiredDocuments: service.documents.map((label, index) => ({
        key: service.documentKeys?.[index] ?? `doc_${index}`,
        label,
        required: service.documentRequired?.[index] !== false,
        type: service.documentTypes?.[index] || "document",
      })),
    };
    // Seed creates missing services and preserves later admin pricing/configuration.
    await prisma.service.upsert({
      where: { id: service.id },
      create: { id: service.id, ...data },
      update: {},
    });
  }
  // Rename only the original label; preserve any name customized by the administrator.
  await prisma.service.updateMany({
    where: { id: "carte-grise", name: "Changement de titulaire" },
    data: { name: "Changement de titulaire carte grise" },
  });
  await prisma.service.updateMany({
    where: { id: "ww", name: "Certificat provisoire WW" },
    data: { name: "WW simple — certificat provisoire" },
  });
  console.log(
    `Catalogue initialisé : ${initialServices.length} prestations. Tarifs initiaux indicatifs ; modifications administratives conservées.`,
  );
}
main().finally(() => prisma.$disconnect());
