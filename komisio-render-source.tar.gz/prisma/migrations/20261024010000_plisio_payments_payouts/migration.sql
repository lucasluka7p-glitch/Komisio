-- Keep historical NOWPayments invoices unchanged; only new default invoices use Plisio.
ALTER TABLE "Payment" ALTER COLUMN "provider" SET DEFAULT 'PLISIO';
ALTER TABLE "Payment" ADD COLUMN "invoiceUrl" TEXT, ADD COLUMN "callbackData" JSONB;
ALTER TABLE "Withdrawal" ADD COLUMN "provider" TEXT, ADD COLUMN "providerTransferId" TEXT, ADD COLUMN "providerAttemptedAt" TIMESTAMP(3), ADD COLUMN "providerReceipt" JSONB;
CREATE UNIQUE INDEX "Withdrawal_providerTransferId_key" ON "Withdrawal"("providerTransferId");
