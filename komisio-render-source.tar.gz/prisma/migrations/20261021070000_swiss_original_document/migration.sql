-- CreateEnum
CREATE TYPE "OriginalDocumentStatus" AS ENUM ('TO_SCHEDULE', 'APPOINTMENT_SET', 'COLLECTED', 'READY_FOR_RETURN', 'RETURNED');

-- CreateTable
CREATE TABLE "OriginalDocument" (
    "orderId" TEXT NOT NULL,
    "status" "OriginalDocumentStatus" NOT NULL DEFAULT 'TO_SCHEDULE',
    "appointmentAt" TIMESTAMP(3),
    "location" TEXT,
    "note" TEXT,
    "collectedAt" TIMESTAMP(3),
    "readyAt" TIMESTAMP(3),
    "returnedAt" TIMESTAMP(3),
    "version" INTEGER NOT NULL DEFAULT 0,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "OriginalDocument_pkey" PRIMARY KEY ("orderId")
);

-- AddForeignKey
ALTER TABLE "OriginalDocument" ADD CONSTRAINT "OriginalDocument_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "Order"("id") ON DELETE RESTRICT ON UPDATE CASCADE;


-- Only future Swiss orders use this intake and quote flow. Order snapshots remain untouched.
UPDATE "Service" SET "priceCents" = 0, "requiresQuote" = true,
 "description" = 'Envoyez une photo de la carte grise et le kilométrage pour recevoir un devis. Après votre accord, nous fixons un rendez-vous pour récupérer la carte grise originale. Elle vous est restituée une fois la démarche effectuée. Droits, taxes et frais externes précisés dans le devis.',
 "turnaround" = 'Sur devis et rendez-vous',
 "fields" = '[{"key":"mileage","label":"Kilométrage du véhicule","type":"number","required":true}]'::jsonb,
 "requiredDocuments" = '[{"key":"registration_certificate","label":"Photo de la carte grise","required":true,"type":"image"}]'::jsonb,
 "updatedAt" = CURRENT_TIMESTAMP WHERE "id" = 'douane-suisse';

ALTER TABLE "OriginalDocument" ADD CONSTRAINT "OriginalDocument_custody" CHECK (
 "version" >= 0 AND
 ("status" = 'TO_SCHEDULE' OR ("appointmentAt" IS NOT NULL AND length(trim("location")) >= 3)) AND
 (("status" IN ('TO_SCHEDULE','APPOINTMENT_SET') AND "collectedAt" IS NULL AND "readyAt" IS NULL AND "returnedAt" IS NULL)
 OR ("status" = 'COLLECTED' AND "collectedAt" IS NOT NULL AND "readyAt" IS NULL AND "returnedAt" IS NULL)
 OR ("status" = 'READY_FOR_RETURN' AND "collectedAt" IS NOT NULL AND "readyAt" >= "collectedAt" AND "readyAt" IS NOT NULL AND "returnedAt" IS NULL)
 OR ("status" = 'RETURNED' AND "collectedAt" IS NOT NULL AND "readyAt" IS NOT NULL AND "returnedAt" IS NOT NULL AND "readyAt" >= "collectedAt" AND "returnedAt" >= "readyAt"))
);
