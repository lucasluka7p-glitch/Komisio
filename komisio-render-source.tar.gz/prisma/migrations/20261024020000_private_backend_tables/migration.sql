-- Supabase exposes public-schema tables through its data API. Business access stays
-- exclusively in the authenticated Node API. The database owner still runs Prisma.
DO $$
DECLARE item RECORD;
BEGIN
  FOR item IN SELECT tablename FROM pg_tables
    WHERE schemaname = 'public' AND tablename IN (
      'User','Service','Order','OrderEvent','Document','Payment','LedgerEntry',
      'AuditLog','NotificationOutbox','Withdrawal','OriginalDocument','_prisma_migrations'
    )
  LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', item.tablename);
  END LOOP;
END $$;
