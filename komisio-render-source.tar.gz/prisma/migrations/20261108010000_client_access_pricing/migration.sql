ALTER TABLE "User" ALTER COLUMN "telegramId" DROP NOT NULL;
ALTER TABLE "User" ADD COLUMN "login" TEXT, ADD COLUMN "passwordHash" TEXT, ADD COLUMN "mustChangePassword" BOOLEAN NOT NULL DEFAULT false, ADD COLUMN "credentialVersion" INTEGER NOT NULL DEFAULT 0, ADD COLUMN "accessReady" BOOLEAN NOT NULL DEFAULT true, ADD COLUMN "defaultDiscountBps" INTEGER NOT NULL DEFAULT 0, ADD COLUMN "pricingVersion" INTEGER NOT NULL DEFAULT 0;
CREATE UNIQUE INDEX "User_login_key" ON "User"("login");
ALTER TABLE "Order" ADD COLUMN "pricingSnapshot" JSONB, ADD COLUMN "quoteReferenceCents" INTEGER;
CREATE TABLE "ClientServicePrice" (
  "userId" TEXT NOT NULL REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  "serviceId" TEXT NOT NULL REFERENCES "Service"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  "mode" TEXT NOT NULL CHECK ("mode" IN ('FIXED', 'DISCOUNT', 'QUOTE')),
  "priceCents" INTEGER,
  "discountBps" INTEGER NOT NULL DEFAULT 0 CHECK ("discountBps" BETWEEN 0 AND 10000),
  "minimumCents" INTEGER NOT NULL DEFAULT 0 CHECK ("minimumCents" BETWEEN 0 AND 10000000),
  "updatedAt" TIMESTAMP(3) NOT NULL,
  PRIMARY KEY ("userId", "serviceId")
);
CREATE TABLE "LoginAttempt" ("key" TEXT PRIMARY KEY, "attempts" INTEGER NOT NULL DEFAULT 1, "windowAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP);
ALTER TABLE "ClientServicePrice" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "LoginAttempt" ENABLE ROW LEVEL SECURITY;
-- Upgrade untouched defaults only; preserve custom admin prices and every existing order.
UPDATE "Service" SET "priceCents"=8000 WHERE "id"='ww' AND "priceCents"=5000 AND NOT "requiresQuote";
UPDATE "Service" SET "priceCents"=10000 WHERE "id"='ww-modification' AND "priceCents"=8000 AND NOT "requiresQuote";
UPDATE "Service" SET "priceCents"=5000 WHERE "id"='situation-vehicule' AND "priceCents"=7000 AND NOT "requiresQuote";
UPDATE "Service" SET "priceCents"=17000 WHERE "id"='fin-leasing' AND "priceCents"=14900 AND NOT "requiresQuote";
UPDATE "Service" SET "priceCents"=4000 WHERE "id"='achat' AND "priceCents"=2900 AND NOT "requiresQuote";
UPDATE "Service" SET "priceCents"=140000 WHERE "id"='creation' AND "priceCents"=14900 AND NOT "requiresQuote";
UPDATE "Service" SET "priceCents"=65000 WHERE "id"='modification' AND "priceCents"=9900 AND NOT "requiresQuote";
UPDATE "Service" SET "priceCents"=10000, "requiresQuote"=false WHERE "id"='regularisation-carte-grise' AND "priceCents"=0 AND "requiresQuote";
