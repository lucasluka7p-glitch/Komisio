-- AlterTable
ALTER TABLE "Service" ADD COLUMN     "subcategory" TEXT;


-- Broaden only the holder label, preserving custom fields and previous order snapshots.
UPDATE "Service" SET "fields" = COALESCE((SELECT jsonb_agg(CASE WHEN item->>'key' = 'holderIdentity' THEN item || '{"label":"Identité du titulaire"}'::jsonb ELSE item END ORDER BY position) FROM jsonb_array_elements("fields") WITH ORDINALITY AS f(item,position)), '[]'::jsonb), "updatedAt" = CURRENT_TIMESTAMP WHERE "id" IN ('carte-grise','carte-grise-sans-ct');
UPDATE "Service" SET "priceCents" = 5000, "requiresQuote" = false, "fields" = '[{"key":"holderAddress","label":"Adresse postale complète du titulaire","type":"textarea","required":true}]'::jsonb, "requiredDocuments" = '[{"key":"registration_certificate","label":"Photo de la carte grise","required":true,"type":"image"},{"key":"holder_identity","label":"Photo de la pièce d’identité du titulaire","required":true,"type":"image"}]'::jsonb, "updatedAt" = CURRENT_TIMESTAMP WHERE "id" = 'ww';
UPDATE "Service" SET "priceCents" = 8000, "requiresQuote" = false, "fields" = '[{"key":"holderAddress","label":"Adresse postale complète du titulaire","type":"textarea","required":true}]'::jsonb, "requiredDocuments" = '[{"key":"registration_certificate","label":"Photo de la carte grise","required":true,"type":"image"},{"key":"holder_identity","label":"Photo de la pièce d’identité du titulaire","required":true,"type":"image"}]'::jsonb, "updatedAt" = CURRENT_TIMESTAMP WHERE "id" = 'ww-modification';
UPDATE "Service" SET "priceCents" = 0, "requiresQuote" = true, "updatedAt" = CURRENT_TIMESTAMP WHERE "id" = 'cedeo-pro';
UPDATE "Service" SET "subcategory" = 'creation-modification' WHERE "id" = 'creation' AND "category" = 'FORMALITES';
UPDATE "Service" SET "subcategory" = 'creation-modification' WHERE "id" = 'modification' AND "category" = 'FORMALITES';
UPDATE "Service" SET "subcategory" = 'comptabilite-depots' WHERE "id" = 'comptes' AND "category" = 'FORMALITES';
UPDATE "Service" SET "subcategory" = 'immatriculation' WHERE "id" = 'carte-grise' AND "category" = 'AUTOMOBILE';
UPDATE "Service" SET "subcategory" = 'immatriculation' WHERE "id" = 'carte-grise-sans-ct' AND "category" = 'AUTOMOBILE';
UPDATE "Service" SET "subcategory" = 'immatriculation' WHERE "id" = 'ww' AND "category" = 'AUTOMOBILE';
UPDATE "Service" SET "subcategory" = 'dossiers-rendez-vous' WHERE "id" = 'assistance' AND "category" = 'ASSISTANCE';
UPDATE "Service" SET "subcategory" = 'vie-entreprise' WHERE "id" = 'sommeil' AND "category" = 'FORMALITES';
UPDATE "Service" SET "subcategory" = 'corrections-regularisations' WHERE "id" = 'rne' AND "category" = 'FORMALITES';
UPDATE "Service" SET "subcategory" = 'vie-entreprise' WHERE "id" = 'cessation' AND "category" = 'FORMALITES';
UPDATE "Service" SET "subcategory" = 'corrections-regularisations' WHERE "id" = 'regularisation' AND "category" = 'FORMALITES';
UPDATE "Service" SET "subcategory" = 'immatriculation' WHERE "id" = 'achat' AND "category" = 'AUTOMOBILE';
UPDATE "Service" SET "subcategory" = 'douanes' WHERE "id" = 'douane' AND "category" = 'AUTOMOBILE';
UPDATE "Service" SET "subcategory" = 'dossiers-rendez-vous' WHERE "id" = 'rdv' AND "category" = 'ASSISTANCE';
UPDATE "Service" SET "subcategory" = 'douanes' WHERE "id" = 'douane-suisse' AND "category" = 'AUTOMOBILE';
UPDATE "Service" SET "subcategory" = 'permis-examens' WHERE "id" = 'code-route' AND "category" = 'ASSISTANCE';
UPDATE "Service" SET "subcategory" = 'permis-examens' WHERE "id" = 'examen-permis' AND "category" = 'ASSISTANCE';
UPDATE "Service" SET "subcategory" = 'dossiers-rendez-vous' WHERE "id" = 'titre-sejour' AND "category" = 'ASSISTANCE';
UPDATE "Service" SET "subcategory" = 'offres-professionnelles' WHERE "id" = 'cedeo-pro' AND "category" = 'ASSISTANCE';
UPDATE "Service" SET "subcategory" = 'controle-restrictions' WHERE "id" = 'controle-convoyage' AND "category" = 'AUTOMOBILE';
UPDATE "Service" SET "subcategory" = 'remboursements' WHERE "id" = 'remboursement-pare-brise' AND "category" = 'ASSISTANCE';
UPDATE "Service" SET "subcategory" = 'remboursements' WHERE "id" = 'remboursement-ameli' AND "category" = 'ASSISTANCE';
UPDATE "Service" SET "subcategory" = 'demandes-personnelles' WHERE "id" = 'acces-donnees-personnelles' AND "category" = 'ASSISTANCE';
UPDATE "Service" SET "subcategory" = 'documents-vehicule' WHERE "id" = 'situation-vehicule' AND "category" = 'AUTOMOBILE';
UPDATE "Service" SET "subcategory" = 'documents-vehicule' WHERE "id" = 'fin-leasing' AND "category" = 'AUTOMOBILE';
UPDATE "Service" SET "subcategory" = 'immatriculation' WHERE "id" = 'ww-modification' AND "category" = 'AUTOMOBILE';
UPDATE "Service" SET "subcategory" = 'controle-restrictions' WHERE "id" = 'levee-procedure' AND "category" = 'AUTOMOBILE';
UPDATE "Service" SET "subcategory" = 'controle-restrictions' WHERE "id" = 'levee-saisie' AND "category" = 'AUTOMOBILE';
UPDATE "Service" SET "subcategory" = 'controle-restrictions' WHERE "id" = 'levee-immobilisation' AND "category" = 'AUTOMOBILE';
