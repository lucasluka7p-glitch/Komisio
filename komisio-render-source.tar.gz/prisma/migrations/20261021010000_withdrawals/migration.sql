-- CreateEnum
CREATE TYPE "WithdrawalStatus" AS ENUM ('REQUESTED', 'QUOTED', 'APPROVED', 'PROCESSING', 'SENT', 'COMPLETED', 'CANCELLED', 'REJECTED', 'FAILED');

-- AlterEnum
-- This migration adds more than one value to an enum.
-- With PostgreSQL versions 11 and earlier, this is not possible
-- in a single migration. This can be worked around by creating
-- multiple migrations, each migration adding only one value to
-- the enum.


ALTER TYPE "LedgerKind" ADD VALUE 'WITHDRAWAL_HOLD';
ALTER TYPE "LedgerKind" ADD VALUE 'WITHDRAWAL_RELEASE';

-- CreateTable
CREATE TABLE "Withdrawal" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "amountCents" INTEGER NOT NULL,
    "currency" TEXT NOT NULL DEFAULT 'usdttrc20',
    "address" TEXT NOT NULL,
    "status" "WithdrawalStatus" NOT NULL DEFAULT 'REQUESTED',
    "idempotencyKey" TEXT NOT NULL,
    "quoteVersion" INTEGER NOT NULL DEFAULT 0,
    "feeCents" INTEGER,
    "exchangeRate" TEXT,
    "netAmount" TEXT,
    "quoteSource" TEXT,
    "quoteExpiresAt" TIMESTAMP(3),
    "acceptedAt" TIMESTAMP(3),
    "txHash" TEXT,
    "note" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Withdrawal_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Withdrawal_txHash_key" ON "Withdrawal"("txHash");

-- CreateIndex
CREATE INDEX "Withdrawal_userId_createdAt_idx" ON "Withdrawal"("userId", "createdAt");

-- CreateIndex
CREATE INDEX "Withdrawal_status_createdAt_idx" ON "Withdrawal"("status", "createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "Withdrawal_userId_idempotencyKey_key" ON "Withdrawal"("userId", "idempotencyKey");

-- AddForeignKey
ALTER TABLE "Withdrawal" ADD CONSTRAINT "Withdrawal_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;


-- Keep amounts valid even if a future writer bypasses the HTTP validators.
ALTER TABLE "Withdrawal" ADD CONSTRAINT "Withdrawal_amount_check" CHECK ("amountCents" > 0 AND "amountCents" <= 10000000);
ALTER TABLE "Withdrawal" ADD CONSTRAINT "Withdrawal_fee_check" CHECK ("feeCents" IS NULL OR ("feeCents" >= 0 AND "feeCents" < "amountCents"));
ALTER TABLE "Withdrawal" ADD CONSTRAINT "Withdrawal_currency_check" CHECK ("currency" = 'usdttrc20');
ALTER TABLE "Withdrawal" ADD CONSTRAINT "Withdrawal_quote_check" CHECK ("status" NOT IN ('QUOTED', 'APPROVED', 'PROCESSING', 'SENT', 'COMPLETED') OR ("feeCents" IS NOT NULL AND "netAmount" IS NOT NULL AND "quoteExpiresAt" IS NOT NULL AND "quoteVersion" > 0));
ALTER TABLE "Withdrawal" ADD CONSTRAINT "Withdrawal_sent_check" CHECK ("status" NOT IN ('SENT', 'COMPLETED') OR "txHash" IS NOT NULL);
