-- AlterEnum
-- This migration adds more than one value to an enum.
-- With PostgreSQL versions 11 and earlier, this is not possible
-- in a single migration. This can be worked around by creating
-- multiple migrations, each migration adding only one value to
-- the enum.


ALTER TYPE "OrderStatus" ADD VALUE 'AWAITING_QUOTE';
ALTER TYPE "OrderStatus" ADD VALUE 'QUOTE_PROPOSED';
ALTER TYPE "OrderStatus" ADD VALUE 'QUOTE_REJECTED';

-- AlterTable
ALTER TABLE "Service" ADD COLUMN     "requiresQuote" BOOLEAN NOT NULL DEFAULT false;

-- AlterTable
ALTER TABLE "Order" ADD COLUMN     "quoteAcceptedAt" TIMESTAMP(3),
ADD COLUMN     "quoteVersion" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "requiresQuote" BOOLEAN NOT NULL DEFAULT false;


-- Zero is a pending quote, never a free fixed-price service or payable order.
ALTER TABLE "Service" DROP CONSTRAINT "Service_priceCents_positive";
ALTER TABLE "Service" ADD CONSTRAINT "Service_priceCents_mode" CHECK (("requiresQuote" AND "priceCents" = 0) OR (NOT "requiresQuote" AND "priceCents" > 0));
ALTER TABLE "Order" DROP CONSTRAINT "Order_priceCents_positive";
ALTER TABLE "Order" ADD CONSTRAINT "Order_priceCents_mode" CHECK ("priceCents" > 0 OR ("requiresQuote" AND "priceCents" = 0 AND "status"::text IN ('AWAITING_QUOTE', 'CANCELLED')));
ALTER TABLE "Order" ADD CONSTRAINT "Order_quote_consent" CHECK (NOT "requiresQuote" OR "status"::text NOT IN ('AWAITING_PAYMENT', 'PROCESSING', 'ACTION_REQUIRED', 'COMPLETED') OR ("quoteAcceptedAt" IS NOT NULL AND "quoteVersion" > 0 AND "priceCents" > 0));

-- Existing orders retain their agreed pricing and status. Only new requests use quotes.
UPDATE "Service" SET "requiresQuote" = true, "priceCents" = 0,
  "requiredDocuments" = COALESCE((SELECT jsonb_agg(item || '{"required":false}'::jsonb) FROM jsonb_array_elements("requiredDocuments") AS item), '[]'::jsonb),
  "updatedAt" = CURRENT_TIMESTAMP WHERE "id" = 'carte-grise';
