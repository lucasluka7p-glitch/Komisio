import test from 'node:test';
import assert from 'node:assert/strict';
import { createHmac, randomUUID } from 'node:crypto';
import { createServer } from 'node:http';
import { createServer as netServer } from 'node:net';
import { spawn } from 'node:child_process';
import { setTimeout as delay } from 'node:timers/promises';
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { PrismaClient } from '@prisma/client';
import { createSessionToken } from '../lib/server/auth';
const database=process.env.WHATSAPP_TEST_DATABASE_URL;
test('WhatsApp real HTTP: signed intake, group isolation, local OCR, reviewed personal-price dossier and crypto consent',{skip:!database,timeout:240000},async t=>{
 assert.equal(new URL(database!).pathname,'/komisio_whatsapp_test');
 const db=new PrismaClient({datasources:{db:{url:database}}}),uploads=await mkdtemp(join(tmpdir(),'komisio-wa-'));
 const secret='w'.repeat(64),sessionSecret='s'.repeat(64),origin='https://komisio-whatsapp.test';let sends=0,ambiguous=false;const invoices:any[]=[],deliveries:any[]=[];
 const mock=createServer(async(req,res)=>{const url=new URL(req.url!,'http://localhost');const chunks:Buffer[]=[];for await(const chunk of req)chunks.push(Buffer.from(chunk));if(url.pathname==='/send')deliveries.push(JSON.parse(Buffer.concat(chunks).toString()));res.setHeader('content-type','application/json');if(url.pathname==='/send'){sends++;if(ambiguous){res.statusCode=500;return res.end('{}');}return res.end(JSON.stringify({id:'mock-send-'+sends}));}if(url.pathname==='/status')return res.end(JSON.stringify({connected:false,status:'QR_REQUIRED',qr:'NONSCANNABLE_TEST_QR'}));if(url.pathname==='/api/v1/invoices/new'){invoices.push(url.searchParams);return res.end(JSON.stringify({status:'success',data:{txn_id:'wa-invoice-'+invoices.length,invoice_url:'https://plisio.net/invoice/test-'+invoices.length,invoice_total_sum:'100'}}));}return res.end(JSON.stringify({ok:true,result:{message_id:1}}));});
 await new Promise<void>(r=>mock.listen(0,'127.0.0.1',r));const mockPort=(mock.address() as {port:number}).port;
 const reserve=netServer();await new Promise<void>(r=>reserve.listen(0,'127.0.0.1',r));const port=(reserve.address() as {port:number}).port;await new Promise<void>(r=>reserve.close(()=>r()));
 let log='';const server=spawn(process.execPath,['node_modules/next/dist/bin/next','dev','--hostname','127.0.0.1','--port',String(port)],{detached:true,stdio:['ignore','pipe','pipe'],env:{...process.env,DATABASE_URL:database,NODE_ENV:'development',NEXT_PUBLIC_DEMO_MODE:'false',NEXT_TELEMETRY_DISABLED:'1',APP_URL:origin,MINI_APP_URL:origin,TELEGRAM_BOT_TOKEN:'123456:'+'b'.repeat(40),ADMIN_TELEGRAM_IDS:'500000001',SESSION_SECRET:sessionSecret,CRON_SECRET:'c'.repeat(64),PRIVATE_UPLOAD_DIR:uploads,STORAGE_DRIVER:'local',PAYMENT_PROVIDER:'PLISIO',PLISIO_API_KEY:'test-only',WHATSAPP_ENABLED:'true',WHATSAPP_TRANSPORT:'WEB',WHATSAPP_BRIDGE_SECRET:secret,WHATSAPP_BRIDGE_URL:`http://127.0.0.1:${mockPort}`,WHATSAPP_OCR_ENABLED:'true',KOMISIO_INTEGRATION_TEST_MODE:'true',TEST_TELEGRAM_API_ROOT:`http://127.0.0.1:${mockPort}`,TEST_PLISIO_API_ROOT:`http://127.0.0.1:${mockPort}/api/v1`}});
 server.stdout!.on('data',c=>log=(log+c).slice(-5000));server.stderr!.on('data',c=>log=(log+c).slice(-5000));const base=`http://127.0.0.1:${port}`;
 async function api(path:string,cookie='',method='GET',input?:unknown,expected=200){const r=await fetch(base+path,{method,headers:{origin,'content-type':'application/json',...(cookie?{cookie}:{})},...(input!==undefined?{body:JSON.stringify(input)}:{})});const data=await r.json();assert.equal(r.status,expected,`${method} ${path}: ${JSON.stringify(data)}`);return data;}
 const cron=async()=>{const r=await fetch(base+'/api/cron/notifications',{method:'POST',headers:{authorization:'Bearer '+'c'.repeat(64)}});assert.equal(r.status,200);return r.json();};
 const group='120363123456789@g.us';let adminCookie='',otherCookie='',client:any,binding:any,draftId='',number=0;
 async function inbound(text:string,id=randomUUID(),media?:{base64:string;filename:string;mimeType:string},sender='33600000001',groupId:string|null=group,expected=200){const value={id,sender,groupId,timestamp:Math.floor(Date.now()/1000),type:media?'image':'text',text,...(media?{media}:{})};const raw=JSON.stringify(value);const r=await fetch(base+'/api/whatsapp/bridge',{method:'POST',headers:{'content-type':'application/json','x-komisio-signature':'sha256='+createHmac('sha256',secret).update(raw).digest('hex')},body:raw});assert.equal(r.status,expected);return r.json();}
 try{
  let ready=false;for(let i=0;i<100;i++){try{if((await fetch(base+'/api/config',{signal:AbortSignal.timeout(1000)})).ok){ready=true;break;}}catch{}await delay(500);}assert.ok(ready);
  const admin=await db.user.create({data:{firstName:'Admin fictif',telegramId:'500000001',role:'ADMIN'}});client=await db.user.create({data:{firstName:'Garage fictif',login:'wa.garage',mustChangePassword:true,accessReady:true,pricingVersion:1,servicePrices:{create:{serviceId:'carte-grise',mode:'DISCOUNT',discountBps:5000,minimumCents:6000}}}});const other=await db.user.create({data:{firstName:'Other',telegramId:'500000003'}});
  adminCookie='forma_session='+createSessionToken(admin.id,sessionSecret);otherCookie='forma_session='+createSessionToken(other.id,sessionSecret);
  await t.test('only admin links a provisioned account; QR is private and wrong senders/groups ignored',async()=>{
   await api('/api/admin/whatsapp',otherCookie,'POST',{action:'bind',userId:client.id,phone:'33600000001',groupId:group},403);
   binding=(await api('/api/admin/whatsapp',adminCookie,'POST',{action:'bind',userId:client.id,phone:'33600000001',groupId:group})).binding;
   await api('/api/admin/whatsapp/bridge',otherCookie,'GET',undefined,403);assert.equal((await api('/api/admin/whatsapp/bridge',adminCookie)).qr,'NONSCANNABLE_TEST_QR');assert.equal('qr' in await api('/api/config'),false);
   const result=await inbound('/cg',randomUUID(),undefined,'33600000002');assert.equal(result.accepted,false);assert.equal((await inbound('/cg',randomUUID(),undefined,'33600000001','120363111111111@g.us')).accepted,false);
   await api('/api/whatsapp/bridge/bindings','','GET',undefined,401);
   const r=await fetch(base+'/api/whatsapp/bridge',{method:'POST',headers:{'content-type':'application/json','x-komisio-signature':'sha256='+'0'.repeat(64)},body:'{}'});assert.equal(r.status,401);
  });
  await t.test('command replay creates one draft; real local OCR attaches privately without guessing buyer identity',async()=>{
   const id=randomUUID();await inbound('/cg',id);await inbound('/cg',id);await cron();assert.equal(await db.whatsAppDraft.count(),1);const draft=await db.whatsAppDraft.findFirstOrThrow();draftId=draft.id;
   await inbound('/piece registration_certificate');await cron();
   const bytes=await readFile('tests/fixtures/registration-fictional.png');await inbound('',randomUUID(),{base64:bytes.toString('base64'),filename:'carte-fictive.png',mimeType:'image/png'});await cron();
   const view=await api('/api/whatsapp/drafts/'+draftId,adminCookie);assert.ok(view.draft.files.length===1);assert.equal(view.draft.files[0].ocrStatus,'DONE');assert.equal(view.draft.fields.registration,'AA-123-AA');assert.equal(view.draft.fields.buyerLastName,undefined);assert.equal('storageKey' in view.draft.files[0],false);
   const file=view.draft.files[0];const r=await fetch(base+`/api/whatsapp/drafts/${draftId}/files/${file.id}`,{headers:{cookie:adminCookie}});assert.equal(r.status,200);await api(`/api/whatsapp/drafts/${draftId}/files/${file.id}`,otherCookie,'GET',undefined,404);
   assert.equal(await db.order.count(),0);assert.equal((await db.user.findUniqueOrThrow({where:{id:client.id}})).balanceCents,0);
  });
  await t.test('missing fields and unreviewed OCR cannot submit; WhatsApp-only account can submit once after explicit review',async()=>{
   await inbound('/valider');await cron();assert.equal(await db.order.count(),0);
   const draft=await api('/api/whatsapp/drafts/'+draftId,adminCookie);
   await api('/api/whatsapp/drafts/'+draftId,adminCookie,'PATCH',{action:'update',expectedVersion:draft.draft.version,fields:{registration:'AA-123-AA',vin:'VF000000000000001',formulaNumber:'2020AB12345',holderIdentity:'Société fictive',buyerLastName:'Test',buyerFirstName:'Alice',buyerBirthPlace:'Lyon',buyerBirthDate:'1990-01-01',deliveryAddress:'1 rue fictive, Paris'}});
   await inbound('/valider');await cron();assert.equal(await db.order.count(),0);
   await inbound('/voir');await cron();await inbound('/valider');await cron();const order=await db.order.findFirstOrThrow();number=order.number;assert.equal(order.status,'AWAITING_QUOTE');assert.equal(order.priceCents,0);assert.equal((await db.whatsAppDraft.findUniqueOrThrow({where:{id:draftId}})).orderId,order.id);
   await inbound('/valider');await cron();assert.equal(await db.order.count(),1);assert.equal(await db.ledgerEntry.count(),0);assert.equal(await db.payment.count(),0);
   await api('/api/catalog','forma_session='+createSessionToken(client.id,sessionSecret),'GET',undefined,403);
  });
  await t.test('plain replies fill an explicitly prompted field and long summaries cannot mark a draft reviewed',async()=>{
   await inbound('/fiche po');await cron();await inbound('BB-456-BB');await cron();
   const draft=await db.whatsAppDraft.findFirstOrThrow({where:{status:'OPEN',serviceId:'situation-vehicule'}});assert.equal((draft.fields as any).registration,'BB-456-BB');assert.equal(draft.reviewedVersion,null);
   await inbound('/annuler');await cron();
   await inbound('/cg');await cron();const current=await db.whatsAppDraft.findFirstOrThrow({where:{status:'OPEN'}});
   await api('/api/whatsapp/drafts/'+current.id,adminCookie,'PATCH',{action:'update',expectedVersion:current.version,fields:{holderIdentity:'X'.repeat(4000)}});
   await inbound('/voir');await cron();assert.equal((await db.whatsAppDraft.findUniqueOrThrow({where:{id:current.id}})).reviewedVersion,null);
   await inbound('/annuler');await cron();
  });
  await t.test('quote consent precedes an explicit hosted invoice at the snapshotted personal price',async()=>{
   const order=await db.order.findFirstOrThrow();const quote=await api(`/api/admin/orders/${order.id}/quote`,adminCookie,'POST',{amountCents:20000,expectedVersion:0});assert.equal(quote.priceCents,10000);
   await inbound(`/payer ${number}`);await cron();assert.equal(invoices.length,0);
   await inbound(`/accepter ${number} ${quote.quoteVersion}`);await cron();await inbound(`/payer ${number}`);await cron();assert.equal(invoices.length,1);assert.equal(invoices[0].get('source_amount'),'100.00');assert.equal((await db.order.findUniqueOrThrow({where:{id:order.id}})).status,'AWAITING_PAYMENT');
  });
  await t.test('completed deliverables are sent privately to the linked WEB group even days after the last message',async()=>{
   const order=await db.order.findFirstOrThrow();await db.order.update({where:{id:order.id},data:{status:'PROCESSING',paidAt:new Date()}});
   const key=randomUUID(),bytes=Buffer.from('%PDF-1.4\nLivrable fictif\n%%EOF');await writeFile(join(uploads,key),bytes,{mode:0o600});
   const document=await db.document.create({data:{ownerId:client.id,orderId:order.id,serviceId:order.serviceId,fieldKey:'deliverable',kind:'DELIVERABLE',storageKey:key,fileName:'livrable-fictif.pdf',mimeType:'application/pdf',bytes:bytes.length}});
   await db.whatsAppBinding.update({where:{id:binding.id},data:{lastInboundAt:new Date(Date.now()-8*86400000)}});
   await api(`/api/admin/orders/${order.id}`,adminCookie,'PATCH',{status:'COMPLETED',deliverableId:document.id});await cron();
   const delivery=deliveries.find(value=>value.media?.filename==='livrable-fictif.pdf');assert.ok(delivery);assert.equal(delivery.groupId,group);assert.equal(Buffer.from(delivery.media.base64,'base64').toString(),bytes.toString());
  });
  await t.test('uncertain replies are never automatically resent; disabling a binding blocks new intake',async()=>{
   ambiguous=true;await inbound('/solde');await cron();const unknown=await db.whatsAppOutbox.count({where:{status:'UNKNOWN'}});assert.ok(unknown>0);const count=sends;await cron();assert.equal(sends,count);
   await api('/api/admin/whatsapp',adminCookie,'POST',{action:'disable_binding',id:binding.id});assert.equal((await inbound('/cg')).accepted,false);
  });
 }catch(error){console.error(log);throw error;}finally{try{process.kill(-server.pid!,'SIGTERM');}catch{}await delay(300);try{process.kill(-server.pid!,'SIGKILL');}catch{}await new Promise<void>(r=>mock.close(()=>r()));await db.$disconnect();await rm(uploads,{recursive:true,force:true});}
});
