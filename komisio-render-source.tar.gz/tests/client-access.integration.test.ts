import test from "node:test";
import assert from "node:assert/strict";
import { createHmac, randomUUID } from "node:crypto";
import { createServer } from "node:http";
import { createServer as netServer } from "node:net";
import { spawn } from "node:child_process";
import { setTimeout as delay } from "node:timers/promises";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { PrismaClient } from "@prisma/client";
const database = process.env.CLIENT_TEST_DATABASE_URL;
test("admin-managed accounts: draft, credentials, Telegram binding, private prices, snapshots and revocation", { skip: !database, timeout: 180000 }, async t => {
  assert.equal(new URL(database!).pathname, "/komisio_clients_test");
  const db = new PrismaClient({ datasources: { db: { url: database } } });
  const uploads = await mkdtemp(join(tmpdir(), "komisio-clients-"));
  const invoices: URLSearchParams[] = [];
  const mock = createServer(async (request, response) => {
    const url = new URL(request.url!, "http://localhost");
    response.setHeader("content-type", "application/json");
    if (url.pathname === "/api/v1/invoices/new") { invoices.push(url.searchParams); return response.end(JSON.stringify({ status: "success", data: { txn_id: "test-invoice-" + invoices.length, invoice_url: "https://plisio.net/invoice/test-" + invoices.length, invoice_total_sum: "10" } })); }
    response.end(JSON.stringify({ ok: true, result: { message_id: 1 } }));
  });
  await new Promise<void>(resolve => mock.listen(0, "127.0.0.1", resolve));
  const mockPort = (mock.address() as { port: number }).port;
  const reservation = netServer(); await new Promise<void>(resolve => reservation.listen(0, "127.0.0.1", resolve)); const port = (reservation.address() as { port: number }).port; await new Promise<void>(resolve => reservation.close(() => resolve()));
  const origin = "https://komisio-clients.test", base = `http://127.0.0.1:${port}`, botToken = "123456:" + "b".repeat(40);
  let log = "";
  const server = spawn(process.execPath, ["node_modules/next/dist/bin/next", "dev", "--hostname", "127.0.0.1", "--port", String(port)], { detached: true, stdio: ["ignore", "pipe", "pipe"], env: { ...process.env, DATABASE_URL: database, NODE_ENV: "development", NEXT_PUBLIC_DEMO_MODE: "false", NEXT_TELEMETRY_DISABLED: "1", APP_URL: origin, MINI_APP_URL: origin, TELEGRAM_BOT_TOKEN: botToken, ADMIN_TELEGRAM_IDS: "700000001", SESSION_SECRET: "s".repeat(64), PRIVATE_UPLOAD_DIR: uploads, STORAGE_DRIVER: "local", PAYMENT_PROVIDER: "PLISIO", PLISIO_API_KEY: "local-test-only", KOMISIO_INTEGRATION_TEST_MODE: "true", TEST_TELEGRAM_API_ROOT: `http://127.0.0.1:${mockPort}`, TEST_PLISIO_API_ROOT: `http://127.0.0.1:${mockPort}/api/v1` } });
  server.stdout!.on("data", chunk => { log = (log + chunk).slice(-6000); }); server.stderr!.on("data", chunk => { log = (log + chunk).slice(-6000); });
  function initData(id: number) {
    const data = new URLSearchParams({ auth_date: String(Math.floor(Date.now() / 1000)), user: JSON.stringify({ id, first_name: "Test", username: "client_test" }) });
    const check = [...data.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([key, value]) => `${key}=${value}`).join("\n");
    data.set("hash", createHmac("sha256", createHmac("sha256", "WebAppData").update(botToken).digest()).update(check).digest("hex")); return data.toString();
  }
  async function request(path: string, cookie = "", method = "GET", value?: unknown, expected = 200) {
    const response = await fetch(base + path, { method, headers: { origin, ...(cookie ? { cookie } : {}), ...(value instanceof FormData ? {} : { "content-type": "application/json" }) }, ...(value !== undefined ? { body: value instanceof FormData ? value : JSON.stringify(value) } : {}) });
    const data = await response.json(); assert.equal(response.status, expected, `${method} ${path}: ${JSON.stringify(data)}`); return { data, cookie: response.headers.get("set-cookie")?.split(";")[0] || "" };
  }
  const api = async (path: string, cookie = "", method = "GET", value?: unknown, expected = 200) => (await request(path, cookie, method, value, expected)).data;
  const prices = [{ serviceId: "ww", mode: "FIXED", priceCents: 9500, discountBps: 0, minimumCents: 0 }, ...["carte-grise", "carte-grise-sans-ct"].map(serviceId => ({ serviceId, mode: "DISCOUNT", priceCents: null, discountBps: 5000, minimumCents: 6000 }))];
  let admin = "", owner = "", other = "", client: any, credentials: any;
  const fields = { registration: "AA-123-AA", vin: "VF000000000000001", formulaNumber: "TEST", holderIdentity: "Société fictive", buyerLastName: "Test", buyerFirstName: "Alice", buyerBirthPlace: "Lyon", buyerBirthDate: "1990-01-01", deliveryAddress: "1 rue de test" };
  const cg = async () => (await api("/api/orders", owner, "POST", { serviceId: "carte-grise", fields, documentIds: [], paymentMethod: "CRYPTO", idempotencyKey: randomUUID() }, 201)).order;
  try {
    let ready = false; for (let i = 0; i < 100; i++) { try { if ((await fetch(base + "/api/config", { signal: AbortSignal.timeout(1500) })).ok) { ready = true; break; } } catch {} await delay(500); } assert.ok(ready);
    admin = (await request("/api/auth/telegram", "", "POST", { initData: initData(700000001) })).cookie;
    await db.user.create({ data: { firstName: "Autre client", telegramId: "700000003" } });
    other = (await request("/api/auth/telegram", "", "POST", { initData: initData(700000003) })).cookie;
    await t.test("uninvited Telegram identities cannot register; only admin creates drafts", async () => {
      await api("/api/auth/telegram", "", "POST", { initData: initData(700000099) }, 403);
      assert.equal(await db.user.count(), 2);
      const input = { name: "Garage de test", login: "garage.test", pricing: { defaultDiscountBps: 1000, prices } };
      await api("/api/admin/users", other, "POST", input, 403);
      const result = await api("/api/admin/users", admin, "POST", input, 201); client = result.client;
      assert.equal(client.accessReady, false); assert.equal("credentials" in result, false); assert.equal("passwordHash" in client, false);
      assert.equal(client.servicePrices.length, 3);
      await api("/api/admin/users", admin, "POST", input, 409);
      await api("/api/admin/users", admin, "POST", { ...input, login: "bad", telegramId: "700000001" }, 400);
    });
    await t.test("activation produces one-time credentials; first login must change the password", async () => {
      const activated = await api(`/api/admin/users/${client.id}/access`, admin, "POST", { action: "activate", expectedVersion: client.credentialVersion }); credentials = activated.credentials; client = activated.client;
      assert.ok(credentials.password.length >= 20); assert.equal(client.accessReady, true);
      await api(`/api/admin/users/${client.id}/access`, admin, "POST", { action: "activate", expectedVersion: client.credentialVersion }, 409);
      const signed = await request("/api/auth/password", "", "POST", credentials); owner = signed.cookie;
      assert.equal(signed.data.user.mustChangePassword, true); assert.equal("passwordHash" in signed.data.user, false);
      await api("/api/catalog", owner, "GET", undefined, 403); await api("/api/orders", owner, "GET", undefined, 403);
      await api("/api/auth/change-password", owner, "POST", { currentPassword: "wrong", password: "test-personal-password-42" }, 400);
      const changed = await request("/api/auth/change-password", owner, "POST", { currentPassword: credentials.password, password: "test-personal-password-42" });
      await api("/api/me", owner, "GET", undefined, 401); owner = changed.cookie;
      assert.equal((await api("/api/me", owner)).user.mustChangePassword, false);
      await api("/api/auth/password", "", "POST", credentials, 401);
    });
    await t.test("each client sees only their prices and cannot submit a forged price", async () => {
      const catalogue = await api("/api/catalog", owner), others = await api("/api/catalog", other);
      assert.equal(catalogue.find((s: any) => s.id === "ww").priceCents, 9500);
      assert.equal(others.find((s: any) => s.id === "ww").priceCents, 8000);
      assert.equal(catalogue.find((s: any) => s.id === "creation").priceCents, 126000);
      assert.equal(catalogue.find((s: any) => s.id === "carte-grise").requiresQuote, true);
      const me = await api("/api/me", owner); assert.equal("passwordHash" in me.user, false); assert.equal("credentialVersion" in me.user, false);
      await api("/api/admin/users", owner, "GET", undefined, 403);
      const files: string[] = [];
      for (const fieldKey of ["registration_certificate", "holder_identity"]) { const form = new FormData(); form.set("serviceId", "ww"); form.set("fieldKey", fieldKey); form.set("file", new Blob([Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jhFYAAAAASUVORK5CYII=", "base64")], { type: "image/png" }), "test.png"); files.push((await api("/api/documents", owner, "POST", form, 201)).id); }
      await api(`/api/admin/users/${client.id}/balance`, admin, "POST", { amountCents: 50000, reason: "Crédit de test", idempotencyKey: randomUUID() });
      const input = { serviceId: "ww", fields: { holderAddress: "1 rue de test" }, documentIds: files, paymentMethod: "WALLET", idempotencyKey: randomUUID(), priceCents: 1 };
      const order = (await api("/api/orders", owner, "POST", input, 201)).order;
      assert.equal(order.priceCents, 9500); assert.equal(order.status, "PROCESSING"); assert.equal((await api("/api/me", owner)).user.balanceCents, 40500);
      assert.equal((await api("/api/orders", owner, "POST", input, 201)).order.id, order.id);
    });
    await t.test("home estimate uses the authenticated client rate and creates no dossier or debit", async () => {
      const data = { serviceId: "carte-grise", region: "ara", fiscalPower: 6, firstRegistration: "2020-06-01", ordinaryFrenchUsedCar: true };
      const orders = await db.order.count();
      const balance = (await api("/api/me", owner)).user.balanceCents;
      await api("/api/vehicle-estimate", "", "POST", data, 401);
      await api("/api/vehicle-estimate", owner, "POST", { ...data, discountBps: 9999 }, 400);
      const result = await api("/api/vehicle-estimate", owner, "POST", data);
      assert.equal(result.estimate.referenceCents, 27176); assert.equal(result.commercialAmountCents, 13588);
      assert.equal(result.pricing.discountBps, 5000);
      assert.equal((await api("/api/vehicle-estimate", other, "POST", data)).commercialAmountCents, null);
      await api("/api/vehicle-estimate", owner, "POST", { ...data, ordinaryFrenchUsedCar: false }, 400);
      assert.equal(await db.order.count(), orders); assert.equal((await api("/api/me", owner)).user.balanceCents, balance);
      await api("/api/admin/whatsapp/bridge", owner, "GET", undefined, 403);
      const config = await api("/api/config"); assert.equal(config.whatsappSupportUrl, null); assert.equal("WHATSAPP_BRIDGE_SECRET" in config, false);
    });
    await t.test("pricing edits are versioned and cannot reprice submitted dossiers or invoices", async () => {
      const first = await cg();
      const input = { name: client.firstName, login: client.login, expectedVersion: client.pricingVersion, pricing: { defaultDiscountBps: 0, prices: prices.map(rule => rule.mode === "DISCOUNT" ? { ...rule, discountBps: 6000 } : rule) } };
      client = (await api(`/api/admin/users/${client.id}`, admin, "PATCH", input)).client;
      await api(`/api/admin/users/${client.id}`, admin, "PATCH", input, 409);
      const quote = await api(`/api/admin/orders/${first.id}/quote`, admin, "POST", { amountCents: 20000, expectedVersion: 0 });
      assert.equal(quote.priceCents, 10000); assert.equal(quote.quoteReferenceCents, 20000);
      const before = (await api("/api/me", owner)).user.balanceCents;
      const count = await db.order.count({ where: { userId: client.id } });
      await api("/api/orders", owner, "POST", { serviceId: "carte-grise", fields, documentIds: [], paymentMethod: "WALLET", expectedPriceCents: 0, expectedPricingVersion: 1, idempotencyKey: randomUUID() }, 409);
      assert.equal(await db.order.count({ where: { userId: client.id } }), count);
      assert.equal((await api("/api/me", owner)).user.balanceCents, before);
      const second = await cg(); const next = await api(`/api/admin/orders/${second.id}/quote`, admin, "POST", { amountCents: 10000, expectedVersion: 0 }); assert.equal(next.priceCents, 6000);
      await api(`/api/orders/${first.id}/quote`, owner, "POST", { action: "accept", quoteVersion: quote.quoteVersion });
      await api(`/api/admin/orders/${first.id}/quote`, admin, "POST", { amountCents: 100, expectedVersion: 1 }, 409);
      const payment = await api("/api/payments", owner, "POST", { orderId: first.id, amountCents: 100, payCurrency: "usdttrc20", idempotencyKey: randomUUID() }, 201);
      assert.equal(payment.amountCents, 10000); assert.equal(invoices.at(-1)!.get("source_amount"), "100.00");
      await api(`/api/orders/${first.id}`, other, "GET", undefined, 404);
      await api(`/api/admin/users/${client.id}`, admin, "PATCH", { ...input, expectedVersion: client.pricingVersion, pricing: { defaultDiscountBps: 0, prices: [{ ...prices[1], minimumCents: 5900 }] } }, 400);
    });
    await t.test("free estimator proposals are recomputed by the server and recorded with their source", async () => {
      const { estimateVehicleTax } = await import("../lib/vehicle-estimate");
      const input = { region: "ara", fiscalPower: 6, firstRegistration: "2020-06-01", ordinaryFrenchUsedCar: true };
      const reference = estimateVehicleTax(input).referenceCents;
      const order = await cg();
      await api(`/api/admin/orders/${order.id}/quote`, admin, "POST", { amountCents: reference + 1, expectedVersion: 0, vehicleEstimate: input }, 400);
      const quote = await api(`/api/admin/orders/${order.id}/quote`, admin, "POST", { amountCents: reference, expectedVersion: 0, vehicleEstimate: input });
      assert.equal(quote.priceCents, Math.max(6000, Math.round(reference * 0.4)));
      const audit = await db.auditLog.findFirstOrThrow({ where: { action: "ORDER_QUOTE_PROPOSED", targetId: order.id } });
      assert.ok(JSON.stringify(audit.details).includes("service-public.gouv.fr"));
    });
    await t.test("verified Telegram can link to a provisioned account without changing its tariffs", async () => {
      const signed = await request("/api/auth/password", "", "POST", { login: credentials.login, password: "test-personal-password-42", initData: initData(700000002) }); owner = signed.cookie;
      assert.equal(signed.data.user.telegramId, "700000002");
      const automatic = await request("/api/auth/telegram", "", "POST", { initData: initData(700000002) }); assert.equal(automatic.data.user.id, client.id);
      await api("/api/auth/password", "", "POST", { login: credentials.login, password: "test-personal-password-42", initData: initData(700000004) }, 409);
      await api("/api/auth/password", "", "POST", { login: credentials.login, password: "test-personal-password-42", initData: initData(700000001) }, 409);
    });
    await t.test("suspension and reset revoke existing sessions, including after resuming", async () => {
      const suspended = (await api(`/api/admin/users/${client.id}/access`, admin, "POST", { action: "suspend", expectedVersion: client.credentialVersion })).client;
      await api("/api/me", owner, "GET", undefined, 403);
      const resumed = (await api(`/api/admin/users/${client.id}/access`, admin, "POST", { action: "resume", expectedVersion: suspended.credentialVersion })).client;
      await api("/api/me", owner, "GET", undefined, 401);
      const reset = await api(`/api/admin/users/${client.id}/access`, admin, "POST", { action: "reset", expectedVersion: resumed.credentialVersion });
      assert.notEqual(reset.credentials.password, credentials.password); await api("/api/auth/password", "", "POST", { login: credentials.login, password: "test-personal-password-42" }, 401);
      assert.ok(await db.auditLog.count({ where: { action: "CLIENT_ACCESS_RESET", targetId: client.id } }));
      const stored = await db.user.findUniqueOrThrow({ where: { id: client.id } }); assert.ok(stored.passwordHash?.startsWith("scrypt$")); assert.equal(stored.passwordHash!.includes(reset.credentials.password), false);
      const logs = await db.auditLog.findMany({ where: { targetId: client.id } }); assert.equal(JSON.stringify(logs).includes(reset.credentials.password), false);
      assert.equal(JSON.stringify(await api("/api/admin/users", admin)).includes("passwordHash"), false);
    });
    await t.test("persistent brute-force limits reject repeated bad passwords and origin checks reject cross-site login", async () => {
      for (let i = 0; i < 8; i++) await api("/api/auth/password", "", "POST", { login: "unknown.user", password: "wrong" }, 401);
      await api("/api/auth/password", "", "POST", { login: "unknown.user", password: "wrong" }, 429);
      const cross = await fetch(base + "/api/auth/password", { method: "POST", headers: { origin: "https://other.test", "content-type": "application/json" }, body: JSON.stringify({ login: "unknown.user", password: "wrong" }) }); assert.equal(cross.status, 403);
    });
  } catch (error) { console.error(log); throw error; } finally {
    try { process.kill(-server.pid!, "SIGTERM"); } catch {} await delay(300); try { process.kill(-server.pid!, "SIGKILL"); } catch {}
    await new Promise<void>(resolve => mock.close(() => resolve())); await db.$disconnect(); await rm(uploads, { recursive: true, force: true });
  }
});
