import test from "node:test";
import assert from "node:assert/strict";
import { body, HttpError, MAX_JSON_BYTES } from "../lib/server/http";
import { validIsoDate } from "../lib/server/validation";

test("JSON parsing bounds a chunked body and cancels its stream before buffering it all", async () => {
  let cancelled = false;
  let chunksRead = 0;
  const stream = new ReadableStream<Uint8Array>({
    pull(controller) {
      chunksRead++;
      controller.enqueue(new Uint8Array(64_001));
    },
    cancel() {
      cancelled = true;
    },
  });
  const request = new Request("https://example.com/api/auth/telegram", {
    method: "POST",
    body: stream,
    duplex: "half",
  } as RequestInit & { duplex: string });
  await assert.rejects(
    () => body(request),
    (error: unknown) => error instanceof HttpError && error.status === 413,
  );
  assert.equal(cancelled, true);
  assert.ok(
    chunksRead <= 3,
    "only bounded chunks, including possible stream prefetch, are read",
  );
});

test("JSON parsing rejects an oversized declared length and invalid UTF-8", async () => {
  await assert.rejects(
    () =>
      body(
        new Request("https://example.com", {
          method: "POST",
          body: "{}",
          headers: { "content-length": String(MAX_JSON_BYTES + 1) },
        }),
      ),
    (error: unknown) => error instanceof HttpError && error.status === 413,
  );
  await assert.rejects(
    () =>
      body(
        new Request("https://example.com", {
          method: "POST",
          body: new Uint8Array([0xff]),
        }),
      ),
    (error: unknown) => error instanceof HttpError && error.status === 400,
  );
});

test("JSON parsing accepts split multibyte UTF-8 within the byte limit", async () => {
  const encoded = new TextEncoder().encode('{"nom":"Élodie"}');
  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      controller.enqueue(encoded.slice(0, 9));
      controller.enqueue(encoded.slice(9));
      controller.close();
    },
  });
  const request = new Request("https://example.com", {
    method: "POST",
    body: stream,
    duplex: "half",
  } as RequestInit & { duplex: string });
  assert.deepEqual(await body(request), { nom: "Élodie" });
});

test("dynamic date fields accept leap dates and reject impossible or rolled-over dates", () => {
  assert.equal(validIsoDate("2024-02-29"), true);
  assert.equal(validIsoDate("2026-10-21"), true);
  for (const value of [
    "2026-02-29",
    "2026-02-31",
    "2026-99-99",
    "2026-04-31",
    "2026-00-01",
    "2026-1-01",
    "not-a-date",
  ])
    assert.equal(validIsoDate(value), false, value);
});
