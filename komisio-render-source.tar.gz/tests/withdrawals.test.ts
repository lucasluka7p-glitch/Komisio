import test from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { calculateNet, validTronAddress, withdrawalInput, adminWithdrawalAction } from "../lib/server/withdrawal-validation";
const address = "T9yD14Nj9j7xAB4dbGeiX9h8unkKHxuWwb";
test("TRON addresses require mainnet prefix, length and valid base58 checksum", () => {
  assert.equal(validTronAddress(address), true);
  assert.equal(validTronAddress(address.slice(0, -1) + "c"), false);
  assert.equal(validTronAddress("0x" + "a".repeat(40)), false);
  assert.equal(validTronAddress("T" + "1".repeat(33)), false);
});
test("withdrawal amount, currency, server-only fields and idempotency are validated", () => {
  const valid = { address, amountCents: 10000, currency: "usdttrc20", idempotencyKey: randomUUID() };
  assert.equal(withdrawalInput.safeParse(valid).success, true);
  for (const change of [{ amountCents: 0 }, { amountCents: 0.5 }, { currency: "usdterc20" }, { status: "COMPLETED" }, { idempotencyKey: "same" }]) assert.equal(withdrawalInput.safeParse({ ...valid, ...change }).success, false);
});
test("net USDT uses exact decimal arithmetic and rounds down to six decimals", () => {
  assert.equal(calculateNet(10000, 125, "1.087654321"), "107.405864");
  assert.equal(calculateNet(101, 1, "1.0000009"), "1.000000");
  assert.throws(() => calculateNet(100, 100, "1"));
  assert.throws(() => calculateNet(100, 0, "0"));
});
test("payout evidence cannot be supplied with an arbitrary hash or negative fee", () => {
  assert.equal(adminWithdrawalAction.safeParse({ action: "sent", txHash: "fake" }).success, false);
  assert.equal(adminWithdrawalAction.safeParse({ action: "sent", txHash: "a".repeat(64) }).success, true);
  assert.equal(adminWithdrawalAction.safeParse({ action: "quote", feeCents: -1, exchangeRate: "1", source: "Provider quote" }).success, false);
});
