import test from 'node:test';
import assert from 'node:assert/strict';
import { createHmac,randomUUID } from 'node:crypto';
import { createServer } from 'node:http';
import { createServer as createNetServer } from 'node:net';
import { spawn } from 'node:child_process';
import { mkdtemp,rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { PrismaClient } from '@prisma/client';
import { canonicalize } from '../lib/server/payment-signature';
const database=process.env.HTTP_TEST_DATABASE_URL;
test('real HTTP flow: Telegram sessions, private files, quotes, wallet, crypto webhooks, recovery, withdrawals and notifications',{skip:!database,timeout:180000},async t=>{
 assert.equal(new URL(database!).pathname,'/komisio_http_test','Disposable test database required');
 const db=new PrismaClient({datasources:{db:{url:database}}});
 const uploadDir=await mkdtemp(join(tmpdir(),'komisio-http-'));
 const receipts=new Map<string,Record<string,any>>();const messages:any[]=[];let ambiguous=false;let nextInvoice=100;
 const mock=createServer(async(req,res)=>{
  const chunks:Buffer[]=[];for await(const part of req)chunks.push(Buffer.from(part));const raw=Buffer.concat(chunks).toString();const input=raw?JSON.parse(raw):{};
  res.setHeader('content-type','application/json');
  if(req.url?.includes('/sendMessage')){messages.push(input);res.end(JSON.stringify({ok:true,result:{message_id:messages.length,date:Math.floor(Date.now()/1000),chat:{id:Number(input.chat_id),type:'private'},text:input.text}}));return;}
  if(req.url==='/v1/payment'&&req.method==='POST'){
   const id=String(nextInvoice++);const receipt={payment_id:id,order_id:input.order_id,payment_status:'waiting',price_amount:input.price_amount,price_currency:'eur',pay_currency:input.pay_currency,pay_amount:'111.00',pay_address:'T9yD14Nj9j7xAB4dbGeiX9h8unkKHxuWwb'};receipts.set(id,receipt);
   if(ambiguous){ambiguous=false;res.statusCode=500;res.end('{}');}else res.end(JSON.stringify(receipt));return;
  }
  const receipt=receipts.get(req.url?.split('/').at(-1)||'');if(receipt){res.end(JSON.stringify(receipt));return;}res.statusCode=404;res.end('{}');
 });
 await new Promise<void>(resolve=>mock.listen(0,'127.0.0.1',resolve));const mockPort=(mock.address() as any).port;
 const probe=createNetServer();await new Promise<void>(resolve=>probe.listen(0,'127.0.0.1',resolve));const port=(probe.address() as any).port;await new Promise<void>(resolve=>probe.close(()=>resolve()));
 const base=`http://127.0.0.1:${port}`,origin='https://komisio.test',botToken='123456:'+('a'.repeat(40)),ipnSecret='i'.repeat(64),webhookSecret='w'.repeat(64);
 let log='';const server=spawn(process.execPath,['node_modules/next/dist/bin/next','dev','--hostname','127.0.0.1','--port',String(port)],{detached:true,env:{...process.env,DATABASE_URL:database,NODE_ENV:'development',NEXT_PUBLIC_DEMO_MODE:'false',NEXT_TELEMETRY_DISABLED:'1',APP_URL:origin,MINI_APP_URL:origin,TELEGRAM_BOT_TOKEN:botToken,TELEGRAM_BOT_USERNAME:'KomisioLocalBot',ADMIN_TELEGRAM_IDS:'900000001',SESSION_SECRET:'s'.repeat(64),CRON_SECRET:'c'.repeat(64),TELEGRAM_WEBHOOK_SECRET:webhookSecret,PAYMENT_PROVIDER:'NOWPAYMENTS',NOWPAYMENTS_API_KEY:'test-local-only',NOWPAYMENTS_IPN_SECRET:ipnSecret,PRIVATE_UPLOAD_DIR:uploadDir,WITHDRAWALS_ENABLED:'true',KOMISIO_INTEGRATION_TEST_MODE:'true',TEST_TELEGRAM_API_ROOT:`http://127.0.0.1:${mockPort}`,TEST_NOWPAYMENTS_API_ROOT:`http://127.0.0.1:${mockPort}/v1`},stdio:['ignore','pipe','pipe']});
 server.stdout?.on('data',chunk=>{log=(log+chunk).slice(-8000)});server.stderr?.on('data',chunk=>{log=(log+chunk).slice(-8000)});
 async function api(path:string,cookie='',method='GET',value?:unknown,expected=200){const response=await fetch(base+path,{method,headers:{origin,...(cookie?{cookie}:{}),...(value instanceof FormData?{}:{'content-type':'application/json'})},body:value===undefined?undefined:value instanceof FormData?value:JSON.stringify(value)});const payload=await response.json();assert.equal(response.status,expected,`${method} ${path}: ${JSON.stringify(payload)}`);return payload;}
 function initData(id:number){const p=new URLSearchParams({auth_date:String(Math.floor(Date.now()/1000)),user:JSON.stringify({id,first_name:'Test '+id,username:'komisio_test_'+id})});const check=[...p.entries()].sort(([a],[b])=>a.localeCompare(b)).map(([key,value])=>`${key}=${value}`).join('\n');const secret=createHmac('sha256','WebAppData').update(botToken).digest();p.set('hash',createHmac('sha256',secret).update(check).digest('hex'));return p.toString();}
 async function login(id:number){const r=await fetch(base+'/api/auth/telegram',{method:'POST',headers:{origin,'content-type':'application/json'},body:JSON.stringify({initData:initData(id)})});assert.equal(r.status,200);return {cookie:r.headers.get('set-cookie')!.split(';')[0],user:(await r.json()).user};}
 async function upload(cookie:string,serviceId:string,fieldKey:string,orderId?:string,kind='ATTACHMENT'){const f=new FormData();f.set('serviceId',serviceId);f.set('fieldKey',fieldKey);if(orderId)f.set('orderId',orderId);f.set('kind',kind);const bytes=kind==='DELIVERABLE'?Buffer.from('%PDF-1.4\nTest fictif\n%%EOF'):Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jhFYAAAAASUVORK5CYII=','base64');f.set('file',new Blob([bytes],{type:kind==='DELIVERABLE'?'application/pdf':'image/png'}),kind==='DELIVERABLE'?'livrable-test.pdf':'piece-test.png');return api('/api/documents',cookie,'POST',f,201);}
 try{
  let started=false;for(let i=0;i<90;i++){try{const r=await fetch(base+'/api/config',{signal:AbortSignal.timeout(1500)});if(r.ok){started=true;break;}}catch{}await delay(500);}assert.ok(started,'Next server did not start');
  for (const telegramId of [900000002, 900000003]) await db.user.create({ data: { telegramId: String(telegramId), firstName: "Client de test" } });
  const admin=await login(900000001),owner=await login(900000002),other=await login(900000003);
  let fixedId='',quoteId='',topupId='';
  await t.test('authentication and private catalogue enforce roles; runtime health is ready',async()=>{
   await api('/api/health');const config=await api('/api/config');assert.equal(config.telegramBotUrl,'https://t.me/KomisioLocalBot');
   await api('/api/me','','GET',undefined,401);await api('/api/admin/services',owner.cookie,'GET',undefined,403);assert.equal((await api('/api/catalog',owner.cookie)).length,36);
   await api('/api/auth/telegram','','POST',{initData:initData(900000004).replace('Test','Tampered')},401);
  });
  await t.test('manual credit is idempotent and a fixed order debits once with private attachments',async()=>{
   const credit={amountCents:50000,reason:'Crédit de test',idempotencyKey:randomUUID()};await api(`/api/admin/users/${owner.user.id}/balance`,admin.cookie,'POST',credit);await api(`/api/admin/users/${owner.user.id}/balance`,admin.cookie,'POST',credit);
   const a=await upload(owner.cookie,'ww','registration_certificate'),b=await upload(owner.cookie,'ww','holder_identity');
   const input={serviceId:'ww',fields:{holderAddress:'1 rue de test, Paris'},documentIds:[a.id,b.id],paymentMethod:'WALLET',idempotencyKey:randomUUID()};
   const first=(await api('/api/orders',owner.cookie,'POST',input,201)).order;fixedId=first.id;assert.equal(first.status,'PROCESSING');assert.equal((await api('/api/orders',owner.cookie,'POST',input,201)).order.id,fixedId);assert.equal((await api('/api/me',owner.cookie)).user.balanceCents,42000);
   assert.equal((await fetch(base+`/api/documents/${a.id}`,{headers:{cookie:owner.cookie}})).status,200);await api(`/api/documents/${a.id}`,other.cookie,'GET',undefined,404);await api(`/api/orders/${fixedId}`,other.cookie,'GET',undefined,404);
  });
  await t.test('missing-document response, deliverable and completed download work through HTTP',async()=>{
   await api(`/api/admin/orders/${fixedId}`,admin.cookie,'PATCH',{status:'ACTION_REQUIRED',note:'Merci de joindre une pièce lisible.'});await upload(owner.cookie,'ww','holder_identity',fixedId);await api(`/api/orders/${fixedId}`,owner.cookie,'PATCH',{note:'Pièce ajoutée.'});const final=await upload(admin.cookie,'ww','final',fixedId,'DELIVERABLE');
   await api(`/api/admin/orders/${fixedId}`,admin.cookie,'PATCH',{status:'COMPLETED',deliverableId:final.id});const download=await fetch(base+`/api/documents/${final.id}`,{headers:{cookie:owner.cookie}});assert.equal(download.status,200);assert.equal(download.headers.get('content-type'),'application/pdf');await api(`/api/documents/${final.id}`,other.cookie,'GET',undefined,404);
  });
  await t.test('quote acceptance gates payment and a cancellation refunds only once',async()=>{
   const fields={registration:'AA-123-AA',vin:'VF000000000000001',formulaNumber:'FORM123',holderIdentity:'Société test',buyerLastName:'Test',buyerFirstName:'Alice',buyerBirthPlace:'Paris',buyerBirthDate:'1990-01-01',deliveryAddress:'1 rue de test, Paris'};
   const order=(await api('/api/orders',owner.cookie,'POST',{serviceId:'carte-grise',fields,documentIds:[],paymentMethod:'WALLET',idempotencyKey:randomUUID()},201)).order;quoteId=order.id;assert.equal(order.status,'AWAITING_QUOTE');await api(`/api/orders/${quoteId}/pay`,owner.cookie,'POST',{},409);
   const quote=await api(`/api/admin/orders/${quoteId}/quote`,admin.cookie,'POST',{amountCents:10000,expectedVersion:0,note:'Prix du test'});await api(`/api/orders/${quoteId}/quote`,owner.cookie,'POST',{action:'accept',quoteVersion:quote.quoteVersion});await api(`/api/orders/${quoteId}/pay`,owner.cookie,'POST',{});assert.equal((await api('/api/me',owner.cookie)).user.balanceCents,32000);
   await api(`/api/admin/orders/${quoteId}`,admin.cookie,'PATCH',{status:'CANCELLED'});await api(`/api/admin/orders/${quoteId}`,admin.cookie,'PATCH',{status:'CANCELLED'},409);assert.equal((await api('/api/me',owner.cookie)).user.balanceCents,42000);
  });
  await t.test('signed crypto webhook credits a top-up once and rejects invalid signatures',async()=>{
   const p=await api('/api/payments',owner.cookie,'POST',{amountCents:2000,payCurrency:'usdttrc20',idempotencyKey:randomUUID()},201);topupId=p.id;const remote=receipts.get(p.providerPaymentId)!;remote.payment_status='finished';remote.actually_paid=remote.pay_amount;const event={payment_id:p.providerPaymentId,order_id:p.id};
   const webhook=async(signature:string)=>fetch(base+'/api/webhooks/nowpayments',{method:'POST',headers:{'content-type':'application/json','x-nowpayments-sig':signature},body:JSON.stringify(event)});
   assert.equal((await webhook('wrong')).status,401);const sig=createHmac('sha512',ipnSecret).update(JSON.stringify(canonicalize(event))).digest('hex');const responses=await Promise.all([webhook(sig),webhook(sig)]);assert.ok(responses.every(r=>r.status===200));assert.equal((await api('/api/me',owner.cookie)).user.balanceCents,44000);assert.equal(await db.ledgerEntry.count({where:{reference:`crypto:${topupId}`}}),1);
  });
  await t.test('lost invoice responses can be recovered only by admin after provider verification',async()=>{
   ambiguous=true;await api('/api/payments',owner.cookie,'POST',{amountCents:1500,payCurrency:'usdttrc20',idempotencyKey:randomUUID()},502);const operations=await api('/api/admin/operations',admin.cookie);const local=operations.invoices[0];assert.ok(local);
   const remote=[...receipts.values()].find(r=>r.order_id===local.id)!;remote.payment_status='finished';remote.actually_paid=remote.pay_amount;
   await api(`/api/admin/payments/${local.id}/link`,owner.cookie,'POST',{providerPaymentId:remote.payment_id},403);await api(`/api/admin/payments/${local.id}/link`,admin.cookie,'POST',{providerPaymentId:[...receipts.keys()][0]},409);
   await api(`/api/admin/payments/${local.id}/link`,admin.cookie,'POST',{providerPaymentId:remote.payment_id});await api(`/api/admin/payments/${local.id}/link`,admin.cookie,'POST',{providerPaymentId:remote.payment_id});assert.equal((await api('/api/me',owner.cookie)).user.balanceCents,45500);assert.equal(await db.auditLog.count({where:{targetId:local.id,action:'PAYMENT_PROVIDER_LINKED'}}),1);
  });
  await t.test('withdrawal fee acceptance reserves once, then manual transfer completes without releasing funds',async()=>{
   const w=await api('/api/withdrawals',owner.cookie,'POST',{amountCents:10000,currency:'usdttrc20',address:'T9yD14Nj9j7xAB4dbGeiX9h8unkKHxuWwb',idempotencyKey:randomUUID()},201);
   const quoted=await api(`/api/admin/withdrawals/${w.id}`,admin.cookie,'POST',{action:'quote',feeCents:100,exchangeRate:'1.1',source:'Devis de test'});await api(`/api/withdrawals/${w.id}`,owner.cookie,'POST',{action:'accept',quoteVersion:quoted.quoteVersion});assert.equal((await api('/api/me',owner.cookie)).user.balanceCents,35500);
   await api(`/api/admin/withdrawals/${w.id}`,admin.cookie,'POST',{action:'process'});await api(`/api/admin/withdrawals/${w.id}`,admin.cookie,'POST',{action:'sent',txHash:'a'.repeat(64)});await api(`/api/admin/withdrawals/${w.id}`,admin.cookie,'POST',{action:'complete',note:'Confirmation de test'});await api(`/api/withdrawals/${w.id}`,owner.cookie,'POST',{action:'cancel'},409);assert.equal((await api('/api/me',owner.cookie)).user.balanceCents,35500);
  });
  await t.test('bot start, notification delivery and audited retry use only the local Telegram simulator',async()=>{
   const update={update_id:1,message:{message_id:1,chat:{id:900000002,type:'private'},text:'/start'}};assert.equal((await fetch(base+'/api/bot',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(update)})).status,401);
   const r=await fetch(base+'/api/bot',{method:'POST',headers:{'content-type':'application/json','x-telegram-bot-api-secret-token':webhookSecret},body:JSON.stringify(update)});assert.equal(r.status,200);assert.ok(messages.some(m=>m.reply_markup?.inline_keyboard?.[0]?.[0]?.web_app?.url===origin+'/'));
   const support={update_id:2,message:{message_id:2,chat:{id:900000002,type:'private'},from:{id:900000002},text:'Question support de test'}};
   const sendUpdate=(body:unknown)=>fetch(base+'/api/bot',{method:'POST',headers:{'content-type':'application/json','x-telegram-bot-api-secret-token':webhookSecret},body:JSON.stringify(body)});
   assert.equal((await sendUpdate(support)).status,200);assert.equal((await sendUpdate(support)).status,200);assert.equal(await db.auditLog.count({where:{action:'SUPPORT_RELAY',targetId:'telegram-update:2'}}),1);
   assert.equal((await sendUpdate({update_id:3,message:{chat:{id:900000001,type:'private'},from:{id:900000001},text:'/reply 900000002 Réponse support de test'}})).status,200);
   await fetch(base+'/api/cron/notifications',{method:'POST',headers:{authorization:'Bearer '+'c'.repeat(64)}});
   assert.ok(messages.some(m=>m.text.includes('Question support de test')&&String(m.chat_id)==='900000001'));assert.ok(messages.some(m=>m.text.includes('Réponse support de test')&&String(m.chat_id)==='900000002'));
   await db.notificationOutbox.create({data:{chatId:'900000002',text:'Relance de test',attempts:10}});await api('/api/admin/operations',admin.cookie,'POST',{action:'retry_notifications'});await fetch(base+'/api/cron/notifications',{method:'POST',headers:{authorization:'Bearer '+'c'.repeat(64)}});assert.ok(messages.some(m=>m.text==='Relance de test'));assert.equal((await api('/api/admin/operations',admin.cookie)).notifications.failed,0);
  });
 }catch(error){console.error(log);throw error;}finally{
  try{process.kill(-server.pid!,'SIGTERM');}catch{}await delay(300);try{process.kill(-server.pid!,'SIGKILL');}catch{}
  await new Promise<void>(resolve=>mock.close(()=>resolve()));await db.$disconnect();await rm(uploadDir,{recursive:true,force:true});
 }
});
