import test from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
const url = process.env.ORDER_QUOTE_TEST_DATABASE_URL;
test("order quotes: optional uploads, consent, payment gates and competing decisions", { skip: !url }, async t => {
  assert.equal(new URL(url!).pathname, "/forma_quotes_test", "Use an isolated quote test database");
  process.env.DATABASE_URL = url;
  process.env.PAYMENT_PROVIDER = "NOWPAYMENTS";
  process.env.NOWPAYMENTS_API_KEY = "test-unused-provider-key";
  process.env.APP_URL = "https://forma.test";
  process.env.SESSION_SECRET = "q".repeat(64);
  const { db, serializable } = await import("../lib/server/db");
  const { createOrder, orderInput, payOrderWithWallet } = await import("../lib/server/orders");
  const { proposeOrderQuote, decideOrderQuote, proposalInput } = await import("../lib/server/order-quotes");
  const { createPayment, reconcilePayment } = await import("../lib/server/payments");
  const { createSessionToken } = await import("../lib/server/auth");
  const { PATCH: updateOrderRoute } = await import("../app/api/admin/orders/[id]/route");
  const { POST: proposalRoute } = await import("../app/api/admin/orders/[id]/quote/route");
  const { updateOriginalDocument, originalDocumentInput } = await import("../lib/server/original-documents");
  const { POST: originalRoute } = await import("../app/api/admin/orders/[id]/original-document/route");
  const prefix = String(Date.now());
  const owner = await db.user.create({ data: { telegramId: `${prefix}1`, firstName: "Quote test", balanceCents: 100000 } });
  const other = await db.user.create({ data: { telegramId: `${prefix}2`, firstName: "Other" } });
  const admin = await db.user.create({ data: { telegramId: `${prefix}3`, firstName: "Admin" } });
  process.env.ADMIN_TELEGRAM_IDS = admin.telegramId!;
  const fields = { registration: "AA-123-AA", vin: "VF000000000000001", formulaNumber: "FORM123", holderIdentity: "Ancien Titulaire", buyerLastName: "Dupont", buyerFirstName: "Alice", buyerBirthPlace: "Lyon", buyerBirthDate: "1990-01-01", deliveryAddress: "1 rue de test, 75001 Paris" };
  const request = () => createOrder(owner.id, orderInput.parse({ serviceId: "carte-grise", fields, documentIds: [], paymentMethod: "WALLET", idempotencyKey: randomUUID() }));
  const offer = (id: string, expectedVersion = 0, amountCents = 12345) => proposeOrderQuote(id, admin.id, { amountCents, expectedVersion, note: "Prix total de la démarche" });
  const ownerBalance = async () => (await db.user.findUniqueOrThrow({ where: { id: owner.id } })).balanceCents;
  const walletPay = (id: string) => serializable(async tx => { const order = await tx.order.findUniqueOrThrow({ where: { id } }); if (order.paidAt) return; await payOrderWithWallet(tx, order); });
  const noCryptoPayment = (id: string) => createPayment({ userId: owner.id, orderId: id, amountCents: 100, payCurrency: "usdttrc20", idempotencyKey: randomUUID() });
  const originalFetch = globalThis.fetch;
  try {
    await t.test("new request without attachments creates no debit, no invoice and one notification", async () => {
      const input = orderInput.parse({ serviceId: "carte-grise", fields, documentIds: [], paymentMethod: "WALLET", idempotencyKey: randomUUID() });
      const order = await createOrder(owner.id, input);
      assert.equal(order.status, "AWAITING_QUOTE"); assert.equal(order.priceCents, 0); assert.equal(order.requiresQuote, true); assert.equal(order.documents.length, 0);
      assert.equal(await ownerBalance(), 100000);
      assert.equal(await db.ledgerEntry.count({ where: { orderId: order.id } }), 0);
      assert.equal((await createOrder(owner.id, input)).id, order.id);
      await assert.rejects(walletPay(order.id));
      await assert.rejects(noCryptoPayment(order.id));
      assert.equal(await db.payment.count({ where: { orderId: order.id } }), 0);
    });
    await t.test("admin proposal cannot start treatment; non-admin cannot set the price", async () => {
      const order = await request(); await offer(order.id);
      assert.equal(await ownerBalance(), 100000);
      await assert.rejects(walletPay(order.id)); await assert.rejects(noCryptoPayment(order.id));
      const cookie = `forma_session=${createSessionToken(admin.id, process.env.SESSION_SECRET!)}`;
      const denied = await updateOrderRoute(new Request(`https://forma.test/api/admin/orders/${order.id}`, { method: "PATCH", headers: { cookie, origin: "https://forma.test", "Content-Type": "application/json" }, body: JSON.stringify({ status: "PROCESSING" }) }), { params: Promise.resolve({ id: order.id }) });
      assert.equal(denied.status, 409);
      const otherCookie = `forma_session=${createSessionToken(other.id, process.env.SESSION_SECRET!)}`;
      const forbidden = await proposalRoute(new Request(`https://forma.test/api/admin/orders/${order.id}/quote`, { method: "POST", headers: { cookie: otherCookie, origin: "https://forma.test", "Content-Type": "application/json" }, body: JSON.stringify({ amountCents: 5000, expectedVersion: 1 }) }), { params: Promise.resolve({ id: order.id }) });
      assert.equal(forbidden.status, 403);
      assert.equal(proposalInput.safeParse({ amountCents: 1.5, expectedVersion: 0 }).success, false);
    });
    await t.test("stale proposals, cross-owner decisions and edits after acceptance are rejected", async () => {
      const order = await request(); const q = await offer(order.id); const newer = await offer(order.id, q.quoteVersion, 15000);
      await assert.rejects(decideOrderQuote(order.id, other.id, { action: "accept", quoteVersion: newer.quoteVersion }));
      await assert.rejects(decideOrderQuote(order.id, owner.id, { action: "accept", quoteVersion: q.quoteVersion }));
      await Promise.all([1, 2].map(() => decideOrderQuote(order.id, owner.id, { action: "accept", quoteVersion: newer.quoteVersion })));
      const accepted = await db.order.findUniqueOrThrow({ where: { id: order.id } });
      assert.equal(accepted.status, "AWAITING_PAYMENT"); assert.ok(accepted.quoteAcceptedAt); assert.equal(accepted.priceCents, 15000);
      assert.equal(await ownerBalance(), 100000);
      await assert.rejects(offer(order.id, newer.quoteVersion, 100));
      await assert.rejects(decideOrderQuote(order.id, owner.id, { action: "reject", quoteVersion: newer.quoteVersion }));
      assert.equal(await db.auditLog.count({ where: { targetId: order.id, action: "ORDER_QUOTE_ACCEPTED" } }), 1);
      const paid = await Promise.allSettled([walletPay(order.id), walletPay(order.id)]);
      assert.ok(paid.some(result => result.status === "fulfilled"));
      assert.equal(await ownerBalance(), 85000);
      assert.equal(await db.ledgerEntry.count({ where: { orderId: order.id, kind: "ORDER_PAYMENT" } }), 1);
      assert.equal((await db.order.findUniqueOrThrow({ where: { id: order.id } })).status, "PROCESSING");
    });
    await t.test("refusal is terminal, idempotent and cannot create a payment", async () => {
      const order = await request(); const q = await offer(order.id);
      const before = await ownerBalance();
      await Promise.all([1, 2].map(() => decideOrderQuote(order.id, owner.id, { action: "reject", quoteVersion: q.quoteVersion })));
      assert.equal((await db.order.findUniqueOrThrow({ where: { id: order.id } })).status, "QUOTE_REJECTED");
      assert.equal(await ownerBalance(), before);
      await assert.rejects(offer(order.id, q.quoteVersion)); await assert.rejects(walletPay(order.id)); await assert.rejects(noCryptoPayment(order.id));
      assert.equal(await db.ledgerEntry.count({ where: { orderId: order.id } }), 0);
    });
    await t.test("competing acceptance and refusal produce exactly one decision", async () => {
      const order = await request(); const q = await offer(order.id);
      const results = await Promise.allSettled([decideOrderQuote(order.id, owner.id, { action: "accept", quoteVersion: q.quoteVersion }), decideOrderQuote(order.id, owner.id, { action: "reject", quoteVersion: q.quoteVersion })]);
      assert.equal(results.filter(result => result.status === "fulfilled").length, 1);
    });
    await t.test("crypto invoice uses accepted price; settlement alone starts treatment", async () => {
      const order = await request(); const q = await offer(order.id, 0, 11234);
      await decideOrderQuote(order.id, owner.id, { action: "accept", quoteVersion: q.quoteVersion });
      const providerId = randomUUID();
      let remote: Record<string, unknown>;
      globalThis.fetch = async (_url, init) => {
        const input = JSON.parse(String(init?.body));
        assert.equal(input.price_amount, "112.34");
        remote = { payment_id: providerId, order_id: input.order_id, payment_status: "waiting", price_amount: "112.34", price_currency: "eur", pay_currency: "usdttrc20", pay_amount: "123.45", pay_address: "T-test-payment" };
        return Response.json(remote);
      };
      const payment = await noCryptoPayment(order.id);
      assert.equal(payment.amountCents, 11234);
      assert.equal((await db.order.findUniqueOrThrow({ where: { id: order.id } })).status, "AWAITING_PAYMENT");
      globalThis.fetch = async () => Response.json({ ...remote, payment_status: "finished", actually_paid: "123.45" });
      await Promise.all([reconcilePayment(payment.id), reconcilePayment(payment.id)]);
      const completedPayment = await db.order.findUniqueOrThrow({ where: { id: order.id } });
      assert.equal(completedPayment.status, "PROCESSING"); assert.ok(completedPayment.paidAt);
      assert.equal(await db.ledgerEntry.count({ where: { paymentId: payment.id } }), 1);
      globalThis.fetch = originalFetch;
    });
    await t.test("the variant without a CT attachment stays on quote with three optional pieces", async () => {
      const order = await createOrder(owner.id, orderInput.parse({ serviceId: "carte-grise-sans-ct", fields, documentIds: [], idempotencyKey: randomUUID() }));
      assert.equal(order.status, "AWAITING_QUOTE"); assert.equal(order.requiresQuote, true);
      const service = await db.service.findUniqueOrThrow({ where: { id: order.serviceId } });
      const definitions = service.requiredDocuments as { label: string; required: boolean }[];
      assert.equal(definitions.length, 3); assert.ok(definitions.every(doc => !doc.required));
    });
    await t.test("technical inspection requires registration and a video, not a PDF in the video slot", async () => {
      const data = { serviceId: "controle-convoyage", fields: { mileage: "125000" }, documentIds: [] as string[], idempotencyKey: randomUUID() };
      await assert.rejects(createOrder(owner.id, orderInput.parse(data)), /Pièce requise/);
      const doc = (key: string, mimeType: string) => db.document.create({ data: { ownerId: owner.id, serviceId: data.serviceId, fieldKey: key, mimeType, fileName: "fixture", bytes: 100, storageKey: randomUUID() } });
      const registration = await doc("registration_certificate", "application/pdf");
      const wrongVideo = await doc("vehicle_video", "application/pdf");
      await assert.rejects(createOrder(owner.id, orderInput.parse({ ...data, documentIds: [registration.id, wrongVideo.id] })), /Vidéo/);
      const video = await doc("vehicle_video", "video/mp4");
      const created = await createOrder(owner.id, orderInput.parse({ ...data, documentIds: [registration.id, video.id] }));
      assert.equal(created.documents.length, 2); assert.equal(created.status, "AWAITING_PAYMENT");
    });
    await t.test("Ameli requires a rights certificate and rejects credential fields", async () => {
      const data = { serviceId: "remboursement-ameli", fields: {}, documentIds: [] as string[], idempotencyKey: randomUUID() };
      await assert.rejects(createOrder(owner.id, orderInput.parse(data)), /Attestation/);
      const certificate = await db.document.create({ data: { ownerId: owner.id, serviceId: data.serviceId, fieldKey: "rights_certificate", mimeType: "application/pdf", fileName: "fixture.pdf", bytes: 100, storageKey: randomUUID() } });
      await assert.rejects(createOrder(owner.id, orderInput.parse({ ...data, fields: { password: "test-placeholder" }, documentIds: [certificate.id] })), /inconnu/);
      const before = await ownerBalance();
      const created = await createOrder(owner.id, orderInput.parse({ ...data, documentIds: [certificate.id], paymentMethod: "WALLET" }));
      assert.equal(created.customerName, "Dossier Ameli"); assert.equal(created.documents.length, 1);
      assert.equal(created.status, "AWAITING_QUOTE"); assert.equal(created.priceCents, 0);
      assert.equal(await ownerBalance(), before);
      await assert.rejects(walletPay(created.id)); await assert.rejects(noCryptoPayment(created.id));
    });
    await t.test("WW prices and photo-only requirements match the requested simple forms", async () => {
      for (const [serviceId, expectedPrice] of [["ww", 8000], ["ww-modification", 10000]] as const) {
        const data = { serviceId, fields: { holderAddress: "10 rue de test, 75001 Paris" }, documentIds: [] as string[], idempotencyKey: randomUUID() };
        await assert.rejects(createOrder(owner.id, orderInput.parse(data)), /Pièce requise/);
        const doc = (fieldKey: string, mimeType: string) => db.document.create({ data: { ownerId: owner.id, serviceId, fieldKey, mimeType, fileName: "fixture", bytes: 100, storageKey: randomUUID() } });
        const card = await doc("registration_certificate", "image/jpeg");
        const wrong = await doc("holder_identity", "application/pdf");
        await assert.rejects(createOrder(owner.id, orderInput.parse({ ...data, documentIds: [card.id, wrong.id] })), /Pièce requise/);
        const identity = await doc("holder_identity", "image/png");
        const created = await createOrder(owner.id, orderInput.parse({ ...data, documentIds: [card.id, identity.id] }));
        assert.equal(created.status, "AWAITING_PAYMENT"); assert.equal(created.priceCents, expectedPrice);
        const snapshot = created.formSnapshot as { fields: { key: string }[] };
        assert.deepEqual(snapshot.fields.map(field => field.key), ["holderAddress"]);
      }
    });
    await t.test("CEDEO uses quote approval without charging its former fixed fee", async () => {
      const before = await ownerBalance();
      const documents = await Promise.all(["doc_0", "doc_1"].map(fieldKey => db.document.create({ data: { ownerId: owner.id, serviceId: "cedeo-pro", fieldKey, mimeType: "application/pdf", fileName: "fixture.pdf", bytes: 100, storageKey: randomUUID() } })));
      const created = await createOrder(owner.id, orderInput.parse({ serviceId: "cedeo-pro", customerName: "Entreprise cliente", fields: { quoteRef: "TEST-CEDEO", cartAmount: "1000" }, documentIds: documents.map(doc => doc.id), paymentMethod: "WALLET", idempotencyKey: randomUUID() }));
      assert.equal(created.status, "AWAITING_QUOTE"); assert.equal(created.priceCents, 0); assert.equal(await ownerBalance(), before);
      const proposal = await offer(created.id, 0, 12500);
      await decideOrderQuote(created.id, owner.id, { action: "accept", quoteVersion: proposal.quoteVersion });
      await walletPay(created.id);
      assert.equal(await ownerBalance(), before - 12500);
    });
    const swissRequest = async () => {
      const data = { serviceId: "douane-suisse", fields: { mileage: "125000" }, documentIds: [] as string[], idempotencyKey: randomUUID() };
      await assert.rejects(createOrder(owner.id, orderInput.parse(data)), /Photo de la carte grise/);
      const doc = (mimeType: string) => db.document.create({ data: { ownerId: owner.id, serviceId: data.serviceId, fieldKey: "registration_certificate", mimeType, fileName: "fixture", bytes: 100, storageKey: randomUUID() } });
      const wrong = await doc("application/pdf");
      await assert.rejects(createOrder(owner.id, orderInput.parse({ ...data, documentIds: [wrong.id] })), /Photo de la carte grise/);
      const photo = await doc("image/jpeg");
      return createOrder(owner.id, orderInput.parse({ ...data, documentIds: [photo.id] }));
    };
    const appointment = { action: "schedule" as const, expectedVersion: 0, appointmentAt: new Date(Date.now() + 86400000).toISOString(), location: "10 rue du rendez-vous, Paris", note: "Apporter l’original" };
    await t.test("Swiss customs: quote, appointment, physical collection and paid completion after return", async () => {
      const before = await ownerBalance();
      const order = await swissRequest();
      assert.equal(order.priceCents, 0); assert.equal(order.status, "AWAITING_QUOTE");
      assert.equal(order.originalDocument?.status, "TO_SCHEDULE"); assert.equal(await ownerBalance(), before);
      await assert.rejects(updateOriginalDocument(order.id, admin.id, appointment), /acceptation/);
      const q = await offer(order.id, 0, 12500);
      await decideOrderQuote(order.id, owner.id, { action: "accept", quoteVersion: q.quoteVersion });
      const scheduled = await updateOriginalDocument(order.id, admin.id, appointment);
      assert.equal(scheduled.status, "AWAITING_PAYMENT"); assert.equal(scheduled.originalDocument?.version, 1);
      const changed = await updateOriginalDocument(order.id, admin.id, { ...appointment, expectedVersion: 1, location: "20 rue du rendez-vous, Paris" });
      assert.equal(changed.originalDocument?.version, 2);
      await assert.rejects(updateOriginalDocument(order.id, admin.id, { action: "collect", expectedVersion: 1, confirmed: true }), /changé/);
      await updateOriginalDocument(order.id, admin.id, { action: "collect", expectedVersion: 2, confirmed: true });
      await assert.rejects(updateOriginalDocument(order.id, admin.id, { action: "ready", expectedVersion: 3, confirmed: true }), /paiement/);
      await walletPay(order.id);
      const cookie = `forma_session=${createSessionToken(admin.id, process.env.SESSION_SECRET!)}`;
      const denied = await updateOrderRoute(new Request(`https://forma.test/api/admin/orders/${order.id}`, { method: "PATCH", headers: { cookie, origin: "https://forma.test", "Content-Type": "application/json" }, body: JSON.stringify({ status: "COMPLETED" }) }), { params: Promise.resolve({ id: order.id }) });
      assert.equal(denied.status, 409);
      await updateOriginalDocument(order.id, admin.id, { action: "ready", expectedVersion: 3, confirmed: true });
      const returnInput = { action: "return" as const, expectedVersion: 4, confirmed: true as const };
      const returned = await updateOriginalDocument(order.id, admin.id, returnInput);
      assert.equal(returned.status, "COMPLETED"); assert.equal(returned.originalDocument?.status, "RETURNED"); assert.ok(returned.originalDocument?.returnedAt);
      const notifications = await db.notificationOutbox.count();
      await updateOriginalDocument(order.id, admin.id, returnInput);
      assert.equal(await db.notificationOutbox.count(), notifications);
      assert.equal(await db.auditLog.count({ where: { targetId: order.id, action: "ORIGINAL_DOCUMENT_RETURN" } }), 1);
      assert.equal(await ownerBalance(), before - 12500);
    });
    await t.test("Swiss custody validates admin, consent, future appointments and transition order", async () => {
      const order = await swissRequest(); const q = await offer(order.id, 0, 1000);
      await decideOrderQuote(order.id, owner.id, { action: "accept", quoteVersion: q.quoteVersion });
      const cookie = `forma_session=${createSessionToken(other.id, process.env.SESSION_SECRET!)}`;
      const response = await originalRoute(new Request(`https://forma.test/api/admin/orders/${order.id}/original-document`, { method: "POST", headers: { cookie, origin: "https://forma.test", "Content-Type": "application/json" }, body: JSON.stringify(appointment) }), { params: Promise.resolve({ id: order.id }) });
      assert.equal(response.status, 403);
      assert.equal(originalDocumentInput.safeParse({ action: "return", expectedVersion: 0, confirmed: false }).success, false);
      assert.equal(originalDocumentInput.safeParse({ ...appointment, appointmentAt: "2026-10-25T15:00" }).success, false);
      await assert.rejects(updateOriginalDocument(order.id, admin.id, { ...appointment, appointmentAt: "2020-01-01T12:00:00.000Z" }), /future/);
      for (const action of ["collect", "ready", "return"] as const) await assert.rejects(updateOriginalDocument(order.id, admin.id, { action, expectedVersion: 0, confirmed: true }));
      const nonSwiss = await request();
      assert.equal(nonSwiss.originalDocument, null);
      await assert.rejects(updateOriginalDocument(nonSwiss.id, admin.id, appointment), /suivi/);
    });
    await t.test("cancellation never prevents return of an already collected original and is not revived", async () => {
      const order = await swissRequest(); const q = await offer(order.id, 0, 1000);
      await decideOrderQuote(order.id, owner.id, { action: "accept", quoteVersion: q.quoteVersion });
      await updateOriginalDocument(order.id, admin.id, appointment);
      await updateOriginalDocument(order.id, admin.id, { action: "collect", expectedVersion: 1, confirmed: true });
      // An unpaid cancelled dossier holds an original, but carries no debit/refund.
      await db.order.update({ where: { id: order.id }, data: { status: "CANCELLED" } });
      const before = await ownerBalance();
      await updateOriginalDocument(order.id, admin.id, { action: "ready", expectedVersion: 2, confirmed: true });
      const returned = await updateOriginalDocument(order.id, admin.id, { action: "return", expectedVersion: 3, confirmed: true });
      assert.equal(returned.status, "CANCELLED"); assert.equal(returned.originalDocument?.status, "RETURNED");
      assert.equal(await ownerBalance(), before); assert.equal(await db.ledgerEntry.count({ where: { orderId: order.id } }), 0);
    });
    await t.test("fixed-price services still charge normally at checkout", async () => {
      const service = await db.service.create({ data: { id: `fixed-${randomUUID()}`, slug: `fixed-${randomUUID()}`, name: "Test fixed service", description: "Test fixture only", category: "ASSISTANCE", priceCents: 1000, turnaround: "Test", fields: [], requiredDocuments: [] } });
      const before = await ownerBalance();
      const order = await createOrder(owner.id, orderInput.parse({ serviceId: service.id, customerName: "Client", fields: {}, documentIds: [], paymentMethod: "WALLET", idempotencyKey: randomUUID() }));
      assert.equal(order.status, "PROCESSING"); assert.equal(order.requiresQuote, false); assert.equal(await ownerBalance(), before - 1000);
    });
  } finally { globalThis.fetch = originalFetch; await db.$disconnect(); }
});
