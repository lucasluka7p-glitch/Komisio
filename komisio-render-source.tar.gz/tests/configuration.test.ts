import test from 'node:test';
import assert from 'node:assert/strict';
import { configurationIssues } from '../lib/server/configuration';
import { integrationEndpoint } from '../lib/server/integrations';
const env={PAYMENT_PROVIDER:'NOWPAYMENTS',NODE_ENV:'production',DATABASE_URL:'postgresql://user:password@db/komisio',APP_URL:'https://partners.test',MINI_APP_URL:'https://partners.test',TELEGRAM_BOT_TOKEN:'12345:test',TELEGRAM_BOT_USERNAME:'KomisioBot',ADMIN_TELEGRAM_IDS:'12345,23456',SESSION_SECRET:'a'.repeat(64),CRON_SECRET:'b'.repeat(64),TELEGRAM_WEBHOOK_SECRET:'c'.repeat(64),NOWPAYMENTS_API_KEY:'key',NOWPAYMENTS_IPN_SECRET:'d'.repeat(64),PRIVATE_UPLOAD_DIR:'.private/uploads',NEXT_PUBLIC_DEMO_MODE:'false'};
test('production checks reject demo builds, missing secrets, test switches and split origins without exposing secrets',()=>{
 assert.deepEqual(configurationIssues(env),[]);
 const bad={...env,NEXT_PUBLIC_DEMO_MODE:'true',CRON_SECRET:env.SESSION_SECRET,MINI_APP_URL:'https://other.test',TEST_TELEGRAM_API_ROOT:'http://127.0.0.1:1234',NOWPAYMENTS_API_KEY:''};
 const issues=configurationIssues(bad);assert.ok(issues.length>=5);assert.ok(issues.every(issue=>!issue.includes(env.SESSION_SECRET)));
 assert.ok(configurationIssues({...env,APP_URL:'http://partners.test'}).some(issue=>issue.includes('HTTPS')));
});
test('protocol test endpoints cannot redirect production integrations or reach remote test hosts',()=>{
 const local={TEST_CHECK_ENDPOINT:'http://127.0.0.1:12345/v1',KOMISIO_INTEGRATION_TEST_MODE:'true',NODE_ENV:'test'};
 assert.equal(integrationEndpoint('TEST_CHECK_ENDPOINT','https://real.test',local),'http://127.0.0.1:12345/v1');
 assert.throws(()=>integrationEndpoint('TEST_CHECK_ENDPOINT','https://real.test',{...local,NODE_ENV:'production'}));
 assert.throws(()=>integrationEndpoint('TEST_CHECK_ENDPOINT','https://real.test',{...local,TEST_CHECK_ENDPOINT:'http://outside.test'}));
});
