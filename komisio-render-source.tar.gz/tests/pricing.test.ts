import test from "node:test";
import assert from "node:assert/strict";
import { discountedPrice, resolvePrice, quotePrice, newClientRules } from "../lib/pricing";
import { clientPricingInput } from "../lib/server/client-validation";
import { hashPassword, verifyPassword } from "../lib/server/passwords";
import { estimateVehicleTax } from "../lib/vehicle-estimate";
const account = { defaultDiscountBps: 1000, pricingVersion: 2 };
test("client prices override the general discount without stacking and round integer cents", () => {
  const service = { id: "ww", priceCents: 8000, requiresQuote: false };
  assert.equal(resolvePrice(service, account).priceCents, 7200);
  assert.equal(resolvePrice(service, account, { serviceId: "ww", mode: "FIXED", priceCents: 9500, discountBps: 0, minimumCents: 0 }).priceCents, 9500);
  assert.equal(resolvePrice(service, account, { serviceId: "ww", mode: "DISCOUNT", priceCents: null, discountBps: 2500, minimumCents: 0 }).priceCents, 6000);
  assert.equal(discountedPrice(12345, 1250), 10802);
});
test("CG reference discount and 60 euro floor are snapshotted, including forced quote rules", () => {
  const rules = newClientRules([{ id: "carte-grise" }, { id: "ww" }]);
  assert.equal(rules.length, 1);
  const price = resolvePrice({ id: "carte-grise", priceCents: 0, requiresQuote: true }, account, rules[0]);
  assert.equal(price.requiresQuote, true); assert.equal(price.priceCents, 0);
  assert.equal(quotePrice(30000, price.pricing), 15000); assert.equal(quotePrice(10000, price.pricing), 6000);
  rules[0].discountBps = 6000; assert.equal(quotePrice(30000, price.pricing), 15000);
  assert.equal(quotePrice(5000, null), 5000); // Legacy dossiers remain unchanged.
});
test("invalid and duplicate client price rules cannot be persisted", () => {
  const rule = { serviceId: "carte-grise", mode: "DISCOUNT", priceCents: null, discountBps: 6000, minimumCents: 6000 };
  const parse = (prices: unknown[]) => clientPricingInput.safeParse({ defaultDiscountBps: 0, prices }).success;
  assert.equal(parse([rule]), true); assert.equal(parse([rule, rule]), false);
  assert.equal(parse([{ ...rule, minimumCents: 5900 }]), false);
  assert.equal(parse([{ ...rule, discountBps: 10001 }]), false);
  assert.equal(parse([{ ...rule, mode: "FIXED", discountBps: 0, priceCents: null }]), false);
  assert.throws(() => discountedPrice(1.1, 5000));
});
test("passwords use independent salted scrypt hashes and an unknown account still performs verification", async () => {
  const first = await hashPassword("fictitious-long-password");
  const second = await hashPassword("fictitious-long-password");
  assert.notEqual(first, second); assert.equal(await verifyPassword("fictitious-long-password", first), true);
  assert.equal(await verifyPassword("incorrect", first), false); assert.equal(await verifyPassword("incorrect", null), false);
});
test("free vehicle estimator uses dated regional rates, age reduction and fixed fees", () => {
  const data = { region: "ara", fiscalPower: 6, firstRegistration: "2020-06-01", ordinaryFrenchUsedCar: true };
  const date = new Date("2026-11-08T12:00:00Z");
  assert.equal(estimateVehicleTax(data, date).referenceCents, 27176);
  assert.equal(estimateVehicleTax({ ...data, firstRegistration: "2010-01-01" }, date).referenceCents, 14276);
  assert.equal(estimateVehicleTax({ ...data, region: "idf" }, date).referenceCents, 42776);
  assert.throws(() => estimateVehicleTax(data, new Date("2027-01-01")), /actualiser/);
  assert.throws(() => estimateVehicleTax({ ...data, ordinaryFrenchUsedCar: false }, date), /officiel/);
  assert.throws(() => estimateVehicleTax({ ...data, firstRegistration: "2020-02-31" }, date));
  assert.throws(() => estimateVehicleTax({ ...data, fiscalPower: 0 }, date));
});
