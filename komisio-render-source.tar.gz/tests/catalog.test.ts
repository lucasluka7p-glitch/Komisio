import test from "node:test";
import assert from "node:assert/strict";
import { initialServices, mergeDemoServices } from "../lib/catalog";
import { serviceInput } from "../lib/server/validation";

test("every catalogue service can be seeded through the server service contract", () => {
  for (const service of initialServices) {
    const parsed = serviceInput.safeParse({
      slug: service.id,
      name: service.title,
      description: service.description,
      category: service.category.toUpperCase(),
      subcategory: service.subcategory,
      priceCents: service.price,
      requiresQuote: !!service.requiresQuote,
      turnaround: service.delay,
      active: service.active,
      fields: service.fields.map((field) => ({
        ...field,
        type: field.type ?? "text",
      })),
      requiredDocuments: service.documents.map((label, index) => ({
        key: service.documentKeys?.[index] ?? `doc_${index}`,
        label,
        required: service.documentRequired?.[index] !== false,
        type: service.documentTypes?.[index] || "document",
      })),
    });
    assert.ok(
      parsed.success,
      `${service.id}: ${parsed.success ? "" : JSON.stringify(parsed.error.issues)}`,
    );
  }
});

test("catalogue identifiers are unique and prices distinguish fixed fees from quotes", () => {
  assert.equal(
    new Set(initialServices.map((service) => service.id)).size,
    initialServices.length,
  );
  for (const service of initialServices) {
    assert.equal(
      service.active,
      true,
      `${service.id} must be available in the initial catalogue`,
    );
    assert.ok(
      Number.isSafeInteger(service.price) && (service.requiresQuote ? service.price === 0 : service.price >= 100),
      `${service.id} requires a valid fixed or quote price`,
    );
    assert.equal(
      new Set(service.fields.map((field) => field.key)).size,
      service.fields.length,
      `${service.id} has duplicate field keys`,
    );
    assert.equal(
      new Set(service.documents).size,
      service.documents.length,
      `${service.id} has duplicate document labels`,
    );
  }
});

test("the requested lawful service additions and existing formalities keep stable unique IDs", () => {
  const requiredIds = [
    "douane-suisse",
    "code-route",
    "examen-permis",
    "titre-sejour",
    "cedeo-pro",
    "controle-convoyage",
    "remboursement-pare-brise",
    "remboursement-ameli",
    "acces-donnees-personnelles",
    "situation-vehicule",
    "fin-leasing",
    "ww-modification",
    "levee-procedure",
    "levee-saisie",
    "levee-immobilisation",
    "carte-grise",
    "carte-grise-sans-ct",
    "ww",
    "creation",
    "modification",
    "comptes",
    "sommeil",
    "rne",
    "cessation",
    "regularisation",
  ];
  for (const id of requiredIds) {
    assert.equal(
      initialServices.filter((service) => service.id === id).length,
      1,
      `${id} should appear once`,
    );
  }
});

test("catalogue updates append new services while preserving saved admin edits and custom services", () => {
  const saved = initialServices.slice(0, 13).map((service, index) =>
    index === 0
      ? {
          ...service,
          title: "Mon offre personnalisée",
          price: 22200,
          active: false,
          documents: ["Document configuré par l’administrateur"],
        }
      : { ...service },
  );
  const custom = {
    ...initialServices[0],
    id: "service-personnalise",
    title: "Service créé dans le navigateur",
    price: 33300,
  };
  saved.push(custom);
  const before = structuredClone(saved);
  const merged = mergeDemoServices(saved);

  assert.equal(merged.length, initialServices.length + 1);
  assert.deepEqual(
    merged.find((service) => service.id === saved[0].id),
    saved[0],
  );
  assert.deepEqual(
    merged.find((service) => service.id === custom.id),
    custom,
  );
  for (const added of initialServices.slice(13)) {
    assert.deepEqual(
      merged.find((service) => service.id === added.id),
      added,
    );
  }
  assert.deepEqual(
    saved,
    before,
    "merging must not mutate the persisted catalogue",
  );
  assert.deepEqual(
    mergeDemoServices(merged),
    merged,
    "reloading must not duplicate services",
  );
});

test("only untouched legacy service titles are upgraded", () => {
  const card = initialServices.find((service) => service.id === "carte-grise")!;
  const ww = initialServices.find((service) => service.id === "ww")!;
  const merged = mergeDemoServices([
    { ...card, title: "Changement de titulaire", price: 8800 },
    { ...ww, title: "Mon service WW personnalisé", price: 9900 },
  ]);

  assert.equal(
    merged.find((service) => service.id === card.id)?.title,
    card.title,
  );
  assert.equal(merged.find((service) => service.id === card.id)?.price, 8800);
  assert.equal(
    merged.find((service) => service.id === ww.id)?.title,
    "Mon service WW personnalisé",
  );
  assert.equal(merged.find((service) => service.id === ww.id)?.price, 9900);
});

test("vehicle form revision replaces cached requirements once and preserves later admin edits", () => {
  const defaults = initialServices.find(service => service.id === "carte-grise")!;
  const cached = { ...defaults, formVersion: undefined, price: 8800, active: false,
    fields: [{ key: "old", label: "Ancien champ", required: true }],
    documents: ["Ancienne pièce"], documentKeys: ["old_doc"] };
  const before = structuredClone(cached);
  const revised = mergeDemoServices([cached]).find(service => service.id === cached.id)!;
  assert.deepEqual(revised.fields, defaults.fields);
  assert.deepEqual(revised.documents, defaults.documents);
  assert.deepEqual(revised.documentKeys, defaults.documentKeys);
  assert.equal(revised.price, 0);
  assert.equal(revised.requiresQuote, true);
  assert.ok(revised.documentRequired?.every(required => required === false));
  assert.equal(revised.active, false);
  assert.deepEqual(cached, before);
  const edited = { ...revised, documents: ["Pièce ajustée par admin"] };
  assert.deepEqual(mergeDemoServices([edited]).find(service => service.id === edited.id), edited);
});

test("requested attachment revision replaces old pieces and preserves later panel changes", () => {
  const service = initialServices.find(service => service.id === "carte-grise")!;
  const saved = { ...service, formVersion: 1, documents: ["Pièce personnalisée"], documentKeys: ["custom_identity"], fields: [{ key: "buyerIdentity", label: "Ancienne identité", required: true }] };
  const revised = mergeDemoServices([saved]).find(service => service.id === saved.id)!;
  assert.deepEqual(revised.fields, service.fields);
  assert.deepEqual(revised.documents, service.documents);
  assert.deepEqual(revised.documentKeys, service.documentKeys);
  const edited = { ...revised, documents: ["Pièce personnalisée après mise à jour"] };
  assert.deepEqual(mergeDemoServices([edited]).find(s => s.id === edited.id), edited);
});

test("catalogue groups every service once and retains uncategorized custom offers", async () => {
  const { groupCatalogue, subcategories } = await import("../lib/catalog");
  const grouped = groupCatalogue(initialServices);
  const ids = grouped.flatMap(category => category.groups.flatMap(group => group.services.map(service => service.id)));
  assert.equal(ids.length, initialServices.length);
  assert.equal(new Set(ids).size, initialServices.length);
  for (const service of initialServices) assert.ok(subcategories.some(group => group.id === service.subcategory && group.category === service.category));
  const custom = { ...initialServices[0], id: "custom", subcategory: "unknown" };
  const category = groupCatalogue([custom])[0];
  assert.equal(category.groups[0].id, "other");
  assert.equal(category.groups[0].services[0].id, "custom");
});

test("explicit WW and CEDEO pricing revisions run once, preserving subsequent panel edits", () => {
  const ids = ["ww", "ww-modification", "cedeo-pro"];
  const saved = initialServices.filter(service => ids.includes(service.id)).map(service => ({ ...service, catalogVersion: undefined, price: 1900, requiresQuote: false }));
  const merged = mergeDemoServices(saved);
  assert.equal(merged.find(service => service.id === "ww")!.price, 8000);
  assert.equal(merged.find(service => service.id === "ww-modification")!.price, 10000);
  assert.equal(merged.find(service => service.id === "cedeo-pro")!.requiresQuote, true);
  assert.equal(merged.find(service => service.id === "cedeo-pro")!.price, 0);
  const edited = merged.map(service => service.id === "ww" ? { ...service, price: 6500, subcategory: null } : service);
  assert.deepEqual(mergeDemoServices(edited), edited);
});

test("holder label revision keeps custom fields and attachments", () => {
  const current = initialServices.find(service => service.id === "carte-grise")!;
  const old = { ...current, formVersion: 4, documents: ["Document personnalisé"], fields: [
    { key: "holderIdentity", label: "Identité du titulaire (nom et prénom)", required: true },
    { key: "custom", label: "Champ personnalisé", required: false },
  ] };
  const updated = mergeDemoServices([old]).find(service => service.id === old.id)!;
  assert.equal(updated.fields[0].label, "Identité du titulaire");
  assert.equal(updated.fields[1].key, "custom");
  assert.deepEqual(updated.documents, old.documents);
});


test("Swiss customs form and quote revision apply once without resetting later admin changes", () => {
  const current = initialServices.find(s => s.id === "douane-suisse")!;
  const old = { ...current, formVersion: undefined, price: 14900, requiresQuote: false, fields: [{ key: "vin", label: "VIN", required: true }], documents: ["Ancienne pièce"] };
  const revised = mergeDemoServices([old]).find(s => s.id === current.id)!;
  assert.equal(revised.price, 0); assert.equal(revised.requiresQuote, true);
  assert.deepEqual(revised.fields.map(f => f.key), ["mileage"]);
  assert.deepEqual(revised.documents, ["Photo de la carte grise"]);
  assert.deepEqual(revised.documentRequired, [true]);
  const edited = { ...revised, description: "Mon offre", documents: ["Ma pièce"], price: 6000, requiresQuote: false };
  assert.deepEqual(mergeDemoServices([edited]).find(s => s.id === current.id), edited);
});


test("offer revisions preserve custom forms and allow later admin overrides", () => {
  const current = initialServices.find(service => service.id === "remboursement-ameli")!;
  const cached = { ...current, offerVersion: undefined, price: 3900, requiresQuote: false, delay: "Selon la démarche", active: false,
    fields: [{ key: "reference", label: "Référence personnalisée", required: false }],
    documents: ["Attestation configurée"], subcategory: null };
  const original = structuredClone(cached);
  const revised = mergeDemoServices([cached]).find(service => service.id === cached.id)!;
  assert.equal(revised.price, 0); assert.equal(revised.requiresQuote, true); assert.equal(revised.delay, "15 jours");
  assert.deepEqual(revised.fields, cached.fields); assert.deepEqual(revised.documents, cached.documents);
  assert.equal(revised.active, false); assert.equal(revised.subcategory, null); assert.deepEqual(cached, original);
  const edited = { ...revised, price: 2500, requiresQuote: false, delay: "20 jours", description: "Mon accompagnement" };
  assert.deepEqual(mergeDemoServices([edited]).find(service => service.id === edited.id), edited);
});

test("new quote offers append once and leave saved orders' service identifiers and admin edits intact", () => {
  const ids = ["regularisation-carte-grise", "homologation", "remboursement-mutuelle", "dossier-recepisse", "dossier-logement", "creation-neph"];
  const old = initialServices.filter(service => !ids.includes(service.id));
  const merged = mergeDemoServices(old);
  assert.equal(merged.length, old.length + ids.length);
  for (const id of ids) {
    const service = merged.find(service => service.id === id)!;
    assert.equal(!!service.requiresQuote, id !== "regularisation-carte-grise"); assert.equal(service.price, id === "regularisation-carte-grise" ? 10000 : 0);
    assert.ok(service.documents.length > 0); assert.ok(service.fields.length > 0);
  }
  const edited = merged.map(service => service.id === "creation-neph" ? { ...service, title: "Mon accompagnement NEPH", price: 4900, requiresQuote: false, active: false } : service);
  assert.deepEqual(mergeDemoServices(edited), edited);
});
test("CEDEO revision upgrades the original 30 percent offer once and preserves later admin copy", () => {
  const current = initialServices.find(service => service.id === "cedeo-pro")!;
  const legacy = { ...current, offerVersion: 1, title: "CEDEO — remise professionnelle de 30 %", description: "Accompagnement à l’application de la remise professionnelle de 30 % selon votre accord commercial CEDEO et ses conditions. Frais de service hors achats.", active: false };
  const before = structuredClone(legacy);
  const revised = mergeDemoServices([legacy]).find(service => service.id === legacy.id)!;
  assert.equal(revised.title, current.title); assert.equal(revised.description, current.description);
  assert.equal(revised.offerVersion, 2); assert.equal(revised.active, false);
  assert.ok(revised.requiresQuote); assert.equal(revised.price, 0); assert.deepEqual(legacy, before);
  const edited = { ...revised, title: "Mon offre CEDEO", description: "Conditions personnalisées", price: 6500, requiresQuote: false };
  assert.deepEqual(mergeDemoServices([edited]).find(service => service.id === edited.id), edited);
  const custom = { ...legacy, title: "Offre personnalisée", description: "Mes conditions", documents: ["Mon document"] };
  const preserved = mergeDemoServices([custom]).find(service => service.id === custom.id)!;
  assert.equal(preserved.title, custom.title); assert.equal(preserved.description, custom.description); assert.deepEqual(preserved.documents, custom.documents);
});
test("leasing moves from vehicle information to registration once without resetting prices or custom groups", () => {
  const current = initialServices.find(service => service.id === "fin-leasing")!;
  const legacy = { ...current, catalogVersion: 1, subcategory: "documents-vehicule", price: 21500, active: false };
  const revised = mergeDemoServices([legacy]).find(service => service.id === legacy.id)!;
  assert.equal(revised.subcategory, "immatriculation"); assert.equal(revised.price, 21500); assert.equal(revised.active, false);
  assert.deepEqual(mergeDemoServices([revised]).find(service => service.id === revised.id), revised);
  const custom = { ...legacy, subcategory: "controle-restrictions" };
  assert.equal(mergeDemoServices([custom]).find(service => service.id === custom.id)!.subcategory, custom.subcategory);
});
