import test from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { orderInput } from "../lib/server/orders";
const base = () => ({ serviceId: "carte-grise", fields: {
  buyerLastName: " Dupont ", buyerFirstName: " Alice ", buyerBirthPlace: "Lyon", buyerBirthDate: "1990-02-28",
}, documentIds: [], paymentMethod: "CRYPTO", idempotencyKey: randomUUID() });
test("vehicle transfer derives the searchable customer from buyer fields without a generic name or email", () => {
  const result = orderInput.parse(base());
  assert.equal(result.customerName, "Dupont Alice");
  assert.equal(result.customerEmail, undefined);
  assert.equal(orderInput.parse({ ...base(), customerName: "Wrong label", customerEmail: "old@example.com" }).customerName, "Dupont Alice");
});
test("vehicle transfer requires all four buyer fields and a real non-future birth date", () => {
  for (const key of ["buyerLastName", "buyerFirstName", "buyerBirthPlace", "buyerBirthDate"]) {
    const input = base(); input.fields[key as keyof typeof input.fields] = "";
    assert.equal(orderInput.safeParse(input).success, false);
  }
  for (const birth of ["1990-02-30", "2999-01-01", "invalid"]) {
    const input = base(); input.fields.buyerBirthDate = birth;
    assert.equal(orderInput.safeParse(input).success, false);
  }
});
test("other services retain their existing customer name requirement and optional email", () => {
  const input = { ...base(), serviceId: "assistance", fields: {} };
  assert.equal(orderInput.safeParse(input).success, false);
  const parsed = orderInput.parse({ ...input, customerName: "Client assistance", customerEmail: "client@example.com" });
  assert.equal(parsed.customerName, "Client assistance");
  assert.equal(parsed.customerEmail, "client@example.com");
});


test("personal request and vehicle status forms derive identity from the requested fields", () => {
  const person = orderInput.parse({ ...base(), serviceId: "acces-donnees-personnelles", fields: { lastName: "Dupont", firstName: "Alice", birthDate: "1990-01-01" } });
  assert.equal(person.customerName, "Dupont Alice");
  assert.equal(orderInput.safeParse({ ...base(), serviceId: "acces-donnees-personnelles", fields: { lastName: "Dupont", firstName: "Alice", birthDate: "" } }).success, false);
  const vehicle = orderInput.parse({ ...base(), serviceId: "situation-vehicule", fields: { registration: "AA-123-AA" } });
  assert.equal(vehicle.customerName, "AA-123-AA");
  assert.equal(orderInput.safeParse({ ...base(), serviceId: "controle-convoyage", fields: { mileage: "-50" } }).success, false);
});


test("WW requests use only the postal address and do not require a generic customer name", () => {
  for (const serviceId of ["ww", "ww-modification"]) {
    const input = { ...base(), serviceId, fields: { holderAddress: "10 rue de test, 75001 Paris" } };
    assert.equal(orderInput.safeParse(input).success, true);
    assert.equal(orderInput.safeParse({ ...input, fields: {} }).success, false);
  }
});


test("Swiss customs asks for mileage without a generic name and rejects invalid mileage", () => {
  const input = { ...base(), serviceId: "douane-suisse", fields: { mileage: "125000" } };
  assert.equal(orderInput.parse(input).customerName, "Dédouanement suisse — 125000 km");
  for (const mileage of ["", "-1", "1.5", "abc", "999999999"]) assert.equal(orderInput.safeParse({ ...input, fields: { mileage } }).success, false);
});
