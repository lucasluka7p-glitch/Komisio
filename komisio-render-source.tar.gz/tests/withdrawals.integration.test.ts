import test from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";

// Explicit opt-in to a disposable test database. Never use DATABASE_URL implicitly.
const testUrl = process.env.WITHDRAWAL_TEST_DATABASE_URL;
test("withdrawal PostgreSQL transactions, permissions, retries and competing debits", { skip: !testUrl }, async t => {
  const parsed = new URL(testUrl!);
  assert.equal(parsed.pathname, "/forma_withdrawals_test", "Use the disposable withdrawal test database only");
  process.env.DATABASE_URL = testUrl;
  process.env.WITHDRAWALS_ENABLED = "true";
  process.env.ADMIN_TELEGRAM_IDS = "999900001";
  const { db, serializable } = await import("../lib/server/db");
  const { requestWithdrawal, actOnWithdrawal } = await import("../lib/server/withdrawals");
  const { GET: listRoute, POST: createRoute } = await import("../app/api/withdrawals/route");
  const { POST: userRoute } = await import("../app/api/withdrawals/[id]/route");
  const { GET: adminRoute } = await import("../app/api/admin/withdrawals/route");
  const { createSessionToken } = await import("../lib/server/auth");
  process.env.SESSION_SECRET = "a".repeat(64);
  process.env.APP_URL = "https://forma.test";
  const prefix = String(Date.now());
  const owner = await db.user.create({ data: { telegramId: prefix, firstName: "Test", balanceCents: 100000 } });
  const other = await db.user.create({ data: { telegramId: `${prefix}1`, firstName: "Other" } });
  const admin = await db.user.create({ data: { telegramId: "999900001", firstName: "Admin" } });
  const input = (amountCents = 10000) => ({ amountCents, currency: "usdttrc20" as const, address: "T9yD14Nj9j7xAB4dbGeiX9h8unkKHxuWwb", idempotencyKey: randomUUID() });
  const request = (amount?: number) => requestWithdrawal(owner.id, input(amount));
  const quote = (id: string) => actOnWithdrawal(id, admin.id, true, { action: "quote", feeCents: 100, exchangeRate: "1.1", source: "Provider quote test" });
  const balance = async () => (await db.user.findUniqueOrThrow({ where: { id: owner.id } })).balanceCents;
  try {
    await t.test("requests deduplicate; conflicting payloads fail; no debit before acceptance", async () => {
      const data = input();
      const [a, b] = await Promise.all([requestWithdrawal(owner.id, data), requestWithdrawal(owner.id, data)]);
      assert.equal(a.id, b.id);
      await assert.rejects(requestWithdrawal(owner.id, { ...data, amountCents: 15000 }));
      assert.equal(await balance(), 100000);
      await actOnWithdrawal(a.id, owner.id, false, { action: "cancel" });
    });
    await t.test("cross-owner reads/actions and reseller admin routes are denied", async () => {
      const w = await request();
      await assert.rejects(actOnWithdrawal(w.id, other.id, false, { action: "cancel" }));
      await assert.rejects(actOnWithdrawal(w.id, other.id, false, { action: "process" }));
      const unauthorized = await listRoute(new Request("https://forma.test/api/withdrawals"));
      assert.equal(unauthorized.status, 401);
      const token = createSessionToken(other.id, process.env.SESSION_SECRET!);
      const headers = { cookie: `forma_session=${token}`, origin: "https://forma.test", "Content-Type": "application/json" };
      assert.equal((await adminRoute(new Request("https://forma.test/api/admin/withdrawals", { headers }))).status, 403);
      const response = await userRoute(new Request(`https://forma.test/api/withdrawals/${w.id}`, { method: "POST", headers, body: JSON.stringify({ action: "cancel" }) }), { params: Promise.resolve({ id: w.id }) });
      assert.equal(response.status, 404);
      const crossed = await createRoute(new Request("https://forma.test/api/withdrawals", { method: "POST", headers: { ...headers, origin: "https://evil.test" }, body: JSON.stringify(input()) }));
      assert.equal(crossed.status, 403);
      await actOnWithdrawal(w.id, owner.id, false, { action: "cancel" });
    });
    await t.test("stale/expired quotes cannot reserve funds", async () => {
      const w = await request(); const q = await quote(w.id); await quote(w.id);
      await assert.rejects(actOnWithdrawal(w.id, owner.id, false, { action: "accept", quoteVersion: q.quoteVersion }));
      await db.withdrawal.update({ where: { id: w.id }, data: { quoteExpiresAt: new Date(0) } });
      await assert.rejects(actOnWithdrawal(w.id, owner.id, false, { action: "accept", quoteVersion: q.quoteVersion + 1 }));
      assert.equal(await balance(), 100000);
      await actOnWithdrawal(w.id, owner.id, false, { action: "cancel" });
    });
    await t.test("concurrent accepts reserve once; concurrent cancellations refund once", async () => {
      const w = await request(); const q = await quote(w.id);
      await Promise.all([1, 2].map(() => actOnWithdrawal(w.id, owner.id, false, { action: "accept", quoteVersion: q.quoteVersion })));
      assert.equal(await balance(), 90000);
      assert.equal(await db.ledgerEntry.count({ where: { reference: `withdrawal:hold:${w.id}` } }), 1);
      await Promise.all([1, 2].map(() => actOnWithdrawal(w.id, owner.id, false, { action: "cancel" })));
      assert.equal(await balance(), 100000);
      assert.equal(await db.ledgerEntry.count({ where: { reference: `withdrawal:release:${w.id}` } }), 1);
    });
    await t.test("withdrawal acceptance competing with an order-style wallet debit cannot overdraw", async () => {
      const w = await request(80000); const q = await quote(w.id);
      const results = await Promise.allSettled([
        actOnWithdrawal(w.id, owner.id, false, { action: "accept", quoteVersion: q.quoteVersion }),
        serializable(async tx => { const claim = await tx.user.updateMany({ where: { id: owner.id, balanceCents: { gte: 80000 } }, data: { balanceCents: { decrement: 80000 } } }); if (!claim.count) throw new Error("Insufficient balance"); }),
      ]);
      assert.equal(results.filter(r => r.status === "fulfilled").length, 1);
      assert.equal(await balance(), 20000);
      const updated = await db.withdrawal.findUniqueOrThrow({ where: { id: w.id } });
      await actOnWithdrawal(w.id, owner.id, false, { action: "cancel" });
      if (updated.status === "QUOTED") await db.user.update({ where: { id: owner.id }, data: { balanceCents: { increment: 80000 } } });
    });
    await t.test("processing races cancellation; no post-broadcast cancellation; complete is idempotent", async () => {
      const w = await request(); const q = await quote(w.id);
      await actOnWithdrawal(w.id, owner.id, false, { action: "accept", quoteVersion: q.quoteVersion });
      const results = await Promise.allSettled([actOnWithdrawal(w.id, admin.id, true, { action: "process" }), actOnWithdrawal(w.id, owner.id, false, { action: "cancel" })]);
      assert.equal(results.filter(r => r.status === "fulfilled").length, 1);
      const current = await db.withdrawal.findUniqueOrThrow({ where: { id: w.id } });
      if (current.status === "CANCELLED") return;
      await assert.rejects(actOnWithdrawal(w.id, owner.id, false, { action: "cancel" }));
      await actOnWithdrawal(w.id, admin.id, true, { action: "sent", txHash: "a".repeat(64) });
      await assert.rejects(actOnWithdrawal(w.id, admin.id, true, { action: "reject", note: "Not allowed" }));
      await actOnWithdrawal(w.id, admin.id, true, { action: "complete", note: "Verified on-chain transfer destination and token amount" });
      await actOnWithdrawal(w.id, admin.id, true, { action: "complete", note: "Retry" });
      assert.equal(await db.ledgerEntry.count({ where: { reference: `withdrawal:release:${w.id}` } }), 0);
    });
    await t.test("successful manual transfer never releases the reserve or repeats notifications", async () => {
      const before = await balance(); const w = await request(); const q = await quote(w.id);
      await actOnWithdrawal(w.id, owner.id, false, { action: "accept", quoteVersion: q.quoteVersion });
      await actOnWithdrawal(w.id, admin.id, true, { action: "process" });
      await actOnWithdrawal(w.id, admin.id, true, { action: "sent", txHash: "b".repeat(64) });
      await actOnWithdrawal(w.id, admin.id, true, { action: "complete", note: "Verified successful USDT transfer, matching destination and amount." });
      await actOnWithdrawal(w.id, admin.id, true, { action: "complete", note: "Duplicate confirmation" });
      await assert.rejects(actOnWithdrawal(w.id, admin.id, true, { action: "fail", confirmedNoFundsMoved: true, note: "Completed transfers cannot be refunded through failure reconciliation" }));
      assert.equal(await balance(), before - 10000);
      assert.equal(await db.ledgerEntry.count({ where: { reference: `withdrawal:release:${w.id}` } }), 0);
      assert.equal(await db.notificationOutbox.count({ where: { chatId: owner.telegramId!, text: { contains: `Retrait ${w.id}` } } }), 5);
    });
    await t.test("reconciled definitive failure releases only once", async () => {
      const before = await balance(); const w = await request(); const q = await quote(w.id);
      await actOnWithdrawal(w.id, owner.id, false, { action: "accept", quoteVersion: q.quoteVersion });
      await actOnWithdrawal(w.id, admin.id, true, { action: "process" });
      const failure = { action: "fail" as const, confirmedNoFundsMoved: true as const, note: "Provider verified no transaction broadcast or pending payout, reference TEST-FAILED" };
      await Promise.all([1, 2].map(() => actOnWithdrawal(w.id, admin.id, true, failure)));
      assert.equal(await balance(), before);
      assert.equal(await db.ledgerEntry.count({ where: { reference: `withdrawal:release:${w.id}` } }), 1);
    });
    await t.test("disabled service rejects new requests without debiting", async () => {
      process.env.WITHDRAWALS_ENABLED = "false";
      const before = await balance(); await assert.rejects(request()); assert.equal(await balance(), before);
    });
  } finally {
    const users = [owner.id, other.id, admin.id];
    await db.auditLog.deleteMany({ where: { actorId: { in: users } } });
    await db.ledgerEntry.deleteMany({ where: { userId: { in: users } } });
    await db.withdrawal.deleteMany({ where: { userId: { in: users } } });
    await db.notificationOutbox.deleteMany({ where: { chatId: { in: [owner.telegramId!, "999900001"] } } });
    await db.user.deleteMany({ where: { id: { in: users } } });
    await db.$disconnect();
  }
});
