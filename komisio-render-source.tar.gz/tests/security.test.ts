import test from "node:test";
import assert from "node:assert/strict";
import { createHmac } from "node:crypto";
import {
  createSessionToken,
  verifySessionToken,
  validateTelegramInitData,
  safeEqual,
  assertSameOrigin,
} from "../lib/server/auth";
import { canonicalize, verifyIpn } from "../lib/server/payment-signature";

const botToken = "123456:test-only-token";
const secret = "test-session-secret-32-characters-minimum";
const now = 1_800_000_000;
function signedInitData(
  authDate = now,
  user: unknown = { id: 123456, first_name: "Marie", username: "marie_test" },
) {
  const params = new URLSearchParams({
    auth_date: String(authDate),
    query_id: "test-query",
    user: JSON.stringify(user),
  });
  const checkString = [...params.entries()]
    .sort(([a], [b]) => a.localeCompare(b, "en"))
    .map(([key, value]) => `${key}=${value}`)
    .join("\n");
  const key = createHmac("sha256", "WebAppData").update(botToken).digest();
  params.set(
    "hash",
    createHmac("sha256", key).update(checkString).digest("hex"),
  );
  return params.toString();
}

test("valid Telegram initData returns only verified identity", () => {
  assert.equal(
    validateTelegramInitData(signedInitData(), botToken, now).id,
    123456,
  );
});
test("tampered Telegram identity is rejected", () => {
  const params = new URLSearchParams(signedInitData());
  params.set("user", JSON.stringify({ id: 999999, first_name: "Attacker" }));
  assert.throws(() =>
    validateTelegramInitData(params.toString(), botToken, now),
  );
});
test("expired, future and duplicated Telegram data is rejected", () => {
  assert.throws(() =>
    validateTelegramInitData(signedInitData(now - 601), botToken, now),
  );
  assert.throws(() =>
    validateTelegramInitData(signedInitData(now + 31), botToken, now),
  );
  assert.throws(() =>
    validateTelegramInitData(
      `${signedInitData()}&auth_date=${now}`,
      botToken,
      now,
    ),
  );
});
test("unsafe Telegram IDs and missing names are rejected", () => {
  assert.throws(() =>
    validateTelegramInitData(
      signedInitData(now, { id: 0, first_name: "A" }),
      botToken,
      now,
    ),
  );
  assert.throws(() =>
    validateTelegramInitData(
      signedInitData(now, { id: 123, first_name: "" }),
      botToken,
      now,
    ),
  );
});
test("signed session expires and cannot be forged", () => {
  const token = createSessionToken("user-123", secret, now);
  assert.equal(verifySessionToken(token, secret, now), "user-123");
  assert.throws(() => verifySessionToken(token, secret, now + 86_400));
  assert.throws(() =>
    verifySessionToken(`${token.slice(0, -1)}!`, secret, now),
  );
  assert.throws(() =>
    verifySessionToken(token, "another-secret-at-least-32-characters", now),
  );
  assert.throws(() => createSessionToken("user-123", "short", now));
});
test("cookie mutation requests reject cross-site origins", () => {
  const old = process.env.APP_URL;
  process.env.APP_URL = "https://forma.example";
  try {
    assert.doesNotThrow(() =>
      assertSameOrigin(
        new Request("https://forma.example/api/orders", {
          method: "POST",
          headers: { origin: "https://forma.example" },
        }),
      ),
    );
    assert.throws(() =>
      assertSameOrigin(
        new Request("https://forma.example/api/orders", {
          method: "POST",
          headers: { origin: "https://attacker.example" },
        }),
      ),
    );
    assert.throws(() =>
      assertSameOrigin(
        new Request("https://forma.example/api/orders", {
          method: "POST",
          headers: { "sec-fetch-site": "cross-site" },
        }),
      ),
    );
    assert.throws(() =>
      assertSameOrigin(
        new Request("https://forma.example/api/orders", { method: "POST" }),
      ),
    );
  } finally {
    if (old === undefined) delete process.env.APP_URL;
    else process.env.APP_URL = old;
  }
});
test("constant-time comparison safely handles length differences", () => {
  assert.equal(safeEqual("abc", "abc"), true);
  assert.equal(safeEqual("abc", "abcd"), false);
  assert.equal(safeEqual("abc", "abd"), false);
});

test("NOWPayments uses recursive codepoint key sorting and preserves array order", () => {
  const payload = {
    z: 1,
    a: { z: 2, _: "underscore", A: "upper", a: "lower" },
    items: [{ b: 2, a: 1 }, 5, 3],
  };
  const expected =
    '{"a":{"A":"upper","_":"underscore","a":"lower","z":2},"items":[{"a":1,"b":2},5,3],"z":1}';
  assert.equal(JSON.stringify(canonicalize(payload)), expected);
  const signature = createHmac("sha512", "ipn-test-secret")
    .update(expected)
    .digest("hex");
  assert.equal(verifyIpn(payload, signature, "ipn-test-secret"), true);
  assert.equal(
    verifyIpn({ ...payload, z: 99 }, signature, "ipn-test-secret"),
    false,
  );
  assert.equal(verifyIpn(payload, signature, "wrong-secret"), false);
  assert.equal(
    verifyIpn(payload, signature.slice(0, -2), "ipn-test-secret"),
    false,
  );
  assert.equal(verifyIpn(payload, signature, ""), false);
});
