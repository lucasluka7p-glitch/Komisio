import test from "node:test";
import assert from "node:assert/strict";
import { whatsappSupportUrl, validateWhatsAppSupportUrl } from "../lib/whatsapp-public";

test("support links use a configured international number and safely encode the message", () => {
  const link = whatsappSupportUrl("+33 (6) 12 34 56 78", "Dossier #42 & pièce à corriger");
  assert.ok(link);
  const url = new URL(link);
  assert.equal(url.origin, "https://wa.me");
  assert.equal(url.pathname, "/33612345678");
  assert.equal(url.searchParams.get("text"), "Dossier #42 & pièce à corriger");
  assert.equal(validateWhatsAppSupportUrl(link), link);
  assert.equal(whatsappSupportUrl(undefined), null);
  assert.equal(whatsappSupportUrl("0612345678"), null);
});

test("a support destination cannot redirect to another host, protocol or credential-bearing URL", () => {
  for (const value of ["javascript:alert(1)", "http://wa.me/33612345678", "https://wa.me.attacker.test/33612345678", "https://attacker.test/?url=https://wa.me/33612345678", "https://user:secret@wa.me/33612345678", "https://wa.me/33612345678/extra", "https://wa.me/0012345678", null]) {
    assert.equal(validateWhatsAppSupportUrl(value), null);
  }
});
