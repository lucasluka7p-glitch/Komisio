import test from "node:test";
import assert from "node:assert/strict";
import {
  fileMime,
  boundedFormData,
  MAX_FILE_BYTES,
} from "../lib/server/storage";

test("document signatures accept PDF/JPEG/PNG and reject disguised executable content", () => {
  assert.equal(fileMime(Buffer.from("%PDF-1.7\n")), "application/pdf");
  assert.equal(fileMime(Uint8Array.from([255, 216, 255, 224])), "image/jpeg");
  assert.equal(
    fileMime(Uint8Array.from([137, 80, 78, 71, 13, 10, 26, 10])),
    "image/png",
  );
  assert.equal(fileMime(Buffer.from("<html><script>alert(1)</script>")), null);
  assert.equal(fileMime(Buffer.from("MZ masquerading-as-document.pdf")), null);
});

test("oversized multipart bodies are rejected before parsing", async () => {
  const request = new Request("https://example.com/api/documents", {
    method: "POST",
    body: "x",
    headers: {
      "content-type": "multipart/form-data; boundary=test",
      "content-length": String(MAX_FILE_BYTES + 100_000),
    },
  });
  await assert.rejects(() => boundedFormData(request), /10 Mo/);
});

test("video containers are accepted only for a video slot, with bounded MP4/MOV headers", async () => {
  const { videoMime, attachmentMime } = await import("../lib/server/storage");
  const mp4 = Buffer.alloc(24); mp4.writeUInt32BE(24); mp4.write("ftyp", 4); mp4.write("isom", 8);
  assert.equal(videoMime(mp4), "video/mp4");
  assert.equal(attachmentMime(mp4, "video"), "video/mp4");
  assert.equal(attachmentMime(mp4, "document"), null);
  assert.equal(attachmentMime(Buffer.from("%PDF-1.7"), "video"), null);
  const mov = Buffer.from(mp4); mov.write("qt  ", 8); assert.equal(videoMime(mov), "video/quicktime");
  const image = Buffer.from(mp4); image.write("heic", 8); assert.equal(videoMime(image), null);
  const truncated = Buffer.from(mp4); truncated.writeUInt32BE(500); assert.equal(videoMime(truncated), null);
  assert.equal(videoMime(Buffer.from("MZ fake video.mov")), null);
});

test("photo-only slots reject PDF documents while allowing JPEG/PNG", async () => {
  const { attachmentMime } = await import("../lib/server/storage");
  assert.equal(attachmentMime(Buffer.from("%PDF-1.7"), "image"), null);
  assert.equal(attachmentMime(Uint8Array.from([255, 216, 255, 224]), "image"), "image/jpeg");
});
