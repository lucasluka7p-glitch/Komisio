import { telegramWebhookSecret } from '../lib/server/telegram-secret';
import test from 'node:test';
import assert from 'node:assert/strict';
import { createHmac } from 'node:crypto';
import { verifyPlisioCallback,plisioAssetMatches,checkedInvoiceUrl } from '../lib/server/plisio';
import { configurationIssues } from '../lib/server/configuration';
test('Plisio JSON callback follows documented SHA-1 insertion-order protocol and rejects mutations',()=>{
 const payload={txn_id:'a'.repeat(24),status:'completed',source_amount:'10.00',currency:'USDT_TRX',order_number:'local-id'};
 const signed={...payload,verify_hash:createHmac('sha1','test-key').update(JSON.stringify(payload)).digest('hex')};
 assert.ok(verifyPlisioCallback(signed,'test-key'));assert.equal(verifyPlisioCallback({...signed,source_amount:'1000.00'},'test-key'),false);assert.equal(verifyPlisioCallback(signed,'wrong'),false);
 const reordered=Object.fromEntries([['currency',payload.currency],...Object.entries(signed).filter(([key])=>key!=='currency')]);assert.equal(verifyPlisioCallback(reordered,'test-key'),false);
 assert.equal(plisioAssetMatches('usdttrc20','USDT'),false);assert.ok(plisioAssetMatches('usdterc20','USDT'));assert.ok(plisioAssetMatches('sol','Solana'));
 assert.throws(()=>checkedInvoiceUrl('https://fake.test/invoice/id'));assert.equal(checkedInvoiceUrl('https://plisio.net/invoice/id'),'https://plisio.net/invoice/id');
});
test('new production configuration requires Plisio, never a legacy NOWPayments account',()=>{
 const issues=configurationIssues({PAYMENT_PROVIDER:'PLISIO'},true);assert.ok(issues.includes('PLISIO_API_KEY manquant'));assert.ok(!issues.some(x=>x.includes('NOWPAYMENTS')));
 const remote=configurationIssues({STORAGE_DRIVER:'supabase'},false);assert.ok(remote.includes('SUPABASE_SERVICE_ROLE_KEY manquant'));
});

test('Render-generated base64 webhook secrets are consistently converted to Telegram-compatible values',()=>{
 const secret=telegramWebhookSecret('B0jrphAPOY7pg92AN0c9MN4yecczLMdwnx4OkA1KFUk=');assert.match(secret,/^[a-f0-9]{64}$/);assert.equal(secret,telegramWebhookSecret('B0jrphAPOY7pg92AN0c9MN4yecczLMdwnx4OkA1KFUk='));assert.equal(telegramWebhookSecret('a'.repeat(64)),'a'.repeat(64));
});
