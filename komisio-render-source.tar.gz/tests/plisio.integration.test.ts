import test from 'node:test';import assert from 'node:assert/strict';import{createHmac,randomUUID}from'node:crypto';import{createServer}from'node:http';import{createServer as netServer}from'node:net';import{spawn}from'node:child_process';import{setTimeout as delay}from'node:timers/promises';import{PrismaClient}from'@prisma/client';
const database=process.env.PLISIO_TEST_DATABASE_URL;
test('Plisio HTTP invoices, signed settlement, cash-outs and private Supabase storage',{skip:!database,timeout:180000},async t=>{
 assert.equal(new URL(database!).pathname,'/komisio_plisio_test');const db=new PrismaClient({datasources:{db:{url:database}}});
 const operations=new Map<string,any>(),objects=new Map<string,Buffer>();let counter=1,payoutCalls=0,unknownInvoice=false,unknownPayout=false,networkFee='1.10',publicBucket=false;
 const apiKey='test-plisio-key-local',botToken='123456:'+('a'.repeat(40));
 const mock=createServer(async(req,res)=>{
  const url=new URL(req.url!,'http://local');const chunks:Buffer[]=[];for await(const c of req)chunks.push(Buffer.from(c));res.setHeader('content-type','application/json');
  if(url.pathname.includes('/sendMessage')){const input=JSON.parse(Buffer.concat(chunks).toString());res.end(JSON.stringify({ok:true,result:{message_id:counter++,date:Math.floor(Date.now()/1000),chat:{id:Number(input.chat_id),type:'private'},text:input.text}}));return;}
  if(url.pathname.includes('/getMe')){res.end(JSON.stringify({ok:true,result:{id:123456,is_bot:true,first_name:'Komisio',username:'KomisioLocalBot'}}));return;}
  if(url.pathname.includes('/getWebhookInfo')){res.end(JSON.stringify({ok:true,result:{url:'https://komisio.test/api/bot',has_custom_certificate:false,pending_update_count:0}}));return;}
  if(['/setWebhook','/setMyCommands','/setChatMenuButton'].some(path=>url.pathname.endsWith(path))){res.end(JSON.stringify({ok:true,result:true}));return;}
  if(url.pathname.startsWith('/storage/')){
   assert.equal(req.headers.authorization,'Bearer private-test-storage-key');if(url.pathname.startsWith('/storage/v1/bucket/')){res.end(JSON.stringify({public:publicBucket}));return;}
   if(req.method==='POST'){objects.set(url.pathname,Buffer.concat(chunks));res.end('{}');return;}if(req.method==='DELETE'){for(const key of JSON.parse(Buffer.concat(chunks).toString()).prefixes)objects.delete(url.pathname+'/'+key);res.end('{}');return;}if(objects.has(url.pathname)){res.end(objects.get(url.pathname));return;}res.statusCode=404;res.end('{}');return;
  }
  const success=(data:unknown)=>res.end(JSON.stringify({status:'success',data}));if(url.searchParams.get('api_key')!==apiKey){res.statusCode=401;res.end('{}');return;}
  if(url.pathname.endsWith('/invoices/new')){
   const id=(counter++).toString(16).padStart(24,'0'),currency=url.searchParams.get('currency')!;assert.equal(url.searchParams.get('allowed_psys_cids'),currency);assert.ok(url.searchParams.get('callback_url')!.endsWith('/api/webhooks/plisio?json=true'));
   const operation={id,type:'invoice',status:'new',psys_cid:currency,currency,params:{order_number:url.searchParams.get('order_number'),source_amount:url.searchParams.get('source_amount'),source_currency:'EUR',amount:'111.00'},amount:'0'};operations.set(id,operation);
   if(unknownInvoice){unknownInvoice=false;res.statusCode=500;res.end('{}');}else success({txn_id:id,invoice_url:`https://plisio.net/invoice/${id}`,invoice_total_sum:'111.00'});return;
  }
  if(url.pathname.endsWith('/currencies/EUR')){success([{cid:'USDT_TRX',fiat:'EUR',fiat_rate:'1.1000000000',hidden:0,maintenance:false}]);return;}
  if(url.pathname.includes('/operations/fee/')){success({psys_cid:'USDT_TRX',currency:'USDT_TRX',fee:networkFee});return;}
  if(url.pathname.includes('/balances/')){success({psys_cid:'USDT_TRX',balance:'10000.00'});return;}
  if(url.pathname.endsWith('/operations/withdraw')){
   payoutCalls++;const id=(counter++).toString(16).padStart(24,'0');const operation={id,type:'cash_out',status:'completed',psys_cid:'USDT_TRX',currency:'USDT_TRX',wallet_hash:url.searchParams.get('to'),amount:url.searchParams.get('amount'),created_at_utc:Math.floor(Date.now()/1000),confirmations:0,tx:[{txid:counter.toString(16).padStart(64,'0')}]};operations.set(id,operation);
   if(unknownPayout){unknownPayout=false;res.statusCode=500;res.end('{}');}else success(operation);return;
  }
  const operation=operations.get(url.pathname.split('/').at(-1)!);if(operation){success(operation);return;}res.statusCode=404;res.end('{}');
 });
 await new Promise<void>(resolve=>mock.listen(0,'127.0.0.1',resolve));const mockPort=(mock.address() as any).port;
 const probe=netServer();await new Promise<void>(resolve=>probe.listen(0,'127.0.0.1',resolve));const port=(probe.address() as any).port;await new Promise<void>(resolve=>probe.close(()=>resolve()));const base=`http://127.0.0.1:${port}`,origin='https://komisio.test';
 let log='';const app=spawn(process.execPath,['node_modules/next/dist/bin/next','dev','--hostname','127.0.0.1','--port',String(port)],{detached:true,env:{...process.env,DATABASE_URL:database,NODE_ENV:'development',NEXT_PUBLIC_DEMO_MODE:'false',NEXT_TELEMETRY_DISABLED:'1',APP_URL:origin,MINI_APP_URL:origin,TELEGRAM_BOT_TOKEN:botToken,TELEGRAM_BOT_USERNAME:'KomisioLocalBot',ADMIN_TELEGRAM_IDS:'800000001',SESSION_SECRET:'s'.repeat(64),CRON_SECRET:'c'.repeat(64),TELEGRAM_WEBHOOK_SECRET:'w'.repeat(64),PAYMENT_PROVIDER:'PLISIO',PLISIO_API_KEY:apiKey,PLISIO_PAYOUTS_ENABLED:'true',WITHDRAWALS_ENABLED:'true',STORAGE_DRIVER:'supabase',SUPABASE_URL:'https://private.supabase.co',SUPABASE_SERVICE_ROLE_KEY:'private-test-storage-key',SUPABASE_STORAGE_BUCKET:'private',PRIVATE_UPLOAD_DIR:'.private/unused',KOMISIO_INTEGRATION_TEST_MODE:'true',TEST_PLISIO_API_ROOT:`http://127.0.0.1:${mockPort}/api/v1`,TEST_SUPABASE_STORAGE_ROOT:`http://127.0.0.1:${mockPort}`,TEST_TELEGRAM_API_ROOT:`http://127.0.0.1:${mockPort}`},stdio:['ignore','pipe','pipe']});app.stdout?.on('data',c=>log=(log+c).slice(-6000));app.stderr?.on('data',c=>log=(log+c).slice(-6000));
 async function api(path:string,cookie='',method='GET',value?:unknown,expected=200){const r=await fetch(base+path,{method,headers:{origin,...(cookie?{cookie}:{}),...(value instanceof FormData?{}:{'content-type':'application/json'})},body:value===undefined?undefined:value instanceof FormData?value:JSON.stringify(value)});const data=await r.json();if(r.status===500&&expected!==500)console.error(log);assert.equal(r.status,expected,`${path}: ${JSON.stringify(data)}`);return data;}
 async function login(id:number){const p=new URLSearchParams({auth_date:String(Math.floor(Date.now()/1000)),user:JSON.stringify({id,first_name:'Plisio test'})});const check=[...p.entries()].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join('\n');const key=createHmac('sha256','WebAppData').update(botToken).digest();p.set('hash',createHmac('sha256',key).update(check).digest('hex'));const r=await fetch(base+'/api/auth/telegram',{method:'POST',headers:{origin,'content-type':'application/json'},body:JSON.stringify({initData:p.toString()})});assert.equal(r.status,200);return{cookie:r.headers.get('set-cookie')!.split(';')[0],user:(await r.json()).user};}
 const receipt=(operation:any,status='completed',amount='111.00')=>({ipn_type:'invoice',txn_id:operation.id,order_number:operation.params.order_number,status,source_currency:'EUR',source_amount:operation.params.source_amount,currency:operation.psys_cid,amount,invoice_total_sum:'111.00'});
 async function callback(data:Record<string,unknown>,expected=200,bad=false){const verify_hash=bad?'0'.repeat(40):createHmac('sha1',apiKey).update(JSON.stringify(data)).digest('hex');return api('/api/webhooks/plisio','','POST',{...data,verify_hash},expected);}
 try{
  let ready=false;for(let i=0;i<90;i++){try{if((await fetch(base+'/api/config',{signal:AbortSignal.timeout(1500)})).ok){ready=true;break;}}catch{}await delay(500);}assert.ok(ready);
  for (const telegramId of [800000002, 800000003]) await db.user.create({ data: { telegramId: String(telegramId), firstName: "Client de test" } });
  const admin=await login(800000001),owner=await login(800000002),other=await login(800000003);const balance=async()=>(await api('/api/me',owner.cookie)).user.balanceCents;
  await t.test('Supabase data API roles cannot bypass the backend to read partner or wallet tables',async()=>{
   await db.$executeRawUnsafe('CREATE ROLE komisio_test_anon NOLOGIN');await db.$executeRawUnsafe('GRANT USAGE ON SCHEMA public TO komisio_test_anon');await db.$executeRawUnsafe('GRANT SELECT ON TABLE public."User" TO komisio_test_anon');
   await db.$transaction(async tx=>{await tx.$executeRawUnsafe('SET LOCAL ROLE komisio_test_anon');const rows=await tx.$queryRawUnsafe<{count:bigint}[]>('SELECT COUNT(*) AS count FROM public."User"');assert.equal(rows[0].count,0n);});
   assert.equal(await db.user.count(),3);
  });
  await t.test('Telegram can be configured from the protected admin panel without a paid hosting shell',async()=>{
   await api('/api/admin/operations',owner.cookie,'POST',{action:'configure_telegram'},403);const configured=await api('/api/admin/operations',admin.cookie,'POST',{action:'configure_telegram'});assert.equal(configured.botUsername,'KomisioLocalBot');assert.equal(await db.auditLog.count({where:{action:'TELEGRAM_BOT_CONFIGURED'}}),1);
  });
  await t.test('hosted invoice returns a URL without white-label or client-supplied address',async()=>{
   for(const [currency,expected]of Object.entries({usdttrc20:'USDT_TRX',usdterc20:'USDT',btc:'BTC',eth:'ETH',sol:'SOL'})){
    const payment=await api('/api/payments',owner.cookie,'POST',{amountCents:2000,payCurrency:currency,idempotencyKey:randomUUID()},201);assert.equal(payment.provider,'PLISIO');assert.ok(payment.invoiceUrl.startsWith('https://plisio.net/invoice/'));assert.equal(payment.payAddress,null);assert.equal(operations.get(payment.providerPaymentId).psys_cid,expected);
   }
   assert.equal(await balance(),0);
  });
  await t.test('settlement needs signed exact fiat/network receipt and authoritative API completion; duplicates credit once',async()=>{
   const payment=await api('/api/payments',owner.cookie,'POST',{amountCents:2000,payCurrency:'usdttrc20',idempotencyKey:randomUUID()},201);const remote=operations.get(payment.providerPaymentId);remote.status='completed';assert.equal((await api(`/api/payments/${payment.id}`,owner.cookie)).status,'WAITING');
   await callback(receipt(remote),401,true);await callback({...receipt(remote),source_amount:'999'},409);await callback({...receipt(remote),currency:'USDT'},409);await callback(receipt(remote,'completed','50.00'),409);assert.equal(await balance(),0);
   await Promise.all([callback(receipt(remote)),callback(receipt(remote))]);assert.equal(await balance(),2000);assert.equal(await db.ledgerEntry.count({where:{reference:`crypto:${payment.id}`}}),1);
  });
  await t.test('a signed callback recovers an ambiguous creation response without another invoice',async()=>{
   unknownInvoice=true;await api('/api/payments',owner.cookie,'POST',{amountCents:1500,payCurrency:'usdttrc20',idempotencyKey:randomUUID()},502);const remote=[...operations.values()].filter(o=>o.type==='invoice').at(-1);remote.status='completed';await callback(receipt(remote));assert.equal(await balance(),3500);assert.equal((await api('/api/admin/operations',admin.cookie)).invoices.length,0);
  });
  await t.test('an accepted quote is invoiced at the server price and only Plisio settlement starts processing',async()=>{
   const fields={registration:'AA-123-AA',vin:'VF000000000000001',formulaNumber:'FORM123',holderIdentity:'Société test',buyerLastName:'Test',buyerFirstName:'Alice',buyerBirthPlace:'Paris',buyerBirthDate:'1990-01-01',deliveryAddress:'1 rue de test, Paris'};
   const order=(await api('/api/orders',owner.cookie,'POST',{serviceId:'carte-grise',fields,documentIds:[],paymentMethod:'CRYPTO',idempotencyKey:randomUUID()},201)).order;
   await api('/api/payments',owner.cookie,'POST',{orderId:order.id,amountCents:100,payCurrency:'usdttrc20',idempotencyKey:randomUUID()},409);
   const quote=await api(`/api/admin/orders/${order.id}/quote`,admin.cookie,'POST',{amountCents:12345,expectedVersion:0});await api(`/api/orders/${order.id}/quote`,owner.cookie,'POST',{action:'accept',quoteVersion:quote.quoteVersion});
   const payment=await api('/api/payments',owner.cookie,'POST',{orderId:order.id,amountCents:100,payCurrency:'usdttrc20',idempotencyKey:randomUUID()},201);const remote=operations.get(payment.providerPaymentId);assert.equal(remote.params.source_amount,'123.45');assert.equal((await api(`/api/orders/${order.id}`,owner.cookie)).status,'AWAITING_PAYMENT');remote.status='completed';await callback(receipt(remote));assert.equal((await api(`/api/orders/${order.id}`,owner.cookie)).status,'PROCESSING');assert.equal(await balance(),3500);
  });
  await t.test('Supabase documents remain private and a public bucket fails closed',async()=>{
   const f=new FormData();f.set('serviceId','carte-grise');f.set('fieldKey','registration_certificate');f.set('file',new Blob(['%PDF-1.4\nTest\n%%EOF'],{type:'application/pdf'}),'test.pdf');const document=await api('/api/documents',owner.cookie,'POST',f,201);assert.equal('storageKey' in document,false);const r=await fetch(base+`/api/documents/${document.id}`,{headers:{cookie:owner.cookie}});assert.equal(r.status,200);assert.ok((await r.text()).startsWith('%PDF-'));await api(`/api/documents/${document.id}`,other.cookie,'GET',undefined,404);
   publicBucket=true;await api('/api/health','','GET',undefined,503);publicBucket=false;await api('/api/health');
  });
  async function request(){return api('/api/withdrawals',owner.cookie,'POST',{amountCents:1000,currency:'usdttrc20',address:'T9yD14Nj9j7xAB4dbGeiX9h8unkKHxuWwb',idempotencyKey:randomUUID()},201);}
  async function quoteAccept(){const w=await request();const q=await api(`/api/admin/withdrawals/${w.id}/plisio`,admin.cookie,'POST',{action:'quote'});assert.equal(q.feeCents,100);assert.equal(q.netAmount,'9.900000');await api(`/api/withdrawals/${w.id}`,owner.cookie,'POST',{action:'accept',quoteVersion:q.quoteVersion});return w;}
  await t.test('accepted fees precede one Plisio transfer, including concurrent sends and network confirmation',async()=>{
   const w=await quoteAccept();await api(`/api/admin/withdrawals/${w.id}/plisio`,owner.cookie,'POST',{action:'send'},403);
   const path=base+`/api/admin/withdrawals/${w.id}/plisio`;const responses=await Promise.all([1,2].map(()=>fetch(path,{method:'POST',headers:{origin,cookie:admin.cookie,'content-type':'application/json'},body:JSON.stringify({action:'send'})})));if(!responses.some(r=>r.status===200))console.error(log);assert.ok(responses.some(r=>r.status===200));assert.ok(responses.every(r=>[200,409].includes(r.status)));assert.equal(payoutCalls,1);assert.equal(await balance(),2500);
   const stored=await db.withdrawal.findUniqueOrThrow({where:{id:w.id}});assert.equal(stored.status,'SENT');const full=operations.get(stored.providerTransferId!);operations.set(stored.providerTransferId!,{id:full.id,type:'cash_out',status:'completed'});await api(`/api/admin/withdrawals/${w.id}/plisio`,admin.cookie,'POST',{action:'reconcile'});assert.equal((await db.withdrawal.findUniqueOrThrow({where:{id:w.id}})).status,'SENT');operations.set(stored.providerTransferId!,{...full,confirmations:1});await api(`/api/admin/withdrawals/${w.id}/plisio`,admin.cookie,'POST',{action:'reconcile'});assert.equal((await db.withdrawal.findUniqueOrThrow({where:{id:w.id}})).status,'COMPLETED');assert.equal(await balance(),2500);
  });
  await t.test('a lost payout response keeps the reserve and blocks resending until a verified operation is linked',async()=>{
   const w=await quoteAccept();unknownPayout=true;await api(`/api/admin/withdrawals/${w.id}/plisio`,admin.cookie,'POST',{action:'send'},502);assert.equal(await balance(),1500);await api(`/api/admin/withdrawals/${w.id}/plisio`,admin.cookie,'POST',{action:'send'},409);assert.equal(payoutCalls,2);await api(`/api/withdrawals/${w.id}`,owner.cookie,'POST',{action:'cancel'},409);
   const operation=[...operations.values()].filter(o=>o.type==='cash_out').at(-1);const invalidId='f'.repeat(24);operations.set(invalidId,{...operation,id:invalidId,wallet_hash:'wrong-wallet'});await api(`/api/admin/withdrawals/${w.id}/plisio`,admin.cookie,'POST',{action:'link',operationId:invalidId},409);assert.equal(await balance(),1500);operation.confirmations=1;await api(`/api/admin/withdrawals/${w.id}/plisio`,admin.cookie,'POST',{action:'link',operationId:operation.id});assert.equal((await db.withdrawal.findUniqueOrThrow({where:{id:w.id}})).status,'COMPLETED');assert.equal(await balance(),1500);
  });
  await t.test('a fee increase never dispatches an unapproved transfer or silently increases the debit',async()=>{
   const w=await quoteAccept();networkFee='2.20';await api(`/api/admin/withdrawals/${w.id}/plisio`,admin.cookie,'POST',{action:'send'},409);assert.equal(payoutCalls,2);assert.equal((await db.withdrawal.findUniqueOrThrow({where:{id:w.id}})).providerAttemptedAt,null);await api(`/api/withdrawals/${w.id}`,owner.cookie,'POST',{action:'cancel'});assert.equal(await balance(),1500);
  });
 }catch(error){console.error(log);throw error;}finally{try{process.kill(-app.pid!,'SIGTERM');}catch{}await delay(300);try{process.kill(-app.pid!,'SIGKILL');}catch{}await new Promise<void>(resolve=>mock.close(()=>resolve()));await db.$disconnect();}
});
