import test from "node:test";
import assert from "node:assert/strict";
import { initialServices } from "../lib/catalog";
import { catalogueSections, serviceSection, findCatalogueServices, quickCatalogueServices, serviceSummary, shortServiceTitle } from "../lib/catalogue-view";
const all = { category: "all", group: "all", query: "", pricing: "all", sort: "recommended" };
test("catalogue search accepts accents, flexible word order and common service names", () => {
  const search = (query: string) => findCatalogueServices(initialServices, { ...all, query }).map(service => service.id);
  assert.ok(search("  SOCIÉTÉ création  ").includes("creation"));
  assert.deepEqual(search("ww modifier"), ["ww-modification"]);
  assert.ok(search("fiche police véhicule").includes("situation-vehicule"));
  assert.equal(search("service introuvable xyz").length, 0);
});
test("quote filters and price order never present an unpriced quote as a free fixed service", () => {
  const quotes = findCatalogueServices(initialServices, { ...all, pricing: "quote" });
  assert.ok(quotes.length > 0); assert.ok(quotes.every(service => service.requiresQuote));
  const sorted = findCatalogueServices(initialServices, { ...all, sort: "price" });
  const firstQuote = sorted.findIndex(service => service.requiresQuote);
  assert.ok(sorted.slice(firstQuote).every(service => service.requiresQuote));
  const fixed = sorted.slice(0, firstQuote);
  assert.ok(fixed.every((service, index) => index === 0 || fixed[index - 1].price <= service.price));
});
test("custom offers stay discoverable, retain their copy, and hidden services stay excluded", () => {
  const original = initialServices[0];
  const custom = { ...original, id: "custom", title: "Ma prestation sur mesure", description: "Description choisie par l’administrateur", category: "automobile" as const, subcategory: "creation-modification" };
  const hidden = { ...original, id: "hidden", active: false };
  assert.equal(shortServiceTitle(custom), custom.title); assert.equal(serviceSummary(custom), custom.description);
  assert.deepEqual(findCatalogueServices([custom, hidden], { ...all, category: "automobile", group: "other" }).map(service => service.id), ["custom"]);
  const edited = { ...original, title: "Ma création", description: "Mes conditions personnalisées" };
  assert.equal(shortServiceTitle(edited), edited.title); assert.equal(serviceSummary(edited), edited.description);
});
test("quick access has no duplicates and fills gaps when an administrator disables an offer", () => {
  const services = initialServices.map(service => ({ ...service, active: !["ww", "creation"].includes(service.id) }));
  const before = structuredClone(services); const picked = quickCatalogueServices(services);
  assert.equal(picked.length, 6); assert.equal(new Set(picked.map(service => service.id)).size, 6);
  assert.ok(picked.every(service => service.active)); assert.deepEqual(services, before);
  assert.equal(findCatalogueServices(services, all).length, services.filter(service => service.active).length);
});

test("concrete service sections cover every active offer exactly once without changing database categories", () => {
  assert.equal(catalogueSections.length, 7);
  const before = structuredClone(initialServices);
  const sections = catalogueSections.map(section => findCatalogueServices(initialServices, { ...all, section: section.id }));
  const ids = sections.flat().map(service => service.id);
  assert.equal(ids.length, initialServices.filter(service => service.active).length);
  assert.equal(new Set(ids).size, ids.length);
  for (const [id, expected] of Object.entries({ "ww": "immatriculation", "carte-grise": "immatriculation", "controle-convoyage": "automobile", "douane-suisse": "automobile", "code-route": "permis", "remboursement-ameli": "remboursements", "creation": "administratif", "titre-sejour": "administratif", "cedeo-pro": "offres-pro", "regularisation-carte-grise": "immatriculation", "fin-leasing": "immatriculation", "homologation": "immatriculation", "remboursement-mutuelle": "remboursements", "dossier-recepisse": "administratif", "dossier-logement": "administratif", "creation-neph": "permis", "situation-vehicule": "informations", "acces-donnees-personnelles": "informations" })) {
    assert.equal(serviceSection(initialServices.find(service => service.id === id)!).id, expected);
  }
  assert.deepEqual(initialServices, before);
});
test("administrator offers follow their configured subcategory and fall back to a visible service section", () => {
  const base = initialServices[0];
  const custom = { ...base, id: "custom", category: "assistance" as const, subcategory: "remboursements" };
  assert.equal(serviceSection(custom).id, "remboursements");
  assert.equal(serviceSection({ ...custom, subcategory: null }).id, "administratif");
  assert.equal(serviceSection({ ...custom, subcategory: "immatriculation" }).id, "administratif");
  assert.equal(findCatalogueServices([custom], { ...all, section: "remboursements", query: "remboursements" }).length, 1);
  assert.equal(findCatalogueServices([{ ...custom, active: false }], { ...all, section: "remboursements" }).length, 0);
});

test("user vocabulary finds precise official services and the new CEDEO offer", () => {
  for (const [query, id] of Object.entries({ "écrasement carte grise": "regularisation-carte-grise", "écrasement leasing": "fin-leasing", "fiche infos véhicule": "situation-vehicule", "fiche police recherche": "acces-donnees-personnelles", "levée valant saisie": "levee-saisie", "remboursement mutuelle": "remboursement-mutuelle", "dossier récépissé": "dossier-recepisse", "création NEPH": "creation-neph", "CEDEO 40": "cedeo-pro" })) {
    assert.ok(findCatalogueServices(initialServices, { ...all, query }).some(service => service.id === id), query);
  }
});
