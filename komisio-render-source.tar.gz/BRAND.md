# Komisio

Identité visuelle reprise de la planche de marque fournie : monogramme K bleu/cyan/vert, mot-symbole Komisio et signature « Vos contacts ont de la valeur. ».

- Bleu principal : `#0866F5` ; action : `#075FE9`.
- Bleu nuit : `#081426` ; texte : `#0B1831`.
- Vert lumineux : `#32EF86` ; texte vert accessible : `#087D55`.
- Fond : `#F4F7FC` ; surfaces blanches ; bordures `#E0E8F3`.
- Polices locales Manrope et DM Sans, sans requête à un service de polices externe.

Le composant `components/brand.tsx` centralise le logo. Les PNG optimisés sont dans `public/brand` ; le monogramme a été extrait et adapté avec l’outil image à partir du visuel fourni. La petite icône bénéficie d’un fond blanc. Le thème commun est dans `components/komisio-theme.css`, complété par les styles structurels globaux et admin.

Le thème couvre la navigation, les écrans de chargement, le catalogue, le portefeuille et les retraits, les commandes, les devis, les fenêtres et les formulaires, le suivi d’original, l’administration, les métadonnées et le message du bot. Les avertissements et statuts conservent des couleurs sémantiques distinctes. Les mises en page et les zones sûres Telegram restent adaptées aux petits écrans ; le bandeau de marque est compact sur mobile.

Les clés de stockage, les cookies et les identifiants internes historiques sont conservés pour éviter de perdre des dossiers, soldes ou sessions. La marque visible et les exports utilisent Komisio. L’URL de publication existante est conservée.


## Apparence claire et sombre

Un bouton soleil/lune dans l’en-tête bascule les deux modes, sur mobile et ordinateur, y compris dans l’admin. Le premier affichage suit `prefers-color-scheme`. Le choix explicite est mémorisé sous `komisio-appearance` ; une préférence du système ne l’écrase plus. Les onglets ouverts se synchronisent via l’événement `storage`. Si le stockage est bloqué, la bascule reste utilisable pour la session.

Le script statique en tête de document applique la préférence avant le premier affichage, pour éviter le flash clair. Les formulaires, tableaux, modales, statuts, devis et retraits ont des couleurs adaptées. Le QR de paiement conserve son fond blanc. Les couleurs de l’interface Telegram et de la barre du navigateur suivent le mode. Les données métier et les clés historiques restent inchangées.


## Komi, le guide de services

Mascotte originale : compagnon en volume blanc nacré, visage marine, yeux cyan, accents bleu et vert, dossier avec coche. Asset optimisé transparent `/brand/komi-mascot.webp` (360 px, environ 23 Ko). Le personnage sert de point d’entrée au guide du catalogue et apporte des conseils dans le formulaire. Son animation légère est limitée, désactivable et respecte les préférences de réduction des mouvements. Il n’est pas présenté comme un opérateur ou comme un conseiller humain.
