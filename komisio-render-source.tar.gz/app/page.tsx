import PartnerApp from "@/components/partner-app";
export default function Page() {
  return <PartnerApp />;
}
