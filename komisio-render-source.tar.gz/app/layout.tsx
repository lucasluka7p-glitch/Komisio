import type { Metadata, Viewport } from "next";
import "./globals.css";
import { appearanceInitScript } from "@/lib/appearance";
export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  interactiveWidget: "resizes-content",
  themeColor: "#081426",
};
export const metadata: Metadata = {
  applicationName: "Komisio",
  icons: { icon: "/brand/komisio-icon.png", apple: "/brand/komisio-icon.png" },
  title: "Komisio — Votre espace partenaire",
  description:
    "Vos contacts ont de la valeur. Services B2B, suivi de dossiers et portefeuille partenaire Komisio.",
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: appearanceInitScript }} />
        <link
          rel="preload"
          href="/fonts/dm-sans.woff2"
          as="font"
          type="font/woff2"
          crossOrigin="anonymous"
        />
        <link
          rel="preload"
          href="/fonts/manrope.woff2"
          as="font"
          type="font/woff2"
          crossOrigin="anonymous"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
