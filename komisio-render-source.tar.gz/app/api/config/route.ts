export const dynamic = 'force-dynamic';
export function GET() {
  const username=process.env.TELEGRAM_BOT_USERNAME || '';
  return Response.json({ telegramBotUrl: /^[a-zA-Z0-9_]{5,32}$/.test(username) ? `https://t.me/${username}` : null, whatsappSupportUrl: whatsappSupportUrl(process.env.WHATSAPP_SUPPORT_NUMBER) }, { headers: { 'Cache-Control':'no-store' } });
}
import { whatsappSupportUrl } from '@/lib/whatsapp-public';
