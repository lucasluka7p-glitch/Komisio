import { processWhatsAppJobs, processWhatsAppOutbox } from "@/lib/server/whatsapp";
import { db } from "@/lib/server/db";
import { reconcilePlisioPayout } from "@/lib/server/plisio-payouts";
import { reconcilePayment } from "@/lib/server/payments";
import { safeEqual } from "@/lib/server/auth";
import { handle, HttpError } from "@/lib/server/http";
import { processNotifications } from "@/lib/server/telegram";

export const runtime = "nodejs";
export const maxDuration = 60;
export const POST = handle(async (request: Request) => {
  const secret = process.env.CRON_SECRET;
  if (!secret || secret.length < 32)
    throw new HttpError(503, "Planificateur non configuré.");
  if (
    !safeEqual(request.headers.get("authorization") ?? "", `Bearer ${secret}`)
  )
    throw new HttpError(401, "Accès refusé.");
  const [payouts,payments] = await Promise.all([db.withdrawal.findMany({where:{provider:"PLISIO",providerTransferId:{not:null},status:{in:["PROCESSING","SENT"]}},take:3,orderBy:{updatedAt:"asc"}}),db.payment.findMany({where:{provider:"PLISIO",status:"WAITING",providerPaymentId:{not:null}},take:3,orderBy:{updatedAt:"asc"}})]);
  const reconciliation = Promise.allSettled([...payouts.map(async item=>{try{return await reconcilePlisioPayout(item.id);}finally{await db.withdrawal.updateMany({where:{id:item.id,status:{in:["PROCESSING","SENT"]}},data:{updatedAt:new Date()}});}}),...payments.map(async item=>{try{return await reconcilePayment(item.id);}finally{await db.payment.updateMany({where:{id:item.id,status:"WAITING"},data:{updatedAt:new Date()}});}})]);
  const [telegram, whatsapp] = await Promise.all([
    processNotifications(),
    (async () => { const jobs = await processWhatsAppJobs(); const outbox = await processWhatsAppOutbox(); return { jobs, outbox }; })(),
    reconciliation,
  ]);
  return Response.json({ ...telegram, whatsapp }, { headers: { "cache-control": "no-store" } });
});
