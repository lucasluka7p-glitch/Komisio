import { z } from "zod";
import { requireUser, sessionCookie } from "@/lib/server/auth";
import { publicUserSelect } from "@/lib/server/clients";
import { serializable } from "@/lib/server/db";
import { hashPassword, verifyPassword } from "@/lib/server/passwords";
import { limitLogin, clearLoginLimit } from "@/lib/server/login";
import { handle, body, HttpError } from "@/lib/server/http";
export const runtime = "nodejs";
export const POST = handle(async (request: Request) => {
  const current = await requireUser(request, false, true);
  const input = z.object({ currentPassword: z.string().min(1).max(256), password: z.string().min(12).max(128) }).strict().parse(await body(request));
  await limitLogin(`change:${current.id}`);
  if (!await verifyPassword(input.currentPassword, current.passwordHash) || input.currentPassword === input.password) throw new HttpError(400, "Vérifiez le mot de passe actuel et choisissez un nouveau mot de passe différent (12 caractères minimum).");
  const passwordHash = await hashPassword(input.password);
  const user = await serializable(async tx => {
    const changed = await tx.user.updateMany({ where: { id: current.id, credentialVersion: current.credentialVersion, disabled: false, accessReady: true }, data: { passwordHash, mustChangePassword: false, credentialVersion: { increment: 1 } } });
    if (!changed.count) throw new HttpError(409, "L’accès a changé. Reconnectez-vous.");
    await tx.auditLog.create({ data: { actorId: current.id, action: "CLIENT_PASSWORD_CHANGED", targetId: current.id, details: {} } });
    return tx.user.findUniqueOrThrow({ where: { id: current.id }, select: { ...publicUserSelect, credentialVersion: true } });
  });
  await clearLoginLimit(`change:${current.id}`);
  return Response.json({ user: { ...user, credentialVersion: undefined } }, { headers: { "set-cookie": sessionCookie(user.id, user.credentialVersion), "cache-control": "no-store" } });
});
