import { z } from "zod";
import { assertSameOrigin, adminTelegramIds, sessionCookie, validateTelegramInitData } from "@/lib/server/auth";
import { clientLogin } from "@/lib/server/client-validation";
import { publicUserSelect } from "@/lib/server/clients";
import { db, serializable } from "@/lib/server/db";
import { verifyPassword } from "@/lib/server/passwords";
import { limitLogin, clearLoginLimit } from "@/lib/server/login";
import { handle, body, HttpError } from "@/lib/server/http";
export const runtime = "nodejs";
export const POST = handle(async (request: Request) => {
  assertSameOrigin(request);
  const input = z.object({ login: clientLogin, password: z.string().min(1).max(256), initData: z.string().max(16384).optional() }).strict().parse(await body(request));
  await limitLogin(input.login);
  const account = await db.user.findUnique({ where: { login: input.login } });
  const valid = await verifyPassword(input.password, account?.passwordHash ?? null);
  if (!valid || !account || !account.accessReady || account.disabled || account.role === "ADMIN" || (account.telegramId && adminTelegramIds().includes(account.telegramId))) throw new HttpError(401, "Identifiant ou mot de passe incorrect, ou accès indisponible.");
  const identity = input.initData ? validateTelegramInitData(input.initData, process.env.TELEGRAM_BOT_TOKEN ?? "") : null;
  if (identity && adminTelegramIds().includes(String(identity.id))) throw new HttpError(409, "Utilisez votre accès administrateur Telegram.");
  const user = await serializable(async tx => {
    const current = await tx.user.findUniqueOrThrow({ where: { id: account.id } });
    if (current.credentialVersion !== account.credentialVersion || current.passwordHash !== account.passwordHash || current.disabled || !current.accessReady) throw new HttpError(401, "L’accès a changé. Reconnectez-vous.");
    if (identity) {
      const telegramId = String(identity.id);
      if (current.telegramId && current.telegramId !== telegramId) throw new HttpError(409, "Ce compte est associé à un autre compte Telegram.");
      const linked = await tx.user.findUnique({ where: { telegramId } });
      if (linked && linked.id !== account.id) throw new HttpError(409, "Ce compte Telegram possède déjà un accès. Contactez l’administrateur.");
      await tx.user.update({ where: { id: account.id }, data: { telegramId, username: identity.username ?? null } });
    }
    return tx.user.findUniqueOrThrow({ where: { id: account.id }, select: publicUserSelect });
  });
  await clearLoginLimit(input.login);
  return Response.json({ user }, { headers: { "set-cookie": sessionCookie(user.id, account.credentialVersion), "cache-control": "no-store" } });
});
