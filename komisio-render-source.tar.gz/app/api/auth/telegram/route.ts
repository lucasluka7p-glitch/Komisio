import { z } from "zod";
import {
  adminTelegramIds,
  assertSameOrigin,
  sessionCookie,
  validateTelegramInitData,
} from "@/lib/server/auth";
import { publicUserSelect } from "@/lib/server/clients";
import { db } from "@/lib/server/db";
import { body, handle, HttpError } from "@/lib/server/http";

export const runtime = "nodejs";
export const POST = handle(async (request: Request) => {
  assertSameOrigin(request);
  const { initData } = z
    .object({ initData: z.string().min(1).max(16_384) })
    .parse(await body(request));
  const identity = validateTelegramInitData(
    initData,
    process.env.TELEGRAM_BOT_TOKEN ?? "",
  );
  const telegramId = String(identity.id);
  const role = adminTelegramIds().includes(telegramId) ? "ADMIN" : "RESELLER";
  const existing = await db.user.findUnique({ where: { telegramId } });
  if (!existing && role !== "ADMIN") throw new HttpError(403, "Votre accès doit être créé par l’administrateur. Connectez-vous avec les identifiants reçus.");
  if (existing && (existing.disabled || !existing.accessReady)) throw new HttpError(403, "Compte indisponible. Contactez votre administrateur.");
  const user = await db.user.upsert({
    where: { telegramId },
    update: {
      ...(!existing?.login ? { firstName: identity.first_name } : {}),
      username: identity.username ?? null,
      role,
    },
    create: {
      telegramId,
      firstName: identity.first_name,
      username: identity.username ?? null,
      role,
    },
  });
  if (user.disabled)
    return Response.json({ error: "Compte suspendu." }, { status: 403 });
  return Response.json(
    {
      user: await db.user.findUniqueOrThrow({ where: { id: user.id }, select: publicUserSelect }),
    },
    {
      headers: {
        "set-cookie": sessionCookie(user.id, user.credentialVersion),
        "cache-control": "no-store",
      },
    },
  );
});
