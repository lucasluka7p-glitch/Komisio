import { requireUser } from "@/lib/server/auth";
import { db } from "@/lib/server/db";
import { handle, HttpError, json } from "@/lib/server/http";
import { reconcilePayment } from "@/lib/server/payments";
export const GET = handle(
  async (request: Request, context: { params: Promise<{ id: string }> }) => {
    const user = await requireUser(request);
    const { id } = await context.params;
    const payment = await db.payment.findFirst({
      where: { id, ...(user.role !== "ADMIN" ? { userId: user.id } : {}) },
    });
    if (!payment) throw new HttpError(404, "Paiement introuvable");
    // Polling performs authoritative provider verification, never browser-led settlement.
    return json(await reconcilePayment(payment.id));
  },
);
