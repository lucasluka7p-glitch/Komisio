import { z } from "zod";
import { requireUser } from "@/lib/server/auth";
import { body, handle, json } from "@/lib/server/http";
import { createPayment } from "@/lib/server/payments";
import { currencies, idempotency } from "@/lib/server/validation";
const input = z.object({
  amountCents: z.number().int().min(100).max(10_000_000),
  payCurrency: z.enum(currencies),
  idempotencyKey: idempotency,
  orderId: z.string().max(100).optional(),
});
export const POST = handle(async (request: Request) => {
  const user = await requireUser(request);
  const values = input.parse(await body(request));
  return json(await createPayment({ ...values, userId: user.id }), 201);
});
