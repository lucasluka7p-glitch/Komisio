import { requireUser } from "@/lib/server/auth";
import { publicUserSelect } from "@/lib/server/clients";
import { db } from "@/lib/server/db";
import { handle, json } from "@/lib/server/http";
export const GET = handle(async (request: Request) => {
  const current = await requireUser(request, false, true);
  const user = await db.user.findUniqueOrThrow({ where: { id: current.id }, select: publicUserSelect });
  const [ledger, orders] = await Promise.all([
    db.ledgerEntry.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: "desc" },
      take: 100,
    }),
    db.order.groupBy({
      by: ["status"],
      where: { userId: user.id },
      _count: true,
    }),
  ]);
  return json({ user: { ...user, role: current.role }, ledger, orders });
});
