import { z } from 'zod';
import { requireUser } from '@/lib/server/auth';
import { body, handle, json } from '@/lib/server/http';
import { linkProviderPayment } from '@/lib/server/payments';
export const POST=handle(async(request:Request,context:{params:Promise<{id:string}>})=>{
  const admin=await requireUser(request,true);
  const input=z.object({providerPaymentId:z.string().trim().min(1).max(100)}).strict().parse(await body(request));
  return json(await linkProviderPayment((await context.params).id,input.providerPaymentId,admin.id));
});
