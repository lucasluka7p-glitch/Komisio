import { requireUser } from "@/lib/server/auth";
import { db } from "@/lib/server/db";
import { handle, json } from "@/lib/server/http";
export const GET = handle(async (request: Request) => {
  await requireUser(request, true);
  return json(
    await db.payment.findMany({
      take: 500,
      orderBy: { createdAt: "desc" },
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            username: true,
            telegramId: true,
          },
        },
      },
    }),
  );
});
