import { queueCustomerNotification } from "@/lib/server/customer-notifications";
import { publicUserSelect } from "@/lib/server/clients";
import { z } from "zod";
import { requireUser } from "@/lib/server/auth";
import { serializable } from "@/lib/server/db";
import { body, handle, HttpError, json } from "@/lib/server/http";
import { idempotency } from "@/lib/server/validation";
const schema = z.object({
  amountCents: z
    .number()
    .int()
    .min(-1_000_000)
    .max(1_000_000)
    .refine((n) => n !== 0),
  reason: z.string().trim().min(3).max(500),
  idempotencyKey: idempotency,
});
export const POST = handle(
  async (request: Request, context: { params: Promise<{ id: string }> }) => {
    const admin = await requireUser(request, true);
    const { id } = await context.params;
    const input = schema.parse(await body(request));
    return json(
      await serializable(async (tx) => {
        const reference = `adjustment:${admin.id}:${id}:${input.idempotencyKey}`;
        const previous = await tx.ledgerEntry.findUnique({
          where: { reference },
        });
        if (previous)
          return {
            user: await tx.user.findUniqueOrThrow({ where: { id }, select: publicUserSelect }),
            entry: previous,
          };
        const exists = await tx.user.findUnique({ where: { id } });
        if (!exists) throw new HttpError(404, "Revendeur introuvable");
        const changed = await tx.user.updateMany({
          where: {
            id,
            ...(input.amountCents < 0
              ? { balanceCents: { gte: -input.amountCents } }
              : { balanceCents: { lte: 2_000_000_000 - input.amountCents } }),
          },
          data: { balanceCents: { increment: input.amountCents } },
        });
        if (!changed.count)
          throw new HttpError(
            409,
            "Solde insuffisant ou plafond de portefeuille atteint.",
          );
        const user = await tx.user.findUniqueOrThrow({ where: { id }, select: publicUserSelect });
        const entry = await tx.ledgerEntry.create({
          data: {
            userId: id,
            amountCents: input.amountCents,
            balanceAfter: user.balanceCents,
            kind: "ADMIN_ADJUSTMENT",
            reason: input.reason,
            actorId: admin.id,
            reference,
          },
        });
        await tx.auditLog.create({
          data: {
            actorId: admin.id,
            action: "BALANCE_ADJUSTMENT",
            targetId: id,
            details: { ...input, balanceAfter: user.balanceCents },
          },
        });
        await queueCustomerNotification(
          tx,
          user,
          `💳 Votre portefeuille a été ajusté de ${(input.amountCents / 100).toFixed(2)} €. Motif : ${input.reason}`,
        );
        return { user, entry };
      }),
    );
  },
);
