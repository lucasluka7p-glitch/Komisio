import { requireUser } from "@/lib/server/auth";
import { updateClient } from "@/lib/server/clients";
import { updateClientInput } from "@/lib/server/client-validation";
import { handle, body, json } from "@/lib/server/http";
export const PATCH = handle(async (request: Request, context: { params: Promise<{ id: string }> }) => {
  const admin = await requireUser(request, true);
  const { id } = await context.params;
  return json(await updateClient(id, admin.id, updateClientInput.parse(await body(request))));
});
