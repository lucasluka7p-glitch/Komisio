import { z } from "zod";
import { requireUser } from "@/lib/server/auth";
import { clientAccessAction } from "@/lib/server/clients";
import { handle, body, json } from "@/lib/server/http";
export const POST = handle(async (request: Request, context: { params: Promise<{ id: string }> }) => {
  const admin = await requireUser(request, true);
  const { id } = await context.params;
  const input = z.object({ action: z.enum(["activate", "reset", "suspend", "resume"]), expectedVersion: z.number().int().min(0) }).strict().parse(await body(request));
  return json(await clientAccessAction(id, admin.id, input.action, input.expectedVersion));
});
