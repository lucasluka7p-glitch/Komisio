import { requireUser } from "@/lib/server/auth";
import { createClient, listClients } from "@/lib/server/clients";
import { createClientInput } from "@/lib/server/client-validation";
import { handle, json, body } from "@/lib/server/http";
export const runtime = "nodejs";
export const GET = handle(async (request: Request) => {
  await requireUser(request, true);
  return json(await listClients());
});
export const POST = handle(async (request: Request) => {
  const admin = await requireUser(request, true);
  return json(await createClient(admin.id, createClientInput.parse(await body(request))), 201);
});
