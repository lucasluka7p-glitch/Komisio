import { requireUser } from "@/lib/server/auth";
import { body, handle, json } from "@/lib/server/http";
import { originalDocumentInput, updateOriginalDocument } from "@/lib/server/original-documents";
export const POST = handle(async (request: Request, context: { params: Promise<{ id: string }> }) => {
  const admin = await requireUser(request, true);
  return json(await updateOriginalDocument((await context.params).id, admin.id, originalDocumentInput.parse(await body(request))));
});
