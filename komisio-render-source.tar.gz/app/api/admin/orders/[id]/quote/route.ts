import { requireUser } from "@/lib/server/auth";
import { body, handle, json } from "@/lib/server/http";
import { proposalInput, proposeOrderQuote } from "@/lib/server/order-quotes";
export const POST = handle(async (request: Request, context: { params: Promise<{ id: string }> }) => {
  const admin = await requireUser(request, true);
  return json(await proposeOrderQuote((await context.params).id, admin.id, proposalInput.parse(await body(request))));
});
