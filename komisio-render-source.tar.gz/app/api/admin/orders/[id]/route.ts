import { queueCustomerNotification } from "@/lib/server/customer-notifications";
import { z } from "zod";
import { assertOriginalDocumentReturned } from "@/lib/original-document";
import { OrderStatus } from "@prisma/client";
import { requireUser } from "@/lib/server/auth";
import { serializable } from "@/lib/server/db";
import { body, handle, HttpError, json } from "@/lib/server/http";
import { orderInclude } from "@/lib/server/orders";
const transitions: Record<OrderStatus, OrderStatus[]> = {
  AWAITING_QUOTE: ["AWAITING_QUOTE", "CANCELLED"],
  QUOTE_PROPOSED: ["QUOTE_PROPOSED", "CANCELLED"],
  QUOTE_REJECTED: [],
  AWAITING_PAYMENT: ["AWAITING_PAYMENT", "CANCELLED"],
  PROCESSING: ["PROCESSING", "ACTION_REQUIRED", "COMPLETED", "CANCELLED"],
  ACTION_REQUIRED: ["ACTION_REQUIRED", "PROCESSING", "COMPLETED", "CANCELLED"],
  COMPLETED: [],
  CANCELLED: [],
};
const labels: Record<OrderStatus, string> = {
  AWAITING_QUOTE: "En attente de devis",
  QUOTE_PROPOSED: "Devis à valider",
  QUOTE_REJECTED: "Devis refusé",
  AWAITING_PAYMENT: "En attente de paiement",
  PROCESSING: "En cours de traitement",
  ACTION_REQUIRED: "Action requise",
  COMPLETED: "Terminé",
  CANCELLED: "Annulé",
};
const inputSchema = z.object({
  status: z.nativeEnum(OrderStatus),
  note: z.string().trim().max(4000).optional(),
  deliverableId: z.string().max(100).optional(),
});
export const PATCH = handle(
  async (request: Request, context: { params: Promise<{ id: string }> }) => {
    const admin = await requireUser(request, true);
    const { id } = await context.params;
    const input = inputSchema.parse(await body(request));
    return json(
      await serializable(async (tx) => {
        const order = await tx.order.findUnique({
          where: { id },
          include: { user: true, documents: true, originalDocument: true },
        });
        if (!order) throw new HttpError(404, "Dossier introuvable");
        if (!transitions[order.status].includes(input.status))
          throw new HttpError(409, "Transition de statut refusée.");
        if (input.status === "ACTION_REQUIRED" && !input.note)
          throw new HttpError(
            400,
            "Précisez le document ou l’action attendue.",
          );
        if (input.deliverableId) {
          const deliverable = await tx.document.findFirst({
            where: {
              id: input.deliverableId,
              orderId: id,
              kind: "DELIVERABLE",
            },
          });
          if (!deliverable)
            throw new HttpError(400, "Livrable introuvable pour ce dossier.");
        }
        if (input.status === "COMPLETED") {
          try { assertOriginalDocumentReturned(order.originalDocument); } catch (error) { throw new HttpError(409, (error as Error).message); }
        }
        if (
          input.status === "COMPLETED" && !order.originalDocument &&
          !order.documents.some((document) => document.kind === "DELIVERABLE")
        )
          throw new HttpError(
            400,
            "Ajoutez le livrable avant de terminer le dossier.",
          );
        if (input.status === "CANCELLED" && order.paidAt) {
          const refund = await tx.user.update({
            where: { id: order.userId },
            data: { balanceCents: { increment: order.priceCents } },
          });
          await tx.ledgerEntry.create({
            data: {
              userId: order.userId,
              orderId: id,
              amountCents: order.priceCents,
              balanceAfter: refund.balanceCents,
              kind: "REFUND",
              reference: `refund-order:${id}`,
              actorId: admin.id,
              reason: `Annulation du dossier #${order.number} : crédit au portefeuille`,
            },
          });
        }
        const updated = await tx.order.update({
          where: { id },
          data: {
            status: input.status,
            events: {
              create: {
                status: input.status,
                note: input.note || null,
                actorId: admin.id,
              },
            },
          },
          include: orderInclude,
        });
        await tx.auditLog.create({
          data: {
            actorId: admin.id,
            action: "ORDER_UPDATE",
            targetId: id,
            details: { previousStatus: order.status, ...input },
          },
        });
        await queueCustomerNotification(
          tx,
          order.user,
          `🔔 Votre dossier #${order.number} (${order.serviceName}) est passé au statut : ${labels[input.status]}.${input.note ? `\n${input.note}` : ""}\nConsultez vos documents dans la Mini App.${input.status === "CANCELLED" && order.paidAt ? "\nLe montant a été recrédité sur votre portefeuille." : ""}`,
          input.status === "COMPLETED" ? input.deliverableId || order.documents.filter(doc => doc.kind === "DELIVERABLE").sort((a,b) => b.createdAt.getTime() - a.createdAt.getTime())[0]?.id : undefined
        );
        return updated;
      }),
    );
  },
);
