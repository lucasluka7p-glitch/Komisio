import { requireUser } from "@/lib/server/auth";
import { db } from "@/lib/server/db";
import { handle, json } from "@/lib/server/http";
import { orderInclude } from "@/lib/server/orders";
export const GET = handle(async (request: Request) => {
  await requireUser(request, true);
  return json(
    await db.order.findMany({
      orderBy: { createdAt: "desc" },
      take: 500,
      include: {
        ...orderInclude,
        user: {
          select: {
            id: true,
            firstName: true,
            username: true,
            telegramId: true,
          },
        },
      },
    }),
  );
});
