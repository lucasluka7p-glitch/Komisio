import { configureTelegramBot } from '@/lib/server/telegram-setup';
import { z } from 'zod';
import { requireUser } from '@/lib/server/auth';
import { configurationIssues } from '@/lib/server/configuration';
import { db, serializable } from '@/lib/server/db';
import { body, handle, json } from '@/lib/server/http';
export const GET=handle(async(request:Request)=>{
  await requireUser(request,true);
  const [pending,failed,invoices]=await Promise.all([
    db.notificationOutbox.count({where:{sentAt:null,attempts:{lt:10}}}),
    db.notificationOutbox.count({where:{sentAt:null,attempts:{gte:10}}}),
    db.payment.findMany({where:{status:'CREATING'},select:{id:true,amountCents:true,payCurrency:true,createdAt:true},orderBy:{createdAt:'asc'},take:50}),
  ]);
  return json({configurationIssues:configurationIssues(),notifications:{pending,failed},invoices,withdrawalsEnabled:process.env.WITHDRAWALS_ENABLED==='true'});
});
export const POST=handle(async(request:Request)=>{
  const admin=await requireUser(request,true);
  const input=z.object({action:z.enum(['retry_notifications','configure_telegram'])}).strict().parse(await body(request));
  if(input.action==='configure_telegram'){const configured=await configureTelegramBot();await db.auditLog.create({data:{actorId:admin.id,action:'TELEGRAM_BOT_CONFIGURED',targetId:'telegram_bot',details:configured}});return json(configured);}
  const count=await serializable(async tx=>{
    const retried=await tx.notificationOutbox.updateMany({where:{sentAt:null,attempts:{gte:10},lockedAt:null},data:{attempts:0,nextAttemptAt:new Date()}});
    await tx.auditLog.create({data:{actorId:admin.id,action:'NOTIFICATIONS_RETRIED',targetId:'notification-outbox',details:{count:retried.count}}});
    return retried.count;
  });
  return json({retried:count});
});
