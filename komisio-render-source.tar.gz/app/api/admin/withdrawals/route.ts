import { requireUser } from "@/lib/server/auth";
import { handle, json } from "@/lib/server/http";
import { listWithdrawals } from "@/lib/server/withdrawals";
export const GET = handle(async (request: Request) => {
  await requireUser(request, true);
  return json({ withdrawals: await listWithdrawals(), plisioEnabled: process.env.PLISIO_PAYOUTS_ENABLED === "true" });
});
