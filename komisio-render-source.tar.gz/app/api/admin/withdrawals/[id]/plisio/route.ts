import { z } from 'zod';
import { requireUser } from '@/lib/server/auth';
import { body,handle,json } from '@/lib/server/http';
import { quotePlisioPayout,sendPlisioPayout,reconcilePlisioPayout,linkPlisioPayout } from '@/lib/server/plisio-payouts';
const input=z.discriminatedUnion('action',[z.object({action:z.literal('quote')}).strict(),z.object({action:z.literal('send')}).strict(),z.object({action:z.literal('reconcile')}).strict(),z.object({action:z.literal('link'),operationId:z.string().min(1).max(100)}).strict()]);
export const POST=handle(async(request:Request,context:{params:Promise<{id:string}>})=>{
 const admin=await requireUser(request,true);const id=(await context.params).id;const action=input.parse(await body(request));
 return json(action.action==='quote'?await quotePlisioPayout(id,admin.id):action.action==='send'?await sendPlisioPayout(id,admin.id):action.action==='link'?await linkPlisioPayout(id,action.operationId,admin.id):await reconcilePlisioPayout(id,admin.id));
});
