import { requireUser } from "@/lib/server/auth";
import { body, handle, json } from "@/lib/server/http";
import { actOnWithdrawal } from "@/lib/server/withdrawals";
import { adminWithdrawalAction } from "@/lib/server/withdrawal-validation";
export const POST = handle(async (request: Request, context: { params: Promise<{ id: string }> }) => {
  const user = await requireUser(request, true);
  return json(await actOnWithdrawal((await context.params).id, user.id, true, adminWithdrawalAction.parse(await body(request))));
});
