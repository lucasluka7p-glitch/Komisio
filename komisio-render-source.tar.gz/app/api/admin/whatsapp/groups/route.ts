import { requireUser } from "@/lib/server/auth";
import { handle, json, HttpError } from "@/lib/server/http";
export const GET = handle(async (request: Request) => {
  await requireUser(request, true);
  const secret = process.env.WHATSAPP_BRIDGE_SECRET || "";
  if (process.env.WHATSAPP_ENABLED !== "true" || process.env.WHATSAPP_TRANSPORT === "CLOUD" || secret.length < 32 || !process.env.WHATSAPP_BRIDGE_URL) throw new HttpError(503, "Connectez d’abord le numéro WhatsApp Web.");
  try {
    const endpoint = new URL(process.env.WHATSAPP_BRIDGE_URL); endpoint.pathname = "/groups";
    const response = await fetch(endpoint, { headers: { authorization: `Bearer ${secret}` }, cache: "no-store", redirect: "error", signal: AbortSignal.timeout(12000) });
    if (!response.ok) throw new Error(); const text = await response.text(); if (text.length > 100000) throw new Error(); const value = JSON.parse(text);
    return json({ groups: (Array.isArray(value.groups) ? value.groups : []).slice(0, 200).filter((group: any) => typeof group.id === "string" && /^\d{5,25}(?:-\d{5,25})?@g\.us$/.test(group.id)).map((group: any) => ({ id: group.id, name: String(group.name || "Groupe").slice(0, 120) })) });
  } catch { throw new HttpError(503, "Impossible de lire les groupes. Vérifiez la connexion du numéro."); }
});
