import { z } from "zod";
import { requireUser, adminTelegramIds } from "@/lib/server/auth";
import { db, serializable } from "@/lib/server/db";
import { handle, json, body, HttpError } from "@/lib/server/http";
import { whatsappConfigured, whatsappTransport } from "@/lib/server/whatsapp-transport";
import { documentOcrAvailability } from "@/lib/server/document-ocr";
export const GET = handle(async (request: Request) => {
  await requireUser(request, true);
  const [bindings, drafts, jobs, outbox, ocr] = await Promise.all([
    db.whatsAppBinding.findMany({ take: 500, include: { user: { select: { firstName: true, login: true } } } }),
    db.whatsAppDraft.findMany({ orderBy: { updatedAt: "desc" }, take: 100, select: { id: true, userId: true, serviceId: true, status: true, version: true, orderId: true } }),
    db.whatsAppInbound.findMany({ where: { status: { not: "DONE" } }, orderBy: { createdAt: "desc" }, take: 50, select: { id: true, status: true, attempts: true, error: true } }),
    db.whatsAppOutbox.findMany({ where: { status: { not: "SENT" } }, orderBy: { createdAt: "desc" }, take: 50, select: { id: true, status: true, attempts: true, error: true } }), documentOcrAvailability(),
  ]);
  return json({ configured: whatsappConfigured(), transport: whatsappTransport(), groupsEnabled: whatsappTransport() === "WEB" || process.env.WHATSAPP_GROUPS_ENABLED === "true", bindings, drafts, jobs, outbox, ocr });
});
export const POST = handle(async (request: Request) => {
  const admin = await requireUser(request, true);
  const input = z.discriminatedUnion("action", [z.object({ action: z.literal("bind"), userId: z.string().min(1).max(100), phone: z.string().regex(/^[1-9]\d{6,14}$/), groupId: z.string().max(200).optional() }).strict(), z.object({ action: z.literal("disable_binding"), id: z.string().min(1).max(100) }).strict()]).parse(await body(request));
  return json(await serializable(async tx => {
    if (input.action === "disable_binding") {
      const binding = await tx.whatsAppBinding.findUnique({ where: { id: input.id } }); if (!binding) throw new HttpError(404, "Rattachement introuvable.");
      await tx.whatsAppBinding.update({ where: { id: input.id }, data: { active: false } });
      await tx.auditLog.create({ data: { actorId: admin.id, action: "WHATSAPP_UNLINKED", targetId: input.id, details: {} } }); return { disabled: true };
    }
    const user = await tx.user.findUnique({ where: { id: input.userId } });
    if (!user || !user.accessReady || user.disabled || user.pricingVersion < 1 || user.role === "ADMIN" || (user.telegramId && adminTelegramIds().includes(user.telegramId))) throw new HttpError(400, "Créez et activez d’abord le compte client et sa grille.");
    const groupId = input.groupId || null, conversation = groupId || input.phone;
    if (groupId && (whatsappTransport() === "WEB" ? !/^\d{5,25}(?:-\d{5,25})?@g\.us$/.test(groupId) : process.env.WHATSAPP_GROUPS_ENABLED !== "true" || !/^[a-zA-Z0-9_-]+$/.test(groupId))) throw new HttpError(400, "Identifiant du groupe invalide ou groupes non activés.");
    const conflict = await tx.whatsAppBinding.findFirst({ where: { OR: [{ phone: input.phone, conversation }, ...(groupId ? [{ groupId }] : [])], userId: { not: user.id } } });
    if (conflict) throw new HttpError(409, "Ce numéro ou groupe est déjà rattaché à un autre compte. Aucune réaffectation automatique.");
    const binding = await tx.whatsAppBinding.upsert({ where: { phone_conversation: { phone: input.phone, conversation } }, create: { userId: user.id, phone: input.phone, conversation, groupId }, update: { active: true } });
    await tx.auditLog.create({ data: { actorId: admin.id, action: "WHATSAPP_LINKED", targetId: binding.id, details: { userId: user.id, phone: input.phone, groupId, independentAccess: true } } }); return { binding };
  }));
});
