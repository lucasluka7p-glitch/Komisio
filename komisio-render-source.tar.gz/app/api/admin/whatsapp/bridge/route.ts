import { requireUser } from "@/lib/server/auth";
import { handle, json } from "@/lib/server/http";
export const runtime = "nodejs";
export const GET = handle(async (request: Request) => {
  await requireUser(request, true);
  const transport = process.env.WHATSAPP_TRANSPORT === "CLOUD" ? "CLOUD" : "WEB";
  if (transport === "CLOUD") return json({ transport, configured: !!process.env.WHATSAPP_ACCESS_TOKEN, connected: false, status: "cloud_configured_separately" });
  const secret = process.env.WHATSAPP_BRIDGE_SECRET || "";
  const endpoint = process.env.WHATSAPP_BRIDGE_URL;
  if (!endpoint || secret.length < 32 || process.env.WHATSAPP_ENABLED !== "true") return json({ transport, configured: false, connected: false, status: "not_configured" });
  try {
    const url = new URL(endpoint);
    if (!["http:", "https:"].includes(url.protocol) || url.username || url.password || url.search || url.hash) throw new Error();
    url.pathname = url.pathname.replace(/\/$/, "") + "/status";
    const response = await fetch(url, { headers: { authorization: `Bearer ${secret}` }, cache: "no-store", redirect: "error", signal: AbortSignal.timeout(7000) });
    if (!response.ok || Number(response.headers.get("content-length") || 0) > 16384) throw new Error();
    const raw = await response.text(); if (raw.length > 16384) throw new Error();
    const data = JSON.parse(raw);
    // QR is a short-lived login secret. It is relayed only to an authenticated admin,
    // never persisted, logged, exposed by public config, or served with cache headers.
    return json({ transport, configured: true, connected: data.connected === true, status: String(data.status || "unknown").slice(0, 80), ...(data.connected !== true && typeof data.qr === "string" && data.qr.length <= 4096 ? { qr: data.qr } : {}) });
  } catch { return json({ transport, configured: true, connected: false, status: "unreachable", error: "Connecteur indisponible. Vérifiez qu’il est démarré et accessible au serveur." }); }
});
