import { requireUser } from "@/lib/server/auth";
import { db, serializable } from "@/lib/server/db";
import { body, handle, json } from "@/lib/server/http";
import { serviceInput } from "@/lib/server/validation";
export const GET = handle(async (request: Request) => {
  await requireUser(request, true);
  return json(
    await db.service.findMany({
      orderBy: [{ category: "asc" }, { name: "asc" }],
    }),
  );
});
export const POST = handle(async (request: Request) => {
  const admin = await requireUser(request, true);
  const input = serviceInput.parse(await body(request));
  return json(
    await serializable(async (tx) => {
      const service = await tx.service.create({ data: input });
      await tx.auditLog.create({
        data: {
          actorId: admin.id,
          action: "SERVICE_CREATE",
          targetId: service.id,
          details: input,
        },
      });
      return service;
    }),
    201,
  );
});
