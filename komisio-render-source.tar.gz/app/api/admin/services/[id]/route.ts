import { requireUser } from "@/lib/server/auth";
import { serializable } from "@/lib/server/db";
import { body, handle, HttpError, json } from "@/lib/server/http";
import { serviceInput } from "@/lib/server/validation";
export const PATCH = handle(
  async (request: Request, context: { params: Promise<{ id: string }> }) => {
    const admin = await requireUser(request, true);
    const { id } = await context.params;
    const patch = await body(request);
    return json(
      await serializable(async (tx) => {
        const old = await tx.service.findUnique({ where: { id } });
        if (!old) throw new HttpError(404, "Service introuvable");
        const input = serviceInput.parse({ ...old, ...patch });
        const service = await tx.service.update({ where: { id }, data: input });
        await tx.auditLog.create({
          data: {
            actorId: admin.id,
            action: "SERVICE_UPDATE",
            targetId: id,
            details: input,
          },
        });
        return service;
      }),
    );
  },
);
