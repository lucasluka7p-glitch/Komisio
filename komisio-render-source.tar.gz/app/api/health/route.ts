import { configurationIssues } from '@/lib/server/configuration';
import { db } from '@/lib/server/db';
import { storeFile, removeFile } from '@/lib/server/storage';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export async function GET() {
  let ready = configurationIssues().length === 0;
  try {
    await db.$queryRaw`SELECT 1`;
    const probe = await storeFile(new Uint8Array([0]));
    await removeFile(probe);
  } catch { ready = false; }
  // Public health reports no secret values, paths, database errors or customer data.
  return Response.json({ status: ready ? 'ok' : 'not_ready' }, { status: ready ? 200 : 503, headers: { 'Cache-Control': 'no-store' } });
}
