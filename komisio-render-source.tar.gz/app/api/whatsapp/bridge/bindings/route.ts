import { db } from "@/lib/server/db";
import { safeEqual } from "@/lib/server/auth";
import { handle, HttpError, json } from "@/lib/server/http";
export const runtime = "nodejs";
/** Private bridge preflight: do not download documents from unrelated phone conversations. */
export const GET = handle(async (request: Request) => {
  const secret = process.env.WHATSAPP_BRIDGE_SECRET || "";
  if (process.env.WHATSAPP_ENABLED !== "true" || process.env.WHATSAPP_TRANSPORT === "CLOUD" || secret.length < 32) throw new HttpError(503, "Connecteur désactivé.");
  if (!safeEqual(request.headers.get("authorization") || "", `Bearer ${secret}`)) throw new HttpError(401, "Accès refusé.");
  const bindings = await db.whatsAppBinding.findMany({ where: { active: true, user: { disabled: false, accessReady: true, pricingVersion: { gte: 1 } } }, select: { phone: true, groupId: true }, take: 1000 });
  return json({ bindings });
});
