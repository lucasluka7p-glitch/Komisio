import { z } from "zod";
import { handle, json, HttpError } from "@/lib/server/http";
import { whatsappRawBody, validWhatsAppSignature, whatsappConfigured, whatsappTransport } from "@/lib/server/whatsapp-transport";
import { enqueueWhatsAppMessage } from "@/lib/server/whatsapp";
const input = z.object({ id: z.string().min(1).max(450), sender: z.string().regex(/^[1-9]\d{6,14}$/), groupId: z.string().regex(/^\d{5,25}(?:-\d{5,25})?@g\.us$/).nullable(), timestamp: z.number().int(), type: z.enum(["text", "image", "document", "video"]), text: z.string().max(4000).optional(), media: z.object({ base64: z.string().max(14_000_000), filename: z.string().max(200), mimeType: z.string().max(100) }).strict().optional() }).strict();
export const runtime = "nodejs";
export const POST = handle(async (request: Request) => {
  if (!whatsappConfigured() || whatsappTransport() !== "WEB") throw new HttpError(503, "Connecteur désactivé.");
  const raw = await whatsappRawBody(request, 14 * 1024 * 1024 + 65536);
  if (!validWhatsAppSignature(raw, request.headers.get("x-komisio-signature") || "", process.env.WHATSAPP_BRIDGE_SECRET || "")) throw new HttpError(401, "Signature invalide.");
  const value = input.parse(JSON.parse(raw.toString("utf8")));
  let media;
  if (value.media) {
    const bytes = Buffer.from(value.media.base64, "base64");
    if (!bytes.length || bytes.length > 10 * 1024 * 1024 || bytes.toString("base64") !== value.media.base64) throw new HttpError(400, "Pièce invalide.");
    media = { bytes, fileName: value.media.filename, mimeType: value.media.mimeType };
  }
  if ((value.type !== "text") !== !!media) throw new HttpError(400, "Message incomplet.");
  return json(await enqueueWhatsAppMessage({ id: value.id.startsWith("web:") ? value.id : `web:${value.id}`, sender: value.sender, groupId: value.groupId, timestamp: value.timestamp, type: value.type, text: value.text, fileName: media?.fileName }, media));
});
