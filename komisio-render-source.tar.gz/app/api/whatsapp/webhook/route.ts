import { safeEqual } from "@/lib/server/auth";
import { handle, HttpError, json } from "@/lib/server/http";
import { whatsappConfigured, whatsappRawBody, validWhatsAppSignature, whatsappTransport } from "@/lib/server/whatsapp-transport";
import { enqueueWhatsAppMessage } from "@/lib/server/whatsapp";
export const runtime = "nodejs";
export const GET = handle(async (request: Request) => {
  const url = new URL(request.url), secret = process.env.WHATSAPP_VERIFY_TOKEN || "";
  if (!secret || url.searchParams.get("hub.mode") !== "subscribe" || !safeEqual(url.searchParams.get("hub.verify_token") || "", secret)) throw new HttpError(403, "Vérification refusée.");
  return new Response((url.searchParams.get("hub.challenge") || "").slice(0, 1000), { headers: { "cache-control": "no-store" } });
});
export const POST = handle(async (request: Request) => {
  if (!whatsappConfigured() || whatsappTransport() !== "CLOUD") throw new HttpError(503, "WhatsApp Cloud désactivé.");
  const raw = await whatsappRawBody(request);
  if (!validWhatsAppSignature(raw, request.headers.get("x-hub-signature-256") || "", process.env.WHATSAPP_APP_SECRET || "")) throw new HttpError(401, "Signature invalide.");
  const payload = JSON.parse(raw.toString("utf8"));
  for (const entry of (Array.isArray(payload.entry) ? payload.entry : []).slice(0, 20)) for (const change of (Array.isArray(entry.changes) ? entry.changes : []).slice(0, 20)) {
    const value = change.value;
    if (String(value?.metadata?.phone_number_id) !== process.env.WHATSAPP_PHONE_NUMBER_ID) continue;
    for (const message of (Array.isArray(value.messages) ? value.messages : []).slice(0, 50)) {
      if (!/^[1-9]\d{6,14}$/.test(message.from || "") || typeof message.id !== "string" || message.id.length > 400 || !["text", "image", "document", "video"].includes(message.type)) continue;
      const media = message[message.type];
      await enqueueWhatsAppMessage({ id: `cloud:${message.id}`, sender: message.from, groupId: typeof message.group_id === "string" ? message.group_id.slice(0, 200) : null, timestamp: Number(message.timestamp), type: message.type, text: String(message.text?.body || media?.caption || "").slice(0, 4000), mediaId: typeof media?.id === "string" ? media.id : undefined, fileName: typeof media?.filename === "string" ? media.filename.slice(0, 100) : undefined });
    }
  }
  return json({ received: true });
});
