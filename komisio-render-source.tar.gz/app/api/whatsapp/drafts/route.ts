import { requireUser } from "@/lib/server/auth";
import { db } from "@/lib/server/db";
import { whatsappDraftInclude, getWhatsAppDraft } from "@/lib/server/whatsapp-drafts";
import { handle, json } from "@/lib/server/http";
export const GET = handle(async (request: Request) => {
  const user = await requireUser(request);
  const rows = await db.whatsAppDraft.findMany({ where: user.role === "ADMIN" ? {} : { userId: user.id }, orderBy: { updatedAt: "desc" }, take: 100, select: { id: true } });
  const drafts = await Promise.all(rows.map(async row => (await getWhatsAppDraft(row.id, user.role === "ADMIN" ? undefined : user.id)).draft));
  return json({ drafts });
});
