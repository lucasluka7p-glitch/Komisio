import { requireUser } from "@/lib/server/auth";
import { db } from "@/lib/server/db";
import { handle, HttpError } from "@/lib/server/http";
import { loadFile } from "@/lib/server/storage";
export const GET = handle(async (request: Request, context: { params: Promise<{ id: string; fileId: string }> }) => {
  const user = await requireUser(request), params = await context.params;
  const file = await db.whatsAppFile.findFirst({ where: { id: params.fileId, draftId: params.id, ...(user.role === "ADMIN" ? {} : { draft: { userId: user.id } }) } });
  if (!file) throw new HttpError(404, "Pièce introuvable.");
  const data = await loadFile(file.storageKey);
  return new Response(Buffer.from(data), { headers: { "content-type": file.mimeType, "content-disposition": `attachment; filename*=UTF-8''${encodeURIComponent(file.fileName)}`, "cache-control": "no-store", "x-content-type-options": "nosniff" } });
});
