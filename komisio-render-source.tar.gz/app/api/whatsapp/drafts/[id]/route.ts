import { requireUser } from "@/lib/server/auth";
import { handle, json, body } from "@/lib/server/http";
import { draftAction, editWhatsAppDraft, getWhatsAppDraft } from "@/lib/server/whatsapp-drafts";
export const GET = handle(async (request: Request, context: { params: Promise<{ id: string }> }) => {
  const user = await requireUser(request); return json(await getWhatsAppDraft((await context.params).id, user.role === "ADMIN" ? undefined : user.id));
});
export const PATCH = handle(async (request: Request, context: { params: Promise<{ id: string }> }) => {
  const user = await requireUser(request); return json(await editWhatsAppDraft((await context.params).id, user.id, user.role === "ADMIN", draftAction.parse(await body(request))));
});
