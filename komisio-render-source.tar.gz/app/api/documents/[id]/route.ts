import { requireUser } from "@/lib/server/auth";
import { db } from "@/lib/server/db";
import { handle, HttpError } from "@/lib/server/http";
import { loadFile } from "@/lib/server/storage";
export const runtime = "nodejs";
export const GET = handle(
  async (request: Request, context: { params: Promise<{ id: string }> }) => {
    const user = await requireUser(request);
    const { id } = await context.params;
    const document = await db.document.findUnique({
      where: { id },
      include: { order: true },
    });
    if (
      !document ||
      (user.role !== "ADMIN" &&
        document.ownerId !== user.id &&
        document.order?.userId !== user.id)
    )
      throw new HttpError(404, "Document introuvable");
    const bytes = await loadFile(document.storageKey);
    return new Response(new Uint8Array(bytes), {
      headers: {
        "Content-Type": document.mimeType,
        "Content-Length": String(bytes.length),
        "Content-Disposition": `attachment; filename="document"; filename*=UTF-8''${encodeURIComponent(document.fileName)}`,
        "X-Content-Type-Options": "nosniff",
        "Cache-Control": "private, no-store",
        "Content-Security-Policy": "default-src 'none'; sandbox",
      },
    });
  },
);
