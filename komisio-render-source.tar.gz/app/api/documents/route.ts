import { z } from "zod";
import { requireUser } from "@/lib/server/auth";
import { db, serializable } from "@/lib/server/db";
import { handle, HttpError, json } from "@/lib/server/http";
import { documentSelection } from "@/lib/server/orders";
import {
  boundedFormData,
  attachmentMime,
  MAX_FILE_BYTES,
  MAX_VIDEO_BYTES,
  removeFile,
  storeFile,
} from "@/lib/server/storage";
import { queueAdmins } from "@/lib/server/telegram";
import { documentDefinition } from "@/lib/server/validation";

export const runtime = "nodejs";
export const POST = handle(async (request: Request) => {
  const user = await requireUser(request);
  const data = await boundedFormData(request, MAX_VIDEO_BYTES);
  const file = data.get("file");
  const input = z
    .object({
      serviceId: z.string().min(1).max(100),
      fieldKey: z.string().min(1).max(100),
      orderId: z.string().max(100).optional(),
      kind: z.enum(["ATTACHMENT", "DELIVERABLE"]).default("ATTACHMENT"),
    })
    .parse(
      Object.fromEntries(
        ["serviceId", "fieldKey", "orderId", "kind"].map((key) => [
          key,
          data.get(key) || undefined,
        ]),
      ),
    );
  if (!(file instanceof File) || !file.size)
    throw new HttpError(400, "Fichier requis.");
  if (input.kind === "DELIVERABLE" && (user.role !== "ADMIN" || !input.orderId))
    throw new HttpError(403, "Livrable réservé à l’administration.");
  const service = await db.service.findUnique({
    where: { id: input.serviceId },
  });
  if (!service) throw new HttpError(404, "Service introuvable");
  const order = input.orderId
    ? await db.order.findUnique({ where: { id: input.orderId } })
    : null;
  if (
    input.orderId &&
    (!order ||
      order.serviceId !== service.id ||
      (user.role !== "ADMIN" && order.userId !== user.id))
  )
    throw new HttpError(404, "Dossier introuvable");
  if (order && ["COMPLETED", "CANCELLED", "QUOTE_REJECTED"].includes(order.status))
    throw new HttpError(409, "Ce dossier est clôturé.");
  const snapshot = order?.formSnapshot as
    | { requiredDocuments?: unknown }
    | undefined;
  const definitions = z
    .array(documentDefinition)
    .parse(snapshot?.requiredDocuments ?? service.requiredDocuments);
  if (
    input.kind === "ATTACHMENT" &&
    !definitions.some((def) => def.key === input.fieldKey)
  )
    throw new HttpError(400, "Type de pièce inconnu.");
  const definition = definitions.find(def => def.key === input.fieldKey);
  const attachmentType = input.kind === "ATTACHMENT" ? definition?.type ?? "document" : "document";
  const maxBytes = attachmentType === "video" ? MAX_VIDEO_BYTES : MAX_FILE_BYTES;
  if (file.size > maxBytes) throw new HttpError(413, `Taille maximale : ${maxBytes / 1024 / 1024} Mo.`);
  const bytes = new Uint8Array(await file.arrayBuffer());
  const mimeType = attachmentMime(bytes, attachmentType);
  if (!mimeType) throw new HttpError(400, attachmentType === "video" ? "Une vidéo MP4 ou MOV valide est requise." : attachmentType === "image" ? "Une photo JPEG ou PNG est requise." : "Formats acceptés : PDF, JPEG et PNG.");
  const pending = await db.document.count({
    where: { ownerId: user.id, orderId: null },
  });
  if (!order && pending >= 100)
    throw new HttpError(
      429,
      "Limite de pièces temporaires atteinte. Contactez le support.",
    );
  const storageKey = await storeFile(bytes);
  try {
    const document = await serializable(async (tx) => {
      // Recheck state within the transaction to prevent uploads racing with cancellation.
      if (order) {
        const latest = await tx.order.findUniqueOrThrow({
          where: { id: order.id },
        });
        if (["COMPLETED", "CANCELLED", "QUOTE_REJECTED"].includes(latest.status))
          throw new HttpError(409, "Ce dossier est clôturé.");
      }
      const created = await tx.document.create({
        data: {
          ...input,
          ownerId: user.id,
          storageKey,
          bytes: file.size,
          mimeType,
          fileName:
            file.name.replace(/[\x00-\x1f\x7f/\\]/g, "_").slice(0, 180) ||
            "document",
        },
        select: documentSelection,
      });
      if (order && input.kind === "ATTACHMENT") {
        await tx.orderEvent.create({
          data: {
            orderId: order.id,
            actorId: user.id,
            status: order.status,
            note: "Une pièce complémentaire a été ajoutée.",
          },
        });
        await queueAdmins(
          tx,
          `📎 Nouvelle pièce pour le dossier #${order.number} : ${order.serviceName}.`,
        );
      }
      return created;
    });
    return json(document, 201);
  } catch (error) {
    await removeFile(storageKey);
    throw error;
  }
});
