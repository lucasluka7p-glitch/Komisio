import { resolvePrice } from "@/lib/pricing";
import { db } from "@/lib/server/db";
import { handle, json } from "@/lib/server/http";
import { requireUser } from "@/lib/server/auth";
export const GET = handle(async (request: Request) => {
  const user = await requireUser(request);
  const rules = await db.clientServicePrice.findMany({ where: { userId: user.id } });
  const services = await db.service.findMany({
      where: { active: true },
      orderBy: [{ category: "asc" }, { name: "asc" }],
    });
  return json(services.map(service => ({ ...service, ...resolvePrice(service, user, rules.find(rule => rule.serviceId === service.id) as import("@/lib/pricing").PriceRule | undefined) })));
});
