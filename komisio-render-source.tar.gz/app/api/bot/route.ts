import { telegramWebhookSecret } from "@/lib/server/telegram-secret";
import { telegramBot } from "@/lib/server/integrations";
import { db, serializable } from "@/lib/server/db";
import { queueAdmins, queueNotification } from "@/lib/server/telegram";
import { adminTelegramIds, safeEqual } from "@/lib/server/auth";
import { body as readBody, handle, HttpError } from "@/lib/server/http";

export const runtime = "nodejs";
export const POST = handle(async (request: Request) => {
  const secret = process.env.TELEGRAM_WEBHOOK_SECRET ? telegramWebhookSecret() : "";
  if (!secret || !process.env.TELEGRAM_BOT_TOKEN || !process.env.MINI_APP_URL)
    throw new HttpError(503, "Bot non configuré.");
  if (
    !safeEqual(
      request.headers.get("x-telegram-bot-api-secret-token") ?? "",
      secret,
    )
  )
    throw new HttpError(401, "Signature du bot invalide.");
  const body = await readBody(request);
  const message = body?.message;
  if (
    message?.chat?.type === "private" &&
    typeof message.text === "string" &&
    /^\/start(?:@[a-zA-Z0-9_]+)?(?:\s|$)/.test(message.text) &&
    Number.isSafeInteger(message.chat.id)
  ) {
    const url = new URL(process.env.MINI_APP_URL);
    if (url.protocol !== "https:")
      throw new HttpError(503, "La Mini App requiert HTTPS.");
    const bot = telegramBot();
    await bot.api.sendMessage(
      message.chat.id,
      /\s+support(?:\s|$)/.test(message.text) ? "Décrivez votre demande ici et indiquez la référence du dossier si besoin. Votre message sera transmis à l’équipe. Ajoutez les pièces de dossier depuis la Mini App." : "Bienvenue sur Komisio. Vos contacts ont de la valeur. Retrouvez vos services B2B, votre portefeuille et le suivi de vos dossiers dans votre espace partenaire.",
      {
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: "Ouvrir mon espace partenaire",
                web_app: { url: url.toString() },
              },
            ],
          ],
        },
      },
    );
  }
  if (message?.chat?.type === "private" && Number.isSafeInteger(message.chat.id) && message.chat.id > 0 && message.from?.id === message.chat.id && typeof message.text === "string" && Number.isSafeInteger(body.update_id)) {
    const actor = String(message.chat.id);
    const reply = message.text.match(/^\/reply\s+(\d+)\s+([\s\S]+)$/);
    const isAdmin = adminTelegramIds().includes(actor);
    const support = !message.text.startsWith("/");
    if (support || (reply && isAdmin)) {
      const sender = await db.user.findUnique({ where: { telegramId: actor } });
      const target = reply && isAdmin ? await db.user.findUnique({ where: { telegramId: reply[1] } }) : null;
      if (!sender || sender.disabled || (reply && !target)) {
        await telegramBot().api.sendMessage(message.chat.id, "Ouvrez d’abord votre espace partenaire depuis /start. Pour une réponse admin, vérifiez l’identifiant du destinataire.");
      } else {
        const queued = await serializable(async tx => {
          const targetId = `telegram-update:${body.update_id}`;
          if (await tx.auditLog.findFirst({ where: { action: "SUPPORT_RELAY", targetId } })) return false;
          if (reply && isAdmin && target) {
            await queueNotification(tx, target.telegramId, `💬 Réponse de l’équipe Komisio :\n${reply[2].slice(0,3000)}`);
          } else {
            await queueAdmins(tx, `💬 Support — ${sender.firstName}${sender.username ? ` (@${sender.username})` : ""}, ID ${actor} :\n${message.text.slice(0,2500)}\n\nRépondre : /reply ${actor} votre message`);
          }
          await tx.auditLog.create({ data: { actorId: sender.id, action: "SUPPORT_RELAY", targetId, details: { direction: reply && isAdmin ? "admin_reply" : "reseller_request", recipient: target?.id || "admins" } } });
          return true;
        });
        if (queued) await telegramBot().api.sendMessage(message.chat.id, reply && isAdmin ? "Réponse prise en charge." : "Votre demande a été transmise à l’équipe Komisio.");
      }
    }
  }

  return Response.json({ ok: true });
});
