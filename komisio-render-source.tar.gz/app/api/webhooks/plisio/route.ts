import { z } from 'zod';
import { db,serializable } from '@/lib/server/db';
import { body,handle,HttpError,json } from '@/lib/server/http';
import { verifyPlisioCallback,validatePlisioReceipt,plisioRequest,type PlisioOperation } from '@/lib/server/plisio';
import { reconcilePayment } from '@/lib/server/payments';
export const POST=handle(async(request:Request)=>{
 const payload=await body(request);
 if(!verifyPlisioCallback(payload,process.env.PLISIO_API_KEY||''))throw new HttpError(401,'Signature Plisio invalide.');
 const event=z.object({txn_id:z.string().min(1).max(100),order_number:z.string().min(1).max(100),status:z.string()}).passthrough().parse(payload);
 const local=await db.payment.findUnique({where:{id:event.order_number}});
 if(!local||local.provider!=='PLISIO')throw new HttpError(404,'Facture Plisio introuvable.');
 validatePlisioReceipt(local,event);
 if(local.status==='CONFIRMED')return json({received:true});
 if(!local.providerPaymentId){const operation=await plisioRequest<PlisioOperation>(`/operations/${encodeURIComponent(event.txn_id)}`);if(operation.id!==event.txn_id||operation.type!=='invoice')throw new HttpError(409,'Opération Plisio incohérente.');}
 await serializable(async tx=>{
  const current=await tx.payment.findUniqueOrThrow({where:{id:local.id}});validatePlisioReceipt(current,event);if(current.status==='CONFIRMED')return;
  const data={providerPaymentId:event.txn_id,invoiceUrl:current.invoiceUrl||`https://plisio.net/invoice/${encodeURIComponent(event.txn_id)}`,...(event.status==='completed'?{callbackData:{txn_id:event.txn_id,order_number:event.order_number,ipn_type:String(event.ipn_type),status:event.status,source_currency:String(event.source_currency),source_amount:String(event.source_amount),currency:String(event.psys_cid||event.currency),amount:String(event.amount),invoice_total_sum:String(event.invoice_total_sum)},payAmount:current.payAmount||String(event.invoice_total_sum)}:{})};
  await tx.payment.update({where:{id:current.id},data});
 });
 await reconcilePayment(local.id);return json({received:true});
});
