import { z } from "zod";
import { db } from "@/lib/server/db";
import { body, handle, HttpError, json } from "@/lib/server/http";
import { reconcilePayment, verifyIpn } from "@/lib/server/payments";
export const POST = handle(async (request: Request) => {
  const payload = await body(request);
  if (
    !verifyIpn(
      payload,
      request.headers.get("x-nowpayments-sig") ?? "",
      process.env.NOWPAYMENTS_IPN_SECRET ?? "",
    )
  )
    throw new HttpError(401, "Signature invalide");
  const event = z
    .object({
      payment_id: z.union([z.string(), z.number()]),
      order_id: z.string().min(1),
    })
    .parse(payload);
  const payment = await db.payment.findUnique({
    where: { id: event.order_id },
  });
  if (!payment || payment.provider !== "NOWPAYMENTS" || !payment.providerPaymentId)
    throw new HttpError(409, "Facture non encore synchronisée");
  if (payment.providerPaymentId !== String(event.payment_id))
    throw new HttpError(409, "Identifiant de paiement incohérent");
  await reconcilePayment(payment.id);
  return json({ received: true });
});
