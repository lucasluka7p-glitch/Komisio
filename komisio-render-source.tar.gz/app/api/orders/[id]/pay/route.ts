import { requireUser } from "@/lib/server/auth";
import { serializable } from "@/lib/server/db";
import { handle, HttpError, json } from "@/lib/server/http";
import { orderInclude, payOrderWithWallet } from "@/lib/server/orders";
export const POST = handle(
  async (request: Request, context: { params: Promise<{ id: string }> }) => {
    const user = await requireUser(request);
    const { id } = await context.params;
    return json(
      await serializable(async (tx) => {
        const order = await tx.order.findFirst({
          where: { id, userId: user.id },
        });
        if (!order) throw new HttpError(404, "Dossier introuvable");
        if (order.paidAt && order.status !== "CANCELLED")
          return tx.order.findUniqueOrThrow({
            where: { id },
            include: orderInclude,
          });
        await payOrderWithWallet(tx, order);
        return tx.order.findUniqueOrThrow({
          where: { id },
          include: orderInclude,
        });
      }),
    );
  },
);
