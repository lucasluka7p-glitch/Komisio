import { requireUser } from "@/lib/server/auth";
import { body, handle, json } from "@/lib/server/http";
import { decisionInput, decideOrderQuote } from "@/lib/server/order-quotes";
export const POST = handle(async (request: Request, context: { params: Promise<{ id: string }> }) => {
  const user = await requireUser(request);
  return json(await decideOrderQuote((await context.params).id, user.id, decisionInput.parse(await body(request))));
});
