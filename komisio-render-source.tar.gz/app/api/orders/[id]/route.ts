import { z } from "zod";
import { requireUser } from "@/lib/server/auth";
import { db, serializable } from "@/lib/server/db";
import { body, handle, HttpError, json } from "@/lib/server/http";
import { orderInclude } from "@/lib/server/orders";
import { queueAdmins } from "@/lib/server/telegram";
export const GET = handle(
  async (request: Request, context: { params: Promise<{ id: string }> }) => {
    const user = await requireUser(request);
    const { id } = await context.params;
    const order = await db.order.findFirst({
      where: { id, ...(user.role === "ADMIN" ? {} : { userId: user.id }) },
      include: orderInclude,
    });
    if (!order) throw new HttpError(404, "Dossier introuvable");
    return json(order);
  },
);
export const PATCH = handle(
  async (request: Request, context: { params: Promise<{ id: string }> }) => {
    const user = await requireUser(request);
    const { id } = await context.params;
    const { note } = z
      .object({ note: z.string().trim().min(1).max(4000) })
      .parse(await body(request));
    const order = await serializable(async (tx) => {
      const current = await tx.order.findFirst({
        where: { id, userId: user.id },
      });
      if (!current) throw new HttpError(404, "Dossier introuvable");
      if (["COMPLETED", "CANCELLED", "QUOTE_REJECTED"].includes(current.status))
        throw new HttpError(409, "Ce dossier est clôturé.");
      await tx.orderEvent.create({
        data: { orderId: id, actorId: user.id, status: current.status, note },
      });
      await queueAdmins(
        tx,
        `📎 Réponse du revendeur pour le dossier #${current.number}. Consultez la Mini App.`,
      );
      return tx.order.findUniqueOrThrow({
        where: { id },
        include: orderInclude,
      });
    });
    return json(order);
  },
);
