import { requireUser } from "@/lib/server/auth";
import { db } from "@/lib/server/db";
import { body, handle, json } from "@/lib/server/http";
import { createOrder, orderInclude, orderInput } from "@/lib/server/orders";
export const GET = handle(async (request: Request) => {
  const user = await requireUser(request);
  return json(
    await db.order.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: "desc" },
      take: 200,
      include: orderInclude,
    }),
  );
});
export const POST = handle(async (request: Request) => {
  const user = await requireUser(request);
  return json(
    {
      order: await createOrder(user.id, orderInput.parse(await body(request))),
    },
    201,
  );
});
