import { z } from "zod";
import { requireUser } from "@/lib/server/auth";
import { serializable } from "@/lib/server/db";
import { body, handle, HttpError, json } from "@/lib/server/http";
import { estimateVehicleTax } from "@/lib/vehicle-estimate";
import { quotePrice, resolvePrice, type PriceRule } from "@/lib/pricing";

export const runtime = "nodejs";
const inputSchema = z.object({
  serviceId: z.enum(["carte-grise", "carte-grise-sans-ct"]),
  region: z.string().min(1).max(10),
  fiscalPower: z.number().int().min(1).max(1000),
  firstRegistration: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  ordinaryFrenchUsedCar: z.boolean(),
}).strict();

/** No dossier, document, payment or external request is created by an estimate. */
export const POST = handle(async (request: Request) => {
  const sessionUser = await requireUser(request);
  const input = inputSchema.parse(await body(request));
  let estimate: ReturnType<typeof estimateVehicleTax>;
  try { estimate = estimateVehicleTax(input); }
  catch (error) { throw new HttpError(400, (error as Error).message); }
  return json(await serializable(async tx => {
    const user = await tx.user.findUniqueOrThrow({ where: { id: sessionUser.id } });
    if (user.disabled || !user.accessReady || user.mustChangePassword) throw new HttpError(403, "Accès client indisponible.");
    const service = await tx.service.findFirst({ where: { id: input.serviceId, active: true } });
    if (!service) throw new HttpError(404, "Cette prestation est momentanément indisponible.");
    const rule = await tx.clientServicePrice.findUnique({ where: { userId_serviceId: { userId: user.id, serviceId: service.id } } });
    const tariff = resolvePrice(service, user, rule as PriceRule | null);
    const commercialAmountCents = tariff.pricing.mode === "QUOTE" ? null
      : tariff.requiresQuote ? quotePrice(estimate.referenceCents, tariff.pricing) : tariff.priceCents;
    return { estimate, serviceId: service.id, serviceTitle: service.name, commercialAmountCents, pricing: tariff.pricing, requiresQuote: tariff.requiresQuote, finalPriceRequiresApproval: tariff.requiresQuote };
  }));
});
