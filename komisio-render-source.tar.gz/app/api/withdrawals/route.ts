import { requireUser } from "@/lib/server/auth";
import { body, handle, json } from "@/lib/server/http";
import { listWithdrawals, requestWithdrawal } from "@/lib/server/withdrawals";
import { withdrawalInput } from "@/lib/server/withdrawal-validation";
export const GET = handle(async (request: Request) => {
  const user = await requireUser(request);
  return json({ withdrawals: await listWithdrawals(user.id), enabled: process.env.WITHDRAWALS_ENABLED === "true" });
});
export const POST = handle(async (request: Request) => {
  const user = await requireUser(request);
  return json(await requestWithdrawal(user.id, withdrawalInput.parse(await body(request))), 201);
});
