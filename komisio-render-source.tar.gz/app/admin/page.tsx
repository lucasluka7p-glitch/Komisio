import PartnerApp from "@/components/partner-app";
export default function AdminPage() {
  return <PartnerApp initialPage="admin" />;
}
