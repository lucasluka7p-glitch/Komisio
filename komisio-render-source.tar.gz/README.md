> **WhatsApp et estimation d’accueil :** voir [WHATSAPP.md](./WHATSAPP.md). Numéro ordinaire via QR WhatsApp Web, groupes rattachés par client, OCR local, brouillons contrôlés et bot à commandes. Le serveur et le pont doivent être déployés avant toute connexion réelle.

> **Accès clients et tarifs individuels :** [CLIENT-ACCESS.md](./CLIENT-ACCESS.md). Création par l’admin, mot de passe temporaire, grilles privées par client et estimateur gratuit de carte grise.

> **Plisio + hébergement gratuit :** voir [FREE-HOSTING.md](./FREE-HOSTING.md) pour Render Free, Supabase Free et la Mini App Telegram. Intégration des factures et retraits : [PLISIO.md](./PLISIO.md). Les offres gratuites ont des quotas et périodes de mise en veille ; aucun compte de production n’est encore raccordé.

> **Mise en production :** voir [DEPLOYMENT.md](./DEPLOYMENT.md). Le lien Sites public reste une démo ; le serveur Node/PostgreSQL et les comptes Telegram/Plisio doivent être raccordés pour les opérations réelles. Docker, HTTPS, migrations, file de notifications et tests d’intégration isolés sont fournis.

<!-- Identity: Komisio. Existing technical storage keys are retained for data continuity. -->
# Komisio — Espace partenaires B2B

V1 en français d’une Telegram Mini App de commande de prestations, avec un dashboard d’administration à `/admin`, un portefeuille en euros, des paiements crypto Plisio (avec compatibilité NOWPayments pour les anciennes factures) et des notifications Telegram via grammY.

Le projet contient **le code complet Next.js avec ses routes serveur** et une **démonstration statique de l’interface**. La démonstration conserve ses données dans le navigateur et simule les paiements ; elle ne fournit ni API de production, ni base de données, ni paiement réel. Utiliser uniquement des documents fictifs dans ce mode. Pour exploiter la plateforme avec des revendeurs réels, déployer l’application Next.js sur un serveur Node.js, configurer PostgreSQL et les intégrations décrites ci-dessous.

Les 36 prestations initiales couvrent les formalités d’entreprise, les démarches automobiles et l’assistance administrative. Les prix sont des exemples de tarifs revendeur à adapter avant ouverture. Ils n’incluent aucune promesse sur les débours, taxes, frais de greffe ou habilitations nécessaires à l’exploitant.

## Stack et architecture

Next.js 15 App Router, React 19, TypeScript, Tailwind CSS, Lucide, `@twa-dev/sdk`, Prisma 6, PostgreSQL, grammY et NOWPayments. Les prix, soldes et écritures du portefeuille sont des **centimes d’euro entiers**. Les montants crypto utilisent des chaînes décimales ; un dépôt USDT n’est jamais traité comme un montant euro sans conversion par la passerelle.

```text
app/
  layout.tsx                    # Langue, métadonnées et styles
  page.tsx                      # Espace revendeur
  admin/page.tsx                # Dashboard administrateur
  globals.css                   # Interface responsive
  api/
    auth/telegram/route.ts      # Vérification initData + session
    auth/logout/route.ts
    me/route.ts                 # Profil, solde et journal
    catalog/route.ts
    orders/                     # Commande, détail, réponse, paiement wallet
    documents/                  # Upload et téléchargement privé
    payments/                   # Facture crypto et réconciliation
    webhooks/nowpayments/route.ts
    bot/route.ts                # /start Telegram
    cron/notifications/route.ts # Reprise de la file d’envoi
    admin/                      # Catalogue, dossiers, revendeurs, finances
components/
  partner-app.tsx              # Catalogue, commande, suivi, portefeuille
  admin-panel.tsx              # Interface complète d’administration
  admin.css
  ui.tsx
lib/
  catalog.ts                    # Types UI et catalogue de démonstration
  server/
    auth.ts                     # HMAC Telegram, cookies, autorisations
    db.ts                       # Prisma et transactions sérialisables
    orders.ts                   # Prix serveur et débit atomique
    payments.ts                 # Intégration NOWPayments
    payment-signature.ts        # Signature IPN SHA-512
    storage.ts                  # Stockage privé et validation des fichiers
    telegram.ts                 # File durable des notifications
    validation.ts
    http.ts
prisma/
  schema.prisma                 # Schéma complet PostgreSQL
  seed.ts                       # Les services, sans comptes fictifs
  migrations/                   # Migration SQL initiale et contraintes
scripts/build-preview.mjs       # Export séparé de la démonstration
tests/                          # Vérifications des fonctions sensibles
.env.example
BACKEND.md                      # Contrats API et détails d’exploitation
```

## Installation et démarrage

Prérequis : Node.js 22 ou supérieur, npm et une base PostgreSQL accessible au serveur. Créer une base et un utilisateur dédiés disposant des droits nécessaires à l’application et aux migrations.

```sh
cp .env.example .env
npm install
```

Renseigner `.env` avant les commandes Prisma. Prisma CLI ne charge pas automatiquement `.env.local`.

```dotenv
DATABASE_URL="postgresql://forma:VOTRE_MOT_DE_PASSE@localhost:5432/forma?schema=public"
APP_URL="https://votre-domaine.fr"
MINI_APP_URL="https://votre-domaine.fr"
TELEGRAM_BOT_TOKEN=""
TELEGRAM_WEBHOOK_SECRET=""
ADMIN_TELEGRAM_IDS=""
SESSION_SECRET=""
CRON_SECRET=""
PAYMENT_PROVIDER="PLISIO"
PLISIO_API_KEY=""
PLISIO_PAYOUTS_ENABLED="false"
PRIVATE_UPLOAD_DIR=".private/uploads"
NEXT_PUBLIC_DEMO_MODE="false"
```

Générer séparément `SESSION_SECRET`, `CRON_SECRET` et le secret de webhook Telegram avec un générateur cryptographique, par exemple `openssl rand -hex 32`. Conserver ces valeurs dans le gestionnaire de secrets de l’hébergement ; ne jamais les publier, les versionner ou leur donner le préfixe `NEXT_PUBLIC_`.

```sh
npm run db:generate
npx prisma migrate deploy
npm run db:seed
npm run dev
```

Ouvrir l’application depuis le bot pour une connexion réelle. Pour ce démarrage local, `APP_URL` et `MINI_APP_URL` peuvent être réglées à cette origine, mais l’ouverture réelle depuis Telegram exige une URL HTTPS publique. Le seed crée les services manquants, préserve les modifications administratives et ne crée aucun compte ni solde de production fictif.

Pour créer une migration lors d’un développement ultérieur : `npm run db:migrate`. Pour une base de production, utiliser `prisma migrate deploy` plutôt que `db push`.

## Explorer la démonstration

Sans PostgreSQL ni clés externes, lancer `NEXT_PUBLIC_DEMO_MODE=true npm run dev`, puis ouvrir `http://localhost:3000`. Le catalogue, les commandes, les documents fictifs, le portefeuille et l’administration sont conservés dans ce navigateur. Le menu du profil permet de réinitialiser la démonstration. Garder `NEXT_PUBLIC_DEMO_MODE=false` dans le déploiement réel : hors Telegram, l’interface demande alors une connexion au bot.

`npm run build:preview` génère séparément `out/`, une version statique de démonstration incluant `/admin`. Ce script ne retire ni ne modifie les API de production. Le site privé publié dans cette livraison héberge cette démonstration ; les routes API et le schéma Prisma sont fournis dans les sources.

## Telegram Mini App et administrateurs

1. Créer le bot auprès de **BotFather**, puis configurer l’URL HTTPS de la WebApp et son bouton de menu. Le token reste exclusivement côté serveur.
2. Régler `APP_URL` sur l’origine publique exacte du serveur, sans chemin. Régler `MINI_APP_URL` sur l’adresse HTTPS de l’espace partenaire.
3. Renseigner `ADMIN_TELEGRAM_IDS` avec les IDs Telegram **numériques**, séparés par des virgules. Un `@username` ne donne aucun droit. L’autorisation administrateur est recalculée côté serveur à chaque requête.
4. Enregistrer le webhook Telegram `https://votre-domaine.fr/api/bot`, en fournissant un `secret_token` identique à `TELEGRAM_WEBHOOK_SECRET`.
5. Chaque revendeur et administrateur doit envoyer `/start` au bot en conversation privée pour recevoir les notifications. Le bot répond avec le bouton d’ouverture de la Mini App.

Cet exemple lit les secrets depuis l’environnement du processus Node et n’affiche pas le token. L’exécuter dans un environnement où les variables sont déjà chargées ; remplacer l’URL uniquement dans `.env` ou la configuration de déploiement.

```sh
node --env-file=.env --input-type=module <<'JS'
const { TELEGRAM_BOT_TOKEN, TELEGRAM_WEBHOOK_SECRET, APP_URL } = process.env;
if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_WEBHOOK_SECRET || !APP_URL?.startsWith('https://')) {
  throw new Error('Configuration Telegram HTTPS incomplète');
}
const response = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/setWebhook`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    url: `${APP_URL.replace(/\/$/, '')}/api/bot`,
    secret_token: TELEGRAM_WEBHOOK_SECRET,
    allowed_updates: ['message'],
  }),
});
const result = await response.json();
if (!response.ok || !result.ok) throw new Error('Enregistrement du webhook refusé');
console.log('Webhook Telegram enregistré.');
JS
```

L’authentification envoie les données **brutes** `Telegram.WebApp.initData` à `POST /api/auth/telegram`. Le serveur vérifie leur signature et une fraîcheur maximale de dix minutes, puis crée un cookie HttpOnly signé. Il ne fait pas confiance à `initDataUnsafe`. En production, le cookie est `Secure`, `SameSite=None` et `Partitioned` pour l’intégration Telegram Web ; le support exact dépend du navigateur. Les écritures authentifiées vérifient l’origine contre `APP_URL`.

L’interface de démonstration permet d’explorer `/admin`. Dans l’application connectée, les routes d’administration nécessitent l’ID Telegram autorisé ; un lien ou une manipulation du navigateur ne suffit pas à obtenir ces droits.

## Paiements NOWPayments

Créer un compte marchand NOWPayments, activer les monnaies souhaitées, puis fournir la clé API et le secret IPN. Les codes configurés sont `usdttrc20`, `usdterc20`, `btc`, `eth` et `sol`. Leur disponibilité, les minimums, les frais et le règlement final dépendent de la configuration du compte marchand.

Le serveur demande un paiement valorisé en euros, avec l’identifiant local dans `order_id` et le callback `https://votre-domaine.fr/api/webhooks/nowpayments`. Le frontend affiche l’adresse, le montant crypto et le QR code, puis suit le statut par polling authentifié. Pour une commande, le montant provient toujours du prix figé côté serveur. Pour une recharge, le montant minimal est de 10 €.

Le webhook valide la signature SHA-512 du JSON trié récursivement, puis relit le paiement auprès de NOWPayments. Le crédit ou le passage en traitement intervient uniquement au statut fournisseur final `finished`, après contrôle des identifiants, devises et montants. Les opérations de règlement sont atomiques et protégées contre les doublons. Un paiement tardif sur un dossier annulé ou déjà réglé est crédité au portefeuille.

Une annulation administrative d’un dossier payé recrédite son montant au portefeuille interne ; elle n’effectue pas de transfert crypto externe. Un paiement dont la création fournisseur a expiré reste `CREATING` pour éviter une seconde facture. Sa réconciliation requiert une intervention opérateur documentée dans [BACKEND.md](BACKEND.md) ; la V1 ne contient pas d’interface dédiée à cette intervention.

## Documents et notifications

Les documents réels sont stockés dans `PRIVATE_UPLOAD_DIR`, en dehors de `public/`, avec une limite de 10 Mo par document PDF/JPEG/PNG et 25 Mo par vidéo MP4/MOV dans un champ vidéo. Le serveur contrôle les signatures binaires des documents et le conteneur des vidéos. Le téléchargement passe par une route privée réservée au propriétaire du dossier et aux administrateurs. La vérification de format ne remplace pas un antivirus ; aucune analyse antivirus n’est intégrée dans cette V1.

Pour un hébergement de production, monter un volume privé persistant, chiffrer le stockage et les sauvegardes, exclure `.private/` et les documents des artefacts et de Git, et définir les durées de conservation ainsi que la purge des pièces temporaires. Un système de fichiers éphémère ou un déploiement statique ne convient pas à ce backend.

Les événements métier créent une entrée de notification dans la même transaction. L’application tente l’envoi après la réponse HTTP. Programmer également chaque minute un appel protégé pour reprendre les échecs :

```sh
node --env-file=.env --input-type=module <<'JS'
const response = await fetch(`${process.env.APP_URL}/api/cron/notifications`, {
  method: 'POST',
  headers: { Authorization: `Bearer ${process.env.CRON_SECRET}` },
});
if (!response.ok) throw new Error(`Reprise des notifications : HTTP ${response.status}`);
console.log(await response.json());
JS
```

La livraison est au moins une fois : une interruption entre l’envoi et son acquittement peut produire un doublon. La file utilise un verrou, un délai exponentiel et dix tentatives maximum. Surveiller les messages non envoyés, les paiements `CREATING` et les erreurs de webhook. Les notifications ne transportent pas les pièces KYC.

## Déploiement et vérifications

```sh
npm run typecheck
npm test
npx prisma validate
npm run build
npm start
```

Déployer sur un hébergement Node.js avec HTTPS, accès PostgreSQL et stockage privé persistant. Appliquer les migrations avant ouverture, configurer la tâche de reprise des notifications et tester les sauvegardes/restaurations. Prévoir une limitation de débit au reverse proxy. Les listes de cette V1 sont bornées à 200 ou 500 entrées ; une pagination sera nécessaire à plus grande échelle.

Les vérifications automatisées couvrent notamment l’intégrité et la fraîcheur Telegram, les sessions, les origines, la signature crypto et les contrôles de fichiers. **Les appels réels Telegram et NOWPayments, les webhooks publics et les scénarios de concurrence sur PostgreSQL déployé n’ont pas été exécutés avec des comptes marchands réels pendant la génération.** Un test de bout en bout avec les identifiants de l’exploitant est nécessaire avant l’encaissement et le traitement de documents réels.

Les contrats complets, les statuts, les règles d’annulation, le format des formulaires dynamiques et les limites d’exploitation figurent dans [BACKEND.md](BACKEND.md).

## Catalogue étendu

Le catalogue comporte 36 prestations. Les nouveaux prix sont des **tarifs de service provisoires**, modifiables dans `/admin` → Catalogue. Ils ne comprennent pas les achats, taxes, soins, réparations ou frais d’organismes tiers lorsqu’ils sont indiqués séparément. La remise CEDEO de 40 % s’applique selon l’accord professionnel déclaré par l’exploitant ; le prix affiché correspond aux frais de service.

Les demandes sont décrites comme des démarches officielles : véhicule présenté au contrôle technique via convoyage, remboursements soumis aux droits réels et à la décision de l’organisme, fin de leasing après accord du bailleur, mainlevées sur justificatifs. Le service relatif aux données de police accompagne uniquement une demande légale d’accès ou de rectification de ses propres données. Le service véhicule fournit une situation administrative officielle, sans accès aux fichiers de police.

Pour une base existante, exécuter `npm run db:seed` après déploiement. Cette commande ajoute les nouvelles prestations et conserve les tarifs/formulaires déjà modifiés. La démonstration fusionne également les nouveaux services avec les données du navigateur, sans réinitialiser le portefeuille ni les dossiers.

## Interface mobile

La navigation principale est placée en bas des écrans de 800 px et moins. Jusqu’à 640 px, les tableaux des dossiers, transactions et de l’administration se lisent sous forme de cartes. Les formulaires utilisent des champs de 16 px, des actions tactiles de 44–51 px et des fenêtres adaptées à la hauteur visible du clavier.

Les marges de sécurité iOS et Telegram, le bouton retour Telegram, le retour navigateur, la navigation clavier et les fenêtres empilées sont pris en charge. Les polices variables DM Sans et Manrope sont hébergées localement dans `public/fonts/`, avec leurs licences. Les builds et les contrôles TypeScript valident les sources ; les parcours ont été vérifiés dans Chromium en tailles mobile et bureau, en clair et en sombre (voir VERIFICATION.md).

Les retraits USDT TRC20 sont intégrés au portefeuille et au panel admin, avec devis de frais, acceptation, réservation atomique et envoi manuel tracé. Voir [WITHDRAWALS.md](./WITHDRAWALS.md) pour le fonctionnement, les API, les tests et les limites de la démonstration. L’activation serveur est désactivée par défaut (`WITHDRAWALS_ENABLED=false`).

Le changement de titulaire fonctionne sur devis, avec toutes ses pièces facultatives : dépôt → proposition admin → accord/refus → paiement → traitement. Voir [QUOTES.md](./QUOTES.md) pour les API, la migration et les vérifications.

Les formulaires d’immatriculation, contrôle technique, Ameli et demandes personnelles ont été actualisés ; voir [CATALOGUE.md](./CATALOGUE.md). La variante sans justificatif de contrôle technique joint suit aussi un devis préalable. Aucun accès Ameli ni mot de passe n’est collecté.

Le catalogue est regroupé en catégories et sous-catégories, configurables par prestation dans le panel admin. WW simple : 80 €, WW modifié : 100 € ; leurs formulaires demandent deux photos et l’adresse postale. CEDEO utilise aussi le parcours sur devis. La migration correspondante préserve les commandes déjà déposées.


### Catalogue organisé en sept rubriques

Le catalogue, le guide Komi et le filtre Catalogue de l’admin partagent sept rubriques : Carte grise & immatriculation ; Régularisation & procédures automobiles ; Informations véhicule & particulier ; Remboursements & assurances ; Démarches administratives ; Permis de conduire ; Avantages & réductions. Les domaines et sous-catégories de gestion restent configurables dans l’éditeur de service.

La régularisation de carte grise est à 100 €. L’homologation, le remboursement mutuelle, le dossier récépissé, le dossier logement et la création NEPH sont sur devis. La remise professionnelle CEDEO est de 40 %, sur devis. Les tarifs WW sont de 80 € / 100 €. Les grilles individuelles et tous les tarifs actualisés sont décrits dans [CLIENT-ACCESS.md](./CLIENT-ACCESS.md). Les dossiers déjà déposés conservent leurs prix. La migration `20261024000000_seven_section_catalogue` crée les nouveaux services sans écraser ceux déjà configurés, met à jour l’offre CEDEO d’origine et reclasse le leasing dans l’immatriculation.
