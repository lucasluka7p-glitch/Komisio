# Retraits portefeuille — V1

Les revendeurs peuvent demander un retrait à toute heure dans **Portefeuille → Retirer**. L’admin traite les demandes dans **Admin → Finances**. La V1 utilise **USDT TRC20**. Le nouveau parcours [Plisio](./PLISIO.md) calcule les frais et permet un envoi par API après acceptation du revendeur et déclenchement admin. Le parcours manuel historique ci-dessous reste disponible pour les opérations hors Plisio.

## Parcours et comptabilité

1. `REQUESTED` : montant EUR brut et adresse TRON vérifiée par base58check ; aucune réservation. Maximum cinq demandes en attente de devis/acceptation par utilisateur.
2. `QUOTED` : l’admin renseigne les frais totaux EUR réellement proposés par le prestataire, le taux USDT/EUR et la référence du devis. Validité 15 minutes ; chaque nouveau devis change de version. Commission de la plateforme : zéro. Le montant net USDT est calculé en décimal exact et arrondi vers le bas à six décimales.
3. `APPROVED` : le revendeur accepte la version du devis, les frais et l’adresse. Le montant brut est immédiatement déduit du solde disponible et inscrit dans le journal (`WITHDRAWAL_HOLD`). Les commandes et les ajustements utilisent ce même solde disponible : aucun montant réservé ne peut être dépensé de nouveau. Aucun débit supplémentaire à la confirmation réseau.
4. `PROCESSING` : l’admin prend en charge l’envoi **avant** d’intervenir sur son prestataire. À partir de là, le revendeur ne peut plus annuler. Vérifier fonds, destinataire, jeton, réseau et montant net. Ne jamais lancer deux envois pour une demande.
5. `SENT` : l’admin enregistre le hash TRON réel (64 caractères hexadécimaux, unique). Lien vers Tronscan pour le revendeur. L’application ne vérifie pas automatiquement la chaîne.
6. `COMPLETED` : l’admin atteste la réussite après vérification effective du réseau, de l’adresse, du jeton et du montant, avec une note de preuve.

Avant `PROCESSING`, le titulaire peut annuler et l’admin peut refuser avec un motif. Toute réserve est libérée une fois (`WITHDRAWAL_RELEASE`). Après prise en charge, un échec **définitif vérifié** peut être réconcilié par l’admin via l’action d’échec : preuve détaillée et attestation qu’aucun transfert n’a abouti et qu’aucun envoi n’est en attente. Il n’y a jamais de restitution sur un simple timeout, ni sur un échec supposé. `FAILED` est terminal, comme les états annulé/refusé/terminé. Pour un transfert réussi, ne jamais utiliser cette action.

Les changements sont audités et les notifications Telegram passent par l’outbox durable. Le prestataire reste la source de vérité sur l’exécution réelle. Les montants disponibles doivent être intégralement couverts par la trésorerie crypto. Le portefeuille existant ne distingue pas les crédits promotionnels : **tout crédit manuel est donc retirable** et doit correspondre à des fonds réels. Les réserves sont déduites du disponible mais affichées séparément dans les retraits en cours.

## API

Toutes les routes utilisent la session Telegram et les contrôles d’origine existants ; les routes admin nécessitent un ID Telegram administrateur autorisé. Les données d’un autre revendeur sont inaccessibles.

- `GET /api/withdrawals` : `{withdrawals, enabled}` du titulaire.
- `POST /api/withdrawals` : `{amountCents, currency: "usdttrc20", address, idempotencyKey: UUID}`. Réutiliser le même UUID après une réponse inconnue. Le changement d’un montant/adresse sous la même clé est refusé.
- `POST /api/withdrawals/:id` : `{action: "accept", quoteVersion}` ou `{action: "cancel"}`. Seul le titulaire accepte les frais.
- `GET /api/admin/withdrawals` : toutes les demandes actives et les 200 dernières demandes terminées avec identité du titulaire.
- `POST /api/admin/withdrawals/:id` : `quote` (`feeCents`, `exchangeRate` chaîne décimale, `source`), `reject` (`note`), `process`, `sent` (`txHash`), `complete` (`note`) ou `fail` (`confirmedNoFundsMoved: true`, `note` de preuve ≥20 caractères).

Le maximum technique par demande est de 100 000 €, minimum 0,01 € brut. Les minimums du prestataire et la faisabilité du montant net sont vérifiés par l’opérateur lors du devis ; aucun minimum économique ni frais arbitraire n’est ajouté. Une transaction PostgreSQL sérialisable englobe chaque transition, solde, journal, audit et notification. Les références uniques rendent les réservations/libérations idempotentes.

## Activation

Appliquer les migrations avec `npx prisma migrate deploy` sur PostgreSQL 12+. Conserver `WITHDRAWALS_ENABLED=false` tant que la trésorerie, les frais, les minimums prestataire et les accès de l’admin à l’envoi sortant ne sont pas vérifiés. Cette variable empêche les nouvelles demandes ; les demandes existantes restent consultables et traitables. Aucun secret de signature ni secret TOTP n’est stocké pour cette fonctionnalité.

Le site publié reste une **démonstration statique**, sans PostgreSQL ni intégration sortante. La simulation utilise le stockage du navigateur, partage les demandes entre portefeuille et panel admin et affiche explicitement qu’aucune crypto n’est envoyée. Les frais et taux ne sont jamais préremplis comme tarifs réels. Les arrondis de simulation utilisent les nombres JavaScript ; seule l’API serveur calcule les sommes financières exactes.

Une automatisation future nécessitera l’activation d’un service de payouts, un contrôle de trésorerie, une identité d’envoi compatible avec l’hébergement, les règles d’authentification/2FA du prestataire et une réconciliation des réponses ambiguës. Elle ne peut pas être déduite de la seule intégration de collecte NOWPayments.

## Vérification

`npm test` et `npm run build`. Tests PostgreSQL isolés : créer une base jetable nommée `forma_withdrawals_test`, appliquer les migrations via son `DATABASE_URL`, puis lancer `WITHDRAWAL_TEST_DATABASE_URL=postgresql://.../forma_withdrawals_test npm test`. La suite refuse un autre nom de base et n’utilise jamais implicitement le `DATABASE_URL` de production. Elle teste doublons, conflits de payload, propriété des dossiers, droits admin, origine, expiration/version des devis, doubles acceptations et restitutions, compétition avec une dépense portefeuille, course annulation/prise en charge et réconciliation d’échec. Les tests ne contactent ni Telegram ni un prestataire et ne déplacent aucun fonds.


## Nouveau parcours Plisio

Voir PLISIO.md pour les quatre actions API admin, la vérification des frais, l’envoi à tentative applicative unique, le suivi réseau et le rattachement après réponse perdue. Les mêmes règles de réserve EUR et de journal s’appliquent. `providerAttemptedAt` interdit un renvoi aveugle ; `providerTransferId` et le hash sont uniques. La libération sur une simple erreur réseau demeure interdite.
