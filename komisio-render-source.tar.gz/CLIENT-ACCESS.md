# Comptes clients et tarifs individuels

## Parcours administrateur

1. Ouvrir **Admin → Clients & tarifs → Nouveau client**.
2. Indiquer un nom ou une société et un identifiant unique. L’ID Telegram numérique est facultatif ; aucun @pseudo ne sert de preuve d’identité.
3. Régler la remise générale et les exceptions pour **chaque prestation**, regroupées dans les sept rubriques du catalogue. Une exception peut être un prix fixe, une remise en pourcentage ou un prix sur devis. Le montant aperçu est celui que verra ce client.
4. Enregistrer un brouillon ou choisir **Créer et générer l’accès**. Le compte, les règles et l’activation sont enregistrés dans une transaction.
5. Copier les identifiants affichés une seule fois et les remettre directement au client. Aucun message n’est envoyé automatiquement.

Les comptes existants restent disponibles. Pour ajouter des identifiants à un ancien compte Telegram, enregistrer son identifiant et sa grille, puis générer un nouveau mot de passe dans **Accès**. La suspension et la réinitialisation révoquent les anciennes sessions. La réactivation ne rend pas les anciennes sessions valides.

## Connexion du client

La version Node propose un formulaire identifiant / mot de passe, sur le Web et dans Telegram. Il n’existe pas d’inscription publique : seuls les comptes provisionnés par l’administrateur sont admis. Les administrateurs initialisent leur accès par Telegram et l’allowlist `ADMIN_TELEGRAM_IDS`.

Le premier mot de passe est temporaire. Le client doit le remplacer par un mot de passe personnel d’au moins 12 caractères avant d’accéder au catalogue, aux pièces, commandes, paiements ou retraits. Les mots de passe sont hachés avec scrypt et un sel aléatoire ; ils ne sont jamais renvoyés dans les profils, journaux d’audit ou exports. Le mot de passe temporaire n’est remis qu’en réponse à sa génération, via HTTPS. Les tentatives de connexion sont limitées dans PostgreSQL, par identifiant et globalement.

En ouvrant la Mini App et en se connectant avec ses identifiants, le client peut relier son compte Telegram. Le serveur vérifie la signature et la fraîcheur de `initData`, refuse les comptes déjà liés et les identifiants réservés aux administrateurs. Une fois lié, Telegram permet la connexion automatique et les notifications du bot, après `/start`. Un compte Web sans Telegram reste utilisable ; les événements de dossier restent consultables dans l’application, sans notification Telegram tant que le compte n’est pas relié.

## Règles de prix

- Les montants sont stockés en centimes d’euro ; les remises en points de base (100 = 1 %).
- La règle spécifique du service remplace la remise générale ; elles ne s’additionnent pas.
- La remise générale s’applique au tarif catalogue ou au montant de référence des devis. Un prix fixe personnalisé remplace le tarif catalogue. Le mode devis oblige à proposer un montant avant acceptation et paiement.
- Un nouveau compte reçoit par défaut une règle de remise de **50 %** sur les deux changements de titulaire. Les raccourcis **50 / 55 / 60 %** permettent de régler ces règles ensemble. Le minimum est **60 € par carte grise**. Tous les autres tarifs restent configurables.
- Pour les dossiers à pourcentage sur devis, l’admin saisit le **montant de référence avant remise**. Le serveur applique le pourcentage et le minimum ; l’interface affiche le montant net avant envoi. Le client accepte ou refuse le montant final.
- Chaque commande conserve un instantané de sa grille. Une modification ultérieure ne change pas ses conditions, un devis accepté, une facture ou un débit.
- Le formulaire envoie le prix, la version de grille et la date du catalogue affichés. Si les conditions ont changé avant validation, le serveur refuse la commande avant tout débit et demande de revoir le catalogue. Les anciens clients API peuvent omettre ces préconditions ; le serveur calcule toujours le tarif lui-même.
- Une demande rejouée avec la même clé retourne sa commande existante sans nouveau débit.
- Les modifications concurrentes d’une même grille sont contrôlées par version et auditées.

## Tarifs catalogue mis à jour

| Prestation | Tarif initial |
| --- | ---: |
| Carte grise avec / sans CT joint | Sur devis, minimum 60 € |
| WW simple | 80 € |
| WW modifié | 100 € |
| Fiche infos véhicule | 50 € |
| Accès à ses données personnelles (« fiche recherche ») | 200 € |
| Régularisation de carte grise (« écrasement ») | 100 € |
| Mise à jour après rachat de leasing | 170 € |
| Déclaration de cession | 40 € |
| Déclaration d’achat | 40 € |
| Création de société | 1 400 € |
| Modification de société | 650 € |

Les conditions et pièces officielles des prestations sont conservées. Les accès à des fichiers de police de tiers ne sont pas proposés. La migration remplace seulement les anciens tarifs par défaut identifiables ; les prix déjà personnalisés et les anciens dossiers restent intacts.

## Calcul gratuit du prix de référence d’une carte grise

Le formulaire de devis admin contient un estimateur local **sans API payante, sans abonnement et sans IA**. Il utilise la région du nouveau titulaire, la puissance fiscale P.6 et la date B de première immatriculation. Une plaque seule ne permet pas de récupérer gratuitement toutes les caractéristiques nécessaires : il faut les lire sur la carte grise.

Périmètre : voiture particulière d’occasion essence ou diesel déjà immatriculée en France, sans importation, conversion, exonération ni malus résiduel. L’admin confirme ce périmètre. Calcul : taxe régionale arrondie à l’euro, réduction d’ancienneté à partir de dix ans, taxe fixe de 11 € et acheminement de 2,76 €. Le résultat est une **estimation de référence**, pas un montant fiscal définitif. L’admin le vérifie puis peut l’utiliser pour proposer le devis ; le calcul est revérifié côté serveur et sa source conservée dans l’audit.

La remise est une condition commerciale du vendeur ; elle ne réduit pas les taxes dues à l’État. Les cas hors périmètre doivent passer par le simulateur officiel puis une référence saisie manuellement. Aucun paiement n’est déclenché par l’estimateur.

Barème intégré : avril à décembre **2026**, sources consultées le **8 novembre 2026**. À compter du 1er janvier 2027, le calcul se bloque et renvoie vers le simulateur officiel jusqu’à mise à jour du barème dans `lib/vehicle-estimate.ts`. Il n’y a pas de synchronisation automatique des barèmes.

Sources :

- [Barèmes régionaux 2026 — Service Public](https://www.service-public.gouv.fr/particuliers/actualites/A18021)
- [Coût et taxes du certificat — Service Public](https://www.service-public.gouv.fr/particuliers/vosdroits/F19211)
- [Simulateur officiel complet](https://www.service-public.gouv.fr/simulateur/calcul/cout-certificat-immatriculation)
- [Taxe régionale et réduction d’ancienneté — Légifrance](https://www.legifrance.gouv.fr/codes/section_lc/LEGITEXT000044595989/LEGISCTA000044599003/2026-09-01)

## Déploiement et démonstration

Appliquer les **13 migrations**, puis le seed. Sur Render, le démarrage existant effectue ces étapes. Aucun nouvel abonnement ni nouvelle clé externe n’est nécessaire pour cette fonctionnalité.

Le lien Sites reste une démonstration statique : ses comptes clients sont stockés dans le navigateur et ses identifiants ne sont pas des accès réels. Les connexions et les comptes partagés nécessitent la version Node reliée à PostgreSQL, comme décrit dans `FREE-HOSTING.md`. Aucun compte de production, mot de passe client ou tarif individuel réel n’a été créé pendant les tests.

## Accès WhatsApp indépendant

Un administrateur peut autoriser un numéro/groupe vérifié sur un compte actif et tarifé. Cet accès indépendant permet de déposer sans passer par le site ; il ne supprime pas le changement du mot de passe temporaire lors de la première connexion Web. Voir WHATSAPP.md.
