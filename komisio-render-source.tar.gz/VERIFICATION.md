# Vérification de la livraison — 8 novembre 2026

## Résultats

- TypeScript frontend, serveur et tests : valide.
- `npm run test:integration` : **132 tests applicatifs réussis, 0 échec, 0 ignoré**, PostgreSQL 16 jetable, quatorze migrations appliquées et catalogue de 36 prestations initialisé.
- Parcours HTTP exécutés avec un vrai serveur Next : connexion Telegram signée, refus des accès non autorisés, crédits idempotents, paiement portefeuille, pièces privées, demande de document complémentaire, livrable final, devis accepté puis payé, annulation/remboursement unique, webhook crypto signé/dédupliqué, récupération d’une facture ambiguë, retrait avec frais et envoi manuel, notifications, support aller/retour et reprise auditée.
- Construction Next standalone et `build:render` : réussie. Démarrage réel via `start:render` avec PostgreSQL jetable : quatorze migrations, 36 services, stockage privé, endpoint de santé et worker opérationnels. Connexion par mot de passe sur le serveur de production, cookie HttpOnly/Secure/Partitioned, catalogue personnalisé et profils sans hachage vérifiés.
- Génération de `.env.production` : fichier privé 0600, secrets distincts et refus d’écrasement. Validation des fichiers Compose et de la variante HTTPS : réussie.
- Export de démonstration : construit. Catalogue, guide Komi, formulaires et admin vérifiés en clair/sombre à 320, 390 et 1440 px, sans débordement horizontal.

## Limites de la recette

Les tests financiers et Telegram utilisent des simulateurs HTTP locaux, interdits en production. Ils ne constituent pas une transaction réelle ni une vérification des comptes externes. Le contrôle du démarrage utilise des identités et des clés fictives locales ; aucune communication réelle avec Telegram, Plisio, Supabase ou NOWPayments n’est déclenchée.

Aucun hébergement Node/PostgreSQL permanent ni bot/token/compte marchand de production n’est encore configuré. Le site Sites public conserve sa démonstration, sans paiement ou retrait réel. Le déploiement réel et une petite transaction de recette sur les comptes de l’exploitant restent à effectuer selon DEPLOYMENT.md.

Les retraits V1 peuvent être envoyés par l’API Plisio après acceptation des frais par le revendeur et déclenchement admin. Le serveur conserve la réserve après une réponse inconnue et ne répète pas automatiquement l’envoi. Le parcours manuel reste disponible pour la réconciliation. Le code ne détient aucune clé privée blockchain. La livraison de la prestation administrative elle-même reste réalisée par l’équipe et les organismes compétents.


## Plisio et hébergement gratuit

Les nouveaux tests couvrent les factures standard sans White Label, le callback JSON SHA-1, la correspondance EUR/réseau/montant, les doublons et réponses perdues, les frais et envois Plisio concurrents, l’augmentation des frais, les confirmations et la vérification d’opérations API moins détaillées. Le stockage Supabase est testé avec refus des accès publics, et une transaction sous rôle SQL anonyme confirme que RLS masque les comptes métier. Le bot est raccordable depuis l’admin sans Shell Render payant. Render/Supabase restent à créer et à configurer sur les comptes du titulaire.

Le démarrage Render a été revérifié avec `RENDER_EXTERNAL_URL` sans APP_URL explicite : configuration, quatorze migrations, seed, endpoint de santé, stockage et worker opérationnels. Le Blueprint a été validé comme un unique service Node Free, sans base ni worker Render payants. Les plafonds et mises en veille des offres sont documentés dans FREE-HOSTING.md.


## Accès clients et tarifs individuels

La suite comprend les parcours réels HTTP suivants : inscription Telegram inconnue refusée, création admin d’un brouillon, activation avec identifiants uniques, changement du mot de passe temporaire obligatoire, séparation des tarifs entre clients, refus de l’auto-attribution des droits admin, rattachement Telegram signé, mots de passe hachés et absents des profils/journaux, suspension/réinitialisation invalidant les anciennes sessions, limites de tentatives persistantes et origine contrôlée.

Les essais financiers vérifient le tarif personnel au débit portefeuille et dans la facture Plisio, les règles de remise et de minimum, la conservation d’un instantané malgré une nouvelle grille et le refus d’un prix devenu obsolète avant tout débit. L’estimateur gratuit est testé avec barèmes, ancienneté, dates invalides, expiration du millésime, recalcul serveur et source dans l’audit du devis.

Les nouveaux écrans admin ont été exercés à 320 px clair, 390 px sombre et 1440 px clair/sombre : création, prix, génération d’accès fictifs, suspension, réouverture de la grille et ajustement du portefeuille. Les écrans de connexion et changement obligatoire de mot de passe ont été vérifiés à 320/390/1440 px avec réponses API simulées dans Chromium ; les API correspondantes sont également testées séparément via HTTP réel avec PostgreSQL. Aucun débordement horizontal relevé. Les captures ont permis de corriger un libellé trop long dans la grille à 320 px.

Aucun accès client réel n’a été remis. Les identifiants de la démonstration statique ne sont pas utilisables pour se connecter à une production. Procédure et limites de l’estimation : CLIENT-ACCESS.md.


## WhatsApp Web, OCR et estimateur d’accueil

- 132 tests applicatifs sur six bases PostgreSQL isolées, dont des parcours HTTP réels de webhook signé, mauvais groupe/expéditeur, compte WhatsApp indépendant, OCR local réel d’une photo fictive, pièces privées, correction des champs, récapitulatif trop long refusé, devis et facture Plisio demandée explicitement, livrable envoyé au groupe rattaché, résultat d’envoi inconnu bloqué et rattachement désactivé.
- 7 tests supplémentaires du pont, sans compte WhatsApp : identité JID/LID, authentification, destinataire exact, refus de télécharger une pièce hors allowlist, limites, FIFO, persistance et déduplication d’envoi, réponse inconnue, état/QR protégés. Import réel de whatsapp-web.js 1.34.7 et présence du résolveur LID vérifiés sans initialiser un client.
- OCR réel Tesseract et extraction PDF Poppler exécutés localement, sur fixtures fictives. Pas d’API OCR payante, pas de documents utilisateur, pas d’IA distante.
- Démarrage Node de production revérifié avec PostgreSQL, 14 migrations, 36 services, worker et stockage privé. Build `build:render` réussi. La configuration Compose avec le pont privé et volume de session est valide.
- La construction Docker complète a rencontré la limite de disque du conteneur de travail avant de terminer. Les caches temporaires du build ont été libérés. La construction de ces images devra être terminée sur l’hôte cible ; elle n’est pas déclarée validée ici.
- Chromium à 320 px clair, 390 px sombre et 1440 px clair : estimateur trois champs, référence 271,76 € et exemple commercial 135,88 €, remise à zéro, assistance WhatsApp non configurée, brouillon fictif corrigé/revu/confirmé, rattachement d’un groupe et désactivation. Aucun QR de démonstration ne simule une connexion réelle. Pas de débordement horizontal.

L’application publique Sites reste statique. Le serveur et le pont doivent être hébergés, le numéro d’assistance renseigné et le QR scanné par le propriétaire avant tout échange réel. Aucune session WhatsApp n’a été ouverte, aucun message externe ni paiement réel envoyé. Box Simular a été examiné via sa documentation publique : la mise en veille exclut une promesse de bot 24 h/24.
