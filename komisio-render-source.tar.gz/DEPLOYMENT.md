# Mettre Komisio en service

**Option gratuite préparée : [Render + Supabase](./FREE-HOSTING.md).** Les instructions ci-dessous restent adaptées à un serveur Docker que vous gérez. Le fournisseur principal est désormais Plisio ; voir [PLISIO.md](./PLISIO.md).

L’URL Sites actuelle héberge la démonstration statique. Le code de production ci-joint utilise Next.js Node, Prisma, PostgreSQL et un volume de documents privé. Il se déploie sur un serveur Docker ou un hébergement Node avec PostgreSQL et stockage persistant. Les clés de production n’ont pas encore été fournies ; aucune recette locale ne prouve que les comptes externes sont raccordés.

## Comptes nécessaires

- Un serveur Docker avec un domaine pointant vers son adresse (ports 80/443 ouverts), ou un hébergement Node équivalent.
- Un bot BotFather : token, nom public et identifiants Telegram numériques des administrateurs. Chaque destinataire doit envoyer `/start` au bot pour recevoir ses notifications.
- Un compte marchand Plisio : clé API, devises/réseaux et autorisations Request IP configurés. Vérifier les minimums du fournisseur pour USDT TRC20/ERC20, BTC, ETH et SOL.

Ne mettez aucun secret dans Git, le navigateur, une capture ou une conversation publique. `.env.production` est ignoré par Git et Docker.

## Installation sur un serveur Docker

1. Récupérez le dépôt puis lancez `npm run deploy:init` (Node 22+). Le générateur crée des secrets distincts et refuse d’écraser un fichier existant.
2. Complétez `.env.production` dans un éditeur privé : `KOMISIO_DOMAIN`, `APP_URL` et `MINI_APP_URL` avec votre domaine HTTPS ; bot, nom sans `@`, administrateurs, clé Plisio avec `PAYMENT_PROVIDER=PLISIO`. Conservez le mot de passe PostgreSQL généré (hexadécimal pour une URL sans ambiguïté).
3. Démarrez :

```sh
docker compose --env-file .env.production -f compose.yaml -f compose.https.yaml up -d --build
```

Le service `migrate` vérifie la configuration, applique les migrations et crée les services manquants sans réinitialiser les tarifs personnalisés. L’application démarre ensuite avec un utilisateur non root. PostgreSQL et les documents utilisent deux volumes persistants ; PostgreSQL n’a pas de port public. Caddy gère le certificat HTTPS. Le service notifications reprend la file toutes les 30 secondes. Vérifiez `docker compose --env-file .env.production ps` et `https://VOTRE-DOMAINE/api/health` : réponse attendue `{"status":"ok"}`.

Dans un environnement de développement avec proxy de session, fournir le certificat CA au build avec `--secret id=proxy_ca,src=...`. Le Dockerfile accepte ce montage sans le conserver dans l’image. Sur un serveur classique, aucun secret de build n’est nécessaire.

4. Raccordez le bot après disponibilité HTTPS :

```sh
docker compose --env-file .env.production run --rm migrate npm run telegram:setup
```

La commande vérifie l’identité du bot, crée le bouton de menu WebApp et enregistre `/api/bot` avec son secret Telegram. Elle n’envoie pas de message aux revendeurs. Paramétrez également le domaine de la Mini App dans BotFather si demandé. Envoyez `/start` dans le bot, ouvrez la Mini App puis testez le rôle admin depuis un identifiant autorisé.

5. Plisio reçoit automatiquement `APP_URL/api/webhooks/plisio?json=true` lors de la création de facture. Vérifiez la clé et les réseaux du compte ; autorisez l’adresse de sortie de l’hébergement dans Request IP. Effectuez une petite recharge et un retrait de recette avant l’ouverture générale. Ces opérations réelles n’ont pas été effectuées ici.

## Assistance Telegram

Le bouton d’assistance ouvre le bot. Le message d’un revendeur connecté est relayé aux administrateurs via la file persistante. Un administrateur autorisé répond avec `/reply IDENTIFIANT_TELEGRAM message`. Les réponses sont relayées au revendeur et les mises en file sont dédupliquées par identifiant de mise à jour Telegram. Les documents restent à joindre dans la Mini App.

## Retraits

V1 : demandes à toute heure, calcul des frais et du taux via Plisio, acceptation du revendeur, réserve atomique, envoi déclenché par l’admin via l’API puis confirmation. Activez `WITHDRAWALS_ENABLED=true` et `PLISIO_PAYOUTS_ENABLED=true` après validation du compte, de Request IP et de la réserve USDT TRC20. L’envoi manuel reste disponible pour les opérations hors Plisio. Voir PLISIO.md et WITHDRAWALS.md.

## Exploitation

La vue d’ensemble admin comprend l’état de configuration, la file de notifications et les factures bloquées en création. Pour une facture dont la réponse de création a été perdue, retrouvez `order_id=Payment.id` dans NOWPayments, puis utilisez « Vérifier et rattacher ». Le serveur vérifie la référence, le prix, la devise et le montant crypto auprès du fournisseur, journalise le rattachement puis réconcilie le paiement. Il ne crée pas une nouvelle facture pour résoudre une réponse perdue.

L’admin peut relancer les notifications épuisées. Les erreurs et reprises sont historisées. `/api/health` vérifie configuration, connexion SQL et écriture privée sans divulguer de secret ni information client.

Sauvegardez **ensemble** PostgreSQL et les fichiers privés. Exemple de sauvegarde SQL, exécuté sur le serveur dans un répertoire privé :

```sh
umask 077
docker compose --env-file .env.production exec -T postgres pg_dump -U komisio -d komisio -Fc > komisio-backup.dump
```

Sauvegardez aussi le volume `komisio_uploads` avec les outils de sauvegarde de votre hébergeur. Testez une restauration sur une base séparée ; n’utilisez jamais `docker compose down -v` en production. Après une mise à jour, recréez les services avec la même commande `up -d --build` et vérifiez l’état de `migrate`.

## Vérifications reproductibles

- `npm run typecheck` : contrats TypeScript, frontend et serveur.
- `npm test` : tests sans services ; les suites PostgreSQL sont ignorées si leurs bases de test explicites ne sont pas configurées.
- `npm run test:integration` : crée un PostgreSQL Docker jetable sur une adresse locale, migre et initialise cinq bases isolées, teste les transactions concurrentes et lance un vrai serveur Next avec simulateurs HTTP locaux Telegram, Plisio, Supabase et ancien NOWPayments. Aucun envoi externe, aucune facture réelle et aucun paiement réel. Supprime les bases et fichiers fictifs après le test.
- `npm run build` : produit l’application Node standalone.

Les options des simulateurs sont explicitement limitées à un processus local de test et rejetées en production. Elles ne doivent jamais figurer dans votre configuration d’hébergement.

## Comptes provisionnés

L’inscription publique via Telegram est fermée. Le premier admin est reconnu par `ADMIN_TELEGRAM_IDS`, puis crée les comptes et tarifs dans **Admin → Clients & tarifs**. Voir [CLIENT-ACCESS.md](./CLIENT-ACCESS.md).

## Numéro WhatsApp ordinaire

Voir [WHATSAPP.md](./WHATSAPP.md) et [whatsapp-bridge/README.md](./whatsapp-bridge/README.md). Le complément `compose.whatsapp.yaml` ajoute le pont QR privé et active l’OCR natif. Il faut une machine qui reste allumée et un volume persistant ; aucun numéro réel n’est connecté dans la livraison.
